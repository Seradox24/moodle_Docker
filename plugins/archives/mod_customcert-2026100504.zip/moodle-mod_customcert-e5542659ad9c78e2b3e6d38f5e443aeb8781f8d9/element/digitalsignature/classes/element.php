<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains the customcert element digitial signature's core interaction API.
 *
 * @package    customcertelement_digitalsignature
 * @copyright  2017 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace customcertelement_digitalsignature;

use context_course;
use context_system;
use core_collator;
use mod_customcert\service\form_service;
use mod_customcert\element_helper;
use mod_customcert\service\element_renderer;
use MoodleQuickForm;
use pdf;
use stdClass;
use stored_file;
use customcertelement_digitalsignature\digitalsignature_payload;

/**
 * The customcert element digital signature's core interaction API.
 *
 * @package    customcertelement_digitalsignature
 * @copyright  2017 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class element extends \customcertelement_image\element {
    /**
     * @var array The file manager options for the certificate.
     */
    protected array $signaturefilemanageroptions = [];

    /**
     * Constructor.
     *
     * @param stdClass $element the element data
     */
    public function __construct($element) {
        global $COURSE;

        $this->signaturefilemanageroptions = [
            'maxbytes' => $COURSE->maxbytes,
            'subdirs' => 1,
            'accepted_types' => ['.crt'],
        ];

        parent::__construct($element);
    }

    /**
     * Render the element in html for preview positioning.
     *
     * @param element_renderer|null $renderer
     * @return string
     */
    public function render_html(?element_renderer $renderer = null): string {
        if ($renderer) {
            return (string)$renderer->render_content($this, '');
        }
        return '';
    }

    /**
     * Build the configuration form for this element.
     *
     * @param MoodleQuickForm $mform
     * @return void
     */
    public function build_form(MoodleQuickForm $mform): void {
        $mform->addElement('select', 'fileid', get_string('image', 'customcertelement_image'), self::get_images());

        $mform->addElement(
            'select',
            'signaturefileid',
            get_string('digitalsignature', 'customcertelement_digitalsignature'),
            self::get_signatures()
        );

        $mform->addElement('text', 'signaturename', get_string('signaturename', 'customcertelement_digitalsignature'));
        $mform->setType('signaturename', PARAM_TEXT);
        $mform->setDefault('signaturename', '');

        $mform->addElement(
            'passwordunmask',
            'signaturepassword',
            get_string('signaturepassword', 'customcertelement_digitalsignature')
        );
        $mform->setType('signaturepassword', PARAM_TEXT);
        $mform->setDefault('signaturepassword', '');

        $mform->addElement('text', 'signaturelocation', get_string('signaturelocation', 'customcertelement_digitalsignature'));
        $mform->setType('signaturelocation', PARAM_TEXT);
        $mform->setDefault('signaturelocation', '');

        $mform->addElement('text', 'signaturereason', get_string('signaturereason', 'customcertelement_digitalsignature'));
        $mform->setType('signaturereason', PARAM_TEXT);
        $mform->setDefault('signaturereason', '');

        $mform->addElement(
            'text',
            'signaturecontactinfo',
            get_string('signaturecontactinfo', 'customcertelement_digitalsignature')
        );
        $mform->setType('signaturecontactinfo', PARAM_TEXT);
        $mform->setDefault('signaturecontactinfo', '');

        element_helper::render_form_element_width($mform);
        element_helper::render_form_element_height($mform);

        if (get_config('customcert', 'showposxy')) {
            element_helper::render_form_element_position($mform);
        }

        $mform->addElement(
            'filemanager',
            'customcertimage',
            get_string('uploadimage', 'customcert'),
            '',
            $this->filemanageroptions
        );

        $mform->addElement(
            'filemanager',
            'digitalsignature',
            get_string('uploaddigitalsignature', 'customcertelement_digitalsignature'),
            '',
            $this->signaturefilemanageroptions
        );
    }

    /**
     * Prepare form defaults and draft areas for the digital signature element.
     *
     * @param MoodleQuickForm $mform
     * @return void
     */
    public function prepare_form(MoodleQuickForm $mform): void {
        global $COURSE, $SITE;

        if (!empty($this->get_data())) {
            $payload = $this->get_payload();

            if (isset($payload['signaturename'])) {
                $mform->setDefault('signaturename', (string)$payload['signaturename']);
            }
            if (isset($payload['signaturelocation'])) {
                $mform->setDefault('signaturelocation', (string)$payload['signaturelocation']);
            }
            if (isset($payload['signaturereason'])) {
                $mform->setDefault('signaturereason', (string)$payload['signaturereason']);
            }
            if (isset($payload['signaturecontactinfo'])) {
                $mform->setDefault('signaturecontactinfo', (string)$payload['signaturecontactinfo']);
            }

            if (!empty($payload['signaturefilename'])) {
                if ($signaturefile = $this->get_signature_file()) {
                    $mform->setDefault('signaturefileid', $signaturefile->get_id());
                }
            }

            if (
                isset(
                    $payload['contextid'],
                    $payload['filearea'],
                    $payload['itemid'],
                    $payload['filepath'],
                    $payload['filename']
                )
            ) {
                if ($file = $this->get_file()) {
                    $mform->setDefault('fileid', $file->get_id());
                }
            }

            // Populate size controls via defaults so they survive set_data lifecycle.
            if (isset($payload['width'])) {
                $mform->setDefault('width', (int)$payload['width']);
            }
            if (isset($payload['height'])) {
                $mform->setDefault('height', (int)$payload['height']);
            }
        }

        // Prepare the draft areas for the uploaders so previously uploaded files show up.
        if ($COURSE->id == $SITE->id) {
            $context = \context_system::instance();
        } else {
            $context = \context_course::instance($COURSE->id);
        }

        $draftitemid = file_get_submitted_draft_itemid('customcertimage');
        file_prepare_draft_area($draftitemid, $context->id, 'mod_customcert', 'image', 0, $this->filemanageroptions);
        $mform->getElement('customcertimage')->setValue($draftitemid);

        $draftitemid = file_get_submitted_draft_itemid('digitalsignature');
        file_prepare_draft_area($draftitemid, $context->id, 'mod_customcert', 'signature', 0, $this->signaturefilemanageroptions);
        $mform->getElement('digitalsignature')->setValue($draftitemid);
    }

    /**
     * Returns the configured width for this element from JSON data.
     *
     * @return int|null
     */
    public function get_width(): ?int {
        $payload = $this->get_payload();
        if (empty($payload)) {
            return null;
        }
        return isset($payload['width']) && $payload['width'] !== '' ? (int)$payload['width'] : null;
    }

    /**
     * Returns the configured height for this element from JSON data.
     *
     * @return int|null
     */
    public function get_height(): ?int {
        $payload = $this->get_payload();
        if (empty($payload)) {
            return null;
        }
        return isset($payload['height']) && $payload['height'] !== '' ? (int)$payload['height'] : null;
    }

    /**
     * Normalise digital signature element data.
     *
     * @param stdClass $formdata Form submission data
     * @return array JSON-serialisable payload
     */
    public function normalise_data(stdClass $formdata): array {
        global $COURSE, $SITE;

        if ($COURSE->id == $SITE->id) {
            $context = \context_system::instance();
        } else {
            $context = \context_course::instance($COURSE->id);
        }

        if (isset($formdata->customcertimage)) {
            form_service::upload_files($formdata->customcertimage, $context->id);
        }

        if (isset($formdata->digitalsignature)) {
            form_service::upload_files($formdata->digitalsignature, $context->id, 'signature');
        }

        $arrtostore = [
            'signaturename' => $formdata->signaturename ?? '',
            'signaturepassword' => $this->resolve_password((string)($formdata->signaturepassword ?? '')),
            'signaturelocation' => $formdata->signaturelocation ?? '',
            'signaturereason' => $formdata->signaturereason ?? '',
            'signaturecontactinfo' => $formdata->signaturecontactinfo ?? '',
            'width' => !empty($formdata->width) ? (int) $formdata->width : 0,
            'height' => !empty($formdata->height) ? (int) $formdata->height : 0,
        ];

        $fs = get_file_storage();

        if (!empty($formdata->fileid) && array_key_exists((int)$formdata->fileid, self::get_images())) {
            if ($file = $fs->get_file_by_id($formdata->fileid)) {
                $arrtostore += [
                    'contextid' => $file->get_contextid(),
                    'filearea' => $file->get_filearea(),
                    'itemid' => $file->get_itemid(),
                    'filepath' => $file->get_filepath(),
                    'filename' => $file->get_filename(),
                ];
            }
        }

        if (!empty($formdata->signaturefileid) && array_key_exists((int)$formdata->signaturefileid, self::get_signatures())) {
            if ($signaturefile = $fs->get_file_by_id($formdata->signaturefileid)) {
                $arrtostore += [
                    'signaturecontextid' => $signaturefile->get_contextid(),
                    'signaturefilearea' => $signaturefile->get_filearea(),
                    'signatureitemid' => $signaturefile->get_itemid(),
                    'signaturefilepath' => $signaturefile->get_filepath(),
                    'signaturefilename' => $signaturefile->get_filename(),
                ];
            }
        }

        return digitalsignature_payload::from_array($arrtostore)->to_array();
    }

    /**
     * Handles rendering the element on the pdf.
     *
     * @param pdf $pdf the pdf object
     * @param bool $preview true if it is a preview, false otherwise
     * @param stdClass $user the user we are rendering this for
     * @param element_renderer|null $renderer the renderer service
     */
    public function render(pdf $pdf, bool $preview, stdClass $user, ?element_renderer $renderer = null): void {
        if (empty($this->get_data())) {
            return;
        }

        $payload = $this->get_payload();

        // Render the visual image, if one is configured. This is optional and independent
        // of whether the cryptographic signature below gets applied.
        if (!empty($payload['filename']) && ($file = $this->get_file())) {
            $location = make_request_directory() . '/target';
            $file->copy_content_to($location);

            $mimetype = $file->get_mimetype();
            if ($mimetype == 'image/svg+xml') {
                $pdf->ImageSVG($location, $this->get_posx(), $this->get_posy(), (int)$payload['width'], (int)$payload['height']);
            } else {
                $pdf->Image($location, $this->get_posx(), $this->get_posy(), (int)$payload['width'], (int)$payload['height']);
            }
        }

        // If there is no signature file, there is nothing to cryptographically sign.
        if (empty($payload['signaturefilename'])) {
            return;
        }

        if ($signaturefile = $this->get_signature_file()) {
            $location = make_request_directory() . '/target';
            $signaturefile->copy_content_to($location);
            $info = [
                'Name' => (string)($payload['signaturename'] ?? ''),
                'Location' => (string)($payload['signaturelocation'] ?? ''),
                'Reason' => (string)($payload['signaturereason'] ?? ''),
                'ContactInfo' => (string)($payload['signaturecontactinfo'] ?? ''),
            ];
            // Decrypt the stored password before passing it to the PDF signing library.
            $encryptedpassword = (string)($payload['signaturepassword'] ?? '');
            $signaturepassword = $encryptedpassword !== '' ? \core\encryption::decrypt($encryptedpassword) : '';
            $pdf->setSignature('file://' . $location, '', $signaturepassword, '', 2, $info);
            $pdf->setSignatureAppearance($this->get_posx(), $this->get_posy(), (int)$payload['width'], (int)$payload['height']);
        }
    }

    /**
     * Return the list of possible digital signature files to use.
     *
     * @return array the list of signature files that can be used
     */
    public static function get_signatures() {
        global $COURSE;

        $fs = get_file_storage();

        $arrfiles = [];
        if (
            $files = $fs->get_area_files(
                context_system::instance()->id,
                'mod_customcert',
                'signature',
                false,
                'filename',
                false
            )
        ) {
            foreach ($files as $hash => $file) {
                $arrfiles[$file->get_id()] = $file->get_filename();
            }
        }
        if (
            $files = $fs->get_area_files(
                context_course::instance($COURSE->id)->id,
                'mod_customcert',
                'signature',
                false,
                'filename',
                false
            )
        ) {
            foreach ($files as $hash => $file) {
                $arrfiles[$file->get_id()] = $file->get_filename();
            }
        }

        core_collator::asort($arrfiles);
        $arrfiles = ['0' => get_string('nosignature', 'customcertelement_digitalsignature')] + $arrfiles;

        return $arrfiles;
    }

    /**
     * Normalises a signaturepassword value recovered from a backup for safe storage.
     *
     * Four cases are handled:
     *  - Empty/missing password: returned as-is (empty string).
     *  - Recognisable Moodle ciphertext (starts with the Sodium method prefix) that decrypts
     *    successfully on this site: preserved as-is (already encrypted with this site's key).
     *  - Recognisable Moodle ciphertext that cannot be decrypted on this site (foreign-site
     *    key): cleared to empty string so the administrator must re-enter it.
     *  - Anything else (legacy plaintext, including plaintext containing a colon such as
     *    "secret:1234"): encrypted with this site's key and returned.
     *
     * @param string $value The raw signaturepassword value from the backup.
     * @return string The normalised value safe to store in customcert_elements.data.
     */
    public static function normalise_restore_password(string $value): string {
        if ($value === '') {
            return '';
        }
        // Detect Moodle ciphertext by its method prefix. A generic "<word>:" heuristic would
        // misclassify legitimate plaintext passwords such as "secret:1234", so only the
        // encryption method(s) this site's core encryption API actually supports are checked.
        if (str_starts_with($value, \core\encryption::METHOD_SODIUM . ':')) {
            // Looks like Moodle-encrypted data. Try to decrypt with this site's key.
            try {
                \core\encryption::decrypt($value);
                // Decryption succeeded — preserve the existing ciphertext.
                return $value;
            } catch (\moodle_exception $e) {
                // Cannot decrypt: foreign-site ciphertext. Clear it rather than
                // double-encrypting the ciphertext as if it were plaintext.
                return '';
            }
        }
        // Legacy plaintext password — encrypt with this site's key.
        return \core\encryption::encrypt($value);
    }

    /**
     * Returns the password to store: the submitted value when non-empty, otherwise the
     * previously stored password so that leaving the field blank on edit does not erase it.
     *
     * @param string $submitted The value submitted via the form password field.
     * @return string
     */
    private function resolve_password(string $submitted): string {
        if ($submitted !== '') {
            // A new password was supplied — encrypt it before storing.
            return \core\encryption::encrypt($submitted);
        }
        // No new password — keep whatever is already stored (already encrypted or empty).
        $payload = $this->get_payload();
        return (string)($payload['signaturepassword'] ?? '');
    }

    /**
     * Fetch stored file.
     *
     * @return stored_file|bool stored_file instance if exists, false if not
     */
    public function get_signature_file() {
        $payload = $this->get_payload();

        $fs = get_file_storage();

        return $fs->get_file(
            (int)$payload['signaturecontextid'],
            'mod_customcert',
            (string)$payload['signaturefilearea'],
            (int)$payload['signatureitemid'],
            (string)$payload['signaturefilepath'],
            (string)$payload['signaturefilename']
        );
    }

    /**
     * {@inheritdoc}
     *
     * @return bool
     */
    public function has_save_and_continue(): bool {
        return true;
    }
}
