<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This is the external API for this tool.
 *
 * @package    mod_customcert
 * @copyright  2016 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace mod_customcert;

use context_module;
use context_system;
use invalid_parameter_exception;
use moodle_exception;
use core_external\external_api;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use core_external\external_function_parameters;
use core_user\fields;
use mod_customcert\event\issue_deleted;
use mod_customcert\service\certificate_repository;
use mod_customcert\service\element_factory;
use mod_customcert\service\element_layout;
use mod_customcert\service\element_repository;
use mod_customcert\service\form_service;
use mod_customcert\service\issue_repository;
use mod_customcert\service\pdf_generation_service;
use mod_customcert\service\persistence_helper;
use mod_customcert\service\template_repository;
use stdClass;
use Throwable;

/**
 * This is the external API for this tool.
 *
 * @copyright  2016 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class external extends external_api {
    /**
     * Returns the save_element() parameters.
     *
     * @return external_function_parameters
     */
    public static function save_element_parameters() {
        return new external_function_parameters(
            [
                'templateid' => new external_value(PARAM_INT, 'The template id'),
                'elementid' => new external_value(PARAM_INT, 'The element id'),
                'values' => new external_multiple_structure(
                    new external_single_structure(
                        [
                            'name' => new external_value(PARAM_ALPHANUMEXT, 'The field to update'),
                            'value' => new external_value(PARAM_RAW, 'The value of the field'),
                        ]
                    )
                ),
            ]
        );
    }

    /**
     * Handles saving element data.
     *
     * Returns the generic layout properties that the rearranger keeps in React state so the
     * interactive editor can refresh without a full page reload. Values are read from the
     * saved element/layout (not from element-type-specific fields).
     *
     * @param int $templateid The template id.
     * @param int $elementid The element id.
     * @param array $values The values to save
     * @return array{id: int, posx: int, posy: int, width: ?int, refpoint: int, alignment: string, html: string}
     */
    public static function save_element($templateid, $elementid, $values) {
        global $USER;

        $params = [
            'templateid' => $templateid,
            'elementid' => $elementid,
            'values' => $values,
        ];
        self::validate_parameters(self::save_element_parameters(), $params);

        $templaterepo = new template_repository();
        $template = template::from_record($templaterepo->get_by_id_or_fail((int)$templateid));

        if ($cm = $template->get_cm()) {
            self::validate_context(context_module::instance($cm->id));
        } else {
            self::validate_context(context_system::instance());
        }
        $template->require_manage();

        // Load the element, verifying it belongs to the authorised template.
        $elementrepo = new element_repository(element_factory::build_with_defaults());
        $element = $elementrepo->get_for_template_or_fail((int)$templateid, (int)$elementid);

        // These fields identify the element and are managed by the server. They must never
        // be overwritten by client-supplied values, otherwise the authorisation performed
        // above (against $element) could be bypassed by mutating the record afterwards.
        $protectedfields = [
            'id' => true,
            'pageid' => true,
            'element' => true,
            'sequence' => true,
            'timecreated' => true,
            'timemodified' => true,
        ];

        // Submit the values through the element edit form so the same select-option filtering
        // and validation as edit_element.php is applied.
        $submission = self::get_form_submission($element);
        foreach ($values as $value) {
            $field = $value['name'];
            if (isset($protectedfields[$field])) {
                throw new invalid_parameter_exception('Field is not allowed to be updated: ' . $field);
            }
            $submission[$field] = $value['value'];
        }

        $factory = element_factory::build_with_defaults();
        $formid = preg_replace('/[^a-z0-9_]/i', '_', edit_element_form::class);
        $submission['_qf__' . $formid] = 1;
        // The web service request is already authenticated, so skip the form's own sesskey check.
        $ignoresesskey = $USER->ignoresesskey ?? null;
        $USER->ignoresesskey = true;
        try {
            $mform = new edit_element_form(
                null,
                ['element' => $element, 'factory' => $factory],
                'post',
                '',
                null,
                true,
                $submission
            );
        } finally {
            if ($ignoresesskey === null) {
                unset($USER->ignoresesskey);
            } else {
                $USER->ignoresesskey = $ignoresesskey;
            }
        }
        if (!$mform->is_validated() || !($data = $mform->get_data())) {
            throw new invalid_parameter_exception('Invalid element values');
        }

        // Only the validated form data is persisted; identity always comes from the authorised element.
        $data->id = (int)$element->id;
        $data->pageid = (int)$element->pageid;
        $data->element = (string)$element->element;

        $dataarray = (array)$data;
        (new form_service())->normalise_submission($dataarray);
        $data = (object)$dataarray;

        $instance = $factory->create_from_record($data);
        if (!$instance) {
            throw new moodle_exception('invalidelementtype', 'customcert');
        }

        $record = (object)[
            'id' => (int)$element->id,
            'pageid' => (int)$element->pageid,
            'element' => (string)$element->element,
            'name' => $data->name,
            'posx' => $data->posx ?? $element->posx,
            'posy' => $data->posy ?? $element->posy,
            'refpoint' => $data->refpoint ?? $element->refpoint,
            'alignment' => $data->alignment ?? $element->alignment,
            'sequence' => $element->sequence,
            'timecreated' => $element->timecreated,
            'timemodified' => $element->timemodified,
        ];
        $record->data = persistence_helper::to_json_data($instance, $data);

        $instance = $factory->create_from_record($record);
        $layout = element_layout::from_record($record);

        // Defence in depth: the instance about to be persisted must still match the
        // authorised element's identity.
        if (
            $instance->get_id() !== (int)$element->id ||
            $instance->get_pageid() !== (int)$element->pageid ||
            $instance->get_type() !== (string)$element->element
        ) {
            throw new invalid_parameter_exception('Element identity mismatch');
        }

        $elementrepo->save($instance, $layout);

        // Return generic layout + preview HTML for the rearranger (element-type agnostic).
        return [
            'id' => $instance->get_id(),
            'posx' => (int)($layout->posx ?? 0),
            'posy' => (int)($layout->posy ?? 0),
            'width' => $instance->get_width(),
            'refpoint' => (int)($layout->refpoint ?? 0),
            'alignment' => $layout->alignment,
            'html' => $instance->render_html(),
        ];
    }

    /**
     * Builds the base form submission from the stored element so omitted fields keep their values.
     *
     * @param stdClass $element The stored element record.
     * @return array
     */
    private static function get_form_submission(stdClass $element): array {
        $submission = [
            'name' => (string)$element->name,
            'posx' => $element->posx,
            'posy' => $element->posy,
            'refpoint' => $element->refpoint,
            'alignment' => $element->alignment,
        ];
        $payload = json_decode((string)($element->data ?? ''), true);
        if (is_array($payload)) {
            foreach ($payload as $key => $value) {
                if (is_scalar($value) && $value !== false) {
                    $submission[$key] = (string)$value;
                }
            }
        }

        return array_filter($submission, static fn($value) => $value !== null);
    }

    /**
     * Returns the save_element result value.
     *
     * @return external_single_structure
     */
    public static function save_element_returns() {
        return new external_single_structure(
            [
                'id' => new external_value(PARAM_INT, 'The element id'),
                'posx' => new external_value(PARAM_INT, 'X position in mm'),
                'posy' => new external_value(PARAM_INT, 'Y position in mm'),
                'width' => new external_value(PARAM_INT, 'Optional max width in mm', VALUE_REQUIRED, null, NULL_ALLOWED),
                'refpoint' => new external_value(PARAM_INT, 'Reference point'),
                'alignment' => new external_value(PARAM_ALPHA, 'Text alignment L, C, or R'),
                'html' => new external_value(PARAM_RAW, 'Server-rendered preview HTML'),
            ],
            'Updated generic layout properties for the saved element'
        );
    }

    /**
     * Returns get_element() parameters.
     *
     * @return external_function_parameters
     */
    public static function get_element_html_parameters() {
        return new external_function_parameters(
            [
                'templateid' => new external_value(PARAM_INT, 'The template id'),
                'elementid' => new external_value(PARAM_INT, 'The element id'),
            ]
        );
    }

    /**
     * Handles return the element's HTML.
     *
     * @param int $templateid The template id
     * @param int $elementid The element id.
     * @return string
     */
    public static function get_element_html($templateid, $elementid) {
        $params = [
            'templateid' => $templateid,
            'elementid' => $elementid,
        ];
        self::validate_parameters(self::get_element_html_parameters(), $params);

        $templaterepo = new template_repository();
        $template = template::from_record($templaterepo->get_by_id_or_fail((int)$templateid));

        if ($cm = $template->get_cm()) {
            self::validate_context(context_module::instance($cm->id));
        } else {
            self::validate_context(context_system::instance());
        }

        // Only users who can manage this template may fetch its element HTML.
        $template->require_manage();

        // Load the element, verifying it belongs to the authorised template.
        $elementrepo = new element_repository(element_factory::build_with_defaults());
        $element = $elementrepo->get_for_template_or_fail((int)$templateid, (int)$elementid);

        $factory = element_factory::build_with_defaults();
        if ($e = $factory->create_from_record($element)) {
            return $e->render_html();
        }

        return '';
    }

    /**
     * Returns the get_element result value.
     *
     * @return external_value
     */
    public static function get_element_html_returns() {
        return new external_value(PARAM_RAW, 'The HTML');
    }

    /**
     * Returns the delete_issue() parameters.
     *
     * @return external_function_parameters
     */
    public static function delete_issue_parameters() {
        return new external_function_parameters(
            [
                'certificateid' => new external_value(PARAM_INT, 'The certificate id'),
                'issueid' => new external_value(PARAM_INT, 'The issue id'),
            ]
        );
    }

    /**
     * Handles deleting a customcert issue.
     *
     * @param int $certificateid The certificate id.
     * @param int $issueid The issue id.
     * @return bool
     */
    public static function delete_issue($certificateid, $issueid) {
        $params = [
            'certificateid' => $certificateid,
            'issueid' => $issueid,
        ];
        self::validate_parameters(self::delete_issue_parameters(), $params);

        $certrepo = new certificate_repository();
        $issuerepo = new issue_repository();

        $certificate = $certrepo->get_by_id_or_fail((int)$certificateid);
        $issue = $issuerepo->get_by_id_or_fail((int)$issueid);

        if ((int)$issue->customcertid !== (int)$certificateid) {
            throw new moodle_exception('nopermissions', 'error', '', 'delete_issue');
        }

        $cm = get_coursemodule_from_instance('customcert', $certificate->id, 0, false, MUST_EXIST);

        $context = context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/customcert:manage', $context);

        $deleted = $issuerepo->delete((int)$issue->id);

        // Trigger event if deletion succeeded.
        if ($deleted) {
            $event = issue_deleted::create([
                'objectid' => $issue->id,
                'context' => $context,
                'relateduserid' => $issue->userid,
            ]);
            $event->trigger();
        }

        return $deleted;
    }

    /**
     * Returns the delete_issue result value.
     *
     * @return external_value
     */
    public static function delete_issue_returns() {
        return new external_value(PARAM_BOOL, 'True if successful, false otherwise');
    }

    /**
     * Returns list_issues parameters.
     *
     * @return external_function_parameters
     */
    public static function list_issues_parameters(): external_function_parameters {
        return new external_function_parameters(
            [
                'timecreatedfrom' => new external_value(
                    PARAM_INT,
                    'Timestamp. Returns items created after this date (included).',
                    VALUE_DEFAULT,
                    null
                ),
                'userid' => new external_value(
                    PARAM_INT,
                    'User id. Returns items for this user.',
                    VALUE_DEFAULT,
                    null
                ),
                'customcertid' => new external_value(
                    PARAM_INT,
                    'Customcert id. Returns items for this customcert.',
                    VALUE_DEFAULT,
                    null
                ),
                'includepdf' => new external_value(
                    PARAM_BOOL,
                    'Whether to include base64-encoded PDF content',
                    VALUE_DEFAULT,
                    false
                ),
                'limit' => new external_value(
                    PARAM_INT,
                    'Maximum number of results (default 100, max 500; max 20 when including PDFs)',
                    VALUE_DEFAULT,
                    100
                ),
                'offset' => new external_value(
                    PARAM_INT,
                    'Offset for results (default 0)',
                    VALUE_DEFAULT,
                    0
                ),
            ]
        );
    }

    /**
     * Returns array of issued certificates.
     *
     * @param ?int $timecreatedfrom Timestamp. Returns items created after this date (included).
     * @param ?int $userid User id. Returns items for this user.
     * @param ?int $customcertid Customcert id. Returns items for this customcert.
     * @param bool $includepdf Whether to include PDF contents
     * @param int $limit Maximum results (500 normally, 20 when including PDFs)
     * @param int $offset Offset for paging
     * @return array
     */
    public static function list_issues(
        ?int $timecreatedfrom = null,
        ?int $userid = null,
        ?int $customcertid = null,
        bool $includepdf = false,
        int $limit = 100,
        int $offset = 0
    ): array {
        global $DB;

        // Validate parameters based on declared external function structure.
        $params = self::validate_parameters(
            self::list_issues_parameters(),
            [
                'timecreatedfrom' => $timecreatedfrom,
                'userid' => $userid,
                'customcertid' => $customcertid,
                'includepdf' => $includepdf,
                'limit' => $limit,
                'offset' => $offset,
            ]
        );

        // Enforce safe boundaries.
        $timecreatedfrom = $params['timecreatedfrom'];
        $userid = $params['userid'];
        $customcertid = $params['customcertid'];
        $includepdf = !empty($params['includepdf']);

        // When including PDFs, we limit the number of issues to avoid resource exhaustion.
        $maxlimit = $includepdf ? 20 : 500;
        $limit = max(1, min($maxlimit, $params['limit']));
        $offset = max(0, $params['offset']);

        // Capability check.
        $context = context_system::instance();
        self::validate_context($context);
        require_capability('mod/customcert:viewallcertificates', $context);

        [$fullnamefields, $sqlparams] = fields::get_sql_fullname();
        $where = [];

        if (!empty($timecreatedfrom)) {
            $where[] = "ci.timecreated >= :timecreatedfrom";
            $sqlparams['timecreatedfrom'] = $timecreatedfrom;
        }
        if (!empty($userid)) {
            $where[] = "ci.userid = :userid";
            $sqlparams['userid'] = $userid;
        }
        if (!empty($customcertid)) {
            $where[] = "ci.customcertid = :customcertid";
            $sqlparams['customcertid'] = $customcertid;
        }

        $sql = "SELECT ci.*,
                   $fullnamefields AS fullname, u.username, u.email,
                   ct.id AS templateid, ct.name AS templatename, ct.contextid
              FROM {customcert_issues} ci
              JOIN {user} u ON u.id = ci.userid
              JOIN {customcert} c ON c.id = ci.customcertid
              JOIN {customcert_templates} ct ON ct.id = c.templateid";

        if ($where) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }

        $sql .= " ORDER BY ci.timecreated DESC";

        $records = $DB->get_records_sql($sql, $sqlparams, $offset, $limit);

        $output = [];

        $pdfservice = $includepdf ? pdf_generation_service::create() : null;
        $templaterepo = $includepdf ? new template_repository() : null;

        foreach ($records as $issue) {
            $pdfname = null;
            $pdfcontent = null;

            if ($includepdf) {
                try {
                    $template = template::from_record($templaterepo->get_by_id_or_fail((int)$issue->templateid));
                    $safe = str_replace(' ', '_', mb_strtolower($template->get_name()));

                    $pdfname = $safe . '_certificate.pdf';
                    $pdfcontent = base64_encode(
                        $pdfservice->generate_pdf($template, false, (int)$issue->userid, true)
                    );
                } catch (Throwable $e) {
                    // Leave PDF fields null on failure and log for developers.
                    debugging('Failed to generate PDF for list_issues: ' . $e->getMessage(), DEBUG_DEVELOPER);
                    $pdfname = null;
                    $pdfcontent = null;
                }
            }

            $output[] = [
                'issue' => [
                    'id' => $issue->id,
                    'customcertid' => $issue->customcertid,
                    'code' => $issue->code,
                    'emailed' => $issue->emailed,
                    'timecreated' => $issue->timecreated,
                ],
                'user' => [
                    'id' => $issue->userid,
                    'fullname' => $issue->fullname,
                    'username' => $issue->username,
                    'email' => $issue->email,
                ],
                'template' => [
                    'id' => $issue->templateid,
                    'name' => $issue->templatename,
                    'contextid' => $issue->contextid,
                ],
                'pdf' => [
                    'name' => $pdfname,
                    'content' => $pdfcontent,
                    'haspdf' => ($pdfcontent !== null),
                ],
            ];
        }

        return $output;
    }

    /**
     * Returns the list_issues result value.
     *
     * @return external_multiple_structure
     */
    public static function list_issues_returns(): external_multiple_structure {
        return new external_multiple_structure(
            new external_single_structure([
                'issue' => new external_single_structure([
                    'id' => new external_value(PARAM_INT, 'issue id'),
                    'customcertid' => new external_value(PARAM_INT, 'customcert id'),
                    'code' => new external_value(PARAM_TEXT, 'code'),
                    'emailed' => new external_value(PARAM_BOOL, 'emailed'),
                    'timecreated' => new external_value(PARAM_INT, 'time created'),
                ]),
                'user' => new external_single_structure([
                    'id' => new external_value(PARAM_INT, 'id of user'),
                    'fullname' => new external_value(PARAM_TEXT, 'fullname'),
                    'username' => new external_value(PARAM_TEXT, 'username'),
                    'email' => new external_value(PARAM_TEXT, 'email'),
                ]),
                'template' => new external_single_structure([
                    'id' => new external_value(PARAM_INT, 'template id'),
                    'name' => new external_value(PARAM_TEXT, 'template name'),
                    'contextid' => new external_value(PARAM_INT, 'context id'),
                ]),
                'pdf' => new external_single_structure([
                    'name' => new external_value(PARAM_TEXT, 'name', VALUE_OPTIONAL),
                    'content' => new external_value(PARAM_TEXT, 'base64 content', VALUE_OPTIONAL),
                    'haspdf' => new external_value(PARAM_BOOL, 'Whether PDF content was included'),
                ]),
            ])
        );
    }
}
