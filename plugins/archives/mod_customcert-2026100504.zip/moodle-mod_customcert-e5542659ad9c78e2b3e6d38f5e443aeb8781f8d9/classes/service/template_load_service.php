<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

declare(strict_types=1);

namespace mod_customcert\service;

use dml_exception;
use mod_customcert\service\element_factory;
use mod_customcert\service\template_service;
use mod_customcert\event\template_updated;
use mod_customcert\template;

/**
 * Service to replace an existing template's pages/elements with another template's content.
 *
 * @package    mod_customcert
 * @copyright  2026 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
final class template_load_service {
    /** @var template_repository */
    private template_repository $templates;

    /** @var template_service */
    private template_service $templateservice;

    /** @var page_repository */
    private page_repository $pages;

    /** @var element_repository */
    private element_repository $elements;

    /**
     * Create a new instance with default dependencies.
     *
     * @return self
     */
    public static function create(): self {
        return new self(
            new template_repository(),
            template_service::create(),
            new page_repository(),
            new element_repository(element_factory::build_with_defaults()),
        );
    }

    /**
     * Constructor.
     *
     * @param template_repository $templates
     * @param template_service $templateservice
     * @param page_repository $pages
     * @param element_repository $elements
     */
    public function __construct(
        template_repository $templates,
        template_service $templateservice,
        page_repository $pages,
        element_repository $elements,
    ) {
        $this->templates = $templates;
        $this->templateservice = $templateservice;
        $this->pages = $pages;
        $this->elements = $elements;
    }

    /**
     * Replace target pages and elements with an ordered copy of the source.
     * Enforce source access here for all callers; emit template_updated for non-system contexts.
     *
     * @param int $targetid Existing template to overwrite
     * @param int $sourceid Template to copy from
     * @return void
     * @throws dml_exception For database errors.
     */
    public function replace(int $targetid, int $sourceid): void {
        global $DB;

        $source = $this->templates->get_by_id_or_fail($sourceid);
        $sourcetemplate = template::from_record($source);

        $targetrecord = $this->templates->get_by_id_or_fail($targetid);
        $targettemplate = template::from_record($targetrecord);

        $targettemplate->require_manage();
        $sourcetemplate->require_use_as_source();

        $transaction = $DB->start_delegated_transaction();

        // Remove existing pages/elements on target via the service so that element
        // cleanup hooks, file deletions, and events are all fired correctly.
        $existingpages = $this->pages->list_by_template($targetid);
        foreach ($existingpages as $page) {
            $this->templateservice->delete_page($targettemplate, (int)$page->id, false);
        }

        // Copy pages and elements from source to target.
        $now = time();
        $sourcepages = $this->pages->list_by_template($sourceid);
        foreach ($sourcepages as $page) {
            $newpageid = $this->pages->create((object) [
                'templateid' => $targetid,
                'width' => $page->width,
                'height' => $page->height,
                'leftmargin' => $page->leftmargin,
                'rightmargin' => $page->rightmargin,
                'sequence' => $page->sequence,
                'timecreated' => $now,
                'timemodified' => $now,
            ]);

            $this->elements->copy_page((int) $page->id, $newpageid, false);
        }

        $transaction->allow_commit();

        if ($targettemplate->get_context()->contextlevel !== CONTEXT_SYSTEM) {
            template_updated::create_from_template($targettemplate)->trigger();
        }
    }
}
