<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Legacy element adapter implementing the v2 element interface.
 *
 * @package    mod_customcert
 *
 * @copyright  2025 Mark Nelson <mdjnelson@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

declare(strict_types=1);

namespace mod_customcert\element;

use mod_customcert\edit_element_form;
use mod_customcert\element as legacy_base;
use MoodleQuickForm;
use stdClass;
use mod_customcert\service\element_renderer;
use mod_customcert\service\element_repository;
use mod_customcert\service\element_factory;
use restore_customcert_activity_task;

/**
 * Exposes legacy element plugins (extending mod_customcert\element) through the v2 element
 * interfaces, delegating to historical hooks such as render_form_elements() and
 * save_unique_data(). Native v2 elements implement the interfaces directly and are never wrapped.
 */
final class legacy_element_adapter implements
    form_element_interface,
    layout_element_interface,
    raw_data_element_interface,
    renderable_element_interface,
    restorable_element_interface,
    stylable_element_interface {
    /** @var legacy_base The wrapped legacy element instance. */
    private legacy_base $inner;

    /** @var bool Whether the wrapped render() declares a renderer parameter (released 5.2 shape). */
    private bool $innerrenderacceptsrenderer;

    /** @var bool Whether the wrapped render_html() declares a renderer parameter (released 5.2 shape). */
    private bool $innerrenderhtmlacceptsrenderer;

    /**
     * Constructor.
     *
     * Reflects once on render()/render_html() so both the 4.5-era signatures and the released
     * 5.2 renderer argument are honoured without reflecting on every render call.
     *
     * @param legacy_base $legacy Legacy element instance to wrap.
     */
    public function __construct(legacy_base $legacy) {
        $this->inner = $legacy;
        $this->innerrenderacceptsrenderer = self::accepts_argument_at(new \ReflectionMethod($legacy, 'render'), 3);
        $this->innerrenderhtmlacceptsrenderer =
            self::accepts_argument_at(new \ReflectionMethod($legacy, 'render_html'), 0);
    }

    /**
     * Whether a method's declaration accepts a positional argument at the given index,
     * either through enough declared parameters or a variadic parameter at or before it.
     *
     * @param \ReflectionMethod $method
     * @param int $position Zero-based argument position.
     * @return bool
     */
    private static function accepts_argument_at(\ReflectionMethod $method, int $position): bool {
        $params = $method->getParameters();
        if (count($params) > $position) {
            return true;
        }
        $last = end($params);
        return $last !== false && $last->isVariadic() && $last->getPosition() <= $position;
    }

    /**
     * Access the wrapped legacy element.
     *
     * @return legacy_base
     */
    public function get_inner(): legacy_base {
        return $this->inner;
    }

    /**
     * Get the internal element ID.
     *
     * @return int
     */
    public function get_id(): int {
        return $this->inner->get_id();
    }

    /**
     * Get the page ID this element belongs to.
     *
     * @return int
     */
    public function get_pageid(): int {
        return $this->inner->get_pageid();
    }

    /**
     * Get the display/name label of the element.
     *
     * @return string
     */
    public function get_name(): string {
        return $this->inner->get_name();
    }

    /**
     * Get element data payload.
     *
     * @return mixed
     */
    public function get_data(): mixed {
        return $this->inner->get_data();
    }

    /**
     * Get the raw, untouched persistence representation of the wrapped element's data.
     *
     * @return mixed
     */
    public function get_raw_data(): mixed {
        return $this->inner->get_raw_data();
    }

    /**
     * Get the font name used by this element.
     *
     * @return string|null
     */
    public function get_font(): ?string {
        return $this->inner->get_font();
    }

    /**
     * Get the font size used by this element.
     *
     * @return int|null
     */
    public function get_fontsize(): ?int {
        return $this->inner->get_fontsize();
    }

    /**
     * Get the colour value used by this element.
     *
     * @return string|null
     */
    public function get_colour(): ?string {
        return $this->inner->get_colour();
    }

    /**
     * Get the width allocated to the element.
     *
     * @return int|null
     */
    public function get_width(): ?int {
        return $this->inner->get_width();
    }


    /**
     * Returns the type of the element.
     *
     * @return string
     */
    public function get_type(): string {
        return $this->inner->get_type();
    }

    /**
     * Set the edit element form instance.
     *
     * @param edit_element_form $editelementform
     * @return void
     */
    public function set_edit_element_form(edit_element_form $editelementform): void {
        $this->inner->set_edit_element_form($editelementform);
    }

    /**
     * Add element-specific fields to the edit form.
     *
     * Delegates to the wrapped legacy element's build_form(), which is always
     * available because the legacy base class provides a bridge implementation
     * that calls render_form_elements() internally.
     *
     * @param MoodleQuickForm $mform
     * @return void
     */
    public function build_form(MoodleQuickForm $mform): void {
        $this->inner->build_form($mform);
    }

    /**
     * Check if this element requires the 'Save and continue' button.
     *
     * @return bool
     */
    public function has_save_and_continue(): bool {
        if (method_exists($this->inner, 'has_save_and_continue')) {
            return $this->inner->has_save_and_continue();
        }
        return false;
    }

    /**
     * Validate form elements (legacy fallback).
     *
     * Only invokes the legacy hook when the wrapped element overrides it, as calling the
     * inherited no-op base implementation would emit a spurious deprecation. No notice is
     * emitted here: persistence_helper reports the deprecation when it calls save_unique_data().
     *
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validate_form_elements(array $data, array $files): array {
        if (method_exists($this->inner, 'validate_form_elements')) {
            $ref = new \ReflectionMethod($this->inner, 'validate_form_elements');
            if ($ref->getDeclaringClass()->getName() !== \mod_customcert\element::class) {
                return $this->inner->validate_form_elements($data, $files);
            }
        }
        return [];
    }

    /**
     * Save unique data for legacy elements (legacy fallback).
     *
     * Only invokes the legacy hook when the wrapped element actually overrides it;
     * calling the inherited no-op base implementation would emit a spurious deprecation.
     *
     * @param \stdClass $data
     * @return mixed
     */
    public function save_unique_data(stdClass $data): mixed {
        if (method_exists($this->inner, 'save_unique_data')) {
            $ref = new \ReflectionMethod($this->inner, 'save_unique_data');
            if ($ref->getDeclaringClass()->getName() !== \mod_customcert\element::class) {
                return $this->inner->save_unique_data($data);
            }
        }
        return null;
    }

    /**
     * Render the element into a PDF context.
     *
     * Preserves the wrapped element's own call shape: a genuine 4.5-era historical
     * render($pdf, $preview, $user) is called with exactly those three arguments, while a
     * released 5.2-compatible render() that declares the renderer parameter also receives it.
     *
     * @param \pdf $pdf
     * @param bool $preview
     * @param \stdClass $user
     * @param element_renderer|null $renderer
     * @return void
     */
    public function render(\pdf $pdf, bool $preview, \stdClass $user, ?element_renderer $renderer = null): void {
        if ($this->innerrenderacceptsrenderer) {
            $this->inner->render($pdf, $preview, $user, $renderer);
        } else {
            $this->inner->render($pdf, $preview, $user);
        }
    }

    /**
     * Render the element in HTML for the drag and drop interface.
     *
     * Preserves the wrapped element's own call shape: a genuine 4.5-era historical
     * render_html() is called with no arguments, while a released 5.2-compatible
     * render_html() that declares the renderer parameter also receives it.
     *
     * @param element_renderer|null $renderer
     * @return string
     */
    public function render_html(?element_renderer $renderer = null): string {
        if ($this->innerrenderhtmlacceptsrenderer) {
            return (string) $this->inner->render_html($renderer);
        }
        return (string) $this->inner->render_html();
    }

    /**
     * Returns the X position of the element on the page (in mm).
     *
     * @return int|null
     */
    public function get_posx(): ?int {
        return $this->inner->get_posx();
    }

    /**
     * Returns the Y position of the element on the page (in mm).
     *
     * @return int|null
     */
    public function get_posy(): ?int {
        return $this->inner->get_posy();
    }

    /**
     * Returns the reference point constant for this element.
     *
     * @return int|null
     */
    public function get_refpoint(): ?int {
        return $this->inner->get_refpoint();
    }

    /**
     * Returns the text alignment for this element.
     *
     * @return string|null
     */
    public function get_alignment(): ?string {
        return $this->inner->get_alignment();
    }

    /**
     * Sets the data on the form when editing an element (legacy fallback).
     *
     * Always delegates, including to the inherited mod_customcert\element implementation,
     * which populates the common form fields. A legacy override calling
     * parent::definition_after_data() triggers that implementation's own deprecation notice;
     * the warning count before/after detects that, so this only emits a fallback notice when
     * the override did not call the parent at all.
     *
     * @param \MoodleQuickForm $mform
     * @return void
     */
    public function definition_after_data(MoodleQuickForm $mform): void {
        $warningsbefore = $this->inner->get_definition_after_data_warning_count();
        $this->inner->definition_after_data($mform);
        if ($this->inner->get_definition_after_data_warning_count() === $warningsbefore) {
            debugging(
                'definition_after_data() is deprecated since Moodle 5.2. '
                . 'Implement mod_customcert\\element\\preparable_form_interface::prepare_form() instead.',
                DEBUG_DEVELOPER
            );
        }
    }

    /**
     * Handle restoration process for legacy elements.
     *
     * Implements restorable_element_interface so the restore task hits the instanceof branch
     * and never emits a deprecation warning for adapted elements. If the wrapped legacy element
     * has its own after_restore() method, it is called silently here as the adapter is the
     * designated compatibility bridge.
     *
     * @param restore_customcert_activity_task $restore
     * @return void
     */
    public function after_restore_from_backup(restore_customcert_activity_task $restore): void {
        // If the wrapped element already implements the new interface, delegate directly
        // without emitting any deprecation notice.
        if ($this->inner instanceof restorable_element_interface) {
            $this->inner->after_restore_from_backup($restore);
            return;
        }
        // Only invoke the legacy hook when the wrapped element actually overrides it;
        // calling the inherited no-op base implementation would emit a spurious deprecation.
        if (method_exists($this->inner, 'after_restore')) {
            $ref = new \ReflectionMethod($this->inner, 'after_restore');
            if ($ref->getDeclaringClass()->getName() !== \mod_customcert\element::class) {
                debugging(
                    'The after_restore() method in ' . get_class($this->inner) . ' is deprecated. ' .
                    'Implement restorable_element_interface and use after_restore_from_backup() instead.',
                    DEBUG_DEVELOPER
                );
                $this->inner->after_restore($restore);
            }
        }
    }

    /**
     * Handle element deletion.
     *
     * Delegates to element_repository::delete(). New code should use the repository directly
     * rather than calling delete() on the element.
     *
     * @return bool true on success
     */
    public function delete(): bool {
        $repository = new element_repository(element_factory::build_with_defaults());
        return $repository->delete($this);
    }
}
