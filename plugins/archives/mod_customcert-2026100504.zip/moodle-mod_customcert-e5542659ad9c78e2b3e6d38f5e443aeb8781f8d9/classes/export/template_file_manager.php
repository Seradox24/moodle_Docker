<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

declare(strict_types=1);

namespace mod_customcert\export;

use coding_exception;
use mod_customcert\export\import_exception;
use mod_customcert\export\template_file_manager_interface;
use mod_customcert\export\template_appendix_manager_interface;
use mod_customcert\export\template;
use Throwable;

/**
 * Manages the export and import of custom certificate template files.
 *
 * This class handles the full process of creating a `.zip` file from a template,
 * including JSON data and appendix files, and supports importing the same structure
 * back into the system. It integrates with file and appendix managers to provide
 * complete backup and restore functionality.
 *
 * @package    mod_customcert
 * @author     Konrad Ebel <konrad.ebel@oncampus.de>
 * @copyright  2025, oncampus GmbH
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class template_file_manager implements template_file_manager_interface {
    /** @var int Maximum number of files allowed in an imported archive. */
    const MAX_ARCHIVE_FILES = 500;

    /** @var int Maximum size in bytes for a single file in an imported archive (50 MB). */
    const MAX_FILE_BYTES = 50 * 1024 * 1024;

    /** @var int Maximum total size in bytes for all files in an imported archive (200 MB). */
    const MAX_TOTAL_BYTES = 200 * 1024 * 1024;

    /** @var template_appendix_manager_interface The manager for appendix file operations. */
    private readonly template_appendix_manager_interface $filemng;

    /** @var template Template handler for import/export operations. */
    private readonly template $template;

    /**
     * Constructor.
     *
     * @param template_appendix_manager_interface $filemng The manager for appendix file operations.
     * @param template $template Template handler for import/export operations.
     */
    public function __construct(
        template_appendix_manager_interface $filemng,
        template $template,
    ) {
        $this->filemng = $filemng;
        $this->template = $template;
    }

    /**
     * Export a template and its files as a downloadable ZIP archive.
     *
     * @param int $templateid The ID of the template to export.
     * @return string The exported file path
     * @throws coding_exception If JSON encoding fails.
     */
    public function export(int $templateid): string {
        $jsondata = $this->template->export($templateid);

        $json = json_encode($jsondata, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new coding_exception("Json error during export");
        }

        $tempdir = make_temp_directory('customcert_export/' . uniqid(more_entropy: true));
        file_put_contents($tempdir . '/template.json', $json);

        $this->filemng->export($templateid, $tempdir);

        if (!$packer = get_file_packer()) {
            throw new import_exception('ZIP packer is not available');
        }
        $zipfile = "$tempdir/certificate-template-$templateid.zip";

        $files = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($tempdir, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $path) {
            $relativepath = substr((string) $path, strlen($tempdir) + 1);
            $relativepath = str_replace(DIRECTORY_SEPARATOR, '/', $relativepath);
            if (!is_dir((string) $path)) {
                $files[$relativepath] = (string) $path;
            }
        }

        $packer->archive_to_pathname(
            $files,
            $zipfile
        );
        return $zipfile;
    }

    /**
     * Import a template and its files from a ZIP archive.
     * On template import failure, roll back newly stored files before rethrowing.
     * Files use mod_customcert/image, itemid=0 and filepath=/ regardless of manifest metadata;
     * round-trips for other file-backed element types are unsupported.
     *
     * @param int $contextid The context ID into which the template will be imported.
     * @param string $tempdir The directory containing the uploaded ZIP archive.
     * @throws import_exception If extraction fails, required files are missing, or ZIP
     *                          content fails validation.
     */
    public function import(int $contextid, string $tempdir): void {
        if (!$packer = get_file_packer()) {
            throw new import_exception('ZIP packer is not available');
        }

        $zippath = "$tempdir/import.zip";
        $this->validate_zip($zippath);

        $unpackdir = "$tempdir/unzipped";
        check_dir_exists($unpackdir);

        if (!$packer->extract_to_pathname($zippath, $unpackdir)) {
            throw new import_exception('Failed to extract the ZIP archive');
        }

        $jsonpath = $unpackdir . '/template.json';
        if (!file_exists($jsonpath)) {
            throw new import_exception('template.json not found in archive');
        }

        $json = file_get_contents($jsonpath);
        $data = json_decode($json, true);
        if (!is_array($data)) {
            throw new import_exception('Invalid template.json (not valid JSON)');
        }

        // Import files first, then template data inside a DB transaction.
        // Wrap both steps so that any failure (including partial file import) triggers cleanup.
        try {
            $this->filemng->import($contextid, $unpackdir);
            $this->template->import($contextid, $data);
        } catch (Throwable $e) {
            $this->filemng->delete_imported_files();
            throw $e;
        }
    }

    /**
     * Validates the ZIP archive before extraction.
     *
     * Checks that the archive can be listed, contains an acceptable number of entries,
     * that no single entry exceeds the maximum allowed size, and that all entry names
     * consist only of safe characters.
     *
     * @param string $zippath Full path to the ZIP file.
     * @throws import_exception If any validation check fails.
     */
    private function validate_zip(string $zippath): void {
        // Inspect raw ZIP paths before Moodle normalisation can hide traversal entries.
        if (!class_exists(\ZipArchive::class)) {
            throw new import_exception('ZIP extension is not available');
        }
        $zip = new \ZipArchive();
        if ($zip->open($zippath) !== true) {
            throw new import_exception('Failed to read the ZIP archive');
        }
        $files = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if ($stat === false || !isset($stat['name'], $stat['size'])) {
                $zip->close();
                throw new import_exception('Failed to inspect the ZIP archive');
            }

            // Normalise backslashes so Windows-style paths are caught by the same checks.
            $name = str_replace('\\', '/', $stat['name']);

            // Reject absolute paths and drive-letter paths before segment checks.
            if ($name === '' || str_starts_with($name, '/') || preg_match('/^[A-Za-z]:\//', $name)) {
                $zip->close();
                throw new import_exception('ZIP archive contains an unsafe filename: ' . $stat['name']);
            }

            // Reject empty, dot and dot-dot segments anywhere in the path.
            foreach (explode('/', trim($name, '/')) as $segment) {
                if ($segment === '' || $segment === '.' || $segment === '..') {
                    $zip->close();
                    throw new import_exception('ZIP archive contains an unsafe filename: ' . $stat['name']);
                }
            }

            // Only allow safe characters: alphanumeric, dash, underscore, dot, slash.
            if (!preg_match('/^[a-zA-Z0-9_\-\.\/]+$/', $name)) {
                $zip->close();
                throw new import_exception('Archive contains an unsafe filename: ' . $stat['name']);
            }

            // Skip safe structural directory entries (name ends with '/') after all
            // security checks have passed; they carry no file content.
            if (str_ends_with($name, '/')) {
                continue;
            }

            $files[] = (object)['pathname' => $name, 'size' => $stat['size']];
        }
        $zip->close();

        // Limit archive entry count to guard against zip bombs.
        $maxfiles = self::MAX_ARCHIVE_FILES;
        if (count($files) > $maxfiles) {
            throw new import_exception('Too many files in archive (max ' . $maxfiles . ')');
        }

        // 50 MB per-entry size limit; 200 MB cumulative uncompressed size limit.
        $maxbytes = self::MAX_FILE_BYTES;
        $maxtotalbytes = self::MAX_TOTAL_BYTES;
        $totalbytes = 0;
        foreach ($files as $file) {
            if ($file->size > $maxbytes) {
                throw new import_exception('A file in the archive exceeds the size limit: ' . $file->pathname);
            }
            $totalbytes += $file->size;
            if ($totalbytes > $maxtotalbytes) {
                throw new import_exception('Archive total uncompressed size exceeds the allowed limit');
            }
        }
    }
}
