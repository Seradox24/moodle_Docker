<?php
// This file is part of the customcert module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

declare(strict_types=1);

namespace mod_customcert\export;

use core\clock;
use mod_customcert\export\datatypes\format_error;
use mod_customcert\export\template_import_logger_interface;
use mod_customcert\export\template_appendix_manager_interface;
use mod_customcert\export\import_exception;
use mod_customcert\export\subplugin_exportable;
use stored_file;

/**
 * Manages the import, export, and file referencing of certificate elements.
 *
 * This class handles the lifecycle of individual certificate elements, including their
 * import from and export to data arrays, integration with plugin-specific exporters,
 * and lookup of associated files. It supports extensibility via subplugin-based export logic.
 *
 * @package    mod_customcert
 * @author     Konrad Ebel <konrad.ebel@oncampus.de>
 * @copyright  2025, oncampus GmbH
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class element {
    /**
     * @var table_exporter Table exporter responsible for retrieving element data from the database.
     */
    private table_exporter $exporter;

    /**
     * @var string Name of the database table containing certificate elements.
     */
    protected static string $dbtable = 'customcert_elements';

    /**
     * @var array List of database fields to be used in import/export operations.
     */
    protected array $fields = [
        'name',
        'element',
        'data',
        'posx',
        'posy',
        'refpoint',
        'alignment',
        'sequence',
    ];

    /**
     * Constructor.
     *
     * @param clock $clock Clock instance used to retrieve current timestamps.
     * @param template_import_logger_interface $logger Logger instance for import warnings.
     * @param template_appendix_manager_interface $filemng File manager for appendix operations.
     */
    public function __construct(
        /** @var clock Clock instance used to retrieve current timestamps. */
        private readonly clock $clock,
        /** @var template_import_logger_interface Logger instance for import warnings. */
        private readonly template_import_logger_interface $logger,
        /** @var template_appendix_manager_interface File manager for appendix operations. */
        private readonly template_appendix_manager_interface $filemng,
    ) {
        $this->exporter = new table_exporter(self::$dbtable);
    }

    /**
     * Retrieves all element IDs associated with a specific certificate page.
     *
     * @param int $pageid The ID of the page to query.
     * @return array List of element IDs.
     */
    public static function get_elementids_from_page(int $pageid): array {
        global $DB;

        $elementids = $DB->get_fieldset(static::$dbtable, 'id', ['pageid' => $pageid]);
        return array_map('intval', $elementids);
    }

    /**
     * Validate and import an element using its subplugin exporter.
     *
     * @param int $pageid The ID of the page to which the element will be added.
     * @param array $data The element data to import.
     * @throws import_exception If required fields like 'name' are missing.
     */
    public function import(int $pageid, array $data): void {
        global $DB;

        if (($data['name'] ?? null) === null || ($data['element'] ?? null) === null) {
            throw new import_exception('Template is missing the required name attribute');
        }

        $specificexporter = $this->get_plugin_specific_exporter($data['element']);
        try {
            $subplugindata = $specificexporter->convert_for_import($data['data']);
        } catch (format_error $e) {
            $this->logger->warning('subplugin data is not valid: ' . $e->getMessage());
            return;
        }
        if ($subplugindata === null) {
            // Unsupported element type — skip insertion rather than storing a broken record.
            return;
        }
        $DB->insert_record(static::$dbtable, [
            'pageid' => $pageid,
            'name' => $data['name'],
            'element' => $data['element'],
            'data' => $subplugindata,
            'posx' => (int) $data['posx'],
            'posy' => (int) $data['posy'],
            'refpoint' => (int) $data['refpoint'],
            'alignment' => $data['alignment'],
            'sequence' => (int) $data['sequence'],
            'timecreated' => $this->clock->time(),
            'timemodified' => $this->clock->time(),
        ]);
    }

    /**
     * Exports a certificate element into an array, including subplugin data.
     *
     * Retrieves the core element data and augments it using a plugin-specific exporter.
     *
     * @param int $elementid The ID of the element to export.
     * @return array The exported element data.
     */
    public function export(int $elementid): array {
        $data = $this->exporter->export($elementid, $this->fields);

        $specificexporter = $this->get_plugin_specific_exporter($data['element']);
        $data['data'] = $specificexporter->export($data['data'] ?? "");
        return $data;
    }

    /**
     * Retrieves files used by a specific certificate element.
     *
     * Delegates the file collection to the corresponding subplugin exporter.
     *
     * @param int $elementid The ID of the element.
     * @return stored_file[] List of file references.
     */
    public function get_files(int $elementid): array {
        $data = $this->exporter->export($elementid, ['element', 'data']);

        $specificexporter = $this->get_plugin_specific_exporter($data['element']);
        return $specificexporter->get_used_files($data['data'] ?? "");
    }

    /**
     * Resolve a subplugin exporter, falling back to a null exporter for missing or incompatible classes.
     *
     * @param string $pluginname The name of the subplugin.
     * @return subplugin_exportable The resolved exporter.
     */
    private function get_plugin_specific_exporter(string $pluginname): subplugin_exportable {
        $classname = '\\customcertelement_' . $pluginname . '\\exporter';

        if (!class_exists($classname)) {
            return new element_null_exporter($pluginname, $this->logger, $this->filemng);
        }
        $exporter = new $classname($pluginname, $this->logger, $this->filemng);
        if (!$exporter instanceof subplugin_exportable) {
            return new element_null_exporter($pluginname, $this->logger, $this->filemng);
        }

        return $exporter;
    }
}
