<?php
// This file is part of the tool_certificate plugin for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace tool_certificate;

use advanced_testcase;
use tool_certificate_generator;
use core_external\external_api;

/**
 * Unit tests for the webservices.
 *
 * @runTestsInSeparateProcesses
 *
 * @package    tool_certificate
 * @group      tool_certificate
 * @category   test
 * @covers     \tool_certificate\external\issues
 * @copyright  2018 Mark Nelson <markn@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
final class external_test extends advanced_testcase {
    /** @var tool_certificate_generator */
    protected $certgenerator;

    /**
     * Test set up.
     */
    public function setUp(): void {
        parent::setUp();
        $this->resetAfterTest();
        $this->certgenerator = self::getDataGenerator()->get_plugin_generator('tool_certificate');
    }

    /**
     * Test the delete_issue web service.
     */
    public function test_delete_issue(): void {
        global $DB;

        $this->setAdminUser();

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create a certificate template.
        $template = $this->certgenerator->create_template((object)['name' => 'Certificate 1']);

        // Create two users.
        $student1 = $this->getDataGenerator()->create_user();
        $student2 = $this->getDataGenerator()->create_user();

        // Enrol them into the course.
        $this->getDataGenerator()->enrol_user($student1->id, $course->id);
        $this->getDataGenerator()->enrol_user($student2->id, $course->id);

        // Issue them both certificates.
        $i1 = $template->issue_certificate($student1->id);
        $i2 = $template->issue_certificate($student2->id);

        $this->assertEquals(2, $DB->count_records('tool_certificate_issues'));

        \tool_certificate\external\issues::revoke_issue($i2);

        $issues = $DB->get_records('tool_certificate_issues');
        $this->assertCount(1, $issues);

        $issue = reset($issues);
        $this->assertEquals($student1->id, $issue->userid);
    }

    /**
     * Test the delete_issue web service.
     */
    public function test_delete_issue_no_login(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create a certificate template.
        $template = $this->certgenerator->create_template((object)['name' => 'Certificate 1']);

        // Create two users.
        $student1 = $this->getDataGenerator()->create_user();
        $student2 = $this->getDataGenerator()->create_user();

        // Enrol them into the course.
        $this->getDataGenerator()->enrol_user($student1->id, $course->id);
        $this->getDataGenerator()->enrol_user($student2->id, $course->id);

        // Issue them both certificates.
        $i1 = $template->issue_certificate($student1->id);
        $i2 = $template->issue_certificate($student2->id);

        $this->assertEquals(2, $DB->count_records('tool_certificate_issues'));

        // Try and delete without logging in.
        $this->expectException('require_login_exception');
        \tool_certificate\external\issues::revoke_issue($i2);
    }

    /**
     * Test the delete_issue web service.
     */
    public function test_delete_issue_no_capability(): void {
        global $DB;

        // Create a course.
        $course = $this->getDataGenerator()->create_course();

        // Create a certificate template.
        $template = $this->certgenerator->create_template((object)['name' => 'Certificate 1']);

        // Create two users.
        $student1 = $this->getDataGenerator()->create_user();
        $student2 = $this->getDataGenerator()->create_user();

        $this->setUser($student1);

        // Enrol them into the course.
        $this->getDataGenerator()->enrol_user($student1->id, $course->id);
        $this->getDataGenerator()->enrol_user($student2->id, $course->id);

        // Issue them both certificates.
        $i1 = $template->issue_certificate($student1->id);
        $i2 = $template->issue_certificate($student2->id);

        $this->assertEquals(2, $DB->count_records('tool_certificate_issues'));

        // Try and delete without the required capability.
        $this->expectException('required_capability_exception');
        \tool_certificate\external\issues::revoke_issue($i2);
    }

    /**
     * Test regenerate_issue_file
     */
    public function test_regenerate_issue_file(): void {
        global $DB, $CFG;
        require_once($CFG->libdir . '/externallib.php');

        $this->setAdminUser();

        // Create the certificate.
        $certificate = $this->certgenerator->create_template((object)['name' => 'Certificate 1']);

        // Issue certificate.
        $user = $this->getDataGenerator()->create_user(['firstname' => 'User', 'lastname' => '01']);
        $issue = $this->certgenerator->issue($certificate, $user);

        // Check issue userfullname data.
        $userfullname = $data = @json_decode($issue->data, true)['userfullname'];
        $this->assertEquals('User 01', $userfullname);

        // Check issue file already exists after issuing certificate.
        $fs = get_file_storage();
        $file = $fs->get_file(
            \context_system::instance()->id,
            'tool_certificate',
            'issues',
            $issue->id,
            '/',
            $issue->code . '.pdf'
        );
        $this->assertNotFalse($file);

        // Change user name.
        $DB->update_record('user', (object) ['id' => $user->id, 'lastname' => '02']);

        // Trigger and capture the event.
        $sink = $this->redirectEvents();

        // Regenerate issue file.
        \tool_certificate\external\issues::regenerate_issue_file($issue->id);

        // Checking that the event was triggered.
        $events = $sink->get_events();
        $this->assertCount(1, $events);
        $event = array_pop($events);

        // Checking that the event contains the expected values.
        $this->assertInstanceOf('\tool_certificate\event\certificate_regenerated', $event);
        $this->assertEquals(\context_system::instance(), $event->get_context());
        $this->assertEventContextNotUsed($event);
        $this->assertNotEmpty($event->get_name());
        $this->assertNotEmpty($event->get_description());
        $sink->close();

        // Check new file was created for issue.
        $newfile = $fs->get_file(
            \context_system::instance()->id,
            'tool_certificate',
            'issues',
            $issue->id,
            '/',
            $issue->code . '.pdf'
        );
        $this->assertNotEquals($file->get_id(), $newfile->get_id());
        $this->assertEquals($issue->id, $newfile->get_itemid());

        // Check issue userfullname data was updated.
        $issue = $DB->get_record('tool_certificate_issues', ['id' => $issue->id]);
        $userfullname = @json_decode($issue->data, true)['userfullname'];
        $this->assertEquals('User 02', $userfullname);
    }

    /**
     * Test for function potential_users_selector()
     *
     * @param string $search
     * @param string[] $expectedfullnames
     * @param int $limitfrom
     * @param int $limitnum
     */
    #[\PHPUnit\Framework\Attributes\DataProvider('potential_users_selector_provider')]
    public function test_potential_users_selector(
        string $search,
        array $expectedfullnames,
        int $limitfrom = 0,
        int $limitnum = 0
    ): void {
        global $DB;

        $this->setAdminUser();

        $course = $this->getDataGenerator()->create_course();
        $template = $this->certgenerator->create_template((object)['name' => 'Certificate 1']);

        // Create two users and enrol them into the course.
        $student1 = $this->getDataGenerator()->create_user([
            'firstname' => 'Bob',
            'lastname' => 'Smith',
            'email' => 'test@example.invalid',
        ]);
        $student2 = $this->getDataGenerator()->create_user([
            'firstname' => 'Lee',
            'lastname' => 'Smith',
        ]);
        $this->getDataGenerator()->enrol_user($student1->id, $course->id);
        $this->getDataGenerator()->enrol_user($student2->id, $course->id);

        // Issue the certificate to the admin user, to skip it in the potential users selector results.
        $template->issue_certificate(get_admin()->id);

        $matchedusers = external_api::clean_returnvalue(
            \tool_certificate\external\issues::potential_users_selector_returns(),
            \tool_certificate\external\issues::potential_users_selector($search, $template->get_id(), $limitfrom, $limitnum),
        );
        $this->assertEqualsCanonicalizing($expectedfullnames, array_column($matchedusers, 'fullname'));
    }

    /**
     * Data provider for potential user selection.
     *
     * @return array
     */
    public static function potential_users_selector_provider(): array {
        return [
            ['', ['Bob Smith', 'Lee Smith']],
            ['bob', ['Bob Smith']],
            ['smith', ['Bob Smith', 'Lee Smith']],
            ['jim', []],
            // Test for limits.
            ['', ['Bob Smith'], 0, 1],
            ['', ['Lee Smith'], 1, 1], // With limits starting from the second record.
            ['smith', ['Bob Smith'], 0, 1],
            ['smith', ['Lee Smith'], 1, 1],
            ['jim', [], 2, 100], // With limits, but still no matches.
        ];
    }
}
