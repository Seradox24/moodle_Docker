<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AJAX endpoint for AI template generation.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$cmid = required_param('cmid', PARAM_INT);
$description = required_param('description', PARAM_TEXT);

$cm = get_coursemodule_from_id('certstudio', $cmid, 0, false, MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
$certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:manage', $context);
require_sesskey();

header('Content-Type: application/json');

try {
    // Get the template's page dimensions.
    $width = 297;
    $height = 210;
    if (!empty($certstudio->templateid)) {
        $page = $DB->get_record('certstudio_pages', ['templateid' => $certstudio->templateid], '*', IGNORE_MULTIPLE);
        if ($page) {
            $width = (int) $page->width;
            $height = (int) $page->height;
        }
    }

    $elements = \mod_certstudio\ai_generator::generate($description, $width, $height);

    echo json_encode([
        'success' => true,
        'elements' => $elements,
        'message' => get_string('aigeneratesuccess', 'mod_certstudio'),
    ]);
} catch (\Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
    ]);
}
