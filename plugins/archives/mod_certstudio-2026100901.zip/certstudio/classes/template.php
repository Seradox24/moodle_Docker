<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Template management class for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * Manages certificate templates including CRUD operations, duplication, and import/export.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class template {
    /** @var string The database table for templates. */
    private const TABLE = 'certstudio_templates';

    /** @var string The database table for pages. */
    private const TABLE_PAGES = 'certstudio_pages';

    /** @var string The database table for elements. */
    private const TABLE_ELEMENTS = 'certstudio_elements';

    /**
     * Create a new certificate template.
     *
     * @param string $name The template name.
     * @param int $contextid The context ID this template belongs to.
     * @return int The ID of the newly created template.
     */
    public static function create(string $name, int $contextid): int {
        global $DB;

        $record = new \stdClass();
        $record->name = $name;
        $record->contextid = $contextid;
        $record->timecreated = time();
        $record->timemodified = $record->timecreated;

        $templateid = $DB->insert_record(self::TABLE, $record);

        // Create a default first page.
        $page = new \stdClass();
        $page->templateid = $templateid;
        $page->width = 297;
        $page->height = 210;
        $page->leftmargin = 0;
        $page->rightmargin = 0;
        $page->sequence = 1;
        $page->timecreated = time();
        $page->timemodified = $page->timecreated;
        $DB->insert_record(self::TABLE_PAGES, $page);

        return $templateid;
    }

    /**
     * Get a template by its ID.
     *
     * @param int $id The template ID.
     * @return \stdClass|false The template record, or false if not found.
     */
    public static function get(int $id) {
        global $DB;

        return $DB->get_record(self::TABLE, ['id' => $id]);
    }

    /**
     * Get all templates belonging to a given context.
     *
     * @param int $contextid The context ID.
     * @return array Array of template records.
     */
    public static function get_by_context(int $contextid): array {
        global $DB;

        return $DB->get_records(self::TABLE, ['contextid' => $contextid], 'name ASC');
    }

    /**
     * Update an existing template.
     *
     * @param int $id The template ID.
     * @param \stdClass|array $data The fields to update.
     * @return bool True on success.
     * @throws \dml_exception If the update fails.
     */
    public static function update(int $id, $data): bool {
        global $DB;

        if (is_array($data)) {
            $data = (object) $data;
        }

        $data->id = $id;
        $data->timemodified = time();

        return $DB->update_record(self::TABLE, $data);
    }

    /**
     * Delete a template and all associated pages and elements.
     *
     * @param int $id The template ID.
     * @return bool True on success.
     */
    public static function delete(int $id): bool {
        global $DB;

        $template = self::get($id);
        if (!$template) {
            return false;
        }

        // Delete all elements belonging to this template's pages.
        $pages = self::get_pages($id);
        foreach ($pages as $page) {
            $DB->delete_records(self::TABLE_ELEMENTS, ['pageid' => $page->id]);
        }

        // Delete all pages.
        $DB->delete_records(self::TABLE_PAGES, ['templateid' => $id]);

        // Delete the template itself.
        $DB->delete_records(self::TABLE, ['id' => $id]);

        return true;
    }

    /**
     * Delete an activity's own template once nothing uses it any more.
     *
     * Templates in other contexts, such as the site gallery, and templates still used by any activity are kept,
     * so replacing or deleting one activity's design never removes another activity's.
     *
     * @param int $id The template ID.
     * @param int $contextid The context of the activity that owned the template.
     * @return bool True if the template was deleted.
     */
    public static function delete_if_unused(int $id, int $contextid): bool {
        global $DB;

        $template = self::get($id);
        if (!$template || (int) $template->contextid !== $contextid || $DB->record_exists('certstudio', ['templateid' => $id])) {
            return false;
        }
        return self::delete($id);
    }

    /**
     * Get all pages for a template, ordered by sequence.
     *
     * @param int $templateid The template ID.
     * @return array Array of page records.
     */
    public static function get_pages(int $templateid): array {
        global $DB;

        return $DB->get_records(self::TABLE_PAGES, ['templateid' => $templateid], 'sequence ASC');
    }

    /**
     * Duplicate a template with a new name.
     *
     * Creates a deep copy of the template including all pages and elements.
     *
     * @param int $id The source template ID.
     * @param string $newname The name for the duplicated template.
     * @return int The ID of the new template.
     * @throws \moodle_exception If the source template is not found.
     */
    public static function duplicate(int $id, string $newname): int {
        global $DB;

        $template = self::get($id);
        if (!$template) {
            throw new \moodle_exception('templatenotfound', 'mod_certstudio');
        }

        // Create the new template.
        $newtemplateid = self::create($newname, $template->contextid);

        // Remove the default page that was created automatically.
        $defaultpages = self::get_pages($newtemplateid);
        foreach ($defaultpages as $defaultpage) {
            $DB->delete_records(self::TABLE_PAGES, ['id' => $defaultpage->id]);
        }

        // Copy pages and elements.
        $pages = self::get_pages($id);
        foreach ($pages as $page) {
            $newpage = clone $page;
            unset($newpage->id);
            $newpage->templateid = $newtemplateid;
            $newpage->timecreated = time();
            $newpage->timemodified = $newpage->timecreated;
            $newpageid = $DB->insert_record(self::TABLE_PAGES, $newpage);

            // Copy elements for this page.
            $elements = $DB->get_records(self::TABLE_ELEMENTS, ['pageid' => $page->id], 'sequence ASC');
            foreach ($elements as $element) {
                $newelement = clone $element;
                unset($newelement->id);
                $newelement->pageid = $newpageid;
                $newelement->timecreated = time();
                $newelement->timemodified = $newelement->timecreated;
                $DB->insert_record(self::TABLE_ELEMENTS, $newelement);
            }
        }

        return $newtemplateid;
    }

    /**
     * Export a template to JSON format.
     *
     * Exports the full template structure including pages and elements.
     *
     * @param int $id The template ID.
     * @return string JSON-encoded template data.
     * @throws \moodle_exception If the template is not found.
     */
    public static function export_json(int $id): string {
        global $DB, $CFG;

        $template = self::get($id);
        if (!$template) {
            throw new \moodle_exception('templatenotfound', 'mod_certstudio');
        }

        $export = new \stdClass();
        $export->name = $template->name;
        $export->pages = [];

        $pages = self::get_pages($id);
        foreach ($pages as $page) {
            $pagedata = new \stdClass();
            $pagedata->width = $page->width;
            $pagedata->height = $page->height;
            $pagedata->leftmargin = $page->leftmargin;
            $pagedata->rightmargin = $page->rightmargin;
            $pagedata->backgroundimage = $page->backgroundimage;
            $pagedata->bgcolor = $page->bgcolor ?? '#ffffff';
            $pagedata->sequence = $page->sequence;

            $pagedata->elements = [];
            $elements = $DB->get_records(self::TABLE_ELEMENTS, ['pageid' => $page->id], 'sequence ASC');
            foreach ($elements as $element) {
                $elementdata = new \stdClass();
                $elementdata->name = $element->name;
                $elementdata->type = $element->type;
                $elementdata->posx = $element->posx;
                $elementdata->posy = $element->posy;
                $elementdata->width = $element->width;
                $elementdata->height = $element->height;
                $elementdata->rotation = $element->rotation;
                $elementdata->fontfamily = $element->fontfamily;
                $elementdata->fontsize = $element->fontsize;
                $elementdata->fontweight = $element->fontweight;
                $elementdata->fontstyle = $element->fontstyle;
                $elementdata->color = $element->color;
                $elementdata->alignment = $element->alignment;
                $elementdata->opacity = $element->opacity;
                $elementdata->locked = $element->locked;
                $elementdata->sequence = $element->sequence;

                // Embed images as base64 data URIs for portable export.
                $dataarr = !empty($element->data) ? json_decode($element->data, true) : [];
                if (is_array($dataarr) && !empty($dataarr['src'])) {
                    $dataarr['src'] = self::embed_image_for_export($dataarr['src']);
                }
                $elementdata->data = json_encode($dataarr);

                $pagedata->elements[] = $elementdata;
            }

            $export->pages[] = $pagedata;
        }

        return json_encode($export, JSON_PRETTY_PRINT);
    }

    /**
     * Convert an image src to a portable format for export.
     *
     * - Plugin pix files (built-in SVGs): kept as relative paths since they exist in every install.
     * - Pluginfile URLs (user uploads): converted to base64 data URIs.
     * - Data URIs: kept as-is.
     * - External URLs: kept as-is.
     *
     * @param string $src The image source URL.
     * @return string The portable image source.
     */
    private static function embed_image_for_export(string $src): string {
        global $CFG;

        // Already a data URI — keep as-is.
        if (strpos($src, 'data:image') === 0) {
            return $src;
        }

        // Built-in plugin pix file — keep relative path (exists on every install).
        if (strpos($src, '/mod/certstudio/pix/') !== false) {
            return $src;
        }

        // Pluginfile URL — read from Moodle file storage and convert to base64.
        if (strpos($src, '/pluginfile.php') !== false) {
            $file = self::resolve_pluginfile_to_stored_file($src);
            if ($file) {
                $mime = $file->get_mimetype();
                $content = $file->get_content();
                return 'data:' . $mime . ';base64,' . base64_encode($content);
            }
        }

        // External URL or unknown — keep as-is.
        return $src;
    }

    /**
     * Resolve a pluginfile URL to a Moodle stored_file object.
     *
     * @param string $url The pluginfile URL.
     * @return \stored_file|null The file, or null if not found.
     */
    private static function resolve_pluginfile_to_stored_file(string $url): ?\stored_file {
        $path = parse_url($url, PHP_URL_PATH);
        if (!$path) {
            return null;
        }
        $pos = strpos($path, '/pluginfile.php/');
        if ($pos === false) {
            return null;
        }
        $relpath = substr($path, $pos + strlen('/pluginfile.php/'));
        $parts = explode('/', $relpath);
        if (count($parts) < 4) {
            return null;
        }

        $contextid = (int)$parts[0];
        $component = $parts[1];
        $filearea = $parts[2];
        $itemid = (int)$parts[3];
        $filename = urldecode(end($parts));

        $fs = get_file_storage();
        $file = $fs->get_file($contextid, $component, $filearea, $itemid, '/', $filename);
        if (!$file || $file->is_directory()) {
            return null;
        }
        return $file;
    }

    /**
     * Import a template from JSON data.
     *
     * @param string $json JSON-encoded template data.
     * @param int $contextid The context ID for the imported template.
     * @return int The ID of the newly created template.
     * @throws \moodle_exception If the JSON is invalid.
     */
    public static function import_json(string $json, int $contextid): int {
        global $DB;

        $data = json_decode($json);
        if ($data === null || !isset($data->name) || !isset($data->pages)) {
            throw new \moodle_exception('invalidjsontemplate', 'mod_certstudio');
        }

        // Create the template.
        $newtemplateid = self::create($data->name, $contextid);

        // Remove the default page that was created automatically.
        $defaultpages = self::get_pages($newtemplateid);
        foreach ($defaultpages as $defaultpage) {
            $DB->delete_records(self::TABLE_PAGES, ['id' => $defaultpage->id]);
        }

        // Import pages and elements.
        foreach ($data->pages as $pagedata) {
            $page = new \stdClass();
            $page->templateid = $newtemplateid;
            $page->width = $pagedata->width ?? 297;
            $page->height = $pagedata->height ?? 210;
            $page->leftmargin = $pagedata->leftmargin ?? 0;
            $page->rightmargin = $pagedata->rightmargin ?? 0;
            $page->backgroundimage = $pagedata->backgroundimage ?? null;
            $page->bgcolor = $pagedata->bgcolor ?? '#ffffff';
            $page->sequence = $pagedata->sequence ?? 0;
            $page->timecreated = time();
            $page->timemodified = $page->timecreated;
            $pageid = $DB->insert_record(self::TABLE_PAGES, $page);

            if (!empty($pagedata->elements)) {
                foreach ($pagedata->elements as $elementdata) {
                    $element = new \stdClass();
                    $element->pageid = $pageid;
                    $element->name = $elementdata->name ?? '';
                    $element->type = $elementdata->type;
                    $element->posx = $elementdata->posx ?? 0;
                    $element->posy = $elementdata->posy ?? 0;
                    $element->width = $elementdata->width ?? 0;
                    $element->height = $elementdata->height ?? 0;
                    $element->rotation = $elementdata->rotation ?? 0;
                    $element->fontfamily = $elementdata->fontfamily ?? null;
                    $element->fontsize = $elementdata->fontsize ?? null;
                    $element->fontweight = $elementdata->fontweight ?? 'normal';
                    $element->fontstyle = $elementdata->fontstyle ?? 'normal';
                    $element->color = $elementdata->color ?? '#000000';
                    $element->alignment = $elementdata->alignment ?? 'L';
                    $element->opacity = $elementdata->opacity ?? 1;
                    $element->locked = $elementdata->locked ?? 0;
                    $element->sequence = $elementdata->sequence ?? 0;
                    $element->timecreated = time();
                    $element->timemodified = $element->timecreated;

                    // Restore base64 data URI images to Moodle file storage.
                    $eldata = $elementdata->data ?? null;
                    if (is_string($eldata)) {
                        $dataarr = json_decode($eldata, true);
                    } else {
                        $dataarr = (array)($eldata ?? []);
                    }
                    if (is_array($dataarr) && !empty($dataarr['src']) && strpos($dataarr['src'], 'data:image') === 0) {
                        $storedurl = self::store_base64_image($dataarr['src'], $contextid, $element->type, $pageid);
                        if ($storedurl) {
                            $dataarr['src'] = $storedurl;
                        }
                    }
                    $element->data = json_encode($dataarr);

                    $DB->insert_record(self::TABLE_ELEMENTS, $element);
                }
            }
        }

        return $newtemplateid;
    }

    /**
     * Store a base64 data URI image into Moodle file storage.
     *
     * @param string $datauri The base64 data URI (data:image/png;base64,...).
     * @param int $contextid The context ID for file storage.
     * @param string $type Element type (bgimage, image, etc.).
     * @param int $itemid Item ID (page ID for backgrounds, element ID for others).
     * @return string|null The pluginfile URL, or null on failure.
     */
    private static function store_base64_image(string $datauri, int $contextid, string $type, int $itemid): ?string {
        // Parse data URI.
        if (!preg_match('#^data:(image/[a-z+]+);base64,(.+)$#i', $datauri, $matches)) {
            return null;
        }
        $mime = $matches[1];
        $content = base64_decode($matches[2]);
        if ($content === false) {
            return null;
        }

        // Determine extension from MIME type.
        $extmap = [
            'image/png' => 'png', 'image/jpeg' => 'jpg', 'image/gif' => 'gif',
            'image/svg+xml' => 'svg', 'image/webp' => 'webp',
        ];
        $ext = $extmap[$mime] ?? 'png';
        $filename = 'imported_' . uniqid() . '.' . $ext;

        $filearea = ($type === 'bgimage') ? 'background' : 'elementimage';

        $fs = get_file_storage();
        $filerecord = [
            'contextid' => $contextid,
            'component' => 'mod_certstudio',
            'filearea' => $filearea,
            'itemid' => $itemid,
            'filepath' => '/',
            'filename' => $filename,
            'mimetype' => $mime,
        ];

        try {
            $file = $fs->create_file_from_string($filerecord, $content);
            if ($file) {
                $url = \moodle_url::make_pluginfile_url(
                    $contextid,
                    'mod_certstudio',
                    $filearea,
                    $itemid,
                    '/',
                    $filename
                );
                return $url->out(false);
            }
        } catch (\Exception $e) {
            // File storage failed - fall back to keeping data URI.
            unset($e);
        }

        return null;
    }
}
