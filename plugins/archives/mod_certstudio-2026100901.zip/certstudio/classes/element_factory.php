<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Element factory for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2017 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * Factory class that instantiates the correct element subclass based on type.
 *
 * @package    mod_certstudio
 * @copyright  2017 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class element_factory {
    /**
     * Get an element instance for the given type.
     *
     * @param string $type The element type identifier (e.g. 'text', 'studentname').
     * @return element An instance of the appropriate element subclass.
     * @throws \moodle_exception If the element type class is not found.
     */
    public static function get_element(string $type): element {
        global $CFG;

        $classname = '\\certstudioselem_' . $type . '\\element';

        // Ensure the file is loaded.
        $filepath = $CFG->dirroot . '/mod/certstudio/element/' . $type . '/classes/element.php';
        if (!class_exists($classname) && file_exists($filepath)) {
            require_once($filepath);
        }

        if (!class_exists($classname)) {
            throw new \moodle_exception('unknownelementtype', 'mod_certstudio', '', $type);
        }

        return new $classname();
    }

    /**
     * Get a list of all available element types.
     *
     * Scans the element/ directory for subplugins.
     *
     * @return array Array of element type data with type, name, icon keys.
     */
    public static function get_available_types(): array {
        global $CFG;

        $types = [];
        $elementdir = $CFG->dirroot . '/mod/certstudio/element';

        if (!is_dir($elementdir)) {
            return $types;
        }

        $dirs = scandir($elementdir);
        foreach ($dirs as $dir) {
            if ($dir === '.' || $dir === '..') {
                continue;
            }

            $classfile = $elementdir . '/' . $dir . '/classes/element.php';
            if (!is_file($classfile)) {
                continue;
            }

            try {
                $element = self::get_element($dir);
                $types[] = [
                    'type' => $dir,
                    'name' => $element->get_name(),
                    'icon' => $element->get_icon(),
                ];
            } catch (\Exception $e) {
                // Skip broken element types.
                debugging('Failed to load element type: ' . $dir . ' - ' . $e->getMessage(), DEBUG_DEVELOPER);
            }
        }

        return $types;
    }
}
