<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Adhoc task to email certificate notifications.
 *
 * @package    mod_certstudio
 * @copyright  2017 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio\task;
/**
 * Adhoc task that sends certificate notification emails to teachers and/or other
 * specified recipients, queued by certificate::issue().
 *
 * The student is normally notified by certificate::issue() itself; the student email
 * here only covers issues whose student was not notified yet, e.g. tasks queued by an
 * older version of the plugin.
 */
class email_certificate_task extends \core\task\adhoc_task {
    /**
     * Return the task name.
     *
     * @return string
     */
    public function get_name() {
        return get_string('taskemailcertificate', 'mod_certstudio');
    }

    /**
     * Execute the task: send certificate emails and mark the issue as emailed.
     */
    public function execute() {
        global $DB;

        $data = $this->get_custom_data();

        if (empty($data->issueid) || empty($data->certstudioid)) {
            mtrace('  email_certificate_task: missing issueid or certstudioid in custom data.');
            return;
        }

        // Look up the issue record. Skip issues deleted or revoked since the task was queued.
        $issue = $DB->get_record('certstudio_issues', ['id' => $data->issueid]);
        if (!$issue || (int) $issue->status !== \mod_certstudio\certificate::STATUS_ACTIVE) {
            mtrace("  email_certificate_task: issue {$data->issueid} not found or no longer active.");
            return;
        }

        // Look up the certstudio record.
        $certstudio = $DB->get_record('certstudio', ['id' => $data->certstudioid]);
        if (!$certstudio) {
            mtrace("  email_certificate_task: certstudio {$data->certstudioid} not found.");
            return;
        }

        // Look up the course.
        $course = $DB->get_record('course', ['id' => $certstudio->course]);
        if (!$course) {
            mtrace("  email_certificate_task: course {$certstudio->course} not found.");
            return;
        }

        // Look up the student.
        $student = \core_user::get_user($issue->userid);
        if (!$student || $student->deleted) {
            mtrace("  email_certificate_task: user {$issue->userid} not found or deleted.");
            return;
        }

        $noreplyuser = \core_user::get_noreply_user();
        $subject = get_string('emailcertificatesubject', 'mod_certstudio', $course->fullname);
        $studentfullname = fullname($student);
        $messagetext = get_string('emailcertificatebody', 'mod_certstudio', (object) [
            'fullname' => $studentfullname,
            'certname' => $certstudio->name,
            'coursename' => $course->fullname,
            'code' => $issue->code,
            'verifyurl' => (new \moodle_url('/mod/certstudio/verify.php', ['code' => $issue->code]))->out(false),
        ]);

        // Email settings are read when the task runs, so a setting switched off in the meantime is respected.
        $emailstudents = get_config('mod_certstudio', 'emailstudents');
        $emailteachers = get_config('mod_certstudio', 'emailteachers');
        $emailothers = get_config('mod_certstudio', 'emailothers');

        // Send to student only if certificate::issue() did not notify them already.
        $studentemailed = false;
        if (!empty($emailstudents) && empty($issue->emailed)) {
            $studentemailed = email_to_user($student, $noreplyuser, $subject, $messagetext);
            mtrace("  Sent certificate email to student {$student->id}.");
        }

        // Send to teachers if enabled.
        if (!empty($emailteachers)) {
            $cm = get_coursemodule_from_instance('certstudio', $certstudio->id, $certstudio->course);
            if ($cm) {
                $context = \context_module::instance($cm->id);
                $teachers = get_enrolled_users($context, 'mod/certstudio:manage');
                $teachermessage = get_string('emailteacherbody', 'mod_certstudio', (object) [
                    'fullname' => $studentfullname,
                    'certname' => $certstudio->name,
                    'coursename' => $course->fullname,
                ]);
                foreach ($teachers as $teacher) {
                    email_to_user($teacher, $noreplyuser, $subject, $teachermessage);
                    mtrace("  Sent certificate email to teacher {$teacher->id}.");
                }
            }
        }

        // Send to other recipients if specified.
        if (!empty($emailothers)) {
            $others = array_map('trim', explode(',', $emailothers));
            $othermessage = get_string('emailteacherbody', 'mod_certstudio', (object) [
                'fullname' => $studentfullname,
                'certname' => $certstudio->name,
                'coursename' => $course->fullname,
            ]);
            foreach ($others as $otheremail) {
                if (!validate_email($otheremail)) {
                    mtrace("  Skipping invalid email: {$otheremail}");
                    continue;
                }
                $otheruser = \core_user::get_noreply_user();
                $otheruser->email = $otheremail;
                email_to_user($otheruser, $noreplyuser, $subject, $othermessage);
                mtrace("  Sent certificate email to {$otheremail}.");
            }
        }

        // The emailed flag means the student has been sent their certificate.
        if ($studentemailed) {
            $DB->set_field('certstudio_issues', 'emailed', 1, ['id' => $issue->id]);
            mtrace("  Marked issue {$issue->id} as emailed.");
        }
    }
}
