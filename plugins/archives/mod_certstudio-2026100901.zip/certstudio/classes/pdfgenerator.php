<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Server-side PDF generator using TCPDF for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
require_once($GLOBALS['CFG']->libdir . '/pdflib.php');

/**
 * Generates PDF certificates server-side using TCPDF.
 *
 * @package    mod_certstudio
 */
class pdfgenerator {
    /**
     * Generate a PDF from template data and return as string.
     *
     * @param object $templatedata The resolved template data from certificate::get_template_data().
     * @return string The PDF content as a string.
     */
    public static function generate($templatedata): string {
        $page = isset($templatedata->pages[0]) ? $templatedata->pages[0] : null;
        if (!$page) {
            // Return a blank PDF.
            $pdf = new \pdf('L', 'mm', 'A4');
            $pdf->AddPage();
            return $pdf->Output('', 'S');
        }

        $w = (float) ($page->width ?? 297);
        $h = (float) ($page->height ?? 210);
        $orientation = $w > $h ? 'L' : 'P';

        $pdf = new \pdf($orientation, 'mm', [$w, $h]);
        $pdf->SetCreator('Certificate Studio');
        $pdf->SetAutoPageBreak(false);
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->AddPage();

        // Background color.
        $bgcolor = $page->bgcolor ?? '#ffffff';
        if ($bgcolor && $bgcolor !== '#ffffff' && $bgcolor !== '#FFFFFF') {
            $rgb = self::hex_to_rgb($bgcolor);
            $pdf->SetFillColor($rgb[0], $rgb[1], $rgb[2]);
            $pdf->Rect(0, 0, $w, $h, 'F');
        }

        // Sort elements by sequence.
        $elements = $page->elements ?? [];
        usort($elements, function ($a, $b) {
            return ($a->sequence ?? 0) - ($b->sequence ?? 0);
        });

        foreach ($elements as $element) {
            self::render_element($pdf, $element);
        }

        return $pdf->Output('', 'S');
    }

    /**
     * Render a single element to the PDF.
     *
     * @param \pdf $pdf TCPDF instance.
     * @param object $element Element data.
     */
    private static function render_element(\pdf $pdf, $element): void {
        $type = $element->type ?? 'text';
        $x = (float) ($element->posx ?? 0);
        $y = (float) ($element->posy ?? 0);
        $w = (float) ($element->width ?? 60);
        $h = (float) ($element->height ?? 10);

        // Decode data.
        $data = $element->data ?? '{}';
        if (is_string($data)) {
            $dataarr = json_decode($data, true) ?? [];
        } else {
            $dataarr = (array) $data;
        }

        // Apply opacity for all element types.
        $opacity = (float)($element->opacity ?? 1);
        $hasopacity = $opacity < 1;
        if ($hasopacity) {
            $pdf->setAlpha($opacity);
        }

        try {
            // Text-based elements.
            $texttypes = ['text', 'studentname', 'coursename', 'categoryname', 'date', 'grade',
            'gradeitemname', 'teachername', 'userfield', 'coursefield', 'daterange',
            'expiry', 'code', 'certdate', 'certstatement'];

            if (in_array($type, $texttypes)) {
                $content = $dataarr['resolvedtext'] ?? '';
                if (empty($content) && $type === 'text') {
                    $content = $dataarr['text'] ?? '';
                }
                if (empty($content)) {
                    return;
                }

                // Font setup.
                $fontfamily = $element->fontfamily ?? 'Helvetica';
                $fontsize = (float) ($element->fontsize ?? 12);
                $color = self::hex_to_rgb($element->color ?? '#000000');
                $alignment = $element->alignment ?? 'L';

                // Map font families to the Unicode fonts that ship with Moodle's TCPDF. The core helvetica and
                // times fonts print '?' for Greek and other non-Latin text, and the dejavu fonts are not included.
                $seriffonts = ['Noto Serif', 'Merriweather', 'Playfair Display', 'GFS Didot', 'Times'];
                $tcpdffont = in_array($fontfamily, $seriffonts, true) ? 'freeserif' : 'freesans';

                // Font style.
                $style = '';
                if (($element->fontweight ?? '') === 'bold') {
                    $style .= 'B';
                }
                if (($element->fontstyle ?? '') === 'italic') {
                    $style .= 'I';
                }

                $pdf->SetFont($tcpdffont, $style, $fontsize);
                $pdf->SetTextColor($color[0], $color[1], $color[2]);

                // Map alignment.
                $alignmap = ['L' => 'L', 'C' => 'C', 'R' => 'R', 'left' => 'L', 'center' => 'C', 'right' => 'R'];
                $align = $alignmap[$alignment] ?? 'L';

                // Use MultiCell for text rendering.
                $pdf->SetXY($x, $y);
                $pdf->MultiCell($w > 0 ? $w : 0, $h > 0 ? $h : $fontsize * 0.3528, $content, 0, $align, false, 1, $x, $y);
                return;
            }

            // Border element.
            if ($type === 'border') {
                $bordercolor = self::hex_to_rgb($dataarr['bordercolor'] ?? '#000000');
                $borderwidth = (float) ($dataarr['borderwidth'] ?? 1);
                $pdf->SetDrawColor($bordercolor[0], $bordercolor[1], $bordercolor[2]);
                $pdf->SetLineWidth($borderwidth * 0.3528);
                $pdf->Rect($x, $y, $w, $h, 'D');
                return;
            }

            // Image element.
            if (in_array($type, ['image', 'bgimage', 'digitalsignature', 'userpicture'])) {
                $src = $dataarr['src'] ?? '';
                if (empty($src)) {
                    return;
                }

                // Resolve the image source to something TCPDF can use.
                $imgsrc = self::resolve_image_src($src);
                if (empty($imgsrc)) {
                    return;
                }

                // Calculate draw dimensions based on sizemode.
                $sizemode = $dataarr['sizemode'] ?? ($type === 'bgimage' ? 'cover' : 'stretch');
                [$dx, $dy, $dw, $dh] = self::calc_image_dimensions($imgsrc, $x, $y, $w, $h, $sizemode);

                try {
                    // Convert SVG files to PNG for reliable PDF rendering.
                    $issvg = false;
                    if (is_string($imgsrc) && strpos($imgsrc, '@') !== 0) {
                        $issvg = (pathinfo($imgsrc, PATHINFO_EXTENSION) === 'svg');
                    }

                    if ($issvg) {
                        $pngpath = self::svg_to_png($imgsrc, $w, $h);
                        if ($pngpath) {
                            $imgsrc = $pngpath;
                        } else {
                            // Fallback to TCPDF's limited SVG support.
                            $pdf->ImageSVG($imgsrc, $x, $y, $w, $h);
                            return;
                        }
                    }

                    if ($sizemode === 'cover') {
                        // For cover mode, clip to the element bounding box.
                        $pdf->StartTransform();
                        $pdf->Rect($x, $y, $w, $h, 'CNZ');
                        $pdf->Image($imgsrc, $dx, $dy, $dw, $dh, '', '', '', false, 300);
                        $pdf->StopTransform();
                    } else {
                        $pdf->Image($imgsrc, $dx, $dy, $dw, $dh, '', '', '', false, 300);
                    }
                } catch (\Exception $e) {
                    // Skip failed images.
                    unset($e);
                }

                return;
            }

            // QR Code element.
            if ($type === 'qrcode') {
                $qrcontent = $dataarr['resolvedtext'] ?? '';
                if (!empty($qrcontent)) {
                    $qrurl = (new \moodle_url('/mod/certstudio/verify.php', ['code' => $qrcontent]))->out(false);
                    $qrsize = min($w, $h);
                    $style = [
                    'border' => false,
                    'padding' => 0,
                    'fgcolor' => [0, 0, 0],
                    'bgcolor' => false,
                    ];
                    $pdf->write2DBarcode($qrurl, 'QRCODE,M', $x, $y, $qrsize, $qrsize, $style);
                }
                return;
            }
        } catch (\Throwable $e) {
            // Skip an element that cannot be rendered instead of failing the whole certificate,
            // which would also stop a bulk email or leave the certificate out of a ZIP export.
            debugging(
                'Certificate Studio: could not render element ' . ($element->type ?? '?') . ': ' . $e->getMessage(),
                DEBUG_DEVELOPER
            );
        } finally {
            // Reset opacity after rendering.
            if ($hasopacity) {
                $pdf->setAlpha(1);
            }
        }
    }

    /**
     * Resolve an image src to a path or data string TCPDF can use.
     *
     * Handles data URIs, Moodle pluginfile URLs (resolved to local path), and external URLs.
     *
     * @param string $src The image source URL or data URI.
     * @return string The resolved image path/data, or empty string on failure.
     */
    private static function resolve_image_src(string $src): string {
        // Data URI — return as TCPDF @data format.
        if (strpos($src, 'data:image') === 0) {
            $parts = explode(',', $src, 2);
            $decoded = base64_decode($parts[1] ?? '');
            if ($decoded === false) {
                return '';
            }
            return '@' . $decoded;
        }

        global $CFG;

        // Reduce a URL on this site to its path below wwwroot.
        $relpath = $src;
        if (strpos($relpath, $CFG->wwwroot) === 0) {
            $relpath = substr($relpath, strlen($CFG->wwwroot));
        } else {
            $wwwpath = parse_url($CFG->wwwroot, PHP_URL_PATH) ?: '';
            if ($wwwpath !== '' && $wwwpath !== '/' && strpos($relpath, $wwwpath . '/') === 0) {
                $relpath = substr($relpath, strlen($wwwpath));
            }
        }

        // Files uploaded to the plugin on this site.
        if (strpos($relpath, '/pluginfile.php/') === 0) {
            return self::resolve_pluginfile($relpath) ?? '';
        }

        // Images shipped with the plugin, such as the built-in backgrounds. Stay inside the plugin directory.
        if (strpos($relpath, '/mod/certstudio/') === 0) {
            $plugindir = realpath($CFG->dirroot . '/mod/certstudio');
            $localpath = realpath($CFG->dirroot . $relpath);
            if ($plugindir && $localpath && strpos($localpath, $plugindir . DIRECTORY_SEPARATOR) === 0) {
                return $localpath;
            }
            return '';
        }

        // Any other web address is downloaded by Moodle, not by TCPDF, so the site's blocked hosts apply.
        if (preg_match('#^https?://#i', $src)) {
            return self::download_image($src);
        }

        return '';
    }

    /**
     * Download an external image through Moodle's curl.
     *
     * Moodle's curl refuses the hosts and ports blocked in the site security settings, which by default include
     * local and private networks, so a certificate cannot be used to reach internal services. Only raster images
     * are accepted, because an SVG can reference further URLs.
     *
     * @param string $url The image URL.
     * @return string Path to a temporary copy, or '' if the image cannot be used.
     */
    private static function download_image(string $url): string {
        global $CFG;
        require_once($CFG->libdir . '/filelib.php');

        $curl = new \curl();
        $content = $curl->get($url, [], ['CURLOPT_TIMEOUT' => 15, 'CURLOPT_CONNECTTIMEOUT' => 5]);
        $info = $curl->get_info();
        if (
            $curl->get_errno() || !empty($curl->error) || (int) ($info['http_code'] ?? 0) !== 200 ||
            !is_string($content) || $content === '' || strlen($content) > 10 * 1024 * 1024
        ) {
            return '';
        }
        $size = getimagesizefromstring($content);
        if (!$size || !in_array($size[2], [IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true)) {
            return '';
        }

        $tmpfile = make_temp_directory('mod_certstudio') . '/ext_' . sha1($content) . image_type_to_extension($size[2]);
        if (!file_exists($tmpfile)) {
            file_put_contents($tmpfile, $content);
        }
        return $tmpfile;
    }

    /**
     * Resolve a Moodle pluginfile URL to a local file path.
     *
     * @param string $url The pluginfile URL.
     * @return string|null Local file path or null.
     */
    private static function resolve_pluginfile(string $url): ?string {
        global $CFG;

        // Parse the pluginfile URL to extract component/filearea/itemid/filename.
        // Format: /pluginfile.php/contextid/component/filearea/itemid/filepath/filename.
        $path = parse_url($url, PHP_URL_PATH);
        if (!$path) {
            return null;
        }
        // Remove everything up to and including pluginfile.php.
        $pos = strpos($path, '/pluginfile.php/');
        if ($pos === false) {
            return null;
        }
        $relpath = substr($path, $pos + strlen('/pluginfile.php/'));
        $parts = explode('/', $relpath);
        if (count($parts) < 4) {
            return null;
        }

        $contextid = (int)$parts[0];
        $component = $parts[1];
        $filearea = $parts[2];
        $itemid = (int)$parts[3];
        $filename = urldecode(end($parts));

        // Only the plugin's own design images: files of other components, such as assignment
        // submissions or private files, must never be pulled into a certificate.
        $designareas = ['image', 'bgimage', 'digitalsignature', 'userpicture', 'background', 'elementimage'];
        if ($component !== 'mod_certstudio' || !in_array($filearea, $designareas, true)) {
            return null;
        }

        $fs = get_file_storage();
        $file = $fs->get_file($contextid, $component, $filearea, $itemid, '/', $filename);
        if (!$file || $file->is_directory()) {
            return null;
        }

        // Copy to a temp file so TCPDF can read it, keyed by content so a re-uploaded image is not served stale.
        $tempdir = make_temp_directory('mod_certstudio');
        $tmpfile = $tempdir . '/img_' . $file->get_contenthash() . '_' . clean_filename($filename);
        if (!file_exists($tmpfile)) {
            $file->copy_content_to($tmpfile);
        }
        return $tmpfile;
    }

    /**
     * Calculate image draw dimensions based on sizemode.
     *
     * @param string $imgsrc Resolved image path/data.
     * @param float $x Element X position.
     * @param float $y Element Y position.
     * @param float $w Element width.
     * @param float $h Element height.
     * @param string $sizemode One of: cover, contain, stretch, actual.
     * @return array [dx, dy, dw, dh] Draw coordinates and dimensions.
     */
    private static function calc_image_dimensions(
        string $imgsrc,
        float $x,
        float $y,
        float $w,
        float $h,
        string $sizemode
    ): array {
        // Default: stretch to element bounds.
        if ($sizemode === 'stretch' || $w <= 0 || $h <= 0) {
            return [$x, $y, $w, $h];
        }

        // Get the image's natural dimensions.
        $imgsize = null;
        if (strpos($imgsrc, '@') === 0) {
            // Data string — write to a request-scoped temp dir to get size.
            $reqdir = make_request_directory();
            $tmp = $reqdir . '/csimg_' . md5($imgsrc) . '.tmp';
            file_put_contents($tmp, substr($imgsrc, 1));
            $imgsize = @getimagesize($tmp);
            @unlink($tmp);
        } else {
            $imgsize = @getimagesize($imgsrc);
        }

        if (!$imgsize || $imgsize[0] <= 0 || $imgsize[1] <= 0) {
            return [$x, $y, $w, $h];
        }

        $imgw = $imgsize[0];
        $imgh = $imgsize[1];
        $imgratio = $imgw / $imgh;
        $boxratio = $w / $h;

        $dx = $x;
        $dy = $y;
        $dw = $w;
        $dh = $h;

        if ($sizemode === 'cover') {
            if ($imgratio > $boxratio) {
                $dh = $h;
                $dw = $h * $imgratio;
            } else {
                $dw = $w;
                $dh = $w / $imgratio;
            }
            $dx = $x + ($w - $dw) / 2;
            $dy = $y + ($h - $dh) / 2;
        } else if ($sizemode === 'contain') {
            if ($imgratio > $boxratio) {
                $dw = $w;
                $dh = $w / $imgratio;
            } else {
                $dh = $h;
                $dw = $h * $imgratio;
            }
            $dx = $x + ($w - $dw) / 2;
            $dy = $y + ($h - $dh) / 2;
        } else if ($sizemode === 'actual') {
            // 1px ≈ 0.2646mm at 96dpi.
            $dw = $imgw * 0.2646;
            $dh = $imgh * 0.2646;
            $dx = $x + ($w - $dw) / 2;
            $dy = $y + ($h - $dh) / 2;
        }

        return [$dx, $dy, $dw, $dh];
    }

    /**
     * Convert an SVG file to PNG for reliable PDF embedding.
     *
     * Uses rsvg-convert (librsvg) if available, otherwise returns null.
     *
     * @param string $svgpath Path to the SVG file.
     * @param float $wmm Width in mm.
     * @param float $hmm Height in mm.
     * @return string|null Path to the generated PNG, or null on failure.
     */
    private static function svg_to_png(string $svgpath, float $wmm, float $hmm): ?string {
        global $CFG;

        // Check cache first.
        $hash = md5($svgpath . $wmm . $hmm);
        $tempdir = make_temp_directory('mod_certstudio');
        $pngpath = $tempdir . '/svg_' . $hash . '.png';
        if (file_exists($pngpath)) {
            return $pngpath;
        }

        // Convert mm to px at 150 DPI (good balance of quality vs size).
        $dpi = 150;
        $wpx = (int) round($wmm * $dpi / 25.4);
        $hpx = (int) round($hmm * $dpi / 25.4);

        // Try rsvg-convert.
        $rsvg = trim(shell_exec('which rsvg-convert 2>/dev/null') ?? '');
        if (!empty($rsvg) && file_exists($svgpath)) {
            $cmd = escapeshellcmd($rsvg)
                . ' -w ' . $wpx . ' -h ' . $hpx
                . ' -f png'
                . ' -o ' . escapeshellarg($pngpath)
                . ' ' . escapeshellarg($svgpath);
            exec($cmd . ' 2>&1', $output, $retval);
            if ($retval === 0 && file_exists($pngpath)) {
                return $pngpath;
            }
        }

        return null;
    }

    /**
     * Convert hex color to RGB array.
     *
     * @param string $hex Hex color string.
     * @return array [r, g, b]
     */
    private static function hex_to_rgb(string $hex): array {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        if (strlen($hex) !== 6) {
            return [0, 0, 0];
        }
        return [
            hexdec(substr($hex, 0, 2)),
            hexdec(substr($hex, 2, 2)),
            hexdec(substr($hex, 4, 2)),
        ];
    }
}
