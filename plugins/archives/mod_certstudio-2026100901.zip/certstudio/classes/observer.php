<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event observer for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * Observes events and triggers auto-issuance of certificates.
 *
 * @package    mod_certstudio
 */
class observer {
    /**
     * Handle course completion events.
     *
     * When a user completes a course, auto-issue certificates for any
     * certstudio activities in that course that have autoissue enabled.
     *
     * @param \core\event\course_completed $event
     */
    public static function course_completed(\core\event\course_completed $event): void {
        global $DB;

        // Auto-issue on course completion is a site-wide setting.
        if (empty(get_config('mod_certstudio', 'autoissue'))) {
            return;
        }

        $courseid = $event->courseid;
        $userid = $event->relateduserid;

        foreach (get_fast_modinfo($courseid, $userid)->get_instances_of('certstudio') as $cm) {
            $activity = $DB->get_record('certstudio', ['id' => $cm->instance]);
            if (!$activity) {
                continue;
            }

            // Same rules as the student's own request. This also skips activities with the approval
            // workflow, users who already have a certificate (active or revoked), activities the user
            // cannot access and users who have not spent the required time.
            if (certificate::can_issue($activity, $cm->id, $userid) !== null) {
                continue;
            }

            certificate::issue($activity->id, $userid);
        }
    }
}
