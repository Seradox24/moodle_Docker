<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External API for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;

/**
 * External API class for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class external extends external_api {

    /**
     * Resolve course module, context, and validate manage capability.
     *
     * @param int $cmid The course module ID.
     * @return array [$cm, $context, $certstudio]
     */
    private static function resolve_cm(int $cmid): array {
        global $DB;
        $cm = get_coursemodule_from_id('certstudio', $cmid, 0, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/certstudio:manage', $context);
        $certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);
        return [$cm, $context, $certstudio];
    }

    /**
     * Check that a page belongs to the activity's own template.
     *
     * The manage capability is checked on the activity only, so pages of other activities' templates
     * and of the shared gallery must not be reachable through it.
     *
     * @param int $pageid The page ID.
     * @param \stdClass $certstudio The certstudio activity record.
     * @throws \moodle_exception If the page is not part of the activity's template.
     */
    private static function require_own_page(int $pageid, \stdClass $certstudio): void {
        global $DB;
        if (
            empty($certstudio->templateid) ||
            !$DB->record_exists('certstudio_pages', ['id' => $pageid, 'templateid' => $certstudio->templateid])
        ) {
            throw new \moodle_exception('invalidpagedata', 'mod_certstudio');
        }
    }

    /**
     * Check that an existing element is on a page of the activity's own template.
     *
     * @param int $elementid The element ID.
     * @param \stdClass $certstudio The certstudio activity record.
     * @throws \moodle_exception If the element does not exist or is not part of the activity's template.
     */
    private static function require_own_element(int $elementid, \stdClass $certstudio): void {
        global $DB;
        $pageid = $DB->get_field('certstudio_elements', 'pageid', ['id' => $elementid]);
        if ($pageid === false) {
            throw new \moodle_exception('invalidelementdata', 'mod_certstudio');
        }
        self::require_own_page((int) $pageid, $certstudio);
    }

    /**
     * Build an element DB record from raw element data.
     *
     * @param array $elementdata The raw element data.
     * @return \stdClass The element record.
     */
    private static function build_element_record(array $elementdata): \stdClass {
        $record = new \stdClass();
        $record->pageid = (int) $elementdata['pageid'];
        $record->name = clean_param($elementdata['name'] ?? '', PARAM_TEXT);
        $record->type = clean_param($elementdata['type'], PARAM_ALPHANUMEXT);
        // Always an object: an empty array would reach the editor as a JS Array, which drops named settings.
        $record->data = json_encode((object) ($elementdata['data'] ?? []));
        $record->posx = (float) $elementdata['posx'];
        $record->posy = (float) $elementdata['posy'];
        $record->width = (float) $elementdata['width'];
        $record->height = (float) $elementdata['height'];
        $record->rotation = (int) ($elementdata['rotation'] ?? 0);
        $record->fontfamily = clean_param($elementdata['fontfamily'] ?? 'Roboto', PARAM_TEXT);
        $record->fontsize = (int) ($elementdata['fontsize'] ?? 14);
        $record->fontweight = clean_param($elementdata['fontweight'] ?? 'normal', PARAM_ALPHA);
        $record->fontstyle = clean_param($elementdata['fontstyle'] ?? 'normal', PARAM_ALPHA);
        $record->color = clean_param($elementdata['color'] ?? '#000000', PARAM_TEXT);
        $record->alignment = clean_param($elementdata['alignment'] ?? 'L', PARAM_ALPHA);
        $record->opacity = (float) ($elementdata['opacity'] ?? 1);
        $record->locked = (int) ($elementdata['locked'] ?? 0);
        $record->sequence = (int) ($elementdata['sequence'] ?? 0);
        $record->timemodified = time();
        return $record;
    }

    // -----------------------------------------------------------------------
    // save_element
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for save_element.
     *
     * @return external_function_parameters
     */
    public static function save_element_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'    => new external_value(PARAM_INT, 'Course module ID'),
            'element' => new external_value(PARAM_RAW, 'JSON-encoded element data'),
        ]);
    }

    /**
     * Save or update a single certificate element.
     *
     * @param int    $cmid    Course module ID.
     * @param string $element JSON-encoded element data.
     * @return array
     */
    public static function save_element(int $cmid, string $element): array {
        global $DB;
        $params = self::validate_parameters(self::save_element_parameters(), [
            'cmid' => $cmid, 'element' => $element,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        $elementdata = json_decode($params['element'], true);
        if (!$elementdata) {
            throw new \moodle_exception('invalidelementdata', 'mod_certstudio');
        }

        $record = self::build_element_record($elementdata);
        self::require_own_page($record->pageid, $certstudio);

        if (!empty($elementdata['id']) && is_numeric($elementdata['id'])) {
            $record->id = (int) $elementdata['id'];
            self::require_own_element($record->id, $certstudio);
            $DB->update_record('certstudio_elements', $record);
        } else {
            $record->timecreated = time();
            $record->id = $DB->insert_record('certstudio_elements', $record);
        }

        return ['id' => (int) $record->id];
    }

    /**
     * Describes the return value for save_element.
     *
     * @return external_single_structure
     */
    public static function save_element_returns(): external_single_structure {
        return new external_single_structure([
            'id' => new external_value(PARAM_INT, 'The saved element ID'),
        ]);
    }

    // -----------------------------------------------------------------------
    // delete_element
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for delete_element.
     *
     * @return external_function_parameters
     */
    public static function delete_element_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'      => new external_value(PARAM_INT, 'Course module ID'),
            'elementid' => new external_value(PARAM_INT, 'The element ID to delete'),
        ]);
    }

    /**
     * Delete a certificate element.
     *
     * @param int $cmid      Course module ID.
     * @param int $elementid Element ID.
     * @return bool
     */
    public static function delete_element(int $cmid, int $elementid): bool {
        global $DB;
        $params = self::validate_parameters(self::delete_element_parameters(), [
            'cmid' => $cmid, 'elementid' => $elementid,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        $pageid = $DB->get_field('certstudio_elements', 'pageid', ['id' => $params['elementid']]);
        if ($pageid === false) {
            // Already deleted.
            return true;
        }
        self::require_own_page((int) $pageid, $certstudio);
        $DB->delete_records('certstudio_elements', ['id' => $params['elementid']]);
        return true;
    }

    /**
     * Describes the return value for delete_element.
     *
     * @return external_value
     */
    public static function delete_element_returns(): external_value {
        return new external_value(PARAM_BOOL, 'True on success');
    }

    // -----------------------------------------------------------------------
    // save_elements
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for save_elements.
     *
     * @return external_function_parameters
     */
    public static function save_elements_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'     => new external_value(PARAM_INT, 'Course module ID'),
            'elements' => new external_value(PARAM_RAW, 'JSON-encoded array of element data'),
        ]);
    }

    /**
     * Save or update multiple certificate elements in batch.
     *
     * @param int    $cmid     Course module ID.
     * @param string $elements JSON-encoded array of element data.
     * @return array
     */
    public static function save_elements(int $cmid, string $elements): array {
        global $DB;
        $params = self::validate_parameters(self::save_elements_parameters(), [
            'cmid' => $cmid, 'elements' => $elements,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        $elementsdata = json_decode($params['elements'], true);
        if (!is_array($elementsdata)) {
            throw new \moodle_exception('invalidelementdata', 'mod_certstudio');
        }

        $savepageid = 0;
        if (!empty($elementsdata)) {
            $savepageid = (int) ($elementsdata[0]['pageid'] ?? 0);
        }

        // Check every page and element before writing anything, so a rejected batch changes nothing.
        foreach ($elementsdata as $elementdata) {
            self::require_own_page((int) ($elementdata['pageid'] ?? 0), $certstudio);
            if (!empty($elementdata['id']) && is_numeric($elementdata['id'])) {
                self::require_own_element((int) $elementdata['id'], $certstudio);
            }
        }

        $ids = [];
        foreach ($elementsdata as $elementdata) {
            $record = self::build_element_record($elementdata);

            if (!empty($elementdata['id']) && is_numeric($elementdata['id'])) {
                $record->id = (int) $elementdata['id'];
                $DB->update_record('certstudio_elements', $record);
            } else {
                $record->timecreated = time();
                $record->id = $DB->insert_record('certstudio_elements', $record);
            }
            $ids[] = (int) $record->id;
        }

        // Delete orphan elements on this page that were not in the save request.
        if ($savepageid > 0 && !empty($ids)) {
            [$insql, $delparams] = $DB->get_in_or_equal($ids, SQL_PARAMS_NAMED, 'id', false);
            $delparams['pageid'] = $savepageid;
            $DB->delete_records_select('certstudio_elements', "pageid = :pageid AND id $insql", $delparams);
        }

        return ['ids' => $ids];
    }

    /**
     * Describes the return value for save_elements.
     *
     * @return external_single_structure
     */
    public static function save_elements_returns(): external_single_structure {
        return new external_single_structure([
            'ids' => new external_multiple_structure(
                new external_value(PARAM_INT, 'Element ID')
            ),
        ]);
    }

    // -----------------------------------------------------------------------
    // save_page
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for save_page.
     *
     * @return external_function_parameters
     */
    public static function save_page_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
            'page' => new external_value(PARAM_RAW, 'JSON-encoded page settings'),
        ]);
    }

    /**
     * Save page settings for a certificate template.
     *
     * @param int    $cmid Course module ID.
     * @param string $page JSON-encoded page settings.
     * @return bool
     */
    public static function save_page(int $cmid, string $page): bool {
        global $DB;
        $params = self::validate_parameters(self::save_page_parameters(), [
            'cmid' => $cmid, 'page' => $page,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        $pagedata = json_decode($params['page'], true);
        if (!$pagedata || empty($pagedata['id'])) {
            throw new \moodle_exception('invalidpagedata', 'mod_certstudio');
        }
        self::require_own_page((int) $pagedata['id'], $certstudio);

        $record = new \stdClass();
        $record->id = (int) $pagedata['id'];
        $record->width = (int) $pagedata['width'];
        $record->height = (int) $pagedata['height'];
        $record->leftmargin = (int) ($pagedata['leftmargin'] ?? 0);
        $record->rightmargin = (int) ($pagedata['rightmargin'] ?? 0);
        $record->bgcolor = clean_param($pagedata['bgcolor'] ?? '#ffffff', PARAM_TEXT);
        $record->backgroundimage = clean_param($pagedata['backgroundimage'] ?? '', PARAM_URL);
        $record->timemodified = time();

        $DB->update_record('certstudio_pages', $record);
        return true;
    }

    /**
     * Describes the return value for save_page.
     *
     * @return external_value
     */
    public static function save_page_returns(): external_value {
        return new external_value(PARAM_BOOL, 'True on success');
    }

    // -----------------------------------------------------------------------
    // use_template
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for use_template.
     *
     * @return external_function_parameters
     */
    public static function use_template_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'       => new external_value(PARAM_INT, 'Course module ID'),
            'templateid' => new external_value(PARAM_INT, 'Template ID to use'),
        ]);
    }

    /**
     * Duplicate a gallery template for use in this activity.
     *
     * @param int $cmid       Course module ID.
     * @param int $templateid Template ID to duplicate.
     * @return array
     */
    public static function use_template(int $cmid, int $templateid): array {
        global $DB;
        $params = self::validate_parameters(self::use_template_parameters(), [
            'cmid' => $cmid, 'templateid' => $templateid,
        ]);
        [, $context, $certstudio] = self::resolve_cm($params['cmid']);

        $template = new \mod_certstudio\template();
        $sourcetemplate = \mod_certstudio\template::get($params['templateid']);
        // Only gallery templates, or templates of activities the user can manage, may be copied.
        $sourcecontext = $sourcetemplate ? \context::instance_by_id($sourcetemplate->contextid, IGNORE_MISSING) : false;
        if (
            !$sourcecontext ||
            ($sourcecontext->contextlevel != CONTEXT_SYSTEM && !has_capability('mod/certstudio:manage', $sourcecontext))
        ) {
            throw new \moodle_exception('templatenotfound', 'mod_certstudio');
        }
        $sourcename = $sourcetemplate->name;
        $newtemplateid = $template->duplicate($params['templateid'], $sourcename);

        $DB->set_field('certstudio_templates', 'contextid', $context->id, ['id' => $newtemplateid]);
        $DB->set_field('certstudio', 'templateid', $newtemplateid, ['id' => $certstudio->id]);

        // Remove the previous design if it was this activity's own and nothing else uses it.
        if (!empty($certstudio->templateid)) {
            \mod_certstudio\template::delete_if_unused((int) $certstudio->templateid, $context->id);
        }

        return ['templateid' => (int) $newtemplateid];
    }

    /**
     * Describes the return value for use_template.
     *
     * @return external_single_structure
     */
    public static function use_template_returns(): external_single_structure {
        return new external_single_structure([
            'templateid' => new external_value(PARAM_INT, 'The new template ID'),
        ]);
    }

    // -----------------------------------------------------------------------
    // create_blank
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for create_blank.
     *
     * @return external_function_parameters
     */
    public static function create_blank_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
        ]);
    }

    /**
     * Create a blank certificate template for this activity.
     *
     * @param int $cmid Course module ID.
     * @return array
     */
    public static function create_blank(int $cmid): array {
        global $DB;
        $params = self::validate_parameters(self::create_blank_parameters(), [
            'cmid' => $cmid,
        ]);
        [, $context, $certstudio] = self::resolve_cm($params['cmid']);

        $template = new \mod_certstudio\template();

        $newtemplateid = $template->create($certstudio->name, $context->id);
        $DB->set_field('certstudio', 'templateid', $newtemplateid, ['id' => $certstudio->id]);

        // Remove the previous design if it was this activity's own and nothing else uses it.
        if (!empty($certstudio->templateid)) {
            \mod_certstudio\template::delete_if_unused((int) $certstudio->templateid, $context->id);
        }

        $newpage = $DB->get_record('certstudio_pages', ['templateid' => $newtemplateid], 'id', IGNORE_MULTIPLE);
        $pageid = $newpage ? (int) $newpage->id : 0;

        return ['templateid' => (int) $newtemplateid, 'pageid' => $pageid];
    }

    /**
     * Describes the return value for create_blank.
     *
     * @return external_single_structure
     */
    public static function create_blank_returns(): external_single_structure {
        return new external_single_structure([
            'templateid' => new external_value(PARAM_INT, 'The new template ID'),
            'pageid'     => new external_value(PARAM_INT, 'The page ID of the new template'),
        ]);
    }

    // -----------------------------------------------------------------------
    // rename_template
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for rename_template.
     *
     * @return external_function_parameters
     */
    public static function rename_template_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
            'name' => new external_value(PARAM_TEXT, 'New template name'),
        ]);
    }

    /**
     * Rename the template for this activity.
     *
     * @param int    $cmid Course module ID.
     * @param string $name New name.
     * @return array
     */
    public static function rename_template(int $cmid, string $name): array {
        global $DB;
        $params = self::validate_parameters(self::rename_template_parameters(), [
            'cmid' => $cmid, 'name' => $name,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        $newname = trim($params['name']);
        if (empty($newname)) {
            throw new \moodle_exception('invalidname', 'mod_certstudio');
        }
        if (!empty($certstudio->templateid)) {
            \mod_certstudio\template::update($certstudio->templateid, ['name' => $newname]);
        }

        return ['name' => $newname];
    }

    /**
     * Describes the return value for rename_template.
     *
     * @return external_single_structure
     */
    public static function rename_template_returns(): external_single_structure {
        return new external_single_structure([
            'name' => new external_value(PARAM_TEXT, 'The updated name'),
        ]);
    }

    // -----------------------------------------------------------------------
    // publish_to_gallery
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for publish_to_gallery.
     *
     * @return external_function_parameters
     */
    public static function publish_to_gallery_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
        ]);
    }

    /**
     * Publish a copy of this activity's template to the site-wide gallery.
     *
     * @param int $cmid Course module ID.
     * @return array
     */
    public static function publish_to_gallery(int $cmid): array {
        global $DB;
        $params = self::validate_parameters(self::publish_to_gallery_parameters(), [
            'cmid' => $cmid,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        if (empty($certstudio->templateid)) {
            throw new \moodle_exception('templatenotfound', 'mod_certstudio');
        }

        $template = new \mod_certstudio\template();
        $sourcetemplate = \mod_certstudio\template::get($certstudio->templateid);
        $sourcename = $sourcetemplate ? $sourcetemplate->name : $certstudio->name;
        $systemctx = \context_system::instance();
        $newid = $template->duplicate($certstudio->templateid, $sourcename);
        $DB->set_field('certstudio_templates', 'contextid', $systemctx->id, ['id' => $newid]);

        return ['templateid' => (int) $newid, 'name' => $sourcename];
    }

    /**
     * Describes the return value for publish_to_gallery.
     *
     * @return external_single_structure
     */
    public static function publish_to_gallery_returns(): external_single_structure {
        return new external_single_structure([
            'templateid' => new external_value(PARAM_INT, 'The published template ID'),
            'name'       => new external_value(PARAM_TEXT, 'The template name'),
        ]);
    }

    // -----------------------------------------------------------------------
    // delete_issue
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for delete_issue.
     *
     * @return external_function_parameters
     */
    public static function delete_issue_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'    => new external_value(PARAM_INT, 'Course module ID'),
            'issueid' => new external_value(PARAM_INT, 'The issue ID to delete'),
        ]);
    }

    /**
     * Delete an issued certificate.
     *
     * @param int $cmid    Course module ID.
     * @param int $issueid Issue ID.
     * @return bool
     */
    public static function delete_issue(int $cmid, int $issueid): bool {
        global $DB;
        $params = self::validate_parameters(self::delete_issue_parameters(), [
            'cmid' => $cmid, 'issueid' => $issueid,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        $issue = $DB->get_record('certstudio_issues', [
            'id'           => $params['issueid'],
            'certstudioid' => $certstudio->id,
        ], '*', MUST_EXIST);

        \mod_certstudio\certificate::delete_issue($issue->id);
        return true;
    }

    /**
     * Describes the return value for delete_issue.
     *
     * @return external_value
     */
    public static function delete_issue_returns(): external_value {
        return new external_value(PARAM_BOOL, 'True if deleted successfully');
    }

    // -----------------------------------------------------------------------
    // revoke_issue
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for revoke_issue.
     *
     * @return external_function_parameters
     */
    public static function revoke_issue_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'    => new external_value(PARAM_INT, 'Course module ID'),
            'issueid' => new external_value(PARAM_INT, 'The issue ID to revoke'),
            'reason'  => new external_value(PARAM_TEXT, 'Reason for revocation', VALUE_DEFAULT, ''),
        ]);
    }

    /**
     * Revoke an issued certificate.
     *
     * @param int    $cmid    Course module ID.
     * @param int    $issueid Issue ID.
     * @param string $reason  Reason.
     * @return bool
     */
    public static function revoke_issue(int $cmid, int $issueid, string $reason = ''): bool {
        global $DB;
        $params = self::validate_parameters(self::revoke_issue_parameters(), [
            'cmid' => $cmid, 'issueid' => $issueid, 'reason' => $reason,
        ]);
        [, , $certstudio] = self::resolve_cm($params['cmid']);

        $issue = $DB->get_record('certstudio_issues', [
            'id'           => $params['issueid'],
            'certstudioid' => $certstudio->id,
        ], '*', MUST_EXIST);

        \mod_certstudio\certificate::revoke($issue->id, $params['reason']);
        return true;
    }

    /**
     * Describes the return value for revoke_issue.
     *
     * @return external_value
     */
    public static function revoke_issue_returns(): external_value {
        return new external_value(PARAM_BOOL, 'True if revoked successfully');
    }

    // -----------------------------------------------------------------------
    // issue_cert
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for issue_cert.
     *
     * @return external_function_parameters
     */
    public static function issue_cert_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
        ]);
    }

    /**
     * Issue a certificate for the current user.
     *
     * @param int $cmid Course module ID.
     * @return array
     */
    public static function issue_cert(int $cmid): array {
        global $DB, $USER;
        $params = self::validate_parameters(self::issue_cert_parameters(), [
            'cmid' => $cmid,
        ]);

        // Use a lighter capability check — students need to issue their own cert.
        $cm = get_coursemodule_from_id('certstudio', $params['cmid'], 0, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/certstudio:view', $context);

        $certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

        $certificate = new \mod_certstudio\certificate();
        $issues = $certificate->get_issues_for_user($certstudio->id, $USER->id);
        if (empty($issues)) {
            // Same rules as the activity page: approval, required time, revocation and access.
            $reason = \mod_certstudio\certificate::can_issue($certstudio, $cm->id, $USER->id);
            if ($reason !== null) {
                throw new \moodle_exception('cannotissue_' . $reason, 'mod_certstudio');
            }
            $certificate->issue($certstudio->id, $USER->id);
            $issues = $certificate->get_issues_for_user($certstudio->id, $USER->id);
        }
        $issue = reset($issues);
        // Resolved for the issue, so the certificate shows its issue and expiry dates.
        $templatedata = $certificate->get_template_data($certstudio->id, $USER->id, $issue->code);

        return [
            'templatedata' => json_encode($templatedata),
            'code'         => $issue->code,
        ];
    }

    /**
     * Describes the return value for issue_cert.
     *
     * @return external_single_structure
     */
    public static function issue_cert_returns(): external_single_structure {
        return new external_single_structure([
            'templatedata' => new external_value(PARAM_RAW, 'JSON-encoded template data for PDF rendering'),
            'code'         => new external_value(PARAM_TEXT, 'The certificate verification code'),
        ]);
    }

    // -----------------------------------------------------------------------
    // list_issues
    // -----------------------------------------------------------------------

    /**
     * Describes the parameters for list_issues.
     *
     * @return external_function_parameters
     */
    public static function list_issues_parameters(): external_function_parameters {
        return new external_function_parameters([
            'timecreatedfrom' => new external_value(PARAM_INT, 'Filter issues created on or after this timestamp',
                VALUE_OPTIONAL),
            'userid'          => new external_value(PARAM_INT, 'Filter issues for a specific user', VALUE_OPTIONAL),
            'certstudioid'    => new external_value(PARAM_INT, 'Filter issues for a specific certstudio instance',
                VALUE_OPTIONAL),
            'limit'           => new external_value(PARAM_INT, 'Maximum number of records to return', VALUE_DEFAULT, 100),
            'offset'          => new external_value(PARAM_INT, 'Number of records to skip', VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * List issued certificates.
     *
     * @param int|null $timecreatedfrom Filter by creation time.
     * @param int|null $userid          Filter by user.
     * @param int|null $certstudioid    Filter by certstudio instance.
     * @param int      $limit           Maximum results.
     * @param int      $offset          Result offset.
     * @return array List of issued certificates.
     */
    public static function list_issues(
        ?int $timecreatedfrom = null,
        ?int $userid = null,
        ?int $certstudioid = null,
        int $limit = 100,
        int $offset = 0
    ): array {
        global $DB;

        $params = self::validate_parameters(self::list_issues_parameters(), [
            'timecreatedfrom' => $timecreatedfrom,
            'userid'          => $userid,
            'certstudioid'    => $certstudioid,
            'limit'           => $limit,
            'offset'          => $offset,
        ]);

        $timecreatedfrom = $params['timecreatedfrom'] ?? null;
        $userid          = $params['userid'] ?? null;
        $certstudioid    = $params['certstudioid'] ?? null;
        $limit           = $params['limit'];
        $offset          = $params['offset'];

        $context = \context_system::instance();
        self::validate_context($context);
        require_capability('mod/certstudio:viewallcertificates', $context);

        $sql = "SELECT ci.id AS issueid,
                       ci.certstudioid,
                       ci.userid,
                       ci.timecreated AS issuetimecreated,
                       u.firstname,
                       u.lastname,
                       u.email,
                       cs.name AS certificatename,
                       cs.course AS courseid
                  FROM {certstudio_issues} ci
                  JOIN {user} u ON u.id = ci.userid
                  JOIN {certstudio} cs ON cs.id = ci.certstudioid
                 WHERE 1 = 1";

        $sqlparams = [];

        if ($timecreatedfrom !== null) {
            $sql .= " AND ci.timecreated >= :timecreatedfrom";
            $sqlparams['timecreatedfrom'] = $timecreatedfrom;
        }
        if ($userid !== null) {
            $sql .= " AND ci.userid = :userid";
            $sqlparams['userid'] = $userid;
        }
        if ($certstudioid !== null) {
            $sql .= " AND ci.certstudioid = :certstudioid";
            $sqlparams['certstudioid'] = $certstudioid;
        }

        $sql .= " ORDER BY ci.timecreated DESC";

        $records = $DB->get_records_sql($sql, $sqlparams, $offset, $limit);

        $issues = [];
        foreach ($records as $record) {
            $issues[] = [
                'issueid'          => (int) $record->issueid,
                'certstudioid'     => (int) $record->certstudioid,
                'userid'           => (int) $record->userid,
                'issuetimecreated' => (int) $record->issuetimecreated,
                'firstname'        => $record->firstname,
                'lastname'         => $record->lastname,
                'email'            => $record->email,
                'certificatename'  => $record->certificatename,
                'courseid'         => (int) $record->courseid,
            ];
        }

        return $issues;
    }

    /**
     * Describes the return value for list_issues.
     *
     * @return external_multiple_structure
     */
    public static function list_issues_returns(): external_multiple_structure {
        return new external_multiple_structure(
            new external_single_structure([
                'issueid'          => new external_value(PARAM_INT, 'The issue ID'),
                'certstudioid'     => new external_value(PARAM_INT, 'The certstudio instance ID'),
                'userid'           => new external_value(PARAM_INT, 'The user ID'),
                'issuetimecreated' => new external_value(PARAM_INT, 'Timestamp when the issue was created'),
                'firstname'        => new external_value(PARAM_TEXT, 'User first name'),
                'lastname'         => new external_value(PARAM_TEXT, 'User last name'),
                'email'            => new external_value(PARAM_TEXT, 'User email'),
                'certificatename'  => new external_value(PARAM_TEXT, 'Certificate name'),
                'courseid'         => new external_value(PARAM_INT, 'Course ID'),
            ])
        );
    }
}
