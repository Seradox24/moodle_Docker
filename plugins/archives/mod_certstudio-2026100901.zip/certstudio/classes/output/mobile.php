<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Mobile output class for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2018 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio\output;
/**
 * Mobile output class for rendering the certificate view in the Moodle Mobile app.
 *
 * @package    mod_certstudio
 * @copyright  2018 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mobile {
    /**
     * Returns the certificate view for the mobile app.
     *
     * @param array $args Arguments from the mobile app containing cmid.
     * @return array HTML, javascript, and other data for the mobile app.
     */
    public static function mobile_course_view($args) {
        global $OUTPUT, $USER, $DB;

        $cmid = $args['cmid'];
        $cm = get_coursemodule_from_id('certstudio', $cmid, 0, false, MUST_EXIST);
        $course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
        $certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

        require_login($course, true, $cm);
        $context = \context_module::instance($cm->id);

        // Check for existing issue.
        $issues = \mod_certstudio\certificate::get_issues_for_user($certstudio->id, $USER->id);
        $issue = !empty($issues) ? reset($issues) : null;

        $data = [
            'cmid' => $cmid,
            'certstudio' => $certstudio,
            'issue' => $issue,
            'hasissue' => !empty($issue),
            'canmanage' => has_capability('mod/certstudio:manage', $context),
            'downloadurl' => (new \moodle_url('/mod/certstudio/mobile_download.php', ['id' => $cmid]))->out(false),
        ];

        return [
            'templates' => [
                [
                    'id' => 'main',
                    'html' => $OUTPUT->render_from_template('mod_certstudio/mobile_view', $data),
                ],
            ],
            'javascript' => '',
            'otherdata' => '',
            'files' => [],
        ];
    }
}
