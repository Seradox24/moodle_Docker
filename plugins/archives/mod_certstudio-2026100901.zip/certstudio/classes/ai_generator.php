<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AI Template Generator for Certificate Studio.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * AI-powered certificate template generator.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class ai_generator {
    /**
     * Generate a certificate template from a text description.
     *
     * @param string $description User's description of the desired certificate
     * @param int $width Page width in mm (default 297 for A4 landscape)
     * @param int $height Page height in mm (default 210)
     * @return array Template data with elements
     * @throws \moodle_exception
     */
    public static function generate(string $description, int $width = 297, int $height = 210): array {
        $provider = get_config('mod_certstudio', 'aiprovider') ?: 'openai';
        $apikey = get_config('mod_certstudio', 'aiapikey');
        $model = get_config('mod_certstudio', 'aimodel') ?: 'gpt-4o-mini';

        if (empty($apikey)) {
            throw new \moodle_exception('ainokey', 'mod_certstudio');
        }

        $systemprompt = self::build_system_prompt($width, $height);
        $userprompt = "Generate a certificate template for: " . $description;

        if ($provider === 'anthropic') {
            return self::call_anthropic($apikey, $model, $systemprompt, $userprompt);
        } else {
            return self::call_openai($apikey, $model, $systemprompt, $userprompt);
        }
    }

    /**
     * Build the system prompt for the AI model.
     *
     * @param int $width Page width in mm
     * @param int $height Page height in mm
     * @return string The system prompt
     */
    private static function build_system_prompt(int $width, int $height): string {
        $innerw = $width - 20;
        $innerh = $height - 20;
        $cx = round(($width - 240) / 2, 1);
        $qrx = $width - 60;

        // Build the example JSON template for the AI prompt.
        $example = self::build_example_json(
            $width,
            $height,
            $innerw,
            $innerh,
            $cx,
            $qrx
        );

        $prompt = "You are a certificate designer. "
            . "Generate a JSON array for a certificate template.\n\n"
            . "Canvas: {$width}x{$height}mm. posx is LEFT EDGE. "
            . "To center a 240mm wide element: posx={$cx}.\n"
            . "Height rule: height = fontsize x 0.5. "
            . "Example: 42pt title = height 21, 13pt label = height 7.\n\n"
            . "Here is an example of a GOOD certificate. "
            . "Adapt the style, colors, title text, and wording "
            . "to match the user's description:\n"
            . $example . "\n\n"
            . "CRITICAL RULES:\n"
            . "1. data.text MUST contain REAL TEXT like "
            . "\"Certificate of Achievement\", "
            . "\"This is to certify that\", \"Awarded on\". "
            . "NEVER use \"Text\" as content.\n"
            . "2. For dynamic types use: "
            . "studentname->\"{Student Name}\", "
            . "coursename->\"{Course Name}\", "
            . "certdate->\"{Date}\", code->\"{Code}\"\n"
            . "3. Adapt colors, fonts, title wording to match the "
            . "user description. Use different color palettes "
            . "(blue=#1e3a5f, green=#276749, red=#9b2c2c, etc.)\n"
            . "4. Fonts: \"Playfair Display\", \"GFS Didot\", "
            . "\"Montserrat\", \"Lato\", \"Poppins\", "
            . "\"Merriweather\", \"Roboto\", \"Open Sans\", "
            . "\"Raleway\", \"Noto Serif\"\n"
            . "5. Alignment: \"C\", \"L\", or \"R\" only\n\n"
            . "Output ONLY the JSON array.";

        return $prompt;
    }

    /**
     * Build the example JSON template for the AI prompt.
     *
     * @param int $width Page width in mm
     * @param int $height Page height in mm
     * @param int $innerw Inner frame width
     * @param int $innerh Inner frame height
     * @param float $cx Center X position
     * @param int $qrx QR code X position
     * @return string JSON-formatted example template
     */
    private static function build_example_json(
        int $width,
        int $height,
        int $innerw,
        int $innerh,
        float $cx,
        int $qrx
    ): string {
        $base = [
            'fontweight' => 'normal',
            'fontstyle' => 'normal',
            'alignment' => 'C',
            'opacity' => 1,
        ];
        $elements = [];
        $sep = str_repeat("\u{2501}", 42);

        $elements[] = array_merge($base, [
            'type' => 'border', 'name' => 'Outer Frame',
            'posx' => 0, 'posy' => 0,
            'width' => $width, 'height' => $height,
            'fontfamily' => 'Roboto', 'fontsize' => 12,
            'color' => '#c9a84c',
            'data' => [
                'borderwidth' => 3,
                'bordercolor' => '#c9a84c',
                'borderstyle' => 'solid',
            ],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'border', 'name' => 'Inner Frame',
            'posx' => 10, 'posy' => 10,
            'width' => $innerw, 'height' => $innerh,
            'fontfamily' => 'Roboto', 'fontsize' => 12,
            'color' => '#b8963e',
            'data' => [
                'borderwidth' => 1,
                'bordercolor' => '#b8963e',
                'borderstyle' => 'solid',
            ],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Ornamental Header',
            'posx' => $cx, 'posy' => 20,
            'width' => 240, 'height' => 6,
            'fontfamily' => 'Montserrat', 'fontsize' => 10,
            'color' => '#8b7355', 'opacity' => 0.7,
            'data' => ['text' => 'PROUDLY PRESENTED TO'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Top Separator',
            'posx' => $cx, 'posy' => 30,
            'width' => 240, 'height' => 5,
            'fontfamily' => 'Roboto', 'fontsize' => 10,
            'color' => '#c9a84c', 'opacity' => 0.3,
            'data' => ['text' => $sep],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Certificate Title',
            'posx' => $cx, 'posy' => 40,
            'width' => 240, 'height' => 22,
            'fontfamily' => 'Playfair Display', 'fontsize' => 42,
            'fontweight' => 'bold', 'color' => '#1a1a2e',
            'data' => ['text' => 'Certificate of Achievement'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Subtitle',
            'posx' => $cx, 'posy' => 66,
            'width' => 240, 'height' => 7,
            'fontfamily' => 'Montserrat', 'fontsize' => 13,
            'fontstyle' => 'italic',
            'color' => '#555555', 'opacity' => 0.7,
            'data' => ['text' => 'This is to certify that'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Separator',
            'posx' => $cx, 'posy' => 78,
            'width' => 240, 'height' => 5,
            'fontfamily' => 'Roboto', 'fontsize' => 10,
            'color' => '#c9a84c', 'opacity' => 0.3,
            'data' => ['text' => $sep],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'studentname', 'name' => 'Student Name',
            'posx' => $cx, 'posy' => 88,
            'width' => 240, 'height' => 18,
            'fontfamily' => 'Playfair Display', 'fontsize' => 34,
            'fontweight' => 'bold', 'color' => '#1a1a2e',
            'data' => ['text' => '{Student Name}'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Underline',
            'posx' => $cx, 'posy' => 110,
            'width' => 240, 'height' => 5,
            'fontfamily' => 'Roboto', 'fontsize' => 10,
            'color' => '#c9a84c', 'opacity' => 0.3,
            'data' => ['text' => $sep],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Completion Phrase',
            'posx' => $cx, 'posy' => 120,
            'width' => 240, 'height' => 7,
            'fontfamily' => 'Montserrat', 'fontsize' => 13,
            'color' => '#555555', 'opacity' => 0.7,
            'data' => [
                'text' => 'has successfully completed the course',
            ],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'coursename', 'name' => 'Course Name',
            'posx' => $cx, 'posy' => 132,
            'width' => 240, 'height' => 12,
            'fontfamily' => 'Playfair Display', 'fontsize' => 24,
            'fontweight' => 'bold', 'color' => '#1a1a2e',
            'data' => ['text' => '{Course Name}'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'text', 'name' => 'Date Label',
            'posx' => $cx, 'posy' => 150,
            'width' => 240, 'height' => 6,
            'fontfamily' => 'Lato', 'fontsize' => 11,
            'color' => '#888888', 'opacity' => 0.6,
            'data' => ['text' => 'Awarded on'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'certdate',
            'name' => 'Certificate Date',
            'posx' => $cx, 'posy' => 160,
            'width' => 240, 'height' => 7,
            'fontfamily' => 'Lato', 'fontsize' => 13,
            'color' => '#333333',
            'data' => [
                'text' => '{Date}',
                'dateformat' => 'F j, Y',
            ],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'digitalsignature',
            'name' => 'Signature',
            'posx' => 20, 'posy' => 178,
            'width' => 100, 'height' => 20,
            'fontfamily' => 'Roboto', 'fontsize' => 10,
            'color' => '#333333',
            'data' => ['label' => 'Authorized Signature'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'qrcode', 'name' => 'QR Code',
            'posx' => $qrx, 'posy' => 178,
            'width' => 25, 'height' => 25,
            'fontfamily' => 'Roboto', 'fontsize' => 10,
            'color' => '#333333',
            'data' => ['qrdata' => 'verify'],
        ]);

        $elements[] = array_merge($base, [
            'type' => 'code', 'name' => 'Verification Code',
            'posx' => $cx, 'posy' => 200,
            'width' => 240, 'height' => 5,
            'fontfamily' => 'Roboto', 'fontsize' => 9,
            'color' => '#999999', 'opacity' => 0.5,
            'data' => ['text' => '{Code}'],
        ]);

        return json_encode(
            $elements,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        );
    }

    /**
     * Call the OpenAI API.
     *
     * @param string $apikey API key
     * @param string $model Model name
     * @param string $system System prompt
     * @param string $user User prompt
     * @return array Parsed elements
     * @throws \moodle_exception
     */
    private static function call_openai(string $apikey, string $model, string $system, string $user): array {
        global $CFG;
        require_once($CFG->libdir . '/filelib.php');

        $curl = new \curl();
        $curl->setopt(['CURLOPT_HTTPHEADER' => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ]]);

        $payload = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $user],
            ],
            'temperature' => 0.7,
            'max_tokens' => 4000,
        ];

        // Use JSON mode for models that support it (gpt-4o, gpt-4o-mini, gpt-4-turbo, etc.).
        if (strpos($model, 'gpt-4') !== false || strpos($model, 'gpt-3.5-turbo') !== false) {
            $payload['response_format'] = ['type' => 'json_object'];
            // Wrap the system prompt to ensure JSON output when using json_object mode.
            $payload['messages'][0]['content'] = $system
                . "\n\nIMPORTANT: Return your response as a JSON object with an \"elements\" key containing the array.";
        }

        $data = json_encode($payload);

        $curl->setopt(['CURLOPT_TIMEOUT' => 60]);
        $response = $curl->post('https://api.openai.com/v1/chat/completions', $data);
        $result = json_decode($response, true);

        if (empty($result['choices'][0]['message']['content'])) {
            $error = $result['error']['message'] ?? ($response ?: 'API request failed or timed out');
            throw new \moodle_exception('aierror', 'mod_certstudio', '', $error);
        }

        $content = $result['choices'][0]['message']['content'];
        return self::parse_elements($content);
    }

    /**
     * Call the Anthropic API.
     *
     * @param string $apikey API key
     * @param string $model Model name
     * @param string $system System prompt
     * @param string $user User prompt
     * @return array Parsed elements
     * @throws \moodle_exception
     */
    private static function call_anthropic(string $apikey, string $model, string $system, string $user): array {
        // If model is still set to an OpenAI default, switch to a Claude model.
        if ($model === 'gpt-4o-mini' || strpos($model, 'gpt') === 0) {
            $model = 'claude-sonnet-4-20250514';
        }

        global $CFG;
        require_once($CFG->libdir . '/filelib.php');

        $curl = new \curl();
        $curl->setopt(['CURLOPT_HTTPHEADER' => [
            'Content-Type: application/json',
            'x-api-key: ' . $apikey,
            'anthropic-version: 2023-06-01',
        ]]);

        $data = json_encode([
            'model' => $model,
            'max_tokens' => 4000,
            'system' => $system,
            'messages' => [
                ['role' => 'user', 'content' => $user],
            ],
        ]);

        $curl->setopt(['CURLOPT_TIMEOUT' => 60]);
        $response = $curl->post('https://api.anthropic.com/v1/messages', $data);
        $result = json_decode($response, true);

        if (empty($result['content'][0]['text'])) {
            $error = $result['error']['message'] ?? ($response ?: 'API request failed or timed out');
            throw new \moodle_exception('aierror', 'mod_certstudio', '', $error);
        }

        $content = $result['content'][0]['text'];
        return self::parse_elements($content);
    }

    /**
     * Parse the AI response into validated element data.
     *
     * @param string $content Raw AI response content
     * @return array Validated element array
     * @throws \moodle_exception
     */
    private static function parse_elements(string $content): array {
        // Strip any markdown code fences.
        $content = preg_replace('/\x60{3}(?:json)?\s*/', '', $content);
        $content = trim($content);

        $decoded = json_decode($content, true);
        if ($decoded === null) {
            throw new \moodle_exception('aiparseerror', 'mod_certstudio');
        }

        // Handle both direct array and { "elements": [...] } wrapper.
        if (is_array($decoded) && isset($decoded['elements']) && is_array($decoded['elements'])) {
            $elements = $decoded['elements'];
        } else if (is_array($decoded) && !isset($decoded['elements']) && isset($decoded[0])) {
            $elements = $decoded;
        } else {
            throw new \moodle_exception('aiparseerror', 'mod_certstudio');
        }

        // Validate and sanitize each element.
        $validtypes = ['text', 'studentname', 'coursename', 'categoryname', 'date', 'grade',
            'gradeitemname', 'code', 'teachername', 'userfield', 'coursefield',
            'daterange', 'expiry', 'certdate', 'certstatement', 'border',
            'image', 'qrcode', 'digitalsignature'];

        // Map alignment values from human-readable to single-char codes.
        $alignmentmap = [
            'left' => 'L', 'center' => 'C', 'right' => 'R',
            'L' => 'L', 'C' => 'C', 'R' => 'R',
        ];

        $result = [];
        foreach ($elements as $el) {
            if (empty($el['type']) || !in_array($el['type'], $validtypes)) {
                continue;
            }

            // Normalize data field: must be an object/array, not a string.
            $data = $el['data'] ?? [];
            if (is_string($data)) {
                // AI sometimes returns data as a plain string instead of {"text": "..."}.
                $data = !empty($data) ? ['text' => $data] : [];
            }

            // Ensure text-based elements have a data.text field.
            $texttypes = ['text', 'studentname', 'coursename', 'categoryname', 'date',
                'code', 'teachername', 'certdate', 'certstatement'];
            if (in_array($el['type'], $texttypes) && empty($data['text'])) {
                $defaulttexts = [
                    'studentname' => '[Student Name]',
                    'coursename' => '[Course Name]',
                    'date' => '[Date]',
                    'certdate' => '[Date]',
                    'code' => '[Code]',
                    'teachername' => '[Teacher Name]',
                    'categoryname' => '[Category]',
                    'certstatement' => 'This certifies that',
                ];
                $data['text'] = $defaulttexts[$el['type']] ?? 'Text';
            }

            // Ensure border elements have proper data.
            if ($el['type'] === 'border' && empty($data['borderwidth'])) {
                $data['borderwidth'] = 2;
                $data['bordercolor'] = $el['color'] ?? '#000000';
                $data['borderstyle'] = 'solid';
            }

            // Ensure reasonable width/height (AI sometimes returns 0).
            $elwidth = (float) ($el['width'] ?? 0);
            $elheight = (float) ($el['height'] ?? 0);
            if ($elwidth <= 0) {
                $elwidth = ($el['type'] === 'border') ? 287 : 200;
            }
            if ($elheight <= 0) {
                $elheight = ($el['type'] === 'border') ? 200 : 15;
            }

            $alignment = $el['alignment'] ?? 'C';
            $alignment = $alignmentmap[strtolower($alignment)] ?? 'C';

            $result[] = [
                'type' => $el['type'],
                'name' => $el['name'] ?? $el['type'],
                'posx' => (float) ($el['posx'] ?? 0),
                'posy' => (float) ($el['posy'] ?? 0),
                'width' => $elwidth,
                'height' => $elheight,
                'fontfamily' => $el['fontfamily'] ?? 'Roboto',
                'fontsize' => (int) ($el['fontsize'] ?? 14),
                'fontweight' => $el['fontweight'] ?? 'normal',
                'fontstyle' => $el['fontstyle'] ?? 'normal',
                'color' => $el['color'] ?? '#000000',
                'alignment' => $alignment,
                'opacity' => (float) ($el['opacity'] ?? 1),
                'data' => $data,
            ];
        }

        if (empty($result)) {
            throw new \moodle_exception('aiparseerror', 'mod_certstudio');
        }

        return $result;
    }
}
