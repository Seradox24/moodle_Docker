<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate issuance class for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * Handles certificate issuance, retrieval, revocation, and placeholder resolution.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class certificate {
    /** @var string The database table for issues. */
    private const TABLE = 'certstudio_issues';

    /** @var string The database table for the activity instance. */
    private const TABLE_INSTANCE = 'certstudio';

    /** @var int Certificate is active. */
    public const STATUS_ACTIVE = 0;

    /** @var int Certificate has been revoked. */
    public const STATUS_REVOKED = 1;

    /** @var string[] Standard user fields the user field element may print. */
    private const USER_FIELDS = [
        'firstname', 'lastname', 'middlename', 'alternatename', 'firstnamephonetic', 'lastnamephonetic',
        'email', 'idnumber', 'institution', 'department', 'city', 'country',
    ];

    /** @var string[] Date formats the date elements offer: language config keys, or strftime formats. */
    public const DATE_FORMATS = [
        'strftimedate', 'strftimedaydate', 'strftimedatemonthabbr', 'strftimemonthyear', 'strftimedatefullshort', '%d/%m/%Y',
    ];

    /** @var string[] Standard course fields the course field element may print. */
    private const COURSE_FIELDS = ['fullname', 'shortname', 'idnumber', 'startdate', 'enddate'];

    /**
     * Issue a certificate to a user.
     *
     * @param int $certstudioid The certstudio activity instance ID.
     * @param int $userid The user ID to issue the certificate to.
     * @param bool $notify Whether to send notification to the student (default true).
     * @return int The ID of the newly created issue record.
     * @throws \moodle_exception If the activity instance is not found.
     */
    public static function issue(int $certstudioid, int $userid, bool $notify = true): int {
        global $DB;

        // Prevent duplicate active issues.
        $existing = $DB->get_record(self::TABLE, [
            'certstudioid' => $certstudioid,
            'userid' => $userid,
            'status' => self::STATUS_ACTIVE,
        ]);
        if ($existing) {
            return $existing->id;
        }

        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $certstudioid], '*', MUST_EXIST);

        // Generate the verification code using the function from lib.php.
        require_once(__DIR__ . '/../lib.php');
        $code = certstudio_generate_code();

        // Resolve template data with real user/course values.
        $templatedata = self::get_template_data($certstudioid, $userid, $code);

        $record = new \stdClass();
        $record->certstudioid = $certstudioid;
        $record->userid = $userid;
        $record->code = $code;
        $record->templatedata = json_encode($templatedata);
        $record->timecreated = time();

        // Set expiry date if configured on the activity.
        $expirydays = (int) ($certstudio->expirydays ?? 0);
        if ($expirydays > 0) {
            $record->expirydate = $record->timecreated + ($expirydays * 86400);
        }

        $issueid = $DB->insert_record(self::TABLE, $record);

        // Fire the certificate_issued event.
        $cm = get_coursemodule_from_instance('certstudio', $certstudioid, $certstudio->course, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);

        $event = \mod_certstudio\event\certificate_issued::create([
            'objectid' => $issueid,
            'context' => $context,
            'relateduserid' => $userid,
            'other' => [
                'certstudioid' => $certstudioid,
                'code' => $code,
            ],
        ]);
        $event->trigger();

        // Send notification to student if enabled and not suppressed.
        if ($notify && get_config('mod_certstudio', 'emailstudents')) {
            $student = $DB->get_record('user', ['id' => $userid]);
            $course = $DB->get_record('course', ['id' => $certstudio->course]);
            if ($student && $course) {
                $viewurl = new \moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]);
                $sent = self::send_notification(
                    'issuedtemplate',
                    $student,
                    get_string('emailcertsubject', 'mod_certstudio', format_string($certstudio->name)),
                    [
                        '{studentname}' => fullname($student),
                        '{certname}' => format_string($certstudio->name),
                        '{coursename}' => format_string($course->fullname),
                        '{url}' => $viewurl->out(false),
                        '{code}' => $code,
                    ],
                    $viewurl
                );
                if ($sent) {
                    $DB->set_field(self::TABLE, 'emailed', 1, ['id' => $issueid]);
                }
            }
        }

        // Teachers and other recipients are emailed in the background, once per issue.
        $emailothers = trim((string) get_config('mod_certstudio', 'emailothers'));
        if ($notify && (get_config('mod_certstudio', 'emailteachers') || $emailothers !== '')) {
            $task = new \mod_certstudio\task\email_certificate_task();
            $task->set_custom_data(['issueid' => $issueid, 'certstudioid' => $certstudioid]);
            \core\task\manager::queue_adhoc_task($task, true);
        }

        return $issueid;
    }

    /**
     * Check whether a user can be issued a new certificate for an activity.
     *
     * Every path that issues a certificate without a teacher choosing the recipient goes through
     * this check: the student's own request, the web service and the course completion observer.
     * It enforces on the server what the activity page shows the student.
     *
     * @param \stdClass $certstudio The certstudio activity instance record.
     * @param int $cmid The course module ID of the activity.
     * @param int $userid The user to check.
     * @param bool $requireapproval If true and the approval workflow is enabled, require an approved
     *     request. Pass false to check whether the user may ask for approval.
     * @return string|null Null if a certificate can be issued, otherwise the reason, which maps to the
     *     lang string 'cannotissue_' . $reason.
     */
    public static function can_issue(\stdClass $certstudio, int $cmid, int $userid, bool $requireapproval = true): ?string {
        global $DB;

        $context = \context_module::instance($cmid);
        if (!is_enrolled($context, $userid, '', true)) {
            return 'notenrolled';
        }
        if (!has_capability('mod/certstudio:receiveissue', $context, $userid)) {
            return 'nopermission';
        }

        // Covers hidden activities and access restrictions, evaluated for this user.
        $cm = get_fast_modinfo($certstudio->course, $userid)->get_cm($cmid);
        if (!$cm->uservisible) {
            return 'notavailable';
        }

        // A revoked certificate blocks a new one; only a teacher can reissue it.
        $issues = $DB->get_records(self::TABLE, ['certstudioid' => $certstudio->id, 'userid' => $userid], '', 'id, status');
        foreach ($issues as $issue) {
            if ((int) $issue->status === self::STATUS_ACTIVE) {
                return 'alreadyissued';
            }
        }
        if (!empty($issues)) {
            return 'revoked';
        }

        $requiredtime = (int) get_config('mod_certstudio', 'requiredtime');
        if ($requiredtime > 0 && self::get_minutes_spent($certstudio->course, $userid) < $requiredtime) {
            return 'requiredtime';
        }

        if ($requireapproval && !empty($certstudio->approvalenabled)) {
            $request = approval::get_user_request($certstudio->id, $userid);
            if (!$request || (int) $request->status !== approval::STATUS_APPROVED) {
                return 'approval';
            }
        }

        return null;
    }

    /**
     * Count the distinct minutes in which a user had logged activity in a course or its activities.
     *
     * @param int $courseid The course ID.
     * @param int $userid The user ID.
     * @return int Number of minutes with at least one logged event.
     */
    public static function get_minutes_spent(int $courseid, int $userid): int {
        global $DB;

        // Use contextid + contextlevel to leverage the default index on logstore_standard_log,
        // which is much faster than scanning the full table by courseid alone.
        $coursecontext = \context_course::instance($courseid);
        return $DB->count_records_sql(
            "SELECT COUNT(DISTINCT FLOOR(timecreated / 60))
               FROM {logstore_standard_log}
              WHERE userid = :userid
                AND contextid IN (
                    SELECT id FROM {context}
                     WHERE contextlevel IN (:ctxcourse, :ctxmodule)
                       AND (id = :coursectxid OR path LIKE :pathprefix)
                )",
            [
                'userid' => $userid,
                'ctxcourse' => CONTEXT_COURSE,
                'ctxmodule' => CONTEXT_MODULE,
                'coursectxid' => $coursecontext->id,
                'pathprefix' => $coursecontext->path . '/%',
            ]
        );
    }

    /**
     * Get a single issue record by ID.
     *
     * @param int $id The issue record ID.
     * @return \stdClass|false The issue record, or false if not found.
     */
    public static function get_issue(int $id) {
        global $DB;

        return $DB->get_record(self::TABLE, ['id' => $id]);
    }

    /**
     * Get active issue records for a specific user in a given activity.
     *
     * @param int $certstudioid The certstudio activity instance ID.
     * @param int $userid The user ID.
     * @param bool $activeonly If true, only return active (non-revoked) certificates.
     * @return array Array of issue records.
     */
    public static function get_issues_for_user(int $certstudioid, int $userid, bool $activeonly = true): array {
        global $DB;

        $params = [
            'certstudioid' => $certstudioid,
            'userid' => $userid,
        ];
        if ($activeonly) {
            $params['status'] = self::STATUS_ACTIVE;
        }

        return $DB->get_records(self::TABLE, $params, 'timecreated DESC');
    }

    /**
     * Get all issue records for a given activity.
     *
     * @param int $certstudioid The certstudio activity instance ID.
     * @return array Array of issue records.
     */
    public static function get_all_issues(int $certstudioid): array {
        global $DB;

        return $DB->get_records(self::TABLE, ['certstudioid' => $certstudioid], 'timecreated DESC');
    }

    /**
     * Revoke a certificate issue (soft-revoke: marks as revoked, keeps record).
     *
     * @param int $id The issue record ID.
     * @param string $reason Optional reason for revocation.
     * @return bool True on success.
     * @throws \moodle_exception If the issue record is not found.
     */
    public static function revoke(int $id, string $reason = ''): bool {
        global $DB, $USER;

        $issue = self::get_issue($id);
        if (!$issue) {
            throw new \moodle_exception('issuenotfound', 'mod_certstudio');
        }

        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $issue->certstudioid], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('certstudio', $issue->certstudioid, $certstudio->course, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);

        // Fire the certificate_revoked event.
        $event = \mod_certstudio\event\certificate_revoked::create([
            'objectid' => $id,
            'context' => $context,
            'relateduserid' => $issue->userid,
            'other' => [
                'certstudioid' => $issue->certstudioid,
                'code' => $issue->code,
            ],
        ]);
        $event->trigger();

        // Soft-revoke: mark as revoked instead of deleting.
        $DB->update_record(self::TABLE, (object) [
            'id' => $id,
            'status' => self::STATUS_REVOKED,
            'revokedby' => $USER->id,
            'revokedat' => time(),
            'revokereason' => $reason,
        ]);

        // Also delete any approval requests for this user/activity so the certificate
        // doesn't get re-issued automatically on the student's next page visit.
        $DB->delete_records('certstudio_approval_requests', [
            'certstudioid' => $issue->certstudioid,
            'userid' => $issue->userid,
        ]);

        // Send revocation notification to student.
        $student = $DB->get_record('user', ['id' => $issue->userid]);
        $course = $DB->get_record('course', ['id' => $certstudio->course]);
        if ($student && $course) {
            self::send_notification(
                'revokedtemplate',
                $student,
                get_string('certificaterevoked', 'mod_certstudio') . ': ' . format_string($certstudio->name),
                [
                    '{studentname}' => fullname($student),
                    '{certname}' => format_string($certstudio->name),
                    '{coursename}' => format_string($course->fullname),
                    '{reason}' => $reason ?: '-',
                ]
            );
        }

        return true;
    }

    /**
     * Hard-delete a certificate issue (permanently removes the record).
     *
     * @param int $id The issue record ID.
     * @return bool True on success.
     */
    public static function delete_issue(int $id): bool {
        global $DB;

        $issue = self::get_issue($id);
        if (!$issue) {
            throw new \moodle_exception('issuenotfound', 'mod_certstudio');
        }

        $DB->delete_records(self::TABLE, ['id' => $id]);

        // Also delete any approval requests.
        $DB->delete_records('certstudio_approval_requests', [
            'certstudioid' => $issue->certstudioid,
            'userid' => $issue->userid,
        ]);

        return true;
    }

    /**
     * Reissue (renew) a certificate for a user, creating a new version.
     *
     * The old certificate is revoked and a new one is issued with an incremented version number.
     *
     * @param int $oldissueid The issue ID to renew.
     * @return int The new issue record ID.
     */
    public static function reissue(int $oldissueid): int {
        global $DB, $USER;

        $oldissue = self::get_issue($oldissueid);
        if (!$oldissue) {
            throw new \moodle_exception('issuenotfound', 'mod_certstudio');
        }

        // Renew from the latest version and revoke every active certificate the student holds for this activity,
        // so reissuing from an older row never leaves two active certificates or two copies of one version.
        $versions = $DB->get_records(
            self::TABLE,
            ['certstudioid' => $oldissue->certstudioid, 'userid' => $oldissue->userid],
            'id DESC'
        );
        $latest = reset($versions);
        foreach ($versions as $version) {
            if ((int) $version->status === self::STATUS_ACTIVE) {
                self::revoke($version->id, get_string('revokedrenewal', 'mod_certstudio'));
            }
        }

        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $oldissue->certstudioid], '*', MUST_EXIST);

        require_once(__DIR__ . '/../lib.php');
        $code = certstudio_generate_code();
        $templatedata = self::get_template_data($oldissue->certstudioid, $oldissue->userid, $code);

        $record = new \stdClass();
        $record->certstudioid = $oldissue->certstudioid;
        $record->userid = $oldissue->userid;
        $record->code = $code;
        $record->templatedata = json_encode($templatedata);
        $record->timecreated = time();
        $record->status = self::STATUS_ACTIVE;
        $record->version = (int) ($latest->version ?? 1) + 1;
        $record->parentid = (int) $latest->id;

        // Set expiry date if configured.
        $expirydays = (int) ($certstudio->expirydays ?? 0);
        if ($expirydays > 0) {
            $record->expirydate = $record->timecreated + ($expirydays * 86400);
        }

        $issueid = $DB->insert_record(self::TABLE, $record);

        // Fire the certificate_issued event.
        $cm = get_coursemodule_from_instance('certstudio', $oldissue->certstudioid, $certstudio->course, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);
        $event = \mod_certstudio\event\certificate_issued::create([
            'objectid' => $issueid,
            'context' => $context,
            'relateduserid' => $oldissue->userid,
            'other' => [
                'certstudioid' => $oldissue->certstudioid,
                'code' => $code,
                'version' => $record->version,
            ],
        ]);
        $event->trigger();

        // Send reissued notification to student.
        $student = $DB->get_record('user', ['id' => $oldissue->userid]);
        $course = $DB->get_record('course', ['id' => $certstudio->course]);
        if ($student && $course) {
            $viewurl = new \moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]);
            $sent = self::send_notification(
                'reissuedtemplate',
                $student,
                get_string('emailcertsubject', 'mod_certstudio', format_string($certstudio->name)),
                [
                    '{studentname}' => fullname($student),
                    '{certname}' => format_string($certstudio->name),
                    '{coursename}' => format_string($course->fullname),
                    '{url}' => $viewurl->out(false),
                    '{code}' => $code,
                ],
                $viewurl
            );
            if ($sent) {
                $DB->set_field(self::TABLE, 'emailed', 1, ['id' => $issueid]);
            }
        }

        return $issueid;
    }

    /**
     * Get the version history for a certificate issue (all versions in the renewal chain).
     *
     * @param int $issueid Any issue ID in the chain.
     * @return array Array of issue records ordered by version ASC.
     */
    public static function get_version_history(int $issueid): array {
        global $DB;

        $issue = self::get_issue($issueid);
        if (!$issue) {
            return [];
        }

        // Walk up to the root.
        $rootid = $issue->id;
        while (!empty($issue->parentid)) {
            $issue = self::get_issue($issue->parentid);
            if ($issue) {
                $rootid = $issue->id;
            } else {
                break;
            }
        }

        // Collect all descendants from root.
        $chain = [];
        $current = self::get_issue($rootid);
        if ($current) {
            $chain[] = $current;
            // Walk down through children.
            while ($child = $DB->get_record(self::TABLE, ['parentid' => $current->id])) {
                $chain[] = $child;
                $current = $child;
            }
        }

        return $chain;
    }

    /**
     * Send certificate PDF as email attachment.
     *
     * @param int $issueid The issue record ID.
     * @return bool True on success.
     */
    public static function email_certificate(int $issueid): bool {
        global $DB, $USER, $CFG;

        require_once($CFG->dirroot . '/mod/certstudio/lib.php');

        $issue = self::get_issue($issueid);
        if (!$issue) {
            return false;
        }

        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $issue->certstudioid], '*', MUST_EXIST);
        $course = $DB->get_record('course', ['id' => $certstudio->course], '*', MUST_EXIST);
        $student = $DB->get_record('user', ['id' => $issue->userid], '*', MUST_EXIST);

        // Generate PDF.
        $templatedata = self::get_template_data($issue->certstudioid, $issue->userid, $issue->code);
        $pdfcontent = \mod_certstudio\pdfgenerator::generate($templatedata);

        // Save to temp file.
        $tempdir = make_temp_directory('certstudio_email');
        $filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $certstudio->name) . '_' . $issue->code . '.pdf';
        $filepath = $tempdir . '/' . $filename;
        file_put_contents($filepath, $pdfcontent);

        // Build email.
        $subject = get_string('emailcertsubject', 'mod_certstudio', format_string($certstudio->name));
        $verifyurl = new \moodle_url('/mod/certstudio/verify.php', ['code' => $issue->code]);
        $cm = get_coursemodule_from_instance('certstudio', $certstudio->id, $course->id);
        $viewurl = $cm ? new \moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]) : $verifyurl;

        $body = self::resolve_message_template('emailcerttemplate', [
            '{studentname}' => fullname($student),
            '{certname}' => format_string($certstudio->name),
            '{coursename}' => format_string($course->fullname),
            '{code}' => $issue->code,
            '{verifyurl}' => $verifyurl->out(false),
            '{url}' => $viewurl->out(false),
        ]);
        $bodyhtml = nl2br(s($body));

        // Send with attachment.
        $userfrom = \core_user::get_noreply_user();
        $result = email_to_user($student, $userfrom, $subject, $body, $bodyhtml, $filepath, $filename);

        // Clean up temp file.
        @unlink($filepath);

        if ($result) {
            $DB->set_field(self::TABLE, 'emailed', 1, ['id' => $issueid]);
        }

        return $result;
    }

    /**
     * Resolve all placeholders in the template with real user and course data.
     *
     * Returns the full template structure with placeholder values replaced by actual
     * data from the user profile, course, and activity settings.
     *
     * @param int $certstudioid The certstudio activity instance ID.
     * @param int $userid The user ID to resolve data for.
     * @param string $code The verification code of the issued certificate, or '' for one being issued now.
     * @return \stdClass Object containing resolved template data with pages and elements.
     * @throws \moodle_exception If the activity instance or template is not found.
     */
    public static function get_template_data(int $certstudioid, int $userid, string $code = ''): \stdClass {
        global $DB, $CFG;

        require_once($CFG->dirroot . '/mod/certstudio/lib.php');

        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $certstudioid], '*', MUST_EXIST);
        $course = $DB->get_record('course', ['id' => $certstudio->course], '*', MUST_EXIST);
        $user = $DB->get_record('user', ['id' => $userid], '*', MUST_EXIST);

        // Dates on the certificate are those of the issue, not of the download.
        $issue = false;
        if ($code !== '') {
            $issue = $DB->get_record(self::TABLE, [
                'certstudioid' => $certstudioid,
                'userid' => $userid,
                'code' => $code,
            ], 'id, timecreated, expirydate', IGNORE_MULTIPLE);
        }
        if ($issue) {
            $issuetime = (int) $issue->timecreated;
            $expirydate = (int) $issue->expirydate;
        } else {
            $issuetime = time();
            $expirydays = (int) ($certstudio->expirydays ?? 0);
            $expirydate = $expirydays > 0 ? $issuetime + ($expirydays * 86400) : 0;
        }
        // In the student's time zone, so the certificate reads the same whoever downloads it.
        $timezone = \core_date::get_user_timezone($user);

        // Force language if set on the activity.
        $origlang = null;
        if (!empty($certstudio->language)) {
            $origlang = force_current_language($certstudio->language);
        }

        // Build the placeholder replacement map.
        $placeholders = [
            '{{fullname}}' => fullname($user),
            '{{firstname}}' => $user->firstname,
            '{{lastname}}' => $user->lastname,
            '{{email}}' => $user->email,
            '{{username}}' => $user->username,
            '{{idnumber}}' => $user->idnumber,
            '{{institution}}' => $user->institution,
            '{{department}}' => $user->department,
            '{{city}}' => $user->city,
            '{{country}}' => $user->country,
            '{{coursename}}' => $course->fullname,
            '{{courseshortname}}' => $course->shortname,
            '{{courseidnumber}}' => $course->idnumber,
            '{{activityname}}' => $certstudio->name,
            '{{date}}' => userdate($issuetime, get_string('strftimedate', 'langconfig'), $timezone),
            '{{datetime}}' => userdate($issuetime, get_string('strftimedatetime', 'langconfig'), $timezone),
        ];

        // Load the template and its pages/elements.
        $template = template::get($certstudio->templateid);
        if (!$template) {
            throw new \moodle_exception('templatenotfound', 'mod_certstudio');
        }

        $result = new \stdClass();
        $result->templatename = $template->name;
        $result->pages = [];

        // Include PDF protection settings.
        $result->protection = [
            'print' => (bool) get_config('mod_certstudio', 'protection_print'),
            'modify' => (bool) get_config('mod_certstudio', 'protection_modify'),
            'copy' => (bool) get_config('mod_certstudio', 'protection_copy'),
        ];

        // Include font URLs so the JS PDF renderer can load custom TTF fonts with Unicode support.
        $fontlist = certstudio_get_fonts();
        $result->fonts = [];
        foreach ($fontlist as $font) {
            $result->fonts[] = [
                'family' => $font['family'],
                'style' => $font['style'],
                'url' => (new \moodle_url('/mod/certstudio/fonts/' . $font['file']))->out(false),
            ];
        }

        $pages = template::get_pages($template->id);
        foreach ($pages as $page) {
            $pagedata = new \stdClass();
            $pagedata->width = $page->width;
            $pagedata->height = $page->height;
            $pagedata->leftmargin = $page->leftmargin;
            $pagedata->rightmargin = $page->rightmargin;
            $pagedata->backgroundimage = $page->backgroundimage;
            $pagedata->bgcolor = $page->bgcolor ?? '#ffffff';
            $pagedata->sequence = $page->sequence;
            $pagedata->elements = [];

            $elements = $DB->get_records('certstudio_elements', ['pageid' => $page->id], 'sequence ASC');
            foreach ($elements as $element) {
                $elementdata = new \stdClass();
                $elementdata->name = $element->name;
                $elementdata->type = $element->type;
                $elementdata->posx = $element->posx;
                $elementdata->posy = $element->posy;
                $elementdata->width = $element->width;
                $elementdata->height = $element->height;
                $elementdata->rotation = $element->rotation;
                $elementdata->fontfamily = $element->fontfamily;
                $elementdata->fontsize = $element->fontsize;
                $elementdata->fontweight = $element->fontweight;
                $elementdata->fontstyle = $element->fontstyle;
                $elementdata->color = $element->color;
                $elementdata->alignment = $element->alignment;
                $elementdata->opacity = $element->opacity;
                $elementdata->sequence = $element->sequence;

                // Resolve element data: replace placeholders in data JSON and inject resolved text for dynamic types.
                $elementdata->data = $element->data;
                if (!empty($elementdata->data)) {
                    $elementdata->data = str_replace(
                        array_keys($placeholders),
                        array_values($placeholders),
                        $elementdata->data
                    );
                }

                // For dynamic element types, resolve the display text based on type.
                $resolvedtext = match ($element->type) {
                    'studentname' => fullname($user),
                    'coursename' => $course->fullname,
                    'categoryname' => $DB->get_field('course_categories', 'name', ['id' => $course->category]),
                    'date' => self::format_date($issuetime, $element, $timezone),
                    'grade' => self::get_user_grade($course->id, $userid, $element),
                    'gradeitemname' => self::get_grade_item_name($course->id, $element),
                    'teachername' => self::get_teacher_name($course->id),
                    'userfield' => self::get_user_field($user, $element),
                    'coursefield' => self::get_course_field($course, $element, $timezone),
                    'daterange' => self::get_course_date_range($course, $element, $timezone),
                    'expiry' => $expirydate ? self::format_date($expirydate, $element, $timezone) : '',
                    'certdate' => self::get_cert_date($element, $issuetime, $timezone),
                    'certstatement' => self::get_cert_statement($element, $user),
                    default => null,
                };

                if ($resolvedtext !== null) {
                    // Inject resolved text so the JS renderer uses it instead of placeholders.
                    $dataarr = !empty($elementdata->data) ? json_decode($elementdata->data, true) : [];
                    if (!is_array($dataarr)) {
                        $dataarr = [];
                    }
                    $dataarr['resolvedtext'] = (string) $resolvedtext;
                    $elementdata->data = json_encode($dataarr);
                }

                // For code/qrcode elements, inject the verification code.
                if ($element->type === 'code' || $element->type === 'qrcode') {
                    $dataarr = !empty($elementdata->data) ? json_decode($elementdata->data, true) : [];
                    if (!is_array($dataarr)) {
                        $dataarr = [];
                    }
                    $dataarr['resolvedtext'] = $code;
                    $elementdata->data = json_encode($dataarr);
                }

                $pagedata->elements[] = $elementdata;
            }

            $result->pages[] = $pagedata;
        }

        // Restore original language.
        if ($origlang !== null) {
            force_current_language($origlang);
        }

        return $result;
    }

    /**
     * Get the grade item chosen for a grade or grade item name element.
     *
     * Falls back to the course total when the element has no grade item, or when its grade item is not in the
     * course, such as in a design copied from another course.
     *
     * @param int $courseid Course ID.
     * @param \stdClass|null $element Element record, or null for the course total.
     * @return \grade_item|null The grade item, or null if the course has no grade items.
     */
    private static function get_grade_item(int $courseid, ?\stdClass $element): ?\grade_item {
        global $CFG;
        require_once($CFG->libdir . '/gradelib.php');

        $data = !empty($element->data) ? json_decode($element->data, true) : [];
        $value = (string) ($data['gradeitem'] ?? '');
        // Designs migrated from Custom certificate keep its grade element settings as JSON.
        $legacy = json_decode($value, true);
        if (is_array($legacy)) {
            $value = (string) ($legacy['gradeitem'] ?? '');
        }

        $gradeitem = false;
        if (preg_match('/^gradeitem:(\d+)$/', $value, $matches)) {
            $gradeitem = \grade_item::fetch(['id' => (int) $matches[1], 'courseid' => $courseid]);
        } else if (ctype_digit($value) && $value !== '0') {
            // Custom certificate stored the course module of an activity.
            $cm = get_coursemodule_from_id('', (int) $value, $courseid);
            if ($cm) {
                $gradeitem = \grade_item::fetch([
                    'courseid' => $courseid,
                    'itemtype' => 'mod',
                    'itemmodule' => $cm->modname,
                    'iteminstance' => $cm->instance,
                    'itemnumber' => 0,
                ]);
            }
        }
        if (!$gradeitem) {
            $gradeitem = \grade_item::fetch(['courseid' => $courseid, 'itemtype' => 'course']);
        }
        return $gradeitem ?: null;
    }

    /**
     * Get the name of the grade item chosen for a grade item name element.
     *
     * @param int $courseid Course ID.
     * @param \stdClass $element Element record.
     * @return string The grade item name, or empty string.
     */
    private static function get_grade_item_name(int $courseid, \stdClass $element): string {
        $gradeitem = self::get_grade_item($courseid, $element);
        return $gradeitem ? $gradeitem->get_name(false, false) : '';
    }

    /**
     * Get the user's final grade for the grade item chosen for the element, by default the course total.
     *
     * @param int $courseid Course ID.
     * @param int $userid User ID.
     * @param \stdClass|null $element Element record, or null for the course total.
     * @return string The formatted grade or empty string.
     */
    private static function get_user_grade(int $courseid, int $userid, ?\stdClass $element = null): string {
        $gradeitem = self::get_grade_item($courseid, $element);
        if (!$gradeitem) {
            return '';
        }
        $grade = $gradeitem->get_grade($userid);
        if (!$grade || $grade->finalgrade === null) {
            return '';
        }
        // A grade hidden from the student, including hidden until a date, must not appear on their certificate.
        if (
            ($gradeitem->is_hidden() || $grade->is_hidden()) &&
            !has_capability('moodle/grade:viewhidden', \context_course::instance($courseid), $userid)
        ) {
            return '';
        }
        return grade_format_gradevalue($grade->finalgrade, $gradeitem);
    }

    /**
     * Get the primary teacher name for the course.
     *
     * @param int $courseid Course ID.
     * @return string Teacher name or empty string.
     */
    private static function get_teacher_name(int $courseid): string {
        $context = \context_course::instance($courseid);
        $teachers = get_enrolled_users($context, 'mod/certstudio:manage', 0, 'u.*', 'u.lastname', 0, 1);
        if (empty($teachers)) {
            // Fallback: try editingteacher role.
            $teachers = get_enrolled_users($context, 'moodle/course:update', 0, 'u.*', 'u.lastname', 0, 1);
        }
        $teacher = reset($teachers);
        return $teacher ? fullname($teacher) : '';
    }

    /**
     * Get a user profile field value for the userfield element.
     *
     * @param \stdClass $user User record.
     * @param \stdClass $element Element record.
     * @return string The field value.
     */
    private static function get_user_field(\stdClass $user, \stdClass $element): string {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/user/profile/lib.php');

        $fieldname = self::get_field_name($element);
        if ($fieldname === '') {
            return '';
        }

        // Only identity fields that belong on a certificate. The user record also holds the password hash,
        // secrets and IP addresses, and the field name is free text in the editor.
        if (in_array($fieldname, self::USER_FIELDS, true)) {
            return (string) ($user->$fieldname ?? '');
        }

        // Custom profile fields, by shortname or as profile_field_<shortname>, if teachers may already see them.
        $shortname = preg_replace('/^profile_field_/', '', $fieldname);
        $field = $DB->get_record_sql(
            "SELECT f.visible, d.data
               FROM {user_info_field} f
          LEFT JOIN {user_info_data} d ON d.fieldid = f.id AND d.userid = :userid
              WHERE f.shortname = :shortname",
            ['userid' => $user->id, 'shortname' => $shortname]
        );
        if ($field && in_array((string) $field->visible, [PROFILE_VISIBLE_ALL, PROFILE_VISIBLE_TEACHERS], true)) {
            return (string) ($field->data ?? '');
        }
        return '';
    }

    /**
     * Get the field name chosen for a user field or course field element.
     *
     * @param \stdClass $element Element record.
     * @return string The field name, or empty string.
     */
    private static function get_field_name(\stdClass $element): string {
        $data = !empty($element->data) ? json_decode($element->data, true) : [];
        $fieldname = trim((string) ($data['fieldname'] ?? ''));
        // Designs migrated from Custom certificate by 1.0.0 hold the field as {name} in the text instead.
        if ($fieldname === '' && preg_match('/^\{(\w+)\}$/', trim((string) ($data['text'] ?? '')), $matches)) {
            $fieldname = $matches[1];
        }
        return $fieldname;
    }

    /**
     * Get a course field value for the coursefield element.
     *
     * @param \stdClass $course Course record.
     * @param \stdClass $element Element record.
     * @param string $timezone Time zone for the course dates.
     * @return string The field value.
     */
    private static function get_course_field(\stdClass $course, \stdClass $element, string $timezone): string {
        $fieldname = self::get_field_name($element);
        if (in_array($fieldname, ['startdate', 'enddate'], true)) {
            return empty($course->$fieldname) ? '' : self::format_date((int) $course->$fieldname, $element, $timezone);
        }
        if (in_array($fieldname, self::COURSE_FIELDS, true)) {
            $context = \context_course::instance($course->id);
            return format_string($course->$fieldname, true, ['context' => $context, 'escape' => false]);
        }

        // Custom course fields that everyone may see, by shortname or as customfield_<shortname>.
        $shortname = preg_replace('/^customfield_/', '', $fieldname);
        if ($shortname === '') {
            return '';
        }
        $handler = \core_course\customfield\course_handler::create();
        foreach ($handler->get_instance_data($course->id, true) as $data) {
            $field = $data->get_field();
            if (
                $field->get('shortname') === $shortname &&
                (int) $field->get_configdata_property('visibility') === \core_course\customfield\course_handler::VISIBLETOALL
            ) {
                return trim(html_to_text((string) $data->export_value(), 0, false));
            }
        }
        return '';
    }

    /**
     * Get the course start and end dates for the date range element.
     *
     * @param \stdClass $course Course record.
     * @param \stdClass $element Element record.
     * @param string $timezone Time zone for the dates.
     * @return string The date range, the start date alone if the course has no end date, or empty string.
     */
    private static function get_course_date_range(\stdClass $course, \stdClass $element, string $timezone): string {
        if (empty($course->startdate)) {
            return '';
        }
        $range = self::format_date((int) $course->startdate, $element, $timezone);
        if (!empty($course->enddate)) {
            $range .= ' - ' . self::format_date((int) $course->enddate, $element, $timezone);
        }
        return $range;
    }

    /**
     * Format a date with the date format chosen for the element.
     *
     * @param int $time Unix timestamp.
     * @param \stdClass $element Element record.
     * @param string $timezone Time zone for the date.
     * @return string The formatted date.
     */
    private static function format_date(int $time, \stdClass $element, string $timezone): string {
        $data = !empty($element->data) ? json_decode($element->data, true) : [];
        $format = (string) ($data['dateformat'] ?? '');
        // Designs migrated from Custom certificate keep its date element settings as JSON.
        $legacy = json_decode($format, true);
        if (is_array($legacy)) {
            $format = (string) ($legacy['dateformat'] ?? '');
        }

        if (strpos($format, 'strftime') === 0 && get_string_manager()->string_exists($format, 'langconfig')) {
            $format = get_string($format, 'langconfig');
        } else if (strpos($format, '%') === false) {
            // Includes the 'F j, Y' the editor stored in 1.0.0, which was never applied.
            $format = get_string('strftimedate', 'langconfig');
        }
        return self::userdate($time, $format, $timezone);
    }

    /**
     * Format a date like userdate(), keeping the leading zero of the day when the month is a number, as in 02/03/2026.
     *
     * @param int $time Unix timestamp.
     * @param string $format strftime format.
     * @param string|float $timezone Time zone, or 99 for the current user's.
     * @return string The formatted date.
     */
    private static function userdate(int $time, string $format, $timezone = 99): string {
        return userdate($time, $format, $timezone, strpos($format, '%m') === false);
    }

    /**
     * Get the date formats the editor offers, labelled with today's date in each format.
     *
     * @return array[] List of ['value' => string, 'label' => string].
     */
    public static function get_date_format_options(): array {
        $options = [];
        foreach (self::DATE_FORMATS as $format) {
            $strftime = strpos($format, '%') === false ? get_string($format, 'langconfig') : $format;
            $options[] = ['value' => $format, 'label' => self::userdate(time(), $strftime)];
        }
        return $options;
    }

    /**
     * Get the grade items the grade and grade item name elements can use in a course.
     *
     * @param int $courseid Course ID.
     * @return array[] List of ['value' => string, 'label' => string], starting with the course total.
     */
    public static function get_grade_item_options(int $courseid): array {
        global $CFG;
        require_once($CFG->libdir . '/gradelib.php');

        $options = [['value' => '', 'label' => get_string('coursetotal', 'grades')]];
        foreach (\grade_item::fetch_all(['courseid' => $courseid]) ?: [] as $gradeitem) {
            if ($gradeitem->is_course_item() || $gradeitem->is_category_item()) {
                continue;
            }
            $options[] = ['value' => 'gradeitem:' . $gradeitem->id, 'label' => $gradeitem->get_name(false, false)];
        }
        return $options;
    }

    /**
     * Get the course fields the course field element can print.
     *
     * @return array[] List of ['value' => string, 'label' => string].
     */
    public static function get_course_field_options(): array {
        $labels = [
            'fullname' => get_string('fullnamecourse'),
            'shortname' => get_string('shortnamecourse'),
            'idnumber' => get_string('idnumbercourse'),
            'startdate' => get_string('startdate'),
            'enddate' => get_string('enddate'),
        ];
        $options = [];
        foreach (self::COURSE_FIELDS as $fieldname) {
            $options[] = ['value' => $fieldname, 'label' => $labels[$fieldname]];
        }

        $handler = \core_course\customfield\course_handler::create();
        foreach ($handler->get_fields() as $field) {
            if ((int) $field->get_configdata_property('visibility') === \core_course\customfield\course_handler::VISIBLETOALL) {
                $options[] = ['value' => 'customfield_' . $field->get('shortname'), 'label' => $field->get_formatted_name()];
            }
        }
        return $options;
    }

    /**
     * Get formatted Greek-style date for certdate element.
     *
     * @param \stdClass $element Element record.
     * @param int $time Unix timestamp of the issue.
     * @param string $timezone Time zone for the date.
     * @return string Formatted date string.
     */
    private static function get_cert_date(\stdClass $element, int $time, string $timezone): string {
        $data = !empty($element->data) ? json_decode($element->data, true) : [];
        $city = $data['city'] ?? 'Αθήνα';
        // Greek month names.
        $months = [
            1 => 'Ιανουαρίου', 2 => 'Φεβρουαρίου', 3 => 'Μαρτίου',
            4 => 'Απριλίου', 5 => 'Μαΐου', 6 => 'Ιουνίου',
            7 => 'Ιουλίου', 8 => 'Αυγούστου', 9 => 'Σεπτεμβρίου',
            10 => 'Οκτωβρίου', 11 => 'Νοεμβρίου', 12 => 'Δεκεμβρίου',
        ];
        $date = new \DateTime('@' . $time);
        $date->setTimezone(\core_date::get_user_timezone_object($timezone));
        return $city . ', ' . $date->format('j') . ' ' . $months[(int) $date->format('n')] . ' ' . $date->format('Y');
    }

    /**
     * Get resolved Greek certificate statement for certstatement element.
     *
     * @param \stdClass $element Element record.
     * @param \stdClass $user User record.
     * @return string Resolved statement.
     */
    private static function get_cert_statement(\stdClass $element, \stdClass $user): string {
        $data = !empty($element->data) ? json_decode($element->data, true) : [];
        $text = $data['text'] ?? 'Βεβαιώνεται ότι ο/η {{fullname}}';
        // Replace common placeholders.
        $text = str_replace('{{fullname}}', fullname($user), $text);
        $text = str_replace('{{firstname}}', $user->firstname, $text);
        $text = str_replace('{{lastname}}', $user->lastname, $text);
        $text = str_replace('ΕΠΩΝΥΜΟ', $user->lastname, $text);
        $text = str_replace('ΟΝΟΜΑ', $user->firstname, $text);
        return $text;
    }

    /**
     * Resolve a message template from plugin settings with placeholder replacements.
     *
     * @param string $templatekey The setting key (e.g. 'issuedtemplate').
     * @param array $placeholders Associative array of {placeholder} => value.
     * @return string The resolved message text.
     */
    public static function resolve_message_template(string $templatekey, array $placeholders): string {
        $template = get_config('mod_certstudio', $templatekey);
        if (empty($template)) {
            // Fall back to lang string default.
            $langkey = $templatekey . '_default';
            $template = get_string_manager()->string_exists($langkey, 'mod_certstudio')
                ? get_string($langkey, 'mod_certstudio')
                : '';
        }
        return str_replace(array_keys($placeholders), array_values($placeholders), $template);
    }

    /**
     * Send a Moodle notification to a user using a template.
     *
     * @param string $templatekey The setting key for the template.
     * @param \stdClass $userto The recipient user.
     * @param string $subject The message subject.
     * @param array $placeholders Placeholder replacements.
     * @param \moodle_url|null $contexturl Optional URL to link in the notification.
     * @return bool True if the message was sent.
     */
    public static function send_notification(
        string $templatekey,
        \stdClass $userto,
        string $subject,
        array $placeholders,
        ?\moodle_url $contexturl = null
    ): bool {
        global $USER;

        $body = self::resolve_message_template($templatekey, $placeholders);
        if (empty($body)) {
            return false;
        }

        $message = new \core\message\message();
        $message->component = 'mod_certstudio';
        $message->name = 'approval_result';
        $message->userfrom = $USER;
        $message->userto = $userto;
        $message->subject = $subject;
        $message->fullmessage = $body;
        $message->fullmessageformat = FORMAT_PLAIN;
        $message->fullmessagehtml = nl2br(s($body));
        $message->smallmessage = $subject;
        $message->notification = 1;
        if ($contexturl) {
            $message->contexturl = $contexturl;
            $message->contexturlname = get_string('downloadcertificate', 'mod_certstudio');
        }
        return (bool) message_send($message);
    }
}
