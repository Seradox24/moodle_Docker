<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Approval workflow class for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * Manages the certificate approval workflow including requests, approvals, rejections, and notifications.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class approval {
    /** @var int Status: pending review. */
    public const STATUS_PENDING = 0;

    /** @var int Status: approved by reviewer. */
    public const STATUS_APPROVED = 1;

    /** @var int Status: rejected by reviewer. */
    public const STATUS_REJECTED = 2;

    /** @var string The database table for approval requests. */
    private const TABLE = 'certstudio_approval_requests';

    /** @var string The database table for the activity instance. */
    private const TABLE_INSTANCE = 'certstudio';

    /**
     * Create a new approval request for a user.
     *
     * @param int $certstudioid The certstudio activity instance ID.
     * @param int $userid The user ID requesting approval.
     * @return int The ID of the newly created request.
     * @throws \moodle_exception If a pending request already exists for this user.
     */
    public static function request(int $certstudioid, int $userid): int {
        global $DB;

        // Check for existing pending request.
        $existing = $DB->get_record(self::TABLE, [
            'certstudioid' => $certstudioid,
            'userid' => $userid,
            'status' => self::STATUS_PENDING,
        ]);

        if ($existing) {
            return $existing->id;
        }

        $record = new \stdClass();
        $record->certstudioid = $certstudioid;
        $record->userid = $userid;
        $record->status = self::STATUS_PENDING;
        $record->timecreated = time();
        $record->timemodified = $record->timecreated;

        $requestid = $DB->insert_record(self::TABLE, $record);

        // Fire the approval_requested event.
        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $certstudioid], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('certstudio', $certstudioid, $certstudio->course, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);

        $event = \mod_certstudio\event\approval_requested::create([
            'objectid' => $requestid,
            'context' => $context,
            'relateduserid' => $userid,
            'other' => [
                'certstudioid' => $certstudioid,
            ],
        ]);
        $event->trigger();

        // Send notification to teacher if enabled.
        if ($certstudio->approvalnotifyteacher) {
            $record->id = $requestid;
            self::send_notification_to_teacher($record);
        }

        return $requestid;
    }

    /**
     * Approve a pending request.
     *
     * @param int $requestid The approval request ID.
     * @param int $reviewerid The user ID of the reviewer.
     * @param string $comment An optional review comment.
     * @return bool True on success.
     * @throws \moodle_exception If the request is not found or not pending.
     */
    public static function approve(int $requestid, int $reviewerid, string $comment = ''): bool {
        global $DB;

        $request = self::get_request($requestid);
        if (!$request) {
            throw new \moodle_exception('approvalrequestnotfound', 'mod_certstudio');
        }

        if ((int) $request->status !== self::STATUS_PENDING) {
            throw new \moodle_exception('approvalrequestnotpending', 'mod_certstudio');
        }

        $request->status = self::STATUS_APPROVED;
        $request->reviewerid = $reviewerid;
        $request->reviewcomment = $comment;
        $request->timemodified = time();

        $result = $DB->update_record(self::TABLE, $request);

        // Fire the approval_approved event.
        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $request->certstudioid], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('certstudio', $request->certstudioid, $certstudio->course, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);

        $event = \mod_certstudio\event\approval_approved::create([
            'objectid' => $requestid,
            'context' => $context,
            'relateduserid' => $request->userid,
            'other' => [
                'certstudioid' => $request->certstudioid,
                'reviewerid' => $reviewerid,
            ],
        ]);
        $event->trigger();

        // Send notification to student if enabled.
        if ($certstudio->approvalnotifystudent) {
            self::send_notification_to_student($request);
        }

        // Issue the certificate now, so it exists for verification and reports straight away
        // rather than only once the student next opens the activity.
        certificate::issue($request->certstudioid, $request->userid);

        return $result;
    }

    /**
     * Reject a pending request.
     *
     * @param int $requestid The approval request ID.
     * @param int $reviewerid The user ID of the reviewer.
     * @param string $comment An optional review comment.
     * @return bool True on success.
     * @throws \moodle_exception If the request is not found or not pending.
     */
    public static function reject(int $requestid, int $reviewerid, string $comment = ''): bool {
        global $DB;

        $request = self::get_request($requestid);
        if (!$request) {
            throw new \moodle_exception('approvalrequestnotfound', 'mod_certstudio');
        }

        if ((int) $request->status !== self::STATUS_PENDING) {
            throw new \moodle_exception('approvalrequestnotpending', 'mod_certstudio');
        }

        $request->status = self::STATUS_REJECTED;
        $request->reviewerid = $reviewerid;
        $request->reviewcomment = $comment;
        $request->timemodified = time();

        $result = $DB->update_record(self::TABLE, $request);

        // Fire the approval_rejected event.
        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $request->certstudioid], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('certstudio', $request->certstudioid, $certstudio->course, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);

        $event = \mod_certstudio\event\approval_rejected::create([
            'objectid' => $requestid,
            'context' => $context,
            'relateduserid' => $request->userid,
            'other' => [
                'certstudioid' => $request->certstudioid,
                'reviewerid' => $reviewerid,
            ],
        ]);
        $event->trigger();

        // Send notification to student if enabled.
        if ($certstudio->approvalnotifystudent) {
            self::send_notification_to_student($request);
        }

        return $result;
    }

    /**
     * Get all pending approval requests for a given activity.
     *
     * @param int $certstudioid The certstudio activity instance ID.
     * @return array Array of pending request records.
     */
    public static function get_pending_requests(int $certstudioid): array {
        global $DB;

        return $DB->get_records(self::TABLE, [
            'certstudioid' => $certstudioid,
            'status' => self::STATUS_PENDING,
        ], 'timecreated ASC');
    }

    /**
     * Get a single approval request by ID.
     *
     * @param int $id The request ID.
     * @return \stdClass|false The request record, or false if not found.
     */
    public static function get_request(int $id) {
        global $DB;

        return $DB->get_record(self::TABLE, ['id' => $id]);
    }

    /**
     * Get the approval request for a specific user in a given activity.
     *
     * Returns the most recent request regardless of status.
     *
     * @param int $certstudioid The certstudio activity instance ID.
     * @param int $userid The user ID.
     * @return \stdClass|false The request record, or false if not found.
     */
    public static function get_user_request(int $certstudioid, int $userid) {
        global $DB;

        $requests = $DB->get_records(self::TABLE, [
            'certstudioid' => $certstudioid,
            'userid' => $userid,
        ], 'timecreated DESC', '*', 0, 1);

        return !empty($requests) ? reset($requests) : false;
    }

    /**
     * Send a notification to teachers about a new approval request.
     *
     * Notifies all users with the mod/certstudio:approvecertificate capability
     * in the activity context.
     *
     * @param \stdClass $request The approval request record.
     * @return void
     */
    public static function send_notification_to_teacher(\stdClass $request): void {
        global $DB;

        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $request->certstudioid], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('certstudio', $request->certstudioid, $certstudio->course, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);
        $student = $DB->get_record('user', ['id' => $request->userid], '*', MUST_EXIST);

        // Get all users who can approve certificates.
        $teachers = get_users_by_capability($context, 'mod/certstudio:approvecertificate');

        foreach ($teachers as $teacher) {
            $message = new \core\message\message();
            $message->component = 'mod_certstudio';
            $message->name = 'approval_request';
            $message->userfrom = \core_user::get_noreply_user();
            $message->userto = $teacher;
            $message->subject = get_string('approvalrequestsubject', 'mod_certstudio', fullname($student));
            $message->fullmessage = get_string('approvalrequestbody', 'mod_certstudio', [
                'student' => fullname($student),
                'activity' => $certstudio->name,
            ]);
            $message->fullmessageformat = FORMAT_PLAIN;
            $message->fullmessagehtml = get_string('approvalrequestbodyhtml', 'mod_certstudio', [
                'student' => fullname($student),
                'activity' => $certstudio->name,
                'url' => (new \moodle_url('/mod/certstudio/approve.php', ['id' => $cm->id]))->out(),
            ]);
            $message->smallmessage = get_string('approvalrequestsmall', 'mod_certstudio', fullname($student));
            $message->notification = 1;
            $message->contexturl = (new \moodle_url('/mod/certstudio/approve.php', ['id' => $cm->id]))->out(false);
            $message->contexturlname = get_string('approvalrequests', 'mod_certstudio');
            $message->courseid = $certstudio->course;

            @message_send($message);
        }
    }

    /**
     * Send a notification to the student about the approval result.
     *
     * @param \stdClass $request The approval request record (must include status and reviewcomment).
     * @return void
     */
    public static function send_notification_to_student(\stdClass $request): void {
        global $DB;

        $certstudio = $DB->get_record(self::TABLE_INSTANCE, ['id' => $request->certstudioid], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('certstudio', $request->certstudioid, $certstudio->course, false, MUST_EXIST);
        $student = $DB->get_record('user', ['id' => $request->userid], '*', MUST_EXIST);
        $reviewer = $DB->get_record('user', ['id' => $request->reviewerid], '*', MUST_EXIST);

        $statustext = ((int) $request->status === self::STATUS_APPROVED)
            ? get_string('approved', 'mod_certstudio')
            : get_string('rejected', 'mod_certstudio');

        $message = new \core\message\message();
        $message->component = 'mod_certstudio';
        $message->name = 'approval_result';
        $message->userfrom = \core_user::get_noreply_user();
        $message->userto = $student;
        $message->subject = get_string('approvalresultsubject', 'mod_certstudio', [
            'activity' => $certstudio->name,
            'status' => $statustext,
        ]);
        $message->fullmessage = get_string('approvalresultbody', 'mod_certstudio', [
            'activity' => $certstudio->name,
            'status' => $statustext,
            'comment' => $request->reviewcomment ?? '',
            'reviewer' => fullname($reviewer),
        ]);
        $message->fullmessageformat = FORMAT_PLAIN;
        $message->fullmessagehtml = get_string('approvalresultbodyhtml', 'mod_certstudio', [
            'activity' => $certstudio->name,
            'status' => $statustext,
            'comment' => $request->reviewcomment ?? '',
            'reviewer' => fullname($reviewer),
            'url' => (new \moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]))->out(),
        ]);
        $message->smallmessage = get_string('approvalresultsmall', 'mod_certstudio', $statustext);
        $message->notification = 1;
        $message->contexturl = (new \moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]))->out(false);
        $message->contexturlname = $certstudio->name;
        $message->courseid = $certstudio->course;

        @message_send($message);
    }
}
