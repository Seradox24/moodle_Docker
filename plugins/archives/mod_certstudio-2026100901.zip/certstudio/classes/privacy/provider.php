<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy Subsystem implementation for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2018 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\helper;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;

/**
 * Privacy provider for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2018 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class provider implements
        \core_privacy\local\metadata\provider,
        \core_privacy\local\request\core_userlist_provider,
        \core_privacy\local\request\plugin\provider {
    /**
     * Returns metadata about the user data stored by this plugin.
     *
     * @param collection $collection The initialised collection to add items to.
     * @return collection A listing of user data stored through this system.
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table(
            'certstudio_issues',
            [
                'userid' => 'privacy:metadata:certstudio_issues:userid',
                'code' => 'privacy:metadata:certstudio_issues:code',
                'templatedata' => 'privacy:metadata:certstudio_issues:templatedata',
                'timecreated' => 'privacy:metadata:certstudio_issues:timecreated',
            ],
            'privacy:metadata:certstudio_issues'
        );

        $collection->add_database_table(
            'certstudio_approval_requests',
            [
                'userid' => 'privacy:metadata:certstudio_approval_requests:userid',
                'status' => 'privacy:metadata:certstudio_approval_requests:status',
                'reviewerid' => 'privacy:metadata:certstudio_approval_requests:reviewerid',
                'reviewcomment' => 'privacy:metadata:certstudio_approval_requests:reviewcomment',
                'timecreated' => 'privacy:metadata:certstudio_approval_requests:timecreated',
                'timemodified' => 'privacy:metadata:certstudio_approval_requests:timemodified',
            ],
            'privacy:metadata:certstudio_approval_requests'
        );

        $collection->add_external_location_link(
            'ai_provider',
            [
                'description' => 'privacy:metadata:ai_provider:description',
            ],
            'privacy:metadata:ai_provider'
        );

        return $collection;
    }

    /**
     * Get the list of contexts that contain user information for the specified user.
     *
     * @param int $userid The user to search.
     * @return contextlist The contextlist containing the list of contexts used in this plugin.
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        $sql = "SELECT ctx.id
                  FROM {context} ctx
            INNER JOIN {course_modules} cm ON cm.id = ctx.instanceid AND ctx.contextlevel = :contextlevel
            INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
            INNER JOIN {certstudio} cs ON cs.id = cm.instance
            INNER JOIN {certstudio_issues} ci ON ci.certstudioid = cs.id
                 WHERE ci.userid = :userid";

        $params = [
            'contextlevel' => CONTEXT_MODULE,
            'modname' => 'certstudio',
            'userid' => $userid,
        ];

        $contextlist->add_from_sql($sql, $params);

        $sql = "SELECT ctx.id
                  FROM {context} ctx
            INNER JOIN {course_modules} cm ON cm.id = ctx.instanceid AND ctx.contextlevel = :contextlevel
            INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
            INNER JOIN {certstudio} cs ON cs.id = cm.instance
            INNER JOIN {certstudio_approval_requests} car ON car.certstudioid = cs.id
                 WHERE car.userid = :userid OR car.reviewerid = :reviewerid";

        $params = [
            'contextlevel' => CONTEXT_MODULE,
            'modname' => 'certstudio',
            'userid' => $userid,
            'reviewerid' => $userid,
        ];

        $contextlist->add_from_sql($sql, $params);

        return $contextlist;
    }

    /**
     * Get the list of users who have data within a context.
     *
     * @param userlist $userlist The userlist containing the list of users who have data in this context/plugin combination.
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();

        if (!$context instanceof \context_module) {
            return;
        }

        $sql = "SELECT ci.userid
                  FROM {certstudio_issues} ci
            INNER JOIN {certstudio} cs ON cs.id = ci.certstudioid
            INNER JOIN {course_modules} cm ON cm.instance = cs.id
            INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                 WHERE cm.id = :cmid";

        $params = [
            'modname' => 'certstudio',
            'cmid' => $context->instanceid,
        ];

        $userlist->add_from_sql('userid', $sql, $params);

        $sql = "SELECT car.userid
                  FROM {certstudio_approval_requests} car
            INNER JOIN {certstudio} cs ON cs.id = car.certstudioid
            INNER JOIN {course_modules} cm ON cm.instance = cs.id
            INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                 WHERE cm.id = :cmid";

        $userlist->add_from_sql('userid', $sql, $params);

        $sql = "SELECT car.reviewerid AS userid
                  FROM {certstudio_approval_requests} car
            INNER JOIN {certstudio} cs ON cs.id = car.certstudioid
            INNER JOIN {course_modules} cm ON cm.instance = cs.id
            INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                 WHERE cm.id = :cmid";

        $userlist->add_from_sql('userid', $sql, $params);
    }

    /**
     * Export all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts to export information for.
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;

        if (empty($contextlist->count())) {
            return;
        }

        $user = $contextlist->get_user();

        [$contextsql, $contextparams] = $DB->get_in_or_equal($contextlist->get_contextids(), SQL_PARAMS_NAMED);

        // Export certstudio_issues data.
        $sql = "SELECT ci.*, ctx.id AS contextid
                  FROM {certstudio_issues} ci
            INNER JOIN {certstudio} cs ON cs.id = ci.certstudioid
            INNER JOIN {course_modules} cm ON cm.instance = cs.id
            INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
            INNER JOIN {context} ctx ON ctx.instanceid = cm.id AND ctx.contextlevel = :contextlevel
                 WHERE ctx.id {$contextsql}
                   AND ci.userid = :userid";

        $params = [
            'modname' => 'certstudio',
            'contextlevel' => CONTEXT_MODULE,
            'userid' => $user->id,
        ] + $contextparams;

        $issues = $DB->get_recordset_sql($sql, $params);
        foreach ($issues as $issue) {
            $context = \context::instance_by_id($issue->contextid);
            $data = (object) [
                'userid' => $issue->userid,
                'code' => $issue->code,
                'templatedata' => $issue->templatedata,
                'timecreated' => \core_privacy\local\request\transform::datetime($issue->timecreated),
            ];
            writer::with_context($context)->export_data(
                [get_string('privacy:path:issues', 'mod_certstudio')],
                $data
            );
        }
        $issues->close();

        // Export certstudio_approval_requests data.
        $sql = "SELECT car.*, ctx.id AS contextid
                  FROM {certstudio_approval_requests} car
            INNER JOIN {certstudio} cs ON cs.id = car.certstudioid
            INNER JOIN {course_modules} cm ON cm.instance = cs.id
            INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
            INNER JOIN {context} ctx ON ctx.instanceid = cm.id AND ctx.contextlevel = :contextlevel
                 WHERE ctx.id {$contextsql}
                   AND (car.userid = :userid OR car.reviewerid = :reviewerid)";

        $params = [
            'modname' => 'certstudio',
            'contextlevel' => CONTEXT_MODULE,
            'userid' => $user->id,
            'reviewerid' => $user->id,
        ] + $contextparams;

        $requests = $DB->get_recordset_sql($sql, $params);
        foreach ($requests as $request) {
            $context = \context::instance_by_id($request->contextid);
            $data = (object) [
                'userid' => $request->userid,
                'status' => $request->status,
                'reviewerid' => $request->reviewerid,
                'reviewcomment' => $request->reviewcomment,
                'timecreated' => \core_privacy\local\request\transform::datetime($request->timecreated),
                'timemodified' => \core_privacy\local\request\transform::datetime($request->timemodified),
            ];
            writer::with_context($context)->export_data(
                [get_string('privacy:path:approvalrequests', 'mod_certstudio')],
                $data
            );
        }
        $requests->close();
    }

    /**
     * Delete all data for all users in the specified context.
     *
     * @param \context $context The specific context to delete data for.
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;

        if ($context->contextlevel != CONTEXT_MODULE) {
            return;
        }

        $cm = get_coursemodule_from_id('certstudio', $context->instanceid);
        if (!$cm) {
            return;
        }

        $DB->delete_records('certstudio_issues', ['certstudioid' => $cm->instance]);
        $DB->delete_records('certstudio_approval_requests', ['certstudioid' => $cm->instance]);
    }

    /**
     * Delete all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts and user information to delete information for.
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;

        if (empty($contextlist->count())) {
            return;
        }

        $userid = $contextlist->get_user()->id;

        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel != CONTEXT_MODULE) {
                continue;
            }

            $cm = get_coursemodule_from_id('certstudio', $context->instanceid);
            if (!$cm) {
                continue;
            }

            $DB->delete_records('certstudio_issues', [
                'certstudioid' => $cm->instance,
                'userid' => $userid,
            ]);

            $DB->delete_records('certstudio_approval_requests', [
                'certstudioid' => $cm->instance,
                'userid' => $userid,
            ]);

            // Nullify reviewer references where this user was the reviewer.
            $DB->set_field_select(
                'certstudio_approval_requests',
                'reviewerid',
                0,
                'certstudioid = :certstudioid AND reviewerid = :reviewerid',
                [
                    'certstudioid' => $cm->instance,
                    'reviewerid' => $userid,
                ]
            );
        }
    }

    /**
     * Delete multiple users within a single context.
     *
     * @param approved_userlist $userlist The approved context and user information to delete information for.
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        global $DB;

        $context = $userlist->get_context();

        if ($context->contextlevel != CONTEXT_MODULE) {
            return;
        }

        $cm = get_coursemodule_from_id('certstudio', $context->instanceid);
        if (!$cm) {
            return;
        }

        $userids = $userlist->get_userids();
        if (empty($userids)) {
            return;
        }

        [$usersql, $userparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);

        $DB->delete_records_select(
            'certstudio_issues',
            "certstudioid = :certstudioid AND userid {$usersql}",
            ['certstudioid' => $cm->instance] + $userparams
        );

        $DB->delete_records_select(
            'certstudio_approval_requests',
            "certstudioid = :certstudioid AND userid {$usersql}",
            ['certstudioid' => $cm->instance] + $userparams
        );

        // Nullify reviewer references for these users.
        $DB->set_field_select(
            'certstudio_approval_requests',
            'reviewerid',
            0,
            "certstudioid = :certstudioid AND reviewerid {$usersql}",
            ['certstudioid' => $cm->instance] + $userparams
        );
    }
}
