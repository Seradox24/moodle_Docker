<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Migration tool from mod_customcert to mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * Handles migration of data from mod_customcert to mod_certstudio.
 */
class migration {
    /** @var array Element type mapping from customcert to certstudio. */
    private const ELEMENT_MAP = [
        'text' => 'text',
        'studentname' => 'studentname',
        'coursename' => 'coursename',
        'categoryname' => 'categoryname',
        'date' => 'date',
        'grade' => 'grade',
        'gradeitemname' => 'grade',
        'code' => 'code',
        'qrcode' => 'qrcode',
        'teachername' => 'teachername',
        'image' => 'image',
        'bgimage' => 'bgimage',
        'border' => 'border',
        'digitalsignature' => 'image',
        'userpicture' => 'image',
        'userfield' => 'text',
        'coursefield' => 'text',
        'daterange' => 'date',
        'expiry' => 'text',
    ];

    /** @var array Migration log messages. */
    private $log = [];

    /** @var int Counter for migrated templates. */
    private $templatecount = 0;

    /** @var int Counter for migrated activities. */
    private $activitycount = 0;

    /** @var int Counter for migrated issues. */
    private $issuecount = 0;

    /**
     * Check if customcert plugin is installed and has data.
     *
     * @return array Summary of what can be migrated.
     */
    public static function get_migration_summary(): array {
        global $DB;

        $result = [
            'available' => false,
            'templates' => 0,
            'activities' => 0,
            'issues' => 0,
            'pages' => 0,
            'elements' => 0,
        ];

        $dbman = $DB->get_manager();
        if (!$dbman->table_exists('customcert')) {
            return $result;
        }

        $result['available'] = true;
        $result['templates'] = $DB->count_records('customcert_templates');
        $result['activities'] = $DB->count_records('customcert');
        $result['issues'] = $DB->count_records('customcert_issues');
        $result['pages'] = $DB->count_records('customcert_pages');
        $result['elements'] = $DB->count_records('customcert_elements');

        return $result;
    }

    /**
     * Run the full migration.
     *
     * @param bool $migratetemplates Whether to migrate templates.
     * @param bool $migrateactivities Whether to migrate activities (requires templates).
     * @param bool $migrateissues Whether to migrate issued certificates.
     * @return array Migration results.
     */
    public function run(
        bool $migratetemplates = true,
        bool $migrateactivities = true,
        bool $migrateissues = true
    ): array {
        global $DB;

        $dbman = $DB->get_manager();
        if (!$dbman->table_exists('customcert')) {
            $this->log[] = 'Error: customcert tables not found.';
            return $this->get_results();
        }

        // Map old template IDs to new ones.
        $templatemap = [];

        if ($migratetemplates) {
            $templatemap = $this->migrate_templates();
        }

        if ($migrateactivities) {
            $this->migrate_activities($templatemap, $migrateissues);
        }

        return $this->get_results();
    }

    /**
     * Migrate all customcert templates.
     *
     * @return array Map of old template ID => new template ID.
     */
    private function migrate_templates(): array {
        global $DB;

        $templatemap = [];
        $templates = $DB->get_records('customcert_templates');

        foreach ($templates as $oldtemplate) {
            // Check if already migrated (by name match).
            $existingname = '[Migrated] ' . $oldtemplate->name;
            if ($DB->record_exists('certstudio_templates', ['name' => $existingname])) {
                $this->log[] = "Skipped template '{$oldtemplate->name}' (already migrated).";
                $existing = $DB->get_record('certstudio_templates', ['name' => $existingname]);
                $templatemap[$oldtemplate->id] = $existing->id;
                continue;
            }

            $newtemplate = new \stdClass();
            $newtemplate->name = $existingname;
            $newtemplate->contextid = $oldtemplate->contextid;
            $newtemplate->timecreated = $oldtemplate->timecreated;
            $newtemplate->timemodified = $oldtemplate->timemodified;
            $newtemplateid = $DB->insert_record('certstudio_templates', $newtemplate);
            $templatemap[$oldtemplate->id] = $newtemplateid;

            // Migrate pages for this template.
            $this->migrate_pages($oldtemplate->id, $newtemplateid);

            $this->templatecount++;
            $this->log[] = "Migrated template '{$oldtemplate->name}' (ID {$oldtemplate->id} -> {$newtemplateid}).";
        }

        return $templatemap;
    }

    /**
     * Migrate pages from a customcert template to a certstudio template.
     *
     * @param int $oldtemplateid Old customcert template ID.
     * @param int $newtemplateid New certstudio template ID.
     */
    private function migrate_pages(int $oldtemplateid, int $newtemplateid): void {
        global $DB;

        $pages = $DB->get_records('customcert_pages', ['templateid' => $oldtemplateid], 'sequence ASC');

        foreach ($pages as $oldpage) {
            $newpage = new \stdClass();
            $newpage->templateid = $newtemplateid;
            $newpage->width = $oldpage->width ?: 297;
            $newpage->height = $oldpage->height ?: 210;
            $newpage->leftmargin = $oldpage->leftmargin;
            $newpage->rightmargin = $oldpage->rightmargin;
            $newpage->sequence = $oldpage->sequence ?: 0;
            $newpage->timecreated = $oldpage->timecreated;
            $newpage->timemodified = $oldpage->timemodified;
            $newpageid = $DB->insert_record('certstudio_pages', $newpage);

            // Migrate elements for this page.
            $this->migrate_elements($oldpage->id, $newpageid);
        }
    }

    /**
     * Migrate elements from a customcert page to a certstudio page.
     *
     * @param int $oldpageid Old customcert page ID.
     * @param int $newpageid New certstudio page ID.
     */
    private function migrate_elements(int $oldpageid, int $newpageid): void {
        global $DB;

        $elements = $DB->get_records('customcert_elements', ['pageid' => $oldpageid], 'sequence ASC');

        foreach ($elements as $oldelement) {
            $type = self::ELEMENT_MAP[$oldelement->element] ?? 'text';

            $newelement = new \stdClass();
            $newelement->pageid = $newpageid;
            $newelement->name = $oldelement->name;
            $newelement->type = $type;
            $newelement->data = $this->convert_element_data($oldelement);
            $newelement->posx = (float) ($oldelement->posx ?: 0);
            $newelement->posy = (float) ($oldelement->posy ?: 0);
            $newelement->width = (float) ($oldelement->width ?: 60);
            $newelement->height = 10.0;
            $newelement->rotation = 0;
            $newelement->fontfamily = $this->convert_font($oldelement->font);
            $newelement->fontsize = $oldelement->fontsize ?: 12;
            $newelement->fontweight = 'normal';
            $newelement->fontstyle = 'normal';
            $newelement->color = $this->convert_colour($oldelement->colour);
            $newelement->alignment = $oldelement->alignment ?: 'L';
            $newelement->opacity = 1.00;
            $newelement->locked = 0;
            $newelement->sequence = $oldelement->sequence ?: 0;
            $newelement->timecreated = $oldelement->timecreated;
            $newelement->timemodified = $oldelement->timemodified;

            $DB->insert_record('certstudio_elements', $newelement);
        }
    }

    /**
     * Convert customcert element data to certstudio JSON format.
     *
     * @param \stdClass $oldelement The customcert element record.
     * @return string JSON-encoded data for certstudio.
     */
    private function convert_element_data(\stdClass $oldelement): string {
        global $DB;

        $data = [];
        $rawdata = $oldelement->data;

        switch ($oldelement->element) {
            case 'text':
                $data['text'] = $rawdata ?: '';
                break;
            case 'date':
            case 'daterange':
                $data['dateformat'] = $rawdata ?: 'd/m/Y';
                break;
            case 'grade':
            case 'gradeitemname':
                $data['gradeitem'] = $rawdata ?: '';
                break;
            case 'userfield':
                $data['fieldname'] = $rawdata ?: 'email';
                break;
            case 'coursefield':
                // Custom certificate stores custom course fields by ID.
                if (ctype_digit((string) $rawdata)) {
                    $shortname = $DB->get_field('customfield_field', 'shortname', ['id' => (int) $rawdata]);
                    $rawdata = $shortname ? 'customfield_' . $shortname : '';
                }
                $data['fieldname'] = $rawdata ?: 'fullname';
                break;
            case 'image':
            case 'bgimage':
            case 'digitalsignature':
            case 'userpicture':
                $data['source'] = 'migrated';
                $data['originaldata'] = $rawdata;
                break;
            case 'border':
                $decoded = @json_decode($rawdata, true);
                if (is_array($decoded)) {
                    $data = $decoded;
                } else {
                    $data['borderwidth'] = 1;
                    $data['borderstyle'] = 'solid';
                }
                break;
            default:
                if (!empty($rawdata)) {
                    $decoded = @json_decode($rawdata, true);
                    $data = is_array($decoded) ? $decoded : ['text' => $rawdata];
                }
                break;
        }

        return json_encode($data);
    }

    /**
     * Convert customcert font name to certstudio font family.
     *
     * @param string|null $font The customcert font name.
     * @return string The certstudio font family.
     */
    private function convert_font(?string $font): string {
        if (empty($font)) {
            return 'Roboto';
        }

        // Customcert uses TCPDF font names (lowercase, no spaces).
        $map = [
            'helvetica' => 'Roboto',
            'times' => 'Merriweather',
            'courier' => 'Roboto',
            'dejavusans' => 'Noto Sans',
            'dejavuserif' => 'Noto Serif',
            'dejavusansmono' => 'Roboto',
            'freeserif' => 'Noto Serif',
            'freesans' => 'Noto Sans',
            'opensans' => 'Open Sans',
            'roboto' => 'Roboto',
            'lato' => 'Lato',
            'montserrat' => 'Montserrat',
            'poppins' => 'Poppins',
            'merriweather' => 'Merriweather',
            'playfairdisplay' => 'Playfair Display',
            'notosans' => 'Noto Sans',
            'notoserif' => 'Noto Serif',
            'raleway' => 'Raleway',
        ];

        $lower = strtolower(str_replace([' ', '-'], '', $font));
        return $map[$lower] ?? 'Roboto';
    }

    /**
     * Convert customcert colour to hex format.
     *
     * @param string|null $colour The customcert colour string.
     * @return string Hex colour code.
     */
    private function convert_colour(?string $colour): string {
        if (empty($colour)) {
            return '#000000';
        }

        // Already hex.
        if (strpos($colour, '#') === 0) {
            return $colour;
        }

        // Customcert may store as "R,G,B" or just a hex without #.
        if (preg_match('/^(\d+)\s*,\s*(\d+)\s*,\s*(\d+)$/', $colour, $m)) {
            return sprintf('#%02x%02x%02x', (int)$m[1], (int)$m[2], (int)$m[3]);
        }

        if (preg_match('/^[0-9a-fA-F]{6}$/', $colour)) {
            return '#' . $colour;
        }

        return '#000000';
    }

    /**
     * Migrate customcert activities to certstudio.
     *
     * @param array $templatemap Map of old template ID => new template ID.
     * @param bool $migrateissues Whether to also migrate issues.
     */
    private function migrate_activities(array $templatemap, bool $migrateissues): void {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/course/lib.php');

        $activities = $DB->get_records('customcert');
        $certstudiomoduleid = $DB->get_field('modules', 'id', ['name' => 'certstudio']);

        foreach ($activities as $oldactivity) {
            // Check if already migrated for this course.
            $migratedname = '[Migrated] ' . $oldactivity->name;
            if (
                $DB->record_exists('certstudio', [
                'course' => $oldactivity->course,
                'name' => $migratedname,
                ])
            ) {
                $this->log[] = "Skipped activity '{$oldactivity->name}' in course {$oldactivity->course} (already migrated).";
                continue;
            }

            $newactivity = new \stdClass();
            $newactivity->course = $oldactivity->course;
            $newactivity->name = $migratedname;
            $newactivity->intro = $oldactivity->intro;
            $newactivity->introformat = $oldactivity->introformat;
            $newactivity->templateid = $templatemap[$oldactivity->templateid] ?? 0;
            $newactivity->protection = $oldactivity->protection ?? '';
            $newactivity->language = $oldactivity->language ?? '';
            $newactivity->timecreated = $oldactivity->timecreated;
            $newactivity->timemodified = $oldactivity->timemodified;
            $newactivityid = $DB->insert_record('certstudio', $newactivity);

            // Create course_module entry so the activity appears in the course.
            if ($certstudiomoduleid) {
                // Place it next to the original activity, with the same visibility, access restrictions,
                // completion and group settings, so it is not open to students the original was closed to.
                $oldcm = get_coursemodule_from_instance('customcert', $oldactivity->id, $oldactivity->course);
                $section = $oldcm ? $DB->get_record('course_sections', ['id' => $oldcm->section]) : false;
                if (!$section) {
                    $section = $DB->get_record('course_sections', [
                        'course' => $oldactivity->course,
                        'section' => 0,
                    ]);
                }
                if (!$section) {
                    $sections = $DB->get_records('course_sections', ['course' => $oldactivity->course], 'section ASC', '*', 0, 1);
                    $section = reset($sections);
                }
                if ($section) {
                    $cm = new \stdClass();
                    $cm->course = $oldactivity->course;
                    $cm->module = $certstudiomoduleid;
                    $cm->instance = $newactivityid;
                    $cm->section = $section->id;
                    if ($oldcm) {
                        $copied = ['visible', 'visibleold', 'availability', 'completion', 'completionview',
                            'completionexpected'];
                        foreach ($copied as $field) {
                            $cm->$field = $oldcm->$field;
                        }
                    } else {
                        // Without the original activity to copy restrictions from, keep it hidden for a teacher to review.
                        $cm->visible = 0;
                    }
                    $cm->added = time();
                    $cmid = $DB->insert_record('course_modules', $cm);

                    // Add to section sequence, right after the original activity when there is one.
                    $sequence = empty($section->sequence) ? [] : explode(',', $section->sequence);
                    $position = $oldcm ? array_search((string) $oldcm->id, $sequence, true) : false;
                    if ($position === false) {
                        $sequence[] = (string) $cmid;
                    } else {
                        array_splice($sequence, $position + 1, 0, [(string) $cmid]);
                    }
                    $section->sequence = implode(',', $sequence);
                    $DB->update_record('course_sections', $section);

                    // Rebuild course cache.
                    rebuild_course_cache($oldactivity->course, true);

                    $this->log[] = "Created course module (cmid={$cmid}) in course {$oldactivity->course}.";
                }
            }

            $this->activitycount++;
            $this->log[] = "Migrated activity '{$oldactivity->name}' "
                . "(course {$oldactivity->course}, "
                . "ID {$oldactivity->id} -> {$newactivityid}).";

            if ($migrateissues) {
                $this->migrate_issues($oldactivity->id, $newactivityid);
            }
        }
    }

    /**
     * Migrate issued certificates from customcert to certstudio.
     *
     * @param int $oldactivityid Old customcert activity ID.
     * @param int $newactivityid New certstudio activity ID.
     */
    private function migrate_issues(int $oldactivityid, int $newactivityid): void {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/mod/certstudio/lib.php');

        $issues = $DB->get_records('customcert_issues', ['customcertid' => $oldactivityid]);

        foreach ($issues as $oldissue) {
            // Check for duplicate.
            if (
                $DB->record_exists('certstudio_issues', [
                'certstudioid' => $newactivityid,
                'userid' => $oldissue->userid,
                ])
            ) {
                continue;
            }

            // Preserve the original code, or generate a new one if empty.
            $code = !empty($oldissue->code) ? $oldissue->code : certstudio_generate_code();

            $newissue = new \stdClass();
            $newissue->certstudioid = $newactivityid;
            $newissue->userid = $oldissue->userid;
            $newissue->code = $code;
            $newissue->timecreated = $oldissue->timecreated;

            // Try to generate template data for this user so downloads work.
            try {
                $templatedata = certificate::get_template_data($newactivityid, $oldissue->userid, $code);
                $newissue->templatedata = json_encode($templatedata);
            } catch (\Exception $e) {
                $newissue->templatedata = null;
            }

            $DB->insert_record('certstudio_issues', $newissue);
            $this->issuecount++;
        }
    }

    /**
     * Get migration results.
     *
     * @return array Results array.
     */
    private function get_results(): array {
        return [
            'templates' => $this->templatecount,
            'activities' => $this->activitycount,
            'issues' => $this->issuecount,
            'log' => $this->log,
        ];
    }
}
