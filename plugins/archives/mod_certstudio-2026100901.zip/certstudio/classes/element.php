<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Abstract base element class for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * Abstract base class for certificate elements.
 *
 * Each element type (text, image, shape, etc.) must extend this class and implement
 * the abstract methods to provide type-specific rendering logic.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
abstract class element {
    /** @var string The database table for elements. */
    private const TABLE = 'certstudio_elements';

    /** @var int|null The element ID. */
    public $id;

    /** @var int The page ID this element belongs to. */
    public $pageid;

    /** @var string|null The element name. */
    public $name;

    /** @var string The element type identifier. */
    public $type;

    /** @var string|null JSON-encoded element data. */
    public $data;

    /** @var float The X position in mm. */
    public $posx;

    /** @var float The Y position in mm. */
    public $posy;

    /** @var float The element width in mm. */
    public $width;

    /** @var float The element height in mm. */
    public $height;

    /** @var int The rotation angle in degrees. */
    public $rotation;

    /** @var string|null The font family name. */
    public $fontfamily;

    /** @var int|null The font size in points. */
    public $fontsize;

    /** @var string|null The font weight (normal, bold). */
    public $fontweight;

    /** @var string|null The font style (normal, italic). */
    public $fontstyle;

    /** @var string|null The colour in hex format. */
    public $color;

    /** @var string|null The text alignment (L, C, R). */
    public $alignment;

    /** @var float The opacity value between 0 and 1. */
    public $opacity;

    /** @var int Whether the element is locked (0 or 1). */
    public $locked;

    /** @var int The z-order sequence number. */
    public $sequence;

    /**
     * Return the element type identifier string.
     *
     * @return string The type identifier (e.g. 'text', 'image', 'shape').
     */
    abstract public function get_type(): string;

    /**
     * Render the element as HTML for the certificate preview.
     *
     * @param array $data Resolved template data including user and course values.
     * @return string HTML output for this element.
     */
    abstract public function render_html(array $data): string;

    /**
     * Render the element as data suitable for PDF generation.
     *
     * @param array $data Resolved template data including user and course values.
     * @return mixed PDF rendering data.
     */
    abstract public function render_pdf_data(array $data);

    /**
     * Save the element to the database.
     *
     * Inserts a new record if the element has no ID, otherwise updates the existing record.
     *
     * @return int The element ID.
     */
    public function save(): int {
        global $DB;

        $record = $this->to_record();

        if (empty($this->id)) {
            $record->timecreated = time();
            $record->timemodified = $record->timecreated;
            $this->id = $DB->insert_record(self::TABLE, $record);
        } else {
            $record->id = $this->id;
            $record->timemodified = time();
            $DB->update_record(self::TABLE, $record);
        }

        return $this->id;
    }

    /**
     * Delete this element from the database.
     *
     * @return bool True on success.
     */
    public function delete(): bool {
        global $DB;

        if (empty($this->id)) {
            return false;
        }

        return $DB->delete_records(self::TABLE, ['id' => $this->id]);
    }

    /**
     * Convert the element to an associative array.
     *
     * @return array Element properties as key-value pairs.
     */
    public function to_array(): array {
        return [
            'id' => $this->id,
            'pageid' => $this->pageid,
            'name' => $this->name,
            'type' => $this->type,
            'data' => $this->data,
            'posx' => $this->posx,
            'posy' => $this->posy,
            'width' => $this->width,
            'height' => $this->height,
            'rotation' => $this->rotation,
            'fontfamily' => $this->fontfamily,
            'fontsize' => $this->fontsize,
            'fontweight' => $this->fontweight,
            'fontstyle' => $this->fontstyle,
            'color' => $this->color,
            'alignment' => $this->alignment,
            'opacity' => $this->opacity,
            'locked' => $this->locked,
            'sequence' => $this->sequence,
        ];
    }

    /**
     * Populate the element properties from a database record.
     *
     * @param \stdClass $record A database record from the certstudio_elements table.
     * @return void
     */
    public function from_record(\stdClass $record): void {
        $this->id = $record->id ?? null;
        $this->pageid = $record->pageid ?? 0;
        $this->name = $record->name ?? null;
        $this->type = $record->type ?? '';
        $this->data = $record->data ?? null;
        $this->posx = $record->posx ?? 0;
        $this->posy = $record->posy ?? 0;
        $this->width = $record->width ?? 0;
        $this->height = $record->height ?? 0;
        $this->rotation = $record->rotation ?? 0;
        $this->fontfamily = $record->fontfamily ?? null;
        $this->fontsize = $record->fontsize ?? null;
        $this->fontweight = $record->fontweight ?? 'normal';
        $this->fontstyle = $record->fontstyle ?? 'normal';
        $this->color = $record->color ?? '#000000';
        $this->alignment = $record->alignment ?? 'L';
        $this->opacity = $record->opacity ?? 1;
        $this->locked = $record->locked ?? 0;
        $this->sequence = $record->sequence ?? 0;
    }

    /**
     * Evaluate a conditional expression to determine if this element should be rendered.
     *
     * The condition is stored in the element's data JSON under the 'condition' key.
     * Supports basic comparisons against user and course fields.
     *
     * @param \stdClass $data Resolved template data.
     * @param \stdClass $user The user record.
     * @param \stdClass $course The course record.
     * @return bool True if the element should be rendered, false otherwise.
     */
    public function evaluate_condition(\stdClass $data, \stdClass $user, \stdClass $course): bool {
        $elementdata = json_decode($this->data ?? '');
        if (empty($elementdata) || empty($elementdata->condition)) {
            // No condition means always render.
            return true;
        }

        $condition = $elementdata->condition;

        // Determine the field value to check.
        $fieldvalue = null;
        if (!empty($condition->field)) {
            $field = $condition->field;

            if (strpos($field, 'user.') === 0) {
                $userfield = substr($field, 5);
                $fieldvalue = $user->$userfield ?? null;
            } else if (strpos($field, 'course.') === 0) {
                $coursefield = substr($field, 7);
                $fieldvalue = $course->$coursefield ?? null;
            }
        }

        if ($fieldvalue === null) {
            return true;
        }

        $operator = $condition->operator ?? 'eq';
        $comparevalue = $condition->value ?? '';

        switch ($operator) {
            case 'eq':
                return $fieldvalue == $comparevalue;
            case 'neq':
                return $fieldvalue != $comparevalue;
            case 'contains':
                return strpos((string) $fieldvalue, (string) $comparevalue) !== false;
            case 'notcontains':
                return strpos((string) $fieldvalue, (string) $comparevalue) === false;
            case 'empty':
                return empty($fieldvalue);
            case 'notempty':
                return !empty($fieldvalue);
            case 'gt':
                return $fieldvalue > $comparevalue;
            case 'lt':
                return $fieldvalue < $comparevalue;
            default:
                return true;
        }
    }

    /**
     * Convert the element properties to a database record object.
     *
     * @return \stdClass Record suitable for database operations.
     */
    private function to_record(): \stdClass {
        $record = new \stdClass();
        $record->pageid = $this->pageid;
        $record->name = $this->name;
        $record->type = $this->type;
        $record->data = $this->data;
        $record->posx = $this->posx;
        $record->posy = $this->posy;
        $record->width = $this->width;
        $record->height = $this->height;
        $record->rotation = $this->rotation;
        $record->fontfamily = $this->fontfamily;
        $record->fontsize = $this->fontsize;
        $record->fontweight = $this->fontweight;
        $record->fontstyle = $this->fontstyle;
        $record->color = $this->color;
        $record->alignment = $this->alignment;
        $record->opacity = $this->opacity;
        $record->locked = $this->locked;
        $record->sequence = $this->sequence;

        return $record;
    }
}
