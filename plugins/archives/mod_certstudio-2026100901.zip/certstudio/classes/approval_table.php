<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Approval requests table for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
require_once($CFG->libdir . '/tablelib.php');

/**
 * Table class for listing and managing certificate approval requests.
 *
 * Extends Moodle's table_sql to display approval requests with student name,
 * request date, status, and action buttons for teachers.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class approval_table extends \table_sql {
    /** @var int The certstudio activity instance ID. */
    protected $certstudioid;

    /** @var int The course module ID. */
    protected $cmid;

    /**
     * Constructor.
     *
     * @param string $uniqueid A unique identifier for this table instance.
     * @param int $certstudioid The certstudio activity instance ID.
     * @param int $cmid The course module ID.
     */
    public function __construct(string $uniqueid, int $certstudioid, int $cmid) {
        parent::__construct($uniqueid);

        $this->certstudioid = $certstudioid;
        $this->cmid = $cmid;

        $this->define_columns([
            'fullname',
            'timecreated',
            'status',
            'actions',
        ]);

        $this->define_headers([
            get_string('student', 'mod_certstudio'),
            get_string('daterequested', 'mod_certstudio'),
            get_string('status', 'mod_certstudio'),
            get_string('actions', 'mod_certstudio'),
        ]);

        $this->sortable(true, 'timecreated', SORT_DESC);
        $this->no_sorting('actions');
        $this->collapsible(false);

        $this->set_attribute('class', 'generaltable certstudio-approval-table');

        $this->setup_sql();
    }

    /**
     * Set up the SQL query for the table.
     *
     * @return void
     */
    protected function setup_sql(): void {
        $fields = "ar.id, ar.userid, ar.status, ar.timecreated, ar.reviewerid, ar.reviewcomment, " .
                  "u.firstname, u.lastname, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename, u.email";

        $from = "{certstudio_approval_requests} ar " .
                "JOIN {user} u ON u.id = ar.userid";

        $where = "ar.certstudioid = :certstudioid";
        $params = ['certstudioid' => $this->certstudioid];

        $this->set_sql($fields, $from, $where, $params);
        $this->set_count_sql(
            "SELECT COUNT(1) FROM {certstudio_approval_requests} ar WHERE ar.certstudioid = :certstudioid",
            $params
        );
    }

    /**
     * Render the student full name column.
     *
     * @param \stdClass $row The row data.
     * @return string The formatted student name.
     */
    public function col_fullname($row): string {
        return fullname($row);
    }

    /**
     * Render the date requested column.
     *
     * @param \stdClass $row The row data.
     * @return string The formatted date.
     */
    public function col_timecreated(\stdClass $row): string {
        return userdate($row->timecreated, get_string('strftimedatetimeshort', 'langconfig'));
    }

    /**
     * Render the status column.
     *
     * @param \stdClass $row The row data.
     * @return string The status label with appropriate styling.
     */
    public function col_status(\stdClass $row): string {
        switch ((int) $row->status) {
            case approval::STATUS_PENDING:
                return \html_writer::tag('span', get_string('pending', 'mod_certstudio'), [
                    'class' => 'badge badge-warning',
                ]);
            case approval::STATUS_APPROVED:
                return \html_writer::tag('span', get_string('approved', 'mod_certstudio'), [
                    'class' => 'badge badge-success',
                ]);
            case approval::STATUS_REJECTED:
                return \html_writer::tag('span', get_string('rejected', 'mod_certstudio'), [
                    'class' => 'badge badge-danger',
                ]);
            default:
                return get_string('unknown', 'mod_certstudio');
        }
    }

    /**
     * Render the actions column with approve/reject buttons.
     *
     * Only shows action buttons for pending requests.
     *
     * @param \stdClass $row The row data.
     * @return string HTML for action buttons.
     */
    public function col_actions(\stdClass $row): string {
        global $OUTPUT;

        if ((int) $row->status !== approval::STATUS_PENDING) {
            return '';
        }

        $approveurl = new \moodle_url('/mod/certstudio/approve.php', [
            'id' => $this->cmid,
            'requestid' => $row->id,
            'action' => 'approve',
            'sesskey' => sesskey(),
        ]);

        $rejecturl = new \moodle_url('/mod/certstudio/approve.php', [
            'id' => $this->cmid,
            'requestid' => $row->id,
            'action' => 'reject',
            'sesskey' => sesskey(),
        ]);

        $actions = '';

        $actions .= \html_writer::link(
            $approveurl,
            $OUTPUT->pix_icon('t/check', get_string('approve', 'mod_certstudio')) .
                ' ' . get_string('approve', 'mod_certstudio'),
            ['class' => 'btn btn-sm btn-success mr-1']
        );

        $actions .= \html_writer::link(
            $rejecturl,
            $OUTPUT->pix_icon('t/delete', get_string('reject', 'mod_certstudio')) .
                ' ' . get_string('reject', 'mod_certstudio'),
            ['class' => 'btn btn-sm btn-danger']
        );

        return $actions;
    }
}
