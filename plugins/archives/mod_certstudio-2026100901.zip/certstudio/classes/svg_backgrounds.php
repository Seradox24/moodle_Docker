<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * SVG background generator for certificate templates.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio;
/**
 * SVG background generator class for certificate templates.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class svg_backgrounds {
    /** @var int Canvas width (A4 Landscape in mm). */
    const W = 297;
    /** @var int Canvas height (A4 Landscape in mm). */
    const H = 210;

    /**
     * Generate all 40 template backgrounds and save to disk.
     *
     * @return array List of ['filename' => ..., 'name' => ..., 'tags' => ...] for each generated SVG.
     */
    public static function generate_all(): array {
        $dir = self::get_backgrounds_dir();

        $templates = [];

        // CLASSIC (8).
        $templates[] = self::save(
            $dir,
            'classic-gold',
            'Classic Gold',
            'classic,gold',
            self::classic('#c9a84c', '#b8860b', '#fdf8ef', '#f5e6c8')
        );
        $templates[] = self::save(
            $dir,
            'classic-navy',
            'Classic Navy',
            'classic,blue',
            self::classic('#1a237e', '#283593', '#f8f9fc', '#eef1f8')
        );
        $templates[] = self::save(
            $dir,
            'classic-emerald',
            'Classic Emerald',
            'classic,green',
            self::classic('#1b5e20', '#2e7d32', '#f6faf6', '#e8f5e9')
        );
        $templates[] = self::save(
            $dir,
            'classic-burgundy',
            'Classic Burgundy',
            'classic,red',
            self::classic('#6d1a36', '#8b2252', '#fdf6f0', '#f8ece3')
        );
        $templates[] = self::save(
            $dir,
            'classic-purple',
            'Classic Purple',
            'classic,purple',
            self::classic('#4a148c', '#6a1b9a', '#f3e5f5', '#ede7f6')
        );
        $templates[] = self::save(
            $dir,
            'classic-bronze',
            'Classic Bronze',
            'classic,gold',
            self::classic('#8d6e63', '#795548', '#faf6f2', '#f5ece3')
        );
        $templates[] = self::save(
            $dir,
            'classic-silver',
            'Classic Silver',
            'classic,gray',
            self::classic('#607d8b', '#78909c', '#fafafa', '#f0f0f0')
        );
        $templates[] = self::save(
            $dir,
            'classic-teal',
            'Classic Teal',
            'classic,green',
            self::classic('#00695c', '#00897b', '#e0f2f1', '#f0faf9')
        );

        // MODERN (8).
        $templates[] = self::save(
            $dir,
            'modern-teal',
            'Modern Teal',
            'modern,green',
            self::modern_panel('#00897b', '#00695c')
        );
        $templates[] = self::save(
            $dir,
            'modern-coral',
            'Modern Coral',
            'modern,red',
            self::modern_panel('#e53935', '#c62828')
        );
        $templates[] = self::save(
            $dir,
            'modern-indigo',
            'Modern Indigo',
            'modern,blue',
            self::modern_panel('#3949ab', '#283593')
        );
        $templates[] = self::save(
            $dir,
            'modern-amber',
            'Modern Amber',
            'modern,gold',
            self::modern_panel('#ff8f00', '#e65100')
        );
        $templates[] = self::save(
            $dir,
            'modern-slate',
            'Modern Slate',
            'modern,gray',
            self::modern_panel('#455a64', '#37474f')
        );
        $templates[] = self::save(
            $dir,
            'modern-rose',
            'Modern Rose',
            'modern,pink',
            self::modern_panel('#ad1457', '#880e4f')
        );
        $templates[] = self::save(
            $dir,
            'modern-forest',
            'Modern Forest',
            'modern,green',
            self::modern_panel('#2e7d32', '#1b5e20')
        );
        $templates[] = self::save(
            $dir,
            'modern-ocean',
            'Modern Ocean',
            'modern,blue',
            self::modern_panel('#0277bd', '#01579b')
        );

        // ELEGANT BANDS (6).
        $templates[] = self::save(
            $dir,
            'bands-burgundy',
            'Elegant Burgundy',
            'elegant,red',
            self::bands('#6d1a36', '#8b2252', '#c9a84c')
        );
        $templates[] = self::save(
            $dir,
            'bands-navy',
            'Elegant Navy',
            'elegant,blue',
            self::bands('#1a237e', '#283593', '#c9a84c')
        );
        $templates[] = self::save(
            $dir,
            'bands-emerald',
            'Elegant Emerald',
            'elegant,green',
            self::bands('#1b5e20', '#2e7d32', '#c9a84c')
        );
        $templates[] = self::save(
            $dir,
            'bands-purple',
            'Elegant Purple',
            'elegant,purple',
            self::bands('#4a148c', '#6a1b9a', '#c0c0c0')
        );
        $templates[] = self::save(
            $dir,
            'bands-black',
            'Elegant Black',
            'elegant,dark',
            self::bands('#212121', '#424242', '#c9a84c')
        );
        $templates[] = self::save(
            $dir,
            'bands-royal',
            'Elegant Royal',
            'elegant,blue',
            self::bands('#0d47a1', '#1565c0', '#ffd700')
        );

        // GRADIENT (6).
        $templates[] = self::save(
            $dir,
            'gradient-ocean',
            'Ocean Waves',
            'gradient,blue',
            self::gradient('#e3f2fd', '#e0f2f1', '#1565c0', '#0277bd')
        );
        $templates[] = self::save(
            $dir,
            'gradient-sunset',
            'Sunset Glow',
            'gradient,gold',
            self::gradient('#fff8f0', '#fce4ec', '#e65100', '#ff8f00')
        );
        $templates[] = self::save(
            $dir,
            'gradient-aurora',
            'Aurora',
            'gradient,purple',
            self::gradient('#e8eaf6', '#e0f7fa', '#4a148c', '#00695c')
        );
        $templates[] = self::save(
            $dir,
            'gradient-forest',
            'Forest Mist',
            'gradient,green',
            self::gradient('#e8f5e9', '#f1f8e9', '#1b5e20', '#33691e')
        );
        $templates[] = self::save(
            $dir,
            'gradient-twilight',
            'Twilight',
            'gradient,purple',
            self::gradient('#ede7f6', '#e3f2fd', '#4527a0', '#1565c0')
        );
        $templates[] = self::save(
            $dir,
            'gradient-rose',
            'Rose Garden',
            'gradient,pink',
            self::gradient('#fce4ec', '#f3e5f5', '#c2185b', '#7b1fa2')
        );

        // MINIMAL (6).
        $templates[] = self::save(
            $dir,
            'minimal-gray',
            'Minimal Gray',
            'minimal,gray',
            self::minimal('#9e9e9e', '#bdbdbd', '#fafafa')
        );
        $templates[] = self::save(
            $dir,
            'minimal-blue',
            'Minimal Blue',
            'minimal,blue',
            self::minimal('#1565c0', '#90caf9', '#f5f9ff')
        );
        $templates[] = self::save(
            $dir,
            'minimal-green',
            'Minimal Green',
            'minimal,green',
            self::minimal('#2e7d32', '#a5d6a7', '#f5fbf5')
        );
        $templates[] = self::save(
            $dir,
            'minimal-black',
            'Minimal Black',
            'minimal,dark',
            self::minimal('#212121', '#757575', '#ffffff')
        );
        $templates[] = self::save(
            $dir,
            'minimal-gold',
            'Minimal Gold',
            'minimal,gold',
            self::minimal('#c9a84c', '#daa520', '#fffdf5')
        );
        $templates[] = self::save(
            $dir,
            'minimal-purple',
            'Minimal Purple',
            'minimal,purple',
            self::minimal('#6a1b9a', '#ce93d8', '#faf5ff')
        );

        // DARK / PREMIUM (4).
        $templates[] = self::save(
            $dir,
            'dark-gold',
            'Dark Gold',
            'dark,gold',
            self::dark('#1a1a2e', '#16213e', '#daa520', '#b8860b')
        );
        $templates[] = self::save(
            $dir,
            'dark-emerald',
            'Dark Emerald',
            'dark,green',
            self::dark('#0a1f0a', '#1a2e1a', '#4caf50', '#2e7d32')
        );
        $templates[] = self::save(
            $dir,
            'dark-ruby',
            'Dark Ruby',
            'dark,red',
            self::dark('#1a0a0a', '#2e1616', '#ef5350', '#c62828')
        );
        $templates[] = self::save(
            $dir,
            'dark-sapphire',
            'Dark Sapphire',
            'dark,blue',
            self::dark('#0a0a2e', '#16163e', '#42a5f5', '#1565c0')
        );

        // SPECIAL (2).
        $templates[] = self::save(
            $dir,
            'greek-meander',
            'Greek Meander',
            'special,blue',
            self::greek('#1a237e', '#c9a84c')
        );
        $templates[] = self::save(
            $dir,
            'art-deco',
            'Art Deco',
            'special,gold',
            self::art_deco('#2c2c2c', '#c9a84c', '#faf8f0')
        );

        return $templates;
    }

    /**
     * Get the backgrounds directory path, creating it if needed.
     *
     * @return string The absolute path to the backgrounds directory.
     */
    private static function get_backgrounds_dir(): string {
        global $CFG;
        $dir = $CFG->dirroot . '/mod/certstudio/pix/backgrounds';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        return $dir;
    }

    /**
     * Save an SVG background file to disk.
     *
     * @param string $dir Directory to save in.
     * @param string $filename File name without extension.
     * @param string $name Display name.
     * @param string $tags Comma-separated tags.
     * @param string $svg SVG content.
     * @return array Template metadata with filename, name, and tags.
     */
    private static function save(string $dir, string $filename, string $name, string $tags, string $svg): array {
        // The backgrounds ship with the plugin, so only recreate a missing file, and never write into a read-only code directory.
        $path = $dir . '/' . $filename . '.svg';
        if (!file_exists($path) && is_writable($dir)) {
            file_put_contents($path, $svg);
        }
        return ['filename' => $filename . '.svg', 'name' => $name, 'tags' => $tags];
    }

    // SVG GENERATORS.

    /**
     * Return the SVG header element.
     *
     * @return string SVG opening tag.
     */
    private static function header(): string {
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 297 210" width="297mm" height="210mm">';
    }

    /**
     * Classic: double border with ornamental corners on gradient background.
     */
    private static function classic(string $c1, string $c2, string $bg1, string $bg2): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0%" stop-color="' . $bg1 . '"/>'
            . '<stop offset="100%" stop-color="' . $bg2 . '"/>'
            . '</linearGradient>
    <linearGradient id="br" x1="0" y1="0" x2="1" y2="0">'
            . '<stop offset="0%" stop-color="' . $c2 . '"/><stop offset="50%" stop-color="' . $c1 . '"/>'
            . '<stop offset="100%" stop-color="' . $c2 . '"/></linearGradient>
    <pattern id="p" width="20" height="20" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
            . '<circle cx="10" cy="10" r=".5" fill="' . $c1 . '" opacity=".12"/></pattern>
  </defs>
  <rect width="' . $w . '" height="' . $h . '" fill="url(#bg)"/><rect width="' . $w . '" height="' . $h . '" fill="url(#p)"/>
  <rect x="5" y="4" width="287" height="202" rx="2" fill="none" stroke="url(#br)" stroke-width="3"/>
  <rect x="10" y="9" width="277" height="192" rx="1" fill="none" stroke="' . $c1 . '" stroke-width=".5" opacity=".5"/>
  <g fill="' . $c1 . '" opacity=".5">
    <circle cx="15" cy="14" r="2"/><circle cx="282" cy="14" r="2"/><circle cx="15" cy="196" r="2"/><circle cx="282" cy="196" r="2"/>
    <path d="M15,10 Q15,14 19,14 Q15,14 15,18 Q15,14 11,14z"/><path d="M282,10 Q282,14 286,14 Q282,14 282,18 Q282,14 278,14z"/>
    <path d="M15,192 Q15,196 19,196 Q15,196 15,200 Q15,196 11,196z"/>'
            . '<path d="M282,192 Q282,196 286,196 Q282,196 282,200 Q282,196 278,196z"/>
  </g>
  <line x1="40" y1="40" x2="257" y2="40" stroke="' . $c1 . '" stroke-width=".3" opacity=".3"/>
  <line x1="40" y1="170" x2="257" y2="170" stroke="' . $c1 . '" stroke-width=".3" opacity=".3"/>
  <g transform="translate(148.5,36)" fill="none" stroke="' . $c1 . '" stroke-width=".4" opacity=".4">
    <path d="M-15,0 Q-8,-4 0,-6 Q8,-4 15,0"/><path d="M-10,0 Q-5,-2.5 0,-3.5 Q5,-2.5 10,0"/>
  </g>
</svg>';
    }

    /**
     * Modern: left colored panel with geometric shapes.
     */
    private static function modern_panel(string $c1, string $c2): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0%" stop-color="' . $c1 . '"/>'
            . '<stop offset="100%" stop-color="' . $c2 . '"/>'
            . '</linearGradient></defs>
  <rect width="' . $w . '" height="' . $h . '" fill="#fff"/>
  <rect width="85" height="' . $h . '" fill="url(#g)"/>
  <circle cx="42" cy="30" r="18" fill="#fff" opacity=".07"/>
  <circle cx="20" cy="105" r="35" fill="#fff" opacity=".05"/>
  <circle cx="70" cy="180" r="22" fill="#fff" opacity=".06"/>
  <rect x="10" y="60" width="30" height="30" rx="15" fill="#fff" opacity=".04" transform="rotate(45,25,75)"/>
  <rect x="85" y="0" width="2" height="' . $h . '" fill="' . $c1 . '" opacity=".3"/>
  <rect y="205" width="' . $w . '" height="5" fill="' . $c1 . '" opacity=".08"/>
  <g fill="' . $c1 . '" opacity=".04">'
            . '<circle cx="120" cy="20" r="1"/><circle cx="150" cy="20" r="1"/><circle cx="180" cy="20" r="1"/>'
            . '<circle cx="210" cy="20" r="1"/><circle cx="240" cy="20" r="1"/><circle cx="270" cy="20" r="1"/>'
            . '<circle cx="120" cy="60" r="1"/><circle cx="150" cy="60" r="1"/><circle cx="180" cy="60" r="1"/>'
            . '<circle cx="210" cy="60" r="1"/><circle cx="240" cy="60" r="1"/><circle cx="270" cy="60" r="1"/>'
            . '<circle cx="120" cy="100" r="1"/><circle cx="150" cy="100" r="1"/><circle cx="180" cy="100" r="1"/>'
            . '<circle cx="210" cy="100" r="1"/><circle cx="240" cy="100" r="1"/><circle cx="270" cy="100" r="1"/>'
            . '<circle cx="120" cy="140" r="1"/><circle cx="150" cy="140" r="1"/><circle cx="180" cy="140" r="1"/>'
            . '<circle cx="210" cy="140" r="1"/><circle cx="240" cy="140" r="1"/><circle cx="270" cy="140" r="1"/>'
            . '<circle cx="120" cy="180" r="1"/><circle cx="150" cy="180" r="1"/><circle cx="180" cy="180" r="1"/>'
            . '<circle cx="210" cy="180" r="1"/><circle cx="240" cy="180" r="1"/><circle cx="270" cy="180" r="1"/>'
            . '
  </g>
</svg>';
    }

    /**
     * Bands: top and bottom curved color bands.
     */
    private static function bands(string $c1, string $c2, string $accent): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0%" stop-color="' . $c1 . '"/>'
            . '<stop offset="100%" stop-color="' . $c2 . '"/>'
            . '</linearGradient></defs>
  <rect width="' . $w . '" height="' . $h . '" fill="#fdf8f2"/>
  <path d="M0,0 L' . $w . ',0 L' . $w . ',35 Q148.5,45 0,35z" fill="url(#g)"/>
  <path d="M0,' . $h . ' L' . $w . ',' . $h . ' L' . $w . ','
            . '180 Q148.5,170 0,180z" fill="url(#g)"/>
  <path d="M0,36 Q148.5,46 ' . $w . ',36" fill="none" stroke="'
            . $accent . '" stroke-width=".8" opacity=".6"/>
  <path d="M0,179 Q148.5,169 ' . $w . ',179" fill="none" stroke="'
            . $accent . '" stroke-width=".8" opacity=".6"/>
  <g fill="#fff" opacity=".08">'
            . '<circle cx="30" cy="15" r="12"/><circle cx="267" cy="15" r="12"/>'
            . '<circle cx="30" cy="195" r="12"/><circle cx="267" cy="195" r="12"/></g>
  <rect x="25" y="50" width="247" height="115" rx="2" fill="none" stroke="' . $c1 . '" stroke-width=".3" opacity=".12"/>
  <g fill="none" stroke="' . $accent . '" stroke-width=".6" opacity=".35">
    <path d="M30,55 L25,50 L35,50 M25,50 L25,60"/><path d="M267,55 L272,50 L262,50 M272,50 L272,60"/>
    <path d="M30,160 L25,165 L35,165 M25,165 L25,155"/><path d="M267,160 L272,165 L262,165 M272,165 L272,155"/>
  </g>
</svg>';
    }

    /**
     * Gradient: soft gradient background with wave shapes.
     */
    private static function gradient(string $bg1, string $bg2, string $c1, string $c2): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0%" stop-color="' . $bg1 . '"/>'
            . '<stop offset="100%" stop-color="' . $bg2 . '"/>'
            . '</linearGradient>
  </defs>
  <rect width="' . $w . '" height="' . $h . '" fill="url(#bg)"/>
  <path d="M0,0 L' . $w . ',0 L' . $w . ',25 Q250,35 200,28 '
            . 'Q150,20 100,30 Q50,40 0,30z" fill="' . $c1 . '" opacity=".1"/>
  <path d="M0,0 L' . $w . ',0 L' . $w . ',18 Q240,28 180,22 '
            . 'Q120,15 60,24 Q30,28 0,25z" fill="' . $c1 . '" opacity=".06"/>
  <path d="M0,' . $h . ' L' . $w . ',' . $h . ' L' . $w . ','
            . '185 Q250,175 200,182 Q150,190 100,180 Q50,170 0,180z"'
            . ' fill="' . $c2 . '" opacity=".1"/>
  <path d="M0,' . $h . ' L' . $w . ',' . $h . ' L' . $w . ','
            . '190 Q240,182 180,188 Q120,195 60,186 Q30,182 0,185z"'
            . ' fill="' . $c2 . '" opacity=".06"/>
  <rect x="18" y="35" width="261" height="145" rx="3" fill="none" stroke="' . $c1 . '" stroke-width=".4" opacity=".15"/>
  <g fill="none" stroke="' . $c1 . '" stroke-width=".5" opacity=".15">
    <path d="M22,40 Q30,38 38,40"/><path d="M259,40 Q267,38 275,40"/>
    <path d="M22,175 Q30,173 38,175"/><path d="M259,175 Q267,173 275,175"/>
  </g>
  <line x1="50" y1="75" x2="247" y2="75" stroke="' . $c1 . '" stroke-width=".2" opacity=".12"/>
  <line x1="50" y1="140" x2="247" y2="140" stroke="' . $c1 . '" stroke-width=".2" opacity=".12"/>
</svg>';
    }

    /**
     * Minimal: very subtle design with thin accents.
     */
    private static function minimal(string $c1, string $c2, string $bg): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <rect width="' . $w . '" height="' . $h . '" fill="' . $bg . '"/>
  <g fill="none" stroke="' . $c2 . '" stroke-width=".3" opacity=".3">
    <line x1="15" y1="10" x2="15" y2="30"/><line x1="10" y1="15" x2="30" y2="15"/><rect x="12" y="12" width="6" height="6"/>
    <line x1="282" y1="10" x2="282" y2="30"/><line x1="267" y1="15" x2="287" y2="15"/><rect x="279" y="12" width="6" height="6"/>
    <line x1="15" y1="180" x2="15" y2="200"/><line x1="10" y1="195" x2="30" y2="195"/><rect x="12" y="192" width="6" height="6"/>
    <line x1="282" y1="180" x2="282" y2="200"/>'
            . '<line x1="267" y1="195" x2="287" y2="195"/><rect x="279" y="192" width="6" height="6"/>
  </g>
  <line x1="35" y1="15" x2="262" y2="15" stroke="' . $c2 . '" stroke-width=".3" opacity=".4"/>
  <line x1="35" y1="195" x2="262" y2="195" stroke="' . $c2 . '" stroke-width=".3" opacity=".4"/>
  <rect x="10" y="35" width="1.5" height="140" fill="' . $c1 . '" opacity=".08"/>
  <rect x="285.5" y="35" width="1.5" height="140" fill="' . $c1 . '" opacity=".08"/>
  <g transform="translate(148.5,105)" fill="none" stroke="' . $c2 . '" stroke-width=".25" opacity=".06">
    <rect x="-40" y="-40" width="80" height="80" transform="rotate(45)"/>
  </g>
</svg>';
    }

    /**
     * Dark: dark background with accent borders and grid.
     */
    private static function dark(string $bg1, string $bg2, string $c1, string $c2): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0%" stop-color="' . $bg1 . '"/>'
            . '<stop offset="100%" stop-color="' . $bg2 . '"/>'
            . '</linearGradient>
    <linearGradient id="ac" x1="0" y1="0" x2="1" y2="0">'
            . '<stop offset="0%" stop-color="' . $c2 . '"/><stop offset="50%" stop-color="' . $c1 . '"/>'
            . '<stop offset="100%" stop-color="' . $c2 . '"/></linearGradient>
    <pattern id="gr" width="15" height="15" patternUnits="userSpaceOnUse">'
            . '<line x1="15" y1="0" x2="15" y2="15" stroke="#fff" stroke-width=".1" opacity=".05"/>'
            . '<line x1="0" y1="15" x2="15" y2="15" stroke="#fff" stroke-width=".1" opacity=".05"/></pattern>
  </defs>
  <rect width="' . $w . '" height="' . $h . '" fill="url(#bg)"/><rect width="' . $w . '" height="' . $h . '" fill="url(#gr)"/>
  <rect x="6" y="5" width="285" height="200" fill="none" stroke="url(#ac)" stroke-width="1.5"/>
  <rect x="9" y="8" width="279" height="194" fill="none" stroke="' . $c1 . '" stroke-width=".3" opacity=".3"/>
  <rect x="6" y="5" width="285" height="2" fill="url(#ac)" opacity=".6"/>
  <rect x="6" y="203" width="285" height="2" fill="url(#ac)" opacity=".6"/>
  <g fill="' . $c1 . '" opacity=".35">
    <path d="M6,5 L20,5 L20,7 L8,7 L8,19 L6,19z"/><path d="M291,5 L277,5 L277,7 L289,7 L289,19 L291,19z"/>
    <path d="M6,205 L20,205 L20,203 L8,203 L8,191 L6,191z"/><path d="M291,205 L277,205 L277,203 L289,203 L289,191 L291,191z"/>
  </g>
  <line x1="50" y1="78" x2="247" y2="78" stroke="' . $c1 . '" stroke-width=".3" opacity=".2"/>
  <line x1="50" y1="135" x2="247" y2="135" stroke="' . $c1 . '" stroke-width=".3" opacity=".2"/>
  <rect x="146" y="75.5" width="5" height="5" rx=".5" transform="rotate(45,148.5,78)" fill="' . $c1 . '" opacity=".25"/>
  <rect x="146" y="132.5" width="5" height="5" rx=".5" transform="rotate(45,148.5,135)" fill="' . $c1 . '" opacity=".25"/>
</svg>';
    }

    /**
     * Greek: meander border pattern with column accents.
     */
    private static function greek(string $c1, string $accent): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <defs>
    <pattern id="m" width="12" height="6" patternUnits="userSpaceOnUse">
      <path d="M0,3 L3,3 L3,0 L6,0 L6,3 L9,3 L9,6 L12,6" fill="none" stroke="' . $c1 . '" stroke-width=".5" opacity=".15"/>
    </pattern>
  </defs>
  <rect width="' . $w . '" height="' . $h . '" fill="#fafbfd"/>
  <rect x="8" y="6" width="281" height="6" fill="url(#m)"/>
  <rect x="8" y="198" width="281" height="6" fill="url(#m)"/>
  <rect x="6" y="4.5" width="285" height="201" fill="none" stroke="' . $c1 . '" stroke-width="1.8"/>
  <rect x="10" y="14" width="277" height="184" fill="none" stroke="' . $c1 . '" stroke-width=".4" opacity=".2"/>
  <g opacity=".07" fill="' . $c1 . '">'
            . '<rect x="14" y="20" width="4" height="170" rx="1"/>'
            . '<rect x="12" y="18" width="8" height="4" rx=".5"/><rect x="12" y="188" width="8" height="4" rx=".5"/></g>
  <g opacity=".07" fill="' . $c1 . '">'
            . '<rect x="279" y="20" width="4" height="170" rx="1"/>'
            . '<rect x="277" y="18" width="8" height="4" rx=".5"/><rect x="277" y="188" width="8" height="4" rx=".5"/></g>
  <g fill="none" stroke="#558b2f" stroke-width=".4" opacity=".15">
    <path d="M30,100 Q35,95 40,100 Q35,105 30,100"/>'
            . '<path d="M28,95 Q33,90 38,95"/><path d="M28,105 Q33,110 38,105"/>'
            . '<line x1="34" y1="88" x2="34" y2="112"/>
    <path d="M257,100 Q262,95 267,100 Q262,105 257,100"/>'
            . '<path d="M259,95 Q264,90 269,95"/>'
            . '<path d="M259,105 Q264,110 269,105"/>'
            . '<line x1="263" y1="88" x2="263" y2="112"/>
  </g>
  <line x1="50" y1="40" x2="247" y2="40" stroke="' . $c1 . '" stroke-width=".3" opacity=".12"/>
  <line x1="50" y1="170" x2="247" y2="170" stroke="' . $c1 . '" stroke-width=".3" opacity=".12"/>
  <g transform="translate(148.5,28)" fill="' . $accent . '" opacity=".25">'
            . '<polygon points="0,-5 1.5,-1.5 5.5,-1.5 2.5,1 '
            . '3.5,5 0,2.5 -3.5,5 -2.5,1 -5.5,-1.5 -1.5,-1.5"/></g>
</svg>';
    }

    /**
     * Art Deco: geometric art deco style.
     */
    private static function art_deco(string $c1, string $accent, string $bg): string {
        $w = self::W;
        $h = self::H;
        return self::header() . '
  <rect width="' . $w . '" height="' . $h . '" fill="' . $bg . '"/>
  <rect x="8" y="6" width="281" height="198" fill="none" stroke="' . $c1 . '" stroke-width="2"/>
  <rect x="12" y="10" width="273" height="190" fill="none" stroke="' . $accent . '" stroke-width=".5" opacity=".5"/>
  <!-- Art deco corners -->
  <g stroke="' . $accent . '" stroke-width="1" fill="none" opacity=".4">
    <path d="M8,30 L8,6 L32,6"/><path d="M14,30 L14,12 L32,12"/>
    <path d="M265,6 L289,6 L289,30"/><path d="M265,12 L283,12 L283,30"/>
    <path d="M8,180 L8,204 L32,204"/><path d="M14,180 L14,198 L32,198"/>
    <path d="M265,204 L289,204 L289,180"/><path d="M265,198 L283,198 L283,180"/>
  </g>
  <!-- Art deco fan top center -->
  <g transform="translate(148.5,6)" stroke="' . $accent . '" stroke-width=".5" fill="none" opacity=".3">
    <path d="M-20,0 L-12,-12 L0,-16 L12,-12 L20,0"/>
    <path d="M-14,0 L-8,-8 L0,-11 L8,-8 L14,0"/>
    <path d="M-8,0 L-4,-5 L0,-6 L4,-5 L8,0"/>
    <line x1="0" y1="0" x2="0" y2="-16"/>
  </g>
  <!-- Horizontal deco lines -->
  <g stroke="' . $accent . '" opacity=".2">
    <line x1="40" y1="42" x2="257" y2="42" stroke-width=".5"/>
    <line x1="50" y1="45" x2="247" y2="45" stroke-width=".25"/>
    <line x1="40" y1="168" x2="257" y2="168" stroke-width=".5"/>
    <line x1="50" y1="165" x2="247" y2="165" stroke-width=".25"/>
  </g>
  <circle cx="148.5" cy="42" r="2" fill="' . $accent . '" opacity=".25"/>
  <circle cx="148.5" cy="168" r="2" fill="' . $accent . '" opacity=".25"/>
</svg>';
    }
}
