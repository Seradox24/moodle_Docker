<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Custom admin setting for API keys that masks the value after saving.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Admin setting for API keys - shows masked value after saving.
 *
 * When a value is already saved, displays "••••••••xxxx" (last 4 chars visible).
 * The user can clear the field and enter a new key to replace it.
 * Submitting the masked placeholder value is ignored (keeps existing key).
 */
class mod_certstudio_admin_setting_apikey extends admin_setting_configtext {
    /** @var string Placeholder shown when a key is already saved. */
    const MASK_PLACEHOLDER = '••••••••';

    /**
     * Constructor.
     *
     * @param string $name Setting name.
     * @param string $visiblename Localised label.
     * @param string $description Localised description.
     * @param string $defaultsetting Default value.
     */
    public function __construct($name, $visiblename, $description, $defaultsetting) {
        parent::__construct($name, $visiblename, $description, $defaultsetting, PARAM_RAW);
    }

    /**
     * Return the current setting value for display.
     *
     * If a real key is stored, return a masked version so the full key
     * is never rendered in the HTML source.
     *
     * @return string
     */
    public function get_setting() {
        $value = parent::get_setting();
        if (!empty($value)) {
            // Return a masked representation for display.
            $last4 = substr($value, -4);
            return self::MASK_PLACEHOLDER . $last4;
        }
        return $value;
    }

    /**
     * Keep the key out of the config changes report, as core does for password settings.
     *
     * @param string $name The setting name.
     * @param mixed $oldvalue The previous value.
     * @param mixed $value The new value.
     */
    protected function add_to_config_log($name, $oldvalue, $value) {
        if ($value !== '' && $value !== null) {
            $value = '********';
        }
        if ($oldvalue !== '' && $oldvalue !== null) {
            $oldvalue = '********';
        }
        parent::add_to_config_log($name, $oldvalue, $value);
    }

    /**
     * Write the setting value.
     *
     * If the submitted value looks like our mask placeholder (starts with ••••),
     * keep the existing stored value unchanged.
     * If the submitted value is empty, clear the key.
     * Otherwise, store the new key.
     *
     * @param string $data The submitted value.
     * @return string Empty string on success, error message otherwise.
     */
    public function write_setting($data) {
        // If the user submitted the masked placeholder, do not overwrite.
        if (strpos($data, self::MASK_PLACEHOLDER) === 0) {
            return '';
        }

        // Allow clearing the key.
        if ($data === '') {
            return parent::write_setting('');
        }

        // Store the new real key.
        return parent::write_setting($data);
    }

    /**
     * Return the HTML for the setting.
     *
     * @param mixed $data Current data.
     * @param string $query Search query.
     * @return string HTML.
     */
    public function output_html($data, $query = '') {
        global $OUTPUT;

        $default = $this->get_defaultsetting();
        $context = (object) [
            'size' => $this->size,
            'id' => $this->get_id(),
            'name' => $this->get_full_name(),
            'value' => $data,
            'forceltr' => $this->get_force_ltr(),
        ];

        // Use password type so the browser doesn't show the masked value in cleartext.
        $inputtype = 'password';
        $placeholder = '';

        if (!empty($data) && strpos($data, self::MASK_PLACEHOLDER) === 0) {
            // Key is saved - show placeholder hint.
            $placeholder = $data;
            $inputtype = 'text';
        }

        $html = '<div class="form-text defaultsnormal">';
        $html .= '<input type="' . $inputtype . '"';
        $html .= ' name="' . $context->name . '"';
        $html .= ' id="' . $context->id . '"';
        $html .= ' class="form-control"';
        $html .= ' value="' . s($data) . '"';
        if ($placeholder) {
            $html .= ' onfocus="if(this.value.indexOf(\''
                . self::MASK_PLACEHOLDER
                . '\')===0){this.value=\'\';this.type=\'password\';}"';
        }
        $html .= ' size="' . $context->size . '"';
        $html .= ' />';
        $html .= '</div>';

        return format_admin_setting($this, $this->visiblename, $html, $this->description, true, '', $default, $query);
    }
}
