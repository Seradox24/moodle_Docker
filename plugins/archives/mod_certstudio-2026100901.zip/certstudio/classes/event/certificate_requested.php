<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The certificate_requested event.
 *
 * @package    mod_certstudio
 * @copyright  2023 Leon Stringer <leon.stringer@ntlworld.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio\event;

/**
 * The certificate_requested event class.
 *
 * Fired when a student requests a certificate.
 *
 * @package    mod_certstudio
 * @copyright  2023 Leon Stringer <leon.stringer@ntlworld.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class certificate_requested extends \core\event\base {
    /**
     * Initialise the event.
     */
    protected function init() {
        $this->data['crud'] = 'c';
        $this->data['edulevel'] = self::LEVEL_PARTICIPATING;
        $this->data['objecttable'] = 'certstudio_approval_requests';
    }

    /**
     * Returns the name of the event.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('eventcertificaterequested', 'mod_certstudio');
    }

    /**
     * Returns the description of the event.
     *
     * @return string
     */
    public function get_description() {
        return "The user with id '$this->userid' requested a certificate in the certstudio activity " .
            "with course module id '$this->contextinstanceid'.";
    }

    /**
     * Returns the URL related to the event.
     *
     * @return \moodle_url
     */
    public function get_url() {
        return new \moodle_url('/mod/certstudio/view.php', ['id' => $this->contextinstanceid]);
    }

    /**
     * Returns the mapping of objectid.
     *
     * @return array
     */
    public static function get_objectid_mapping() {
        return ['db' => 'certstudio_approval_requests', 'restore' => \core\event\base::NOT_MAPPED];
    }

    /**
     * Validate the event data.
     */
    protected function validate_data() {
        parent::validate_data();

        if ($this->contextlevel != CONTEXT_MODULE) {
            throw new \coding_exception('Context level must be CONTEXT_MODULE.');
        }
    }
}
