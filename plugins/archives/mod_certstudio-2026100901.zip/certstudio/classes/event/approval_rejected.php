<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The approval_rejected event.
 *
 * @package    mod_certstudio
 * @copyright  2023 Leon Stringer <leon.stringer@ntlworld.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_certstudio\event;

/**
 * Fired when a certificate approval request is rejected.
 */
class approval_rejected extends \core\event\base {
    /**
     * Initialise the event.
     */
    protected function init() {
        $this->data['crud'] = 'u';
        $this->data['edulevel'] = self::LEVEL_TEACHING;
        $this->data['objecttable'] = 'certstudio_approval_requests';
    }

    /**
     * Return the localised event name.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('eventcertificaterejected', 'mod_certstudio');
    }

    /**
     * Return the event description.
     *
     * @return string
     */
    public function get_description() {
        return "The certificate request with id '$this->objectid' was rejected for user '$this->relateduserid' " .
            "in the certstudio activity with course module id '$this->contextinstanceid'.";
    }

    /**
     * Return the URL related to this event.
     *
     * @return \moodle_url
     */
    public function get_url() {
        return new \moodle_url('/mod/certstudio/approve.php', ['id' => $this->contextinstanceid]);
    }

    /**
     * Return the mapping of objectid for restore.
     *
     * @return array
     */
    public static function get_objectid_mapping() {
        return ['db' => 'certstudio_approval_requests', 'restore' => \core\event\base::NOT_MAPPED];
    }

    /**
     * Validate the event data.
     */
    protected function validate_data() {
        parent::validate_data();
        if ($this->contextlevel != CONTEXT_MODULE) {
            throw new \coding_exception('Context level must be CONTEXT_MODULE.');
        }
    }
}
