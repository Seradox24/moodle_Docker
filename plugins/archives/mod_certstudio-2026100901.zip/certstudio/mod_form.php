<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate Studio activity form.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/course/moodleform_mod.php');

/**
 * Module instance settings form.
 */
class mod_certstudio_mod_form extends moodleform_mod {
    /**
     * Define the form elements.
     */
    public function definition() {
        global $DB;

        $mform = $this->_form;

        // General section.
        $mform->addElement('header', 'general', get_string('general', 'form'));

        $mform->addElement('text', 'name', get_string('name'), ['size' => '64']);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');

        $this->standard_intro_elements();

        // Template section.
        $mform->addElement('header', 'templatehdr', get_string('template', 'mod_certstudio'));

        if (!empty($this->current->templateid)) {
            $currenttemplate = $DB->get_record('certstudio_templates', ['id' => $this->current->templateid]);
            $templatename = $currenttemplate ? format_string($currenttemplate->name) : '(unknown)';
            $mform->addElement(
                'static',
                'currenttemplateinfo',
                get_string('currenttemplate', 'mod_certstudio'),
                '<span style="display:inline-flex;align-items:center;gap:8px;padding:6px 14px;'
                . 'background:#eff6ff;color:#2563eb;border-radius:8px;font-weight:600;border:1px solid #bfdbfe;">'
                . '<i class="fa fa-file-text-o"></i> ' . $templatename . '</span>'
                . '<br><span class="text-muted small mt-1 d-block">'
                . '<i class="fa fa-info-circle"></i> ' . get_string('templategalleryhelp', 'mod_certstudio') . '</span>'
            );
        } else {
            $mform->addElement(
                'static',
                'currenttemplateinfo',
                get_string('currenttemplate', 'mod_certstudio'),
                '<span class="text-muted">' . get_string('notemplateselected', 'mod_certstudio') . '</span>'
                . '<br><span class="text-muted small mt-1 d-block">'
                . '<i class="fa fa-info-circle"></i> ' . get_string('notemplateselectedhelp', 'mod_certstudio') . '</span>'
            );
        }
        // Hidden field to preserve templateid - never overwritten by this form.
        $mform->addElement('hidden', 'templateid', !empty($this->current->templateid) ? $this->current->templateid : 0);
        $mform->setType('templateid', PARAM_INT);

        // PDF Download settings.
        $mform->addElement('header', 'downloadhdr', get_string('downloadsettings', 'mod_certstudio'));

        $mform->addElement('text', 'downloadfilename', get_string('downloadfilename', 'mod_certstudio'), ['size' => '48']);
        $mform->setType('downloadfilename', PARAM_TEXT);
        $mform->setDefault('downloadfilename', '');
        $mform->addHelpButton('downloadfilename', 'downloadfilename', 'mod_certstudio');

        // Approval settings.
        $mform->addElement('header', 'approvalhdr', get_string('approval', 'mod_certstudio'));

        $mform->addElement('advcheckbox', 'approvalenabled', get_string('approvalenabled', 'mod_certstudio'));
        $mform->setDefault('approvalenabled', 0);
        $mform->addHelpButton('approvalenabled', 'approvalenabled', 'mod_certstudio');

        $mform->addElement(
            'advcheckbox',
            'approvalnotifyteacher',
            get_string('approvalnotifyteacher', 'mod_certstudio')
        );
        $mform->setDefault('approvalnotifyteacher', 1);
        $mform->hideIf('approvalnotifyteacher', 'approvalenabled', 'eq', 0);

        $mform->addElement(
            'advcheckbox',
            'approvalnotifystudent',
            get_string('approvalnotifystudent', 'mod_certstudio')
        );
        $mform->setDefault('approvalnotifystudent', 1);
        $mform->hideIf('approvalnotifystudent', 'approvalenabled', 'eq', 0);

        // Expiry settings.
        $mform->addElement('header', 'expiryhdr', get_string('expirysettings', 'mod_certstudio'));

        $mform->addElement('text', 'expirydays', get_string('expirydays', 'mod_certstudio'), ['size' => '10']);
        $mform->setType('expirydays', PARAM_INT);
        $mform->setDefault('expirydays', 0);
        $mform->addHelpButton('expirydays', 'expirydays', 'mod_certstudio');

        // Multi-language settings.
        $mform->addElement('header', 'langhdr', get_string('multilang', 'mod_certstudio'));

        $languages = get_string_manager()->get_list_of_translations();
        $languages = ['' => get_string('default')] + $languages;
        $mform->addElement('select', 'language', get_string('language'), $languages);
        $mform->setDefault('language', '');

        // Standard elements.
        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }
}
