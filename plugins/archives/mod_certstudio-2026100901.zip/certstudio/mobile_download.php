<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Server-side PDF download endpoint for the Moodle Mobile app.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$cmid = required_param('id', PARAM_INT);

$cm = get_coursemodule_from_id('certstudio', $cmid, 0, false, MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
$certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:view', $context);

// Get the user's active issue.
$issues = \mod_certstudio\certificate::get_issues_for_user($certstudio->id, $USER->id);

if (empty($issues)) {
    throw new moodle_exception('nocertificatesissued', 'mod_certstudio');
}

$issue = reset($issues);

// Generate the PDF using the server-side PDF generator.
$templatedata = \mod_certstudio\certificate::get_template_data($certstudio->id, $USER->id, $issue->code);
$pdfcontent = \mod_certstudio\pdfgenerator::generate($templatedata);

// Build a safe filename.
$filename = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $certstudio->name) . '_' . $issue->code . '.pdf';

// Send the PDF as a download.
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($pdfcontent));
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');

echo $pdfcontent;
exit;
