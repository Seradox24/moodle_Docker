<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Page displaying all certificates issued to a user.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

require_login();

$userid = optional_param('userid', $USER->id, PARAM_INT);
$courseid = optional_param('course', 0, PARAM_INT);

$context = context_system::instance();

// If viewing another user's certificates, require the viewallcertificates capability.
if ($userid != $USER->id) {
    require_capability('mod/certstudio:viewallcertificates', $context);
}

$params = ['userid' => $userid];
if ($courseid) {
    $params['course'] = $courseid;
}

$PAGE->set_url('/mod/certstudio/my_certificates.php', $params);
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_title(get_string('mycertificates', 'mod_certstudio'));
$PAGE->set_heading(get_string('mycertificates', 'mod_certstudio'));

// Build the query.
$sql = "SELECT ci.id, ci.code, ci.timecreated, ci.expirydate, ci.status,
               cs.name AS certname,
               c.fullname AS coursename
          FROM {certstudio_issues} ci
          JOIN {certstudio} cs ON cs.id = ci.certstudioid
          JOIN {course} c ON c.id = cs.course
         WHERE ci.userid = :userid";
$sqlparams = ['userid' => $userid];

if ($courseid) {
    $sql .= " AND cs.course = :courseid";
    $sqlparams['courseid'] = $courseid;
}

$sql .= " ORDER BY ci.timecreated DESC";

$issues = $DB->get_records_sql($sql, $sqlparams);

echo $OUTPUT->header();

if (empty($issues)) {
    echo $OUTPUT->notification(get_string('nocertificates', 'mod_certstudio'), 'info');
    echo $OUTPUT->footer();
    die;
}

// Build the table.
$table = new html_table();
$table->head = [
    get_string('certificate', 'mod_certstudio'),
    get_string('course', 'mod_certstudio'),
    get_string('showcaseissuedon', 'mod_certstudio'),
    get_string('verificationcode', 'mod_certstudio'),
    get_string('status'),
];
$table->attributes['class'] = 'generaltable';

foreach ($issues as $issue) {
    // Determine status.
    if ($issue->status == 1) {
        // Revoked.
        $statushtml = html_writer::span(get_string('revoked', 'mod_certstudio'), 'badge badge-danger');
    } else if (!empty($issue->expirydate) && $issue->expirydate < time()) {
        // Expired.
        $statushtml = html_writer::span(get_string('expired', 'mod_certstudio'), 'badge badge-warning');
    } else {
        // Valid.
        $statushtml = html_writer::span(get_string('valid', 'mod_certstudio'), 'badge badge-success');
    }

    // Verification code as link to showcase.
    $showcaseurl = new moodle_url('/mod/certstudio/showcase.php', ['code' => $issue->code]);
    $codelink = html_writer::link($showcaseurl, s($issue->code));

    $table->data[] = [
        s($issue->certname),
        s($issue->coursename),
        userdate($issue->timecreated),
        $codelink,
        $statushtml,
    ];
}

echo html_writer::table($table);

echo $OUTPUT->footer();
