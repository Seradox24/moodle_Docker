<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Restore task for mod_certstudio.
 *
 * Provides all the settings and steps to perform one complete restore of the activity.
 *
 * @package   mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/certstudio/backup/moodle2/restore_certstudio_stepslib.php');

/**
 * Certstudio restore task that provides all the settings and steps to perform one
 * complete restore of the activity.
 *
 * @package   mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class restore_certstudio_activity_task extends restore_activity_task {
    /**
     * Define (add) particular settings this activity can have.
     */
    protected function define_my_settings() {
        // No particular settings for this activity.
    }

    /**
     * Define (add) particular steps this activity can have.
     */
    protected function define_my_steps() {
        $this->add_step(new restore_certstudio_activity_structure_step('certstudio_structure', 'certstudio.xml'));
    }

    /**
     * Define the contents in the activity that must be processed by the link decoder.
     *
     * @return array
     */
    public static function define_decode_contents() {
        $contents = [];

        $contents[] = new restore_decode_content('certstudio', ['intro'], 'certstudio');

        return $contents;
    }

    /**
     * Define the decoding rules for links belonging to the activity to be executed by the link decoder.
     *
     * @return array of restore_decode_rule
     */
    public static function define_decode_rules() {
        $rules = [];

        $rules[] = new restore_decode_rule(
            'CERTSTUDIOVIEWBYID',
            '/mod/certstudio/view.php?id=$1',
            'course_module'
        );
        $rules[] = new restore_decode_rule(
            'CERTSTUDIOINDEX',
            '/mod/certstudio/index.php?id=$1',
            'course'
        );

        return $rules;
    }

    /**
     * Define the restore log rules that will be applied by the restore_logs_processor
     * when restoring certstudio logs.
     *
     * @return array of restore_log_rule
     */
    public static function define_restore_log_rules() {
        $rules = [];

        $rules[] = new restore_log_rule('certstudio', 'add', 'view.php?id={course_module}', '{certstudio}');
        $rules[] = new restore_log_rule('certstudio', 'update', 'view.php?id={course_module}', '{certstudio}');
        $rules[] = new restore_log_rule('certstudio', 'view', 'view.php?id={course_module}', '{certstudio}');

        return $rules;
    }

    /**
     * Define the restore log rules that will be applied by the restore_logs_processor
     * when restoring course logs.
     *
     * @return array
     */
    public static function define_restore_log_rules_for_course() {
        $rules = [];

        $rules[] = new restore_log_rule('certstudio', 'view all', 'index.php?id={course}', null);

        return $rules;
    }
}
