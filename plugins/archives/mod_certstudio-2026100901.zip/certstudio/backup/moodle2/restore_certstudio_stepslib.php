<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Restore steps for mod_certstudio.
 *
 * @package   mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Define the complete certstudio structure for restore, with file and id annotations.
 *
 * @package   mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class restore_certstudio_activity_structure_step extends restore_activity_structure_step {
    /**
     * Define the structure of the restore workflow.
     *
     * @return array of restore_path_element
     */
    protected function define_structure() {

        $paths = [];
        $userinfo = $this->get_setting_value('userinfo');

        $paths[] = new restore_path_element('certstudio', '/activity/certstudio');
        $paths[] = new restore_path_element(
            'certstudio_template',
            '/activity/certstudio/templates/template'
        );
        $paths[] = new restore_path_element(
            'certstudio_page',
            '/activity/certstudio/templates/template/pages/page'
        );
        $paths[] = new restore_path_element(
            'certstudio_element',
            '/activity/certstudio/templates/template/pages/page/elements/element'
        );

        if ($userinfo) {
            $paths[] = new restore_path_element(
                'certstudio_issue',
                '/activity/certstudio/issues/issue'
            );
            $paths[] = new restore_path_element(
                'certstudio_approval_request',
                '/activity/certstudio/approval_requests/approval_request'
            );
        }

        return $this->prepare_activity_structure($paths);
    }

    /**
     * Process the certstudio activity record.
     *
     * @param array $data The data from the backup file.
     */
    protected function process_certstudio($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->course = $this->get_courseid();

        // The templateid will be remapped after the template is restored.
        $data->templateid = 0;

        $newitemid = $DB->insert_record('certstudio', $data);
        $this->apply_activity_instance($newitemid);
    }

    /**
     * Process a certstudio template record.
     *
     * @param array $data The data from the backup file.
     */
    protected function process_certstudio_template($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        // Set the contextid to the new module context.
        $data->contextid = $this->task->get_contextid();

        $newitemid = $DB->insert_record('certstudio_templates', $data);
        $this->set_mapping('certstudio_template', $oldid, $newitemid);

        // Update the certstudio record with the new templateid.
        $certstudioid = $this->get_new_parentid('certstudio');
        $DB->set_field('certstudio', 'templateid', $newitemid, ['id' => $certstudioid]);
    }

    /**
     * Process a certstudio page record.
     *
     * @param array $data The data from the backup file.
     */
    protected function process_certstudio_page($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->templateid = $this->get_new_parentid('certstudio_template');

        $newitemid = $DB->insert_record('certstudio_pages', $data);
        $this->set_mapping('certstudio_page', $oldid, $newitemid, true);
    }

    /**
     * Process a certstudio element record.
     *
     * @param array $data The data from the backup file.
     */
    protected function process_certstudio_element($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->pageid = $this->get_new_parentid('certstudio_page');

        $newitemid = $DB->insert_record('certstudio_elements', $data);
        $this->set_mapping('certstudio_element', $oldid, $newitemid, true);
    }

    /**
     * Process a certstudio issue record.
     *
     * @param array $data The data from the backup file.
     */
    protected function process_certstudio_issue($data) {
        global $CFG, $DB;

        $data = (object)$data;
        $oldid = $data->id;

        // Codes are unique site-wide, so a course copy or a restore on the same site needs new ones.
        if ($DB->record_exists('certstudio_issues', ['code' => $data->code])) {
            require_once($CFG->dirroot . '/mod/certstudio/lib.php');
            $data->code = certstudio_generate_code();
        }

        $data->certstudioid = $this->get_new_parentid('certstudio');
        $data->userid = $this->get_mappingid('user', $data->userid);

        if (!empty($data->revokedby)) {
            $data->revokedby = $this->get_mappingid('user', $data->revokedby);
        }

        if (!empty($data->parentid)) {
            $data->parentid = $this->get_mappingid('certstudio_issue', $data->parentid);
        }

        $newitemid = $DB->insert_record('certstudio_issues', $data);
        $this->set_mapping('certstudio_issue', $oldid, $newitemid);
    }

    /**
     * Process a certstudio approval request record.
     *
     * @param array $data The data from the backup file.
     */
    protected function process_certstudio_approval_request($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->certstudioid = $this->get_new_parentid('certstudio');
        $data->userid = $this->get_mappingid('user', $data->userid);

        if (!empty($data->reviewerid)) {
            $data->reviewerid = $this->get_mappingid('user', $data->reviewerid);
        }

        $newitemid = $DB->insert_record('certstudio_approval_requests', $data);
        $this->set_mapping('certstudio_approval_request', $oldid, $newitemid);
    }

    /**
     * Once the database tables have been fully restored, restore the files.
     */
    protected function after_execute() {
        $this->add_related_files('mod_certstudio', 'intro', null);
        $this->add_related_files('mod_certstudio', 'background', 'certstudio_page');
        $this->add_related_files('mod_certstudio', 'elementimage', 'certstudio_element');
    }
}
