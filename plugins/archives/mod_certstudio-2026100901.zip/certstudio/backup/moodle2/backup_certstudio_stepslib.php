<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Backup steps for mod_certstudio.
 *
 * @package   mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Define the complete certstudio structure for backup, with file and id annotations.
 *
 * @package   mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class backup_certstudio_activity_structure_step extends backup_activity_structure_step {
    /**
     * Define the structure for the certstudio activity.
     *
     * @return backup_nested_element
     */
    protected function define_structure() {

        // To know if we are including userinfo.
        $userinfo = $this->get_setting_value('userinfo');

        // Define each element separated.
        $certstudio = new backup_nested_element('certstudio', ['id'], [
            'course',
            'name',
            'intro',
            'introformat',
            'templateid',
            'approvalenabled',
            'approvalnotifyteacher',
            'approvalnotifystudent',
            'protection',
            'downloadfilename',
            'expirydays',
            'language',
            'timecreated',
            'timemodified',
        ]);

        // Templates structure.
        $templates = new backup_nested_element('templates');
        $template = new backup_nested_element('template', ['id'], [
            'name',
            'contextid',
            'timecreated',
            'timemodified',
        ]);

        // Pages structure.
        $pages = new backup_nested_element('pages');
        $page = new backup_nested_element('page', ['id'], [
            'templateid',
            'width',
            'height',
            'leftmargin',
            'rightmargin',
            'backgroundimage',
            'bgcolor',
            'sequence',
            'timecreated',
            'timemodified',
        ]);

        // Elements structure.
        $elements = new backup_nested_element('elements');
        $element = new backup_nested_element('element', ['id'], [
            'pageid',
            'name',
            'type',
            'data',
            'posx',
            'posy',
            'width',
            'height',
            'rotation',
            'fontfamily',
            'fontsize',
            'fontweight',
            'fontstyle',
            'color',
            'alignment',
            'opacity',
            'locked',
            'sequence',
            'timecreated',
            'timemodified',
        ]);

        // Issues structure (user data).
        $issues = new backup_nested_element('issues');
        $issue = new backup_nested_element('issue', ['id'], [
            'certstudioid',
            'userid',
            'code',
            'templatedata',
            'timecreated',
            'expirydate',
            'status',
            'revokedby',
            'revokedat',
            'revokereason',
            'version',
            'parentid',
            'emailed',
        ]);

        // Approval requests structure (user data).
        $approvalrequests = new backup_nested_element('approval_requests');
        $approvalrequest = new backup_nested_element('approval_request', ['id'], [
            'certstudioid',
            'userid',
            'status',
            'reviewerid',
            'reviewcomment',
            'timecreated',
            'timemodified',
        ]);

        // Build the tree.
        // Templates -> pages -> elements hierarchy.
        $certstudio->add_child($templates);
        $templates->add_child($template);

        $template->add_child($pages);
        $pages->add_child($page);

        $page->add_child($elements);
        $elements->add_child($element);

        // User data children.
        $certstudio->add_child($issues);
        $issues->add_child($issue);

        $certstudio->add_child($approvalrequests);
        $approvalrequests->add_child($approvalrequest);

        // Define sources.
        $certstudio->set_source_table('certstudio', ['id' => backup::VAR_ACTIVITYID]);

        $template->set_source_sql('
            SELECT t.*
              FROM {certstudio_templates} t
             WHERE t.id = (
                SELECT c.templateid
                  FROM {certstudio} c
                 WHERE c.id = ?
             )', [backup::VAR_ACTIVITYID]);

        $page->set_source_table('certstudio_pages', ['templateid' => backup::VAR_PARENTID]);

        $element->set_source_table('certstudio_elements', ['pageid' => backup::VAR_PARENTID]);

        // User data sources (only if userinfo is being backed up).
        if ($userinfo) {
            // In id order, so a reissued certificate is restored after the version it replaces and its parentid maps.
            $issue->set_source_table('certstudio_issues', ['certstudioid' => backup::VAR_PARENTID], 'id ASC');
            $approvalrequest->set_source_table(
                'certstudio_approval_requests',
                ['certstudioid' => backup::VAR_PARENTID]
            );
        }

        // Define id annotations.
        $issue->annotate_ids('user', 'userid');
        $issue->annotate_ids('user', 'revokedby');
        $approvalrequest->annotate_ids('user', 'userid');
        $approvalrequest->annotate_ids('user', 'reviewerid');

        // Define file annotations.
        $certstudio->annotate_files('mod_certstudio', 'intro', null);
        $page->annotate_files('mod_certstudio', 'background', 'id');
        $element->annotate_files('mod_certstudio', 'elementimage', 'id');

        // Return the root element (certstudio), wrapped into standard activity structure.
        return $this->prepare_activity_structure($certstudio);
    }
}
