<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Template export/import (sharing) page.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$action = optional_param('action', '', PARAM_ALPHA);
$templateid = optional_param('templateid', 0, PARAM_INT);

$PAGE->set_url('/mod/certstudio/templateshare.php');
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('templatesharing', 'mod_certstudio'));
$PAGE->set_heading(get_string('templatesharing', 'mod_certstudio'));

// Handle export.
if ($action === 'export' && $templateid) {
    $template = $DB->get_record('certstudio_templates', ['id' => $templateid], '*', MUST_EXIST);
    $pages = $DB->get_records('certstudio_pages', ['templateid' => $templateid], 'sequence ASC');

    // Preload all elements for all pages in a single query to avoid N+1.
    $pageids = array_keys($pages);
    $allelements = [];
    if (!empty($pageids)) {
        [$insql, $inparams] = $DB->get_in_or_equal($pageids, SQL_PARAMS_NAMED);
        $allelements = $DB->get_records_sql(
            "SELECT * FROM {certstudio_elements} WHERE pageid {$insql} ORDER BY sequence ASC",
            $inparams
        );
    }
    // Group elements by pageid.
    $elementsbypageid = [];
    foreach ($allelements as $el) {
        $elementsbypageid[$el->pageid][] = $el;
    }

    $export = new stdClass();
    $export->format = 'certstudio_template';
    $export->version = 1;
    $export->name = $template->name;
    $export->pages = [];

    foreach ($pages as $page) {
        $pagedata = new stdClass();
        $pagedata->width = $page->width;
        $pagedata->height = $page->height;
        $pagedata->leftmargin = $page->leftmargin;
        $pagedata->rightmargin = $page->rightmargin;
        $pagedata->backgroundimage = $page->backgroundimage;
        $pagedata->sequence = $page->sequence;
        $pagedata->elements = [];

        foreach ($elementsbypageid[$page->id] ?? [] as $el) {
            $eldata = new stdClass();
            foreach (
                ['name', 'type', 'data', 'posx', 'posy', 'width', 'height', 'rotation',
                       'fontfamily', 'fontsize', 'fontweight', 'fontstyle', 'color', 'alignment',
                       'opacity', 'locked', 'sequence'] as $field
            ) {
                $eldata->$field = $el->$field;
            }
            $pagedata->elements[] = $eldata;
        }
        $export->pages[] = $pagedata;
    }

    $json = json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $template->name) . '.certstudio.json';

    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $json;
    exit;
}

// Handle delete.
if ($action === 'delete' && $templateid && confirm_sesskey()) {
    $template = $DB->get_record('certstudio_templates', ['id' => $templateid]);
    if ($template) {
        // Check if any activity uses this template.
        $usagecount = $DB->count_records('certstudio', ['templateid' => $templateid]);
        if ($usagecount > 0) {
            redirect(
                new moodle_url('/mod/certstudio/templateshare.php'),
                get_string('templateinuse', 'mod_certstudio', $usagecount),
                null,
                \core\output\notification::NOTIFY_ERROR
            );
        }
        // Delete elements, pages, then template.
        $pages = $DB->get_records('certstudio_pages', ['templateid' => $templateid]);
        foreach ($pages as $page) {
            $DB->delete_records('certstudio_elements', ['pageid' => $page->id]);
        }
        $DB->delete_records('certstudio_pages', ['templateid' => $templateid]);
        $DB->delete_records('certstudio_templates', ['id' => $templateid]);
        redirect(
            new moodle_url('/mod/certstudio/templateshare.php'),
            get_string('templatedeleted', 'mod_certstudio', $template->name),
            null,
            \core\output\notification::NOTIFY_SUCCESS
        );
    }
}

// Handle import.
if ($action === 'import' && confirm_sesskey()) {
    if (!empty($_FILES['templatefile']['tmp_name'])) {
        $content = file_get_contents($_FILES['templatefile']['tmp_name']);
        $data = json_decode($content);

        if (!$data || empty($data->format) || $data->format !== 'certstudio_template') {
            echo $OUTPUT->header();
            echo $OUTPUT->notification(get_string('templateimportinvalid', 'mod_certstudio'), 'error');
            echo $OUTPUT->continue_button(new moodle_url('/mod/certstudio/templateshare.php'));
            echo $OUTPUT->footer();
            die;
        }

        // Create template.
        $template = new stdClass();
        $template->name = '[Imported] ' . ($data->name ?? 'Untitled');
        $template->contextid = context_system::instance()->id;
        $template->timecreated = time();
        $template->timemodified = time();
        $newtemplateid = $DB->insert_record('certstudio_templates', $template);

        $pagecount = 0;
        $elementcount = 0;

        foreach (($data->pages ?? []) as $pagedata) {
            $page = new stdClass();
            $page->templateid = $newtemplateid;
            $page->width = $pagedata->width ?? 297;
            $page->height = $pagedata->height ?? 210;
            $page->leftmargin = $pagedata->leftmargin ?? 0;
            $page->rightmargin = $pagedata->rightmargin ?? 0;
            $page->backgroundimage = $pagedata->backgroundimage ?? null;
            $page->sequence = $pagedata->sequence ?? 0;
            $page->timecreated = time();
            $page->timemodified = time();
            $newpageid = $DB->insert_record('certstudio_pages', $page);
            $pagecount++;

            foreach (($pagedata->elements ?? []) as $eldata) {
                $element = new stdClass();
                $element->pageid = $newpageid;
                foreach (
                    ['name', 'type', 'data', 'posx', 'posy', 'width', 'height', 'rotation',
                           'fontfamily', 'fontsize', 'fontweight', 'fontstyle', 'color', 'alignment',
                           'opacity', 'locked', 'sequence'] as $field
                ) {
                    $element->$field = $eldata->$field ?? null;
                }
                $element->timecreated = time();
                $element->timemodified = time();
                $DB->insert_record('certstudio_elements', $element);
                $elementcount++;
            }
        }

        echo $OUTPUT->header();
        echo $OUTPUT->notification(
            get_string('templateimported', 'mod_certstudio', (object) [
                'name' => $template->name,
                'pages' => $pagecount,
                'elements' => $elementcount,
            ]),
            'success'
        );
        echo $OUTPUT->continue_button(new moodle_url('/mod/certstudio/templateshare.php'));
        echo $OUTPUT->footer();
        die;
    }
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('templatesharing', 'mod_certstudio'));

// Build template data for Mustache rendering.
$templates = $DB->get_records('certstudio_templates', [], 'name ASC');

// Preload page counts, element counts, and activities in bulk (avoid N+1 queries).
$pagecounts = [];
$elementcounts = [];
$activitiesbytemplate = [];

if (!empty($templates)) {
    // Page counts per template.
    $rows = $DB->get_records_sql(
        "SELECT templateid, COUNT(*) AS cnt FROM {certstudio_pages} GROUP BY templateid"
    );
    foreach ($rows as $row) {
        $pagecounts[$row->templateid] = (int) $row->cnt;
    }

    // Element counts per template.
    $rows = $DB->get_records_sql(
        "SELECT p.templateid, COUNT(e.id) AS cnt
           FROM {certstudio_elements} e
           JOIN {certstudio_pages} p ON p.id = e.pageid
          GROUP BY p.templateid"
    );
    foreach ($rows as $row) {
        $elementcounts[$row->templateid] = (int) $row->cnt;
    }

    // Activities using each template.
    $rows = $DB->get_records_sql(
        "SELECT cs.id, cs.name, cs.templateid, c.shortname
           FROM {certstudio} cs
           JOIN {course} c ON c.id = cs.course
          WHERE cs.templateid IS NOT NULL AND cs.templateid > 0"
    );
    foreach ($rows as $row) {
        $activitiesbytemplate[$row->templateid][] = [
            'activityname' => $row->name,
            'courseshortname' => $row->shortname,
        ];
    }
}

$templatedata = [];
foreach ($templates as $t) {
    $pagecount = $pagecounts[$t->id] ?? 0;
    $elementcount = $elementcounts[$t->id] ?? 0;
    $activitylist = $activitiesbytemplate[$t->id] ?? [];

    $exporturl = new moodle_url('/mod/certstudio/templateshare.php', [
        'action' => 'export', 'templateid' => $t->id,
    ]);
    $deleteurl = new moodle_url('/mod/certstudio/templateshare.php', [
        'action' => 'delete', 'templateid' => $t->id, 'sesskey' => sesskey(),
    ]);

    $templatedata[] = [
        'id' => $t->id,
        'name' => $t->name,
        'pagecount' => $pagecount,
        'elementcount' => $elementcount,
        'hasactivities' => !empty($activitylist),
        'activities' => $activitylist,
        'timecreated' => userdate($t->timecreated, get_string('strftimedateshort', 'langconfig')),
        'exporturl' => $exporturl->out(false),
        'deleteurl' => $deleteurl->out(false),
    ];
}

$importurl = new moodle_url('/mod/certstudio/templateshare.php');

$context = [
    'templates' => $templatedata,
    'templatecount' => count($templatedata),
    'hastemplates' => !empty($templatedata),
    'importurl' => $importurl->out(false),
    'sesskey' => sesskey(),
    'str' => [
        'alltemplates' => get_string('alltemplates', 'mod_certstudio'),
        'notemplates' => get_string('notemplates', 'mod_certstudio'),
        'name' => get_string('name'),
        'pages' => get_string('pages', 'mod_certstudio'),
        'elements' => get_string('elements', 'mod_certstudio'),
        'course' => get_string('course'),
        'created' => get_string('created', 'mod_certstudio'),
        'actions' => get_string('actions'),
        'export' => get_string('exporttemplate', 'mod_certstudio'),
        'delete' => get_string('delete', 'mod_certstudio'),
        'confirmdelete' => get_string('confirmdelete', 'mod_certstudio'),
        'importtemplate' => get_string('importtemplate', 'mod_certstudio'),
        'templatefile' => get_string('templatefile', 'mod_certstudio'),
        'templatefilehelp' => get_string('templatefilehelp', 'mod_certstudio'),
    ],
];

$PAGE->requires->js_call_amd('mod_certstudio/templateshare', 'init');
echo $OUTPUT->render_from_template('mod_certstudio/templateshare', $context);

echo $OUTPUT->footer();
