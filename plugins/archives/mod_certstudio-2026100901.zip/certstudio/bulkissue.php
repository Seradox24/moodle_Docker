<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Bulk issue certificates to all eligible students.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT); // Course module id.
$confirm = optional_param('confirm', 0, PARAM_INT);

$cm = get_coursemodule_from_id('certstudio', $id, 0, false, MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
$certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:manage', $context);

$PAGE->set_url('/mod/certstudio/bulkissue.php', ['id' => $cm->id]);
$PAGE->set_title(get_string('bulkissue', 'mod_certstudio'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);

// Get students with an active enrolment who can receive a certificate.
$students = get_enrolled_users($context, 'mod/certstudio:receiveissue', 0, 'u.*', 'u.lastname, u.firstname', 0, 0, true);
// Filter out users who can manage (teachers/admins).
$students = array_filter($students, function ($u) use ($context) {
    return !has_capability('mod/certstudio:manage', $context, $u->id);
});

// Users who already have a certificate, mapped to their best status: active, or revoked only.
// A revoked certificate is renewed with Reissue, so bulk issue does not hand out a new one.
$issuedset = $DB->get_records_sql_menu(
    "SELECT userid, MIN(status) FROM {certstudio_issues} WHERE certstudioid = ? GROUP BY userid",
    [$certstudio->id]
);

// Split into eligible and already-issued.
$eligible = [];
$alreadyissued = [];
foreach ($students as $student) {
    if (isset($issuedset[$student->id])) {
        $alreadyissued[] = $student;
    } else {
        $eligible[] = $student;
    }
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('bulkissue', 'mod_certstudio'));

if ($confirm && confirm_sesskey()) {
    // Process bulk issue.
    $selectedids = optional_param_array('userids', [], PARAM_INT);
    $notifyemail = optional_param('notifyemail', 0, PARAM_INT);
    $notifymoodle = optional_param('notifymoodle', 0, PARAM_INT);
    $notifymessage = optional_param('notifymessage', '', PARAM_TEXT);

    if (empty($selectedids)) {
        echo $OUTPUT->notification(get_string('bulkissuenoselection', 'mod_certstudio'), 'warning');
    } else {
        $certificate = new \mod_certstudio\certificate();
        $count = 0;
        $notifiedcount = 0;
        $eligibleset = array_flip(array_column($eligible, 'id'));
        foreach ($selectedids as $uid) {
            // Only issue to users listed as eligible: actively enrolled, able to receive and not already issued.
            if (isset($eligibleset[$uid])) {
                unset($eligibleset[$uid]);
                $certificate->issue($certstudio->id, $uid, false);
                $count++;

                // Send notifications if requested.
                if ($notifyemail || $notifymoodle) {
                    $student = $DB->get_record('user', ['id' => $uid]);
                    if ($student) {
                        $viewurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]);
                        // Resolve placeholders in the message.
                        $msgtext = str_replace(
                            ['{studentname}', '{coursename}', '{certname}', '{url}'],
                            [fullname($student), $course->fullname, $certstudio->name, $viewurl->out(false)],
                            $notifymessage
                        );

                        if ($notifymoodle) {
                            $message = new \core\message\message();
                            $message->component = 'mod_certstudio';
                            $message->name = 'approval_result';
                            $message->userfrom = $USER;
                            $message->userto = $student;
                            $message->subject = get_string(
                                'bulkissuenotifysubject',
                                'mod_certstudio',
                                format_string($certstudio->name)
                            );
                            $message->fullmessage = $msgtext;
                            $message->fullmessageformat = FORMAT_PLAIN;
                            $message->fullmessagehtml = nl2br(s($msgtext));
                            $message->smallmessage = get_string(
                                'bulkissuenotifysmall',
                                'mod_certstudio',
                                format_string($certstudio->name)
                            );
                            $message->notification = 1;
                            $message->contexturl = $viewurl;
                            $message->contexturlname = get_string('downloadcertificate', 'mod_certstudio');
                            message_send($message);
                        }

                        if ($notifyemail) {
                            $subject = get_string(
                                'bulkissuenotifysubject',
                                'mod_certstudio',
                                format_string($certstudio->name)
                            );
                            email_to_user($student, $USER, $subject, $msgtext, nl2br(s($msgtext)));
                        }

                        $notifiedcount++;
                    }
                }
            }
        }

        $resultmsg = get_string('bulkissuecomplete', 'mod_certstudio', $count);
        if ($notifiedcount > 0) {
            $resultmsg .= ' ' . get_string('bulkissuenotified', 'mod_certstudio', $notifiedcount);
        }
        echo $OUTPUT->notification($resultmsg, 'success');
        echo $OUTPUT->continue_button(new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]));
        echo $OUTPUT->footer();
        die;
    }
}

// Show form.
$viewurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]);
echo '<p>' . get_string('bulkissuedesc', 'mod_certstudio') . '</p>';

if (empty($eligible)) {
    echo $OUTPUT->notification(get_string('bulkissuenoeligible', 'mod_certstudio'), 'info');
    echo $OUTPUT->continue_button($viewurl);
    echo $OUTPUT->footer();
    die;
}

echo '<form method="post" action="' . (new moodle_url('/mod/certstudio/bulkissue.php', ['id' => $cm->id]))->out(false) . '">';
echo '<input type="hidden" name="confirm" value="1">';
echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';

echo '<div class="mb-3">';
echo '<div class="form-check mb-2">';
echo '<input type="checkbox" class="form-check-input" id="bulkissue-selectall">';
echo '<label class="form-check-label font-weight-bold" for="bulkissue-selectall">'
    . get_string('selectall') . ' (' . count($eligible) . ' ' . get_string('students') . ')</label>';
echo '</div>';

echo '<div class="table-responsive"><table class="table table-sm table-striped">';
echo '<thead><tr><th></th><th>' . get_string('student', 'mod_certstudio') . '</th><th>Email</th></tr></thead><tbody>';
foreach ($eligible as $student) {
    echo '<tr>';
    echo '<td><input type="checkbox" class="form-check-input bulkissue-cb" '
        . 'name="userids[]" value="' . $student->id . '" checked></td>';
    echo '<td>' . s(fullname($student)) . '</td>';
    echo '<td>' . s($student->email) . '</td>';
    echo '</tr>';
}
echo '</tbody></table></div>';
echo '</div>';

if (!empty($alreadyissued)) {
    echo '<div class="card mb-3"><div class="card-body">';
    echo '<h6>' . get_string('bulkissuealreadyissued', 'mod_certstudio', count($alreadyissued)) . '</h6>';
    echo '<ul class="mb-0 small">';
    foreach ($alreadyissued as $student) {
        $revoked = (int) $issuedset[$student->id] === \mod_certstudio\certificate::STATUS_REVOKED;
        echo '<li>' . s(fullname($student)) . ' (' . s($student->email) . ')'
            . ($revoked ? ' <span class="badge bg-warning text-dark">' . get_string('revoked', 'mod_certstudio') . '</span>' : '')
            . '</li>';
    }
    echo '</ul></div></div>';
}

// Notification options.
$defaultmsg = get_config('mod_certstudio', 'issuedtemplate') ?: get_string('bulkissuedefaultmessage', 'mod_certstudio');
echo '<div class="card mb-3"><div class="card-body">';
echo '<h5>' . get_string('bulkissuenotify', 'mod_certstudio') . '</h5>';

echo '<div class="form-check mb-2">';
echo '<input type="checkbox" class="form-check-input" name="notifyemail" value="1" id="bi-notifyemail">';
echo '<label class="form-check-label" for="bi-notifyemail"><i class="fa fa-envelope"></i> '
    . get_string('bulkissuenotifyemail', 'mod_certstudio') . '</label>';
echo '</div>';

echo '<div class="form-check mb-3">';
echo '<input type="checkbox" class="form-check-input" name="notifymoodle" value="1" id="bi-notifymoodle">';
echo '<label class="form-check-label" for="bi-notifymoodle"><i class="fa fa-bell"></i> '
    . get_string('bulkissuenotifymoodle', 'mod_certstudio') . '</label>';
echo '</div>';

echo '<div id="bi-message-wrap" style="display:none">';
echo '<label for="bi-message" class="form-label font-weight-bold">'
    . get_string('bulkissuenotifymessage', 'mod_certstudio') . '</label>';
echo '<p class="text-muted small">' . get_string('bulkissuenotifyplaceholders', 'mod_certstudio') . '</p>';
echo '<textarea name="notifymessage" id="bi-message" class="form-control" rows="5">' . s($defaultmsg) . '</textarea>';
echo '</div>';

echo '</div></div>';

echo '<button type="submit" class="btn btn-primary" id="bulkissue-submit"><i class="fa fa-certificate"></i> '
    . '<span id="bulkissue-submit-label">' . get_string('bulkissuesubmit', 'mod_certstudio', count($eligible)) . '</span></button>';
echo ' <a href="' . $viewurl->out(false) . '" class="btn btn-secondary">' . get_string('cancel') . '</a>';
echo '</form>';

// JS: Select all + Show/hide message textarea.
echo '<script>
var submitBtnLabel = "' . addslashes_js(get_string('bulkissuesubmit', 'mod_certstudio', '__COUNT__')) . '";
function updateSubmitCount() {
    var count = document.querySelectorAll(".bulkissue-cb:checked").length;
    document.getElementById("bulkissue-submit-label").textContent = submitBtnLabel.replace("__COUNT__", count);
    document.getElementById("bulkissue-submit").disabled = (count === 0);
}
document.getElementById("bulkissue-selectall").addEventListener("change", function() {
    document.querySelectorAll(".bulkissue-cb").forEach(function(cb) { cb.checked = this.checked; }.bind(this));
    updateSubmitCount();
});
document.querySelectorAll(".bulkissue-cb").forEach(function(cb) {
    cb.addEventListener("change", updateSubmitCount);
});
function toggleMessageBox() {
    var show = document.getElementById("bi-notifyemail").checked || document.getElementById("bi-notifymoodle").checked;
    document.getElementById("bi-message-wrap").style.display = show ? "block" : "none";
}
document.getElementById("bi-notifyemail").addEventListener("change", toggleMessageBox);
document.getElementById("bi-notifymoodle").addEventListener("change", toggleMessageBox);
</script>';

echo $OUTPUT->footer();
