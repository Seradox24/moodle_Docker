<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Border element for mod_certstudio.
 *
 * @package    certstudioselem_border
 * @subpackage certstudioselem_border
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace certstudioselem_border;
/**
 * Border element class.
 */
class element extends \mod_certstudio\element {
    /**
     * Get the element type identifier.
     *
     * @return string
     */
    public function get_type(): string {
        return 'border';
    }

    /**
     * Get the display name of this element.
     *
     * @return string
     */
    public function get_name(): string {
        return get_string('pluginname', 'certstudioselem_border');
    }

    /**
     * Get the FontAwesome icon class.
     *
     * @return string
     */
    public function get_icon(): string {
        return 'fa-square-o';
    }

    /**
     * Render the element as HTML.
     *
     * @param array $data Element data.
     * @return string
     */
    public function render_html(array $data): string {
        $color = $data['color'] ?? '#000000';
        $width = $data['width'] ?? '1';
        $style = $data['style'] ?? 'solid';
        return '<div style="border: ' . s($width) . 'px ' . s($style) . ' ' . s($color) .
               '; width: 100%; height: 100%; box-sizing: border-box;"></div>';
    }

    /**
     * Render PDF output data.
     *
     * @param array $data Element data.
     * @return mixed
     */
    public function render_pdf_data(array $data) {
        return [
            'type' => 'rect',
            'color' => $data['color'] ?? '#000000',
            'width' => $data['width'] ?? '1',
            'style' => $data['style'] ?? 'solid',
        ];
    }
}
