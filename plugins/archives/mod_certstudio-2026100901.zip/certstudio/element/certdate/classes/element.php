<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Greek certificate date element for mod_certstudio.
 *
 * Renders dates in the format "City, DD Month YYYY" using Greek month names.
 *
 * @package    certstudioselem_certdate
 * @subpackage certstudioselem_certdate
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace certstudioselem_certdate;
/**
 * Greek certificate date element class.
 */
class element extends \mod_certstudio\element {
    /** @var array Greek month names in genitive case, indexed 1-12. */
    private const GREEK_MONTHS = [
        1  => 'Ιανουαρίου',
        2  => 'Φεβρουαρίου',
        3  => 'Μαρτίου',
        4  => 'Απριλίου',
        5  => 'Μαΐου',
        6  => 'Ιουνίου',
        7  => 'Ιουλίου',
        8  => 'Αυγούστου',
        9  => 'Σεπτεμβρίου',
        10 => 'Οκτωβρίου',
        11 => 'Νοεμβρίου',
        12 => 'Δεκεμβρίου',
    ];

    /**
     * Get the element type identifier.
     *
     * @return string
     */
    public function get_type(): string {
        return 'certdate';
    }

    /**
     * Get the display name of this element.
     *
     * @return string
     */
    public function get_name(): string {
        return get_string('pluginname', 'certstudioselem_certdate');
    }

    /**
     * Get the FontAwesome icon class.
     *
     * @return string
     */
    public function get_icon(): string {
        return 'fa-map-marker';
    }

    /**
     * Format a timestamp as a Greek date string.
     *
     * @param int $timestamp Unix timestamp.
     * @param string $city City name.
     * @return string Formatted date string, e.g. "Αθήνα, 14 Απριλίου 2025".
     */
    protected function format_greek_date(int $timestamp, string $city): string {
        $day = date('j', $timestamp);
        $month = (int) date('n', $timestamp);
        $year = date('Y', $timestamp);
        $monthname = self::GREEK_MONTHS[$month] ?? '';
        return $city . ', ' . $day . ' ' . $monthname . ' ' . $year;
    }

    /**
     * Render the element as HTML.
     *
     * @param array $data Element data.
     * @return string
     */
    public function render_html(array $data): string {
        $city = $data['city'] ?? 'Αθήνα';
        $timestamp = $data['timestamp'] ?? time();
        return $this->format_greek_date((int) $timestamp, $city);
    }

    /**
     * Render PDF output data.
     *
     * @param array $data Element data.
     * @return mixed
     */
    public function render_pdf_data(array $data) {
        return '{CERTDATE}';
    }
}
