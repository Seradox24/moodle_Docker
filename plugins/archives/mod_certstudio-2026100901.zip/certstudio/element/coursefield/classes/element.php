<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Course field element for mod_certstudio.
 *
 * @package    certstudioselem_coursefield
 * @subpackage certstudioselem_coursefield
 * @copyright  2019 Catalyst IT
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace certstudioselem_coursefield;
/**
 * Course field element class.
 */
class element extends \mod_certstudio\element {
    /**
     * Get the element type identifier.
     *
     * @return string
     */
    public function get_type(): string {
        return 'coursefield';
    }

    /**
     * Get the display name of this element.
     *
     * @return string
     */
    public function get_name(): string {
        return get_string('pluginname', 'certstudioselem_coursefield');
    }

    /**
     * Get the FontAwesome icon class.
     *
     * @return string
     */
    public function get_icon(): string {
        return 'fa-info-circle';
    }

    /**
     * Render the element as HTML.
     *
     * @param array $data Element data.
     * @return string
     */
    public function render_html(array $data): string {
        $fieldname = $data['fieldname'] ?? '';
        return '{COURSEFIELD:' . s($fieldname) . '}';
    }

    /**
     * Render PDF output data.
     *
     * @param array $data Element data.
     * @return mixed
     */
    public function render_pdf_data(array $data) {
        $fieldname = $data['fieldname'] ?? '';
        return '{COURSEFIELD:' . $fieldname . '}';
    }
}
