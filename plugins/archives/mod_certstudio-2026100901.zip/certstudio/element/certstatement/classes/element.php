<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Greek certificate statement element for mod_certstudio.
 *
 * Renders the formal Greek certificate attestation with patronymic.
 * Line 1: "Βεβαιώνεται ότι ο/η" (article based on gender)
 * Line 2: "ΕΠΩΝΥΜΟ ΟΝΟΜΑ του ΠΑΤΡΩΝΥΜΟ" (bold, uppercase, accents removed)
 *
 * @package    certstudioselem_certstatement
 * @subpackage certstudioselem_certstatement
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace certstudioselem_certstatement;
/**
 * Greek certificate statement element class.
 */
class element extends \mod_certstudio\element {
    /**
     * Map of Greek accented lowercase characters to their uppercase unaccented equivalents.
     */
    private const ACCENT_MAP = [
        'ά' => 'Α',
        'έ' => 'Ε',
        'ή' => 'Η',
        'ί' => 'Ι',
        'ό' => 'Ο',
        'ύ' => 'Υ',
        'ώ' => 'Ω',
        'ΐ' => 'Ι',
        'ΰ' => 'Υ',
        'Ά' => 'Α',
        'Έ' => 'Ε',
        'Ή' => 'Η',
        'Ί' => 'Ι',
        'Ό' => 'Ο',
        'Ύ' => 'Υ',
        'Ώ' => 'Ω',
        'ϊ' => 'Ι',
        'ϋ' => 'Υ',
    ];

    /**
     * Get the element type identifier.
     *
     * @return string
     */
    public function get_type(): string {
        return 'certstatement';
    }

    /**
     * Get the display name of this element.
     *
     * @return string
     */
    public function get_name(): string {
        return get_string('pluginname', 'certstudioselem_certstatement');
    }

    /**
     * Get the FontAwesome icon class.
     *
     * @return string
     */
    public function get_icon(): string {
        return 'fa-file-text';
    }

    /**
     * Remove Greek accents and convert to uppercase.
     *
     * @param string $text Greek text.
     * @return string Uppercase text with accents removed.
     */
    protected function greek_uppercase(string $text): string {
        // First replace accented characters with their unaccented uppercase equivalents.
        $text = strtr($text, self::ACCENT_MAP);
        // Then convert the rest to uppercase using multibyte function.
        return mb_strtoupper($text, 'UTF-8');
    }

    /**
     * Determine the Greek article based on gender.
     *
     * @param string $gender The gender value from custom profile field.
     * @return string The article: "ο", "η", or "ο/η".
     */
    protected function get_article(string $gender): string {
        if ($gender === 'Άνδρας') {
            return 'ο';
        } else if ($gender === 'Γυναίκα') {
            return 'η';
        }
        return 'ο/η';
    }

    /**
     * Render the element as HTML.
     *
     * @param array $data Element data.
     * @return string
     */
    public function render_html(array $data): string {
        $gender = $data['gender'] ?? '';
        $lastname = $data['lastname'] ?? '';
        $firstname = $data['firstname'] ?? '';
        $fathername = $data['fathername'] ?? '';

        $article = $this->get_article($gender);
        $line1 = 'Βεβαιώνεται ότι ' . $article;

        $upperlast = $this->greek_uppercase($lastname);
        $upperfirst = $this->greek_uppercase($firstname);
        $upperfather = $this->greek_uppercase($fathername);

        $line2 = '<b>' . s($upperlast) . ' ' . s($upperfirst) . '</b> του <b>' . s($upperfather) . '</b>';

        return '<div>' . s($line1) . '</div><div>' . $line2 . '</div>';
    }

    /**
     * Render PDF output data.
     *
     * @param array $data Element data.
     * @return mixed
     */
    public function render_pdf_data(array $data) {
        return '{CERTSTATEMENT}';
    }
}
