<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate Studio template editor page.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT); // Course module id.
$pageid = optional_param('pageid', 0, PARAM_INT);

$cm = get_coursemodule_from_id('certstudio', $id, 0, false, MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
$certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:manage', $context);

$PAGE->set_url('/mod/certstudio/edit.php', ['id' => $cm->id]);
$PAGE->set_title(get_string('edittemplate', 'mod_certstudio') . ': ' . format_string($certstudio->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);
$PAGE->set_pagelayout('popup'); // Full width for editor.

// Ensure a template exists.
$template = new \mod_certstudio\template();
if (empty($certstudio->templateid)) {
    // Create new template.
    $templateid = $template->create($certstudio->name, $context->id);
    $DB->set_field('certstudio', 'templateid', $templateid, ['id' => $certstudio->id]);
    $certstudio->templateid = $templateid;
} else {
    $templateid = $certstudio->templateid;
}

// Get or create page.
$pages = $template->get_pages($templateid);
if (empty($pages)) {
    $page = new \stdClass();
    $page->templateid = $templateid;
    $page->width = 297;
    $page->height = 210;
    $page->leftmargin = 0;
    $page->rightmargin = 0;
    $page->sequence = 1;
    $page->timecreated = time();
    $page->timemodified = time();
    $page->id = $DB->insert_record('certstudio_pages', $page);
    $pages = [$page];
}

if ($pageid) {
    $currentpage = null;
    foreach ($pages as $p) {
        if ($p->id == $pageid) {
            $currentpage = $p;
            break;
        }
    }
    if (!$currentpage) {
        $currentpage = reset($pages);
    }
} else {
    $currentpage = reset($pages);
}

// Get elements for this page.
$elements = $DB->get_records('certstudio_elements', ['pageid' => $currentpage->id], 'sequence ASC');
$elementsdata = [];
foreach ($elements as $el) {
    $elementsdata[] = [
        'id' => $el->id,
        'pageid' => $el->pageid,
        'name' => $el->name,
        'type' => $el->type,
        'data' => (object) ($el->data ? json_decode($el->data, true) : []),
        'posx' => (float)$el->posx,
        'posy' => (float)$el->posy,
        'width' => (float)$el->width,
        'height' => (float)$el->height,
        'rotation' => (int)$el->rotation,
        'fontfamily' => $el->fontfamily,
        'fontsize' => (int)$el->fontsize,
        'fontweight' => $el->fontweight,
        'fontstyle' => $el->fontstyle,
        'color' => $el->color,
        'alignment' => $el->alignment,
        'opacity' => (float)$el->opacity,
        'locked' => (int)$el->locked,
        'sequence' => (int)$el->sequence,
    ];
}

// Get available element types.
$factory = new \mod_certstudio\element_factory();
$availabletypes = array_values(array_filter($factory->get_available_types(), function ($t) {
    return $t['type'] !== 'bgimage'; // Bgimage is managed via page settings, not palette.
}));

// Get available fonts.
$fonts = certstudio_get_fonts();

// Prepare font URLs for CSS @font-face.
$fonturls = [];
$fontfamilies = [];
foreach ($fonts as $font) {
    $fonturls[] = [
        'family' => $font['family'],
        'style' => $font['style'],
        'url' => (new moodle_url('/mod/certstudio/fonts/' . $font['file']))->out(false),
    ];
    $fontfamilies[$font['family']] = $font['family'];
}
// Deduplicated font family list for the font selector dropdown.
$fontfamilylist = [];
foreach ($fontfamilies as $family) {
    $fontfamilylist[] = ['family' => $family];
}

// Get template name.
$templaterecord = \mod_certstudio\template::get($templateid);
$templatename = $templaterecord ? $templaterecord->name : $certstudio->name;

// Build editor data.
$editordata = [
    'cmid' => $cm->id,
    'templateid' => $templateid,
    'templatename' => $templatename,
    'viewurl' => (new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]))->out(false),
    'page' => [
        'id' => $currentpage->id,
        'width' => (int)$currentpage->width,
        'height' => (int)$currentpage->height,
        'leftmargin' => (int)$currentpage->leftmargin,
        'rightmargin' => (int)$currentpage->rightmargin,
        'backgroundimage' => $currentpage->backgroundimage ?? '',
        'bgcolor' => $currentpage->bgcolor ?? '#ffffff',
    ],
    'pages' => array_values(array_map(function ($p) {
        return ['id' => $p->id, 'sequence' => $p->sequence];
    }, $pages)),
    'elements' => $elementsdata,
    'elementtypes' => $availabletypes,
    'fonts' => $fonturls,
    'fontfamilies' => $fontfamilylist,
    'sesskey' => sesskey(),
    'uploadurl' => (new moodle_url('/mod/certstudio/upload.php'))->out(false),
    // Choices for the element settings of the date, grade and course field elements.
    'dateformats' => \mod_certstudio\certificate::get_date_format_options(),
    'gradeitems' => \mod_certstudio\certificate::get_grade_item_options($course->id),
    'coursefields' => \mod_certstudio\certificate::get_course_field_options(),
];

// Load third-party libraries.
$PAGE->requires->js(new moodle_url('/mod/certstudio/thirdparty/interact/interact.min.js'), true);
$PAGE->requires->js(new moodle_url('/mod/certstudio/thirdparty/jspdf/jspdf.umd.min.js'), true);
$PAGE->requires->js(new moodle_url('/mod/certstudio/thirdparty/qrcode/qrcode.min.js'), true);

// Initialize the editor AMD module - pass only minimal args, data goes via data attribute.
$PAGE->requires->js_call_amd('mod_certstudio/editor', 'init');

// Moodle 5.3+ adds a Previous/Next activity footer to module pages, which would overlap the full-screen editor.
if (method_exists($PAGE, 'set_show_navigation_footer')) {
    $PAGE->set_show_navigation_footer(false);
}

echo $OUTPUT->header();

// Pass large editor config via a data attribute on a hidden element to avoid js_call_amd size limit.
$jsonconfig = json_encode($editordata, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
echo html_writer::tag('div', '', [
    'id' => 'certstudio-config',
    'data-config' => $jsonconfig,
    'style' => 'display:none;',
]);

echo $OUTPUT->render_from_template('mod_certstudio/editor', $editordata);
echo $OUTPUT->footer();
