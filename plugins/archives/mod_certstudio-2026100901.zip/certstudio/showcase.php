<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Animated digital certificate showcase & verification page.
 *
 * When visited with a code: renders the certificate as animated HTML5.
 * When visited without a code: shows the verification form.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$code = optional_param('code', '', PARAM_ALPHANUMEXT);

$PAGE->set_url('/mod/certstudio/showcase.php', ['code' => $code]);
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('standard');
$PAGE->set_title(get_string('showcasetitle', 'mod_certstudio'));
$PAGE->set_heading(get_string('showcasetitle', 'mod_certstudio'));

// Check if public verification is enabled.
$allowpublic = !empty(get_config('mod_certstudio', 'verifyany'));
if (!$allowpublic) {
    if (!isloggedin() || isguestuser()) {
        require_login();
    }
}

// ========================================================================
// No code provided -> show verification form.
// ========================================================================
if (empty($code)) {
    echo $OUTPUT->header();
    echo '<div class="certstudio-showcase" style="max-width:600px;">';
    echo '<div class="text-center mb-4">';
    echo '<h3><i class="fa fa-shield text-primary"></i> ' . get_string('verifycertificate', 'mod_certstudio') . '</h3>';
    echo '<p class="text-muted">' . format_string($SITE->fullname) . '</p>';
    echo '</div>';
    echo '<form method="get" action="' . (new moodle_url('/mod/certstudio/showcase.php'))->out(false) . '" class="d-flex justify-content-center mb-4">';
    echo '<div class="input-group" style="max-width:450px;">';
    echo '<input type="text" name="code" class="form-control" placeholder="' . get_string('entercode', 'mod_certstudio') . '">';
    echo '<div class="input-group-append">';
    echo '<button type="submit" class="btn btn-primary">' . get_string('verify', 'mod_certstudio') . '</button>';
    echo '</div></div></form>';
    echo '</div>';
    echo $OUTPUT->footer();
    die();
}

// ========================================================================
// Code provided -> look up issue and render showcase.
// ========================================================================
$issue = $DB->get_record('certstudio_issues', ['code' => $code]);
if (!$issue) {
    echo $OUTPUT->header();
    // Show "not found" with the search form so user can try again.
    echo '<div class="certstudio-showcase" style="max-width:600px;">';
    echo '<div class="text-center mb-4">';
    echo '<i class="fa fa-times-circle fa-3x text-danger mb-2" style="display:block;"></i>';
    echo '<h4>' . get_string('certificatenotfound', 'mod_certstudio') . '</h4>';
    echo '</div>';
    echo '<form method="get" action="' . (new moodle_url('/mod/certstudio/showcase.php'))->out(false) . '" class="d-flex justify-content-center mb-4">';
    echo '<div class="input-group" style="max-width:450px;">';
    echo '<input type="text" name="code" class="form-control" placeholder="' . get_string('entercode', 'mod_certstudio') . '" value="' . s($code) . '">';
    echo '<div class="input-group-append">';
    echo '<button type="submit" class="btn btn-primary">' . get_string('verify', 'mod_certstudio') . '</button>';
    echo '</div></div></form>';
    echo '</div>';
    echo $OUTPUT->footer();
    die();
}

$certstudio = $DB->get_record('certstudio', ['id' => $issue->certstudioid]);
$user = $DB->get_record('user', ['id' => $issue->userid]);
$course = $certstudio ? $DB->get_record('course', ['id' => $certstudio->course]) : null;

// Determine certificate status.
$isrevoked = !empty($issue->status) && (int) $issue->status === \mod_certstudio\certificate::STATUS_REVOKED;
$isexpired = !empty($issue->expirydate) && $issue->expirydate < time();
$isvalid = !$isrevoked && !$isexpired;

$studentname = $user ? fullname($user) : get_string('unknownuser', 'mod_certstudio');
$coursename = $course ? format_string($course->fullname) : get_string('unknowncourse', 'mod_certstudio');
$certname = $certstudio ? format_string($certstudio->name) : '';
$issuedate = userdate($issue->timecreated);

echo $OUTPUT->header();

echo '<div class="certstudio-showcase" style="max-width:600px;">';

// Status badge.
if ($isvalid) {
    echo '<div class="text-center mb-3">';
    echo '<i class="fa fa-check-circle fa-3x mb-2" style="display:block;color:#059669;"></i>';
    echo '<div class="certstudio-showcase-verified">';
    echo '<i class="fa fa-check-circle"></i> ' . get_string('showcaseverified', 'mod_certstudio');
    echo '</div>';
    echo '</div>';
} else if ($isrevoked) {
    echo '<div class="text-center mb-3">';
    echo '<i class="fa fa-ban fa-3x mb-2" style="display:block;color:#dc2626;"></i>';
    echo '<div class="certstudio-showcase-warning">';
    echo '<i class="fa fa-ban"></i> ' . get_string('certificaterevoked', 'mod_certstudio');
    echo '</div>';
    echo '</div>';
} else if ($isexpired) {
    echo '<div class="text-center mb-3">';
    echo '<i class="fa fa-clock-o fa-3x mb-2" style="display:block;color:#d97706;"></i>';
    echo '<div class="certstudio-showcase-warning">';
    echo '<i class="fa fa-clock-o"></i> ' . get_string(
        'certificateexpired',
        'mod_certstudio',
        userdate($issue->expirydate)
    );
    echo '</div>';
    echo '</div>';
}

// Certificate details table.
echo '<table class="table table-bordered mt-3">';
echo '<tr><td class="text-muted" style="width:40%;">' . get_string('certificate', 'mod_certstudio') . '</td><td><strong>' . s($certname) . '</strong></td></tr>';
echo '<tr><td class="text-muted">' . get_string('showcaserecipient', 'mod_certstudio') . '</td><td><strong>' . s($studentname) . '</strong></td></tr>';
echo '<tr><td class="text-muted">' . get_string('showcasecourse', 'mod_certstudio') . '</td><td><strong>' . s($coursename) . '</strong></td></tr>';
echo '<tr><td class="text-muted">' . get_string('showcaseissuedon', 'mod_certstudio') . '</td><td><strong>' . $issuedate . '</strong></td></tr>';
if (!empty($issue->expirydate)) {
    echo '<tr><td class="text-muted">' . get_string('expirydate', 'mod_certstudio') . '</td><td><strong>' . userdate($issue->expirydate) . '</strong></td></tr>';
}
echo '<tr><td class="text-muted">' . get_string('verificationcode', 'mod_certstudio') . '</td><td><code>' . s($issue->code) . '</code></td></tr>';
echo '</table>';

// Verify another code form.
echo '<div class="mt-4 pt-3" style="border-top:1px solid #e2e8f0;">';
echo '<form method="get" action="' . (new moodle_url('/mod/certstudio/showcase.php'))->out(false) . '" class="d-flex justify-content-center">';
echo '<div class="input-group" style="max-width:400px;">';
echo '<input type="text" name="code" class="form-control form-control-sm" placeholder="' . get_string('entercode', 'mod_certstudio') . '">';
echo '<div class="input-group-append">';
echo '<button type="submit" class="btn btn-sm btn-outline-primary">' . get_string('verify', 'mod_certstudio') . '</button>';
echo '</div></div></form>';
echo '</div>';

echo '</div>'; // .certstudio-showcase

echo $OUTPUT->footer();
