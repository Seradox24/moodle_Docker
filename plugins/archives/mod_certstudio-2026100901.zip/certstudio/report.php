<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate Studio analytics report.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$action = optional_param('action', '', PARAM_ALPHA);

// Handle ODS export.
if ($action === 'exportods') {
    require_once($CFG->libdir . '/odslib.class.php');
    $allissues = $DB->get_records_sql(
        "SELECT ci.id, ci.code, ci.timecreated, ci.status, ci.expirydate,
                u.firstname, u.lastname, u.email,
                cs.name AS certname, c.fullname AS coursename
         FROM {certstudio_issues} ci
         JOIN {user} u ON u.id = ci.userid
         JOIN {certstudio} cs ON cs.id = ci.certstudioid
         JOIN {course} c ON c.id = cs.course
         ORDER BY ci.timecreated DESC"
    );
    $workbook = new MoodleODSWorkbook('-');
    $workbook->send('certstudio_report.ods');
    $sheet = $workbook->add_worksheet(get_string('issuedcertificates', 'mod_certstudio'));
    $boldformat = $workbook->add_format(['bold' => 1]);
    $headers = [
        get_string('student', 'mod_certstudio'),
        get_string('email'),
        get_string('course'),
        get_string('certificate', 'mod_certstudio'),
        get_string('verificationcode', 'mod_certstudio'),
        get_string('status'),
        get_string('dateissued', 'mod_certstudio'),
        get_string('expirydate', 'mod_certstudio'),
    ];
    foreach ($headers as $col => $header) {
        $sheet->write_string(0, $col, $header, $boldformat);
    }
    $row = 1;
    foreach ($allissues as $issue) {
        $sheet->write_string($row, 0, $issue->firstname . ' ' . $issue->lastname);
        $sheet->write_string($row, 1, $issue->email);
        $sheet->write_string($row, 2, $issue->coursename);
        $sheet->write_string($row, 3, $issue->certname);
        $sheet->write_string($row, 4, $issue->code);
        $sheet->write_string($row, 5, (int) $issue->status === 0 ? get_string('active', 'mod_certstudio') : get_string('revoked', 'mod_certstudio'));
        $sheet->write_string($row, 6, userdate($issue->timecreated, '%Y-%m-%d %H:%M'));
        $sheet->write_string($row, 7, !empty($issue->expirydate) ? userdate($issue->expirydate, '%Y-%m-%d') : get_string('expirynever', 'mod_certstudio'));
        $row++;
    }
    $workbook->close();
    exit;
}

// Handle CSV export.
if ($action === 'exportcsv') {
    $allissues = $DB->get_records_sql(
        "SELECT ci.id, ci.code, ci.timecreated, ci.status, ci.expirydate,
                u.firstname, u.lastname, u.email,
                cs.name AS certname, c.fullname AS coursename
         FROM {certstudio_issues} ci
         JOIN {user} u ON u.id = ci.userid
         JOIN {certstudio} cs ON cs.id = ci.certstudioid
         JOIN {course} c ON c.id = cs.course
         ORDER BY ci.timecreated DESC"
    );
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="certstudio_report.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, [
        get_string('student', 'mod_certstudio'),
        get_string('email'),
        get_string('course'),
        get_string('certificate', 'mod_certstudio'),
        get_string('verificationcode', 'mod_certstudio'),
        get_string('status'),
        get_string('dateissued', 'mod_certstudio'),
        get_string('expirydate', 'mod_certstudio'),
    ]);
    foreach ($allissues as $issue) {
        fputcsv($out, [
            $issue->firstname . ' ' . $issue->lastname,
            $issue->email,
            $issue->coursename,
            $issue->certname,
            $issue->code,
            (int) $issue->status === 0 ? get_string('active', 'mod_certstudio') : get_string('revoked', 'mod_certstudio'),
            userdate($issue->timecreated, '%Y-%m-%d %H:%M'),
            !empty($issue->expirydate) ? userdate($issue->expirydate, '%Y-%m-%d') : get_string('expirynever', 'mod_certstudio'),
        ]);
    }
    fclose($out);
    exit;
}

// Handle XLSX export.
if ($action === 'exportxlsx') {
    require_once($CFG->libdir . '/excellib.class.php');
    $allissues = $DB->get_records_sql(
        "SELECT ci.id, ci.code, ci.timecreated, ci.status, ci.expirydate,
                u.firstname, u.lastname, u.email,
                cs.name AS certname, c.fullname AS coursename
         FROM {certstudio_issues} ci
         JOIN {user} u ON u.id = ci.userid
         JOIN {certstudio} cs ON cs.id = ci.certstudioid
         JOIN {course} c ON c.id = cs.course
         ORDER BY ci.timecreated DESC"
    );
    $workbook = new MoodleExcelWorkbook('-');
    $workbook->send('certstudio_report.xlsx');
    $sheet = $workbook->add_worksheet(get_string('issuedcertificates', 'mod_certstudio'));
    $boldformat = $workbook->add_format(['bold' => 1]);
    $headers = [
        get_string('student', 'mod_certstudio'),
        get_string('email'),
        get_string('course'),
        get_string('certificate', 'mod_certstudio'),
        get_string('verificationcode', 'mod_certstudio'),
        get_string('status'),
        get_string('dateissued', 'mod_certstudio'),
        get_string('expirydate', 'mod_certstudio'),
    ];
    foreach ($headers as $col => $header) {
        $sheet->write_string(0, $col, $header, $boldformat);
    }
    $row = 1;
    foreach ($allissues as $issue) {
        $sheet->write_string($row, 0, $issue->firstname . ' ' . $issue->lastname);
        $sheet->write_string($row, 1, $issue->email);
        $sheet->write_string($row, 2, $issue->coursename);
        $sheet->write_string($row, 3, $issue->certname);
        $sheet->write_string($row, 4, $issue->code);
        $sheet->write_string($row, 5, (int) $issue->status === 0 ? get_string('active', 'mod_certstudio') : get_string('revoked', 'mod_certstudio'));
        $sheet->write_string($row, 6, userdate($issue->timecreated, '%Y-%m-%d %H:%M'));
        $sheet->write_string($row, 7, !empty($issue->expirydate) ? userdate($issue->expirydate, '%Y-%m-%d') : get_string('expirynever', 'mod_certstudio'));
        $row++;
    }
    $workbook->close();
    exit;
}

$PAGE->set_url('/mod/certstudio/report.php');
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('reportanalytics', 'mod_certstudio'));
$PAGE->set_heading(get_string('reportanalytics', 'mod_certstudio'));

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('reportanalytics', 'mod_certstudio'));

// Export buttons.
echo '<div class="mb-3 d-flex gap-1 flex-wrap">';
$csvurl = new moodle_url('/mod/certstudio/report.php', ['action' => 'exportcsv']);
echo '<a href="' . $csvurl->out(false) . '" class="btn btn-sm btn-outline-success"><i class="fa fa-file-text-o"></i> CSV</a>';
$xlsxurl = new moodle_url('/mod/certstudio/report.php', ['action' => 'exportxlsx']);
echo '<a href="' . $xlsxurl->out(false) . '" class="btn btn-sm btn-outline-success"><i class="fa fa-file-excel-o"></i> XLSX</a>';
$odsurl = new moodle_url('/mod/certstudio/report.php', ['action' => 'exportods']);
echo '<a href="' . $odsurl->out(false) . '" class="btn btn-sm btn-outline-success"><i class="fa fa-table"></i> ODS</a>';
echo '</div>';

// Global statistics.
$totalissued = $DB->count_records('certstudio_issues');
$totalactivities = $DB->count_records('certstudio');
$totaltemplates = $DB->count_records('certstudio_templates');
$totalusers = $DB->count_records_sql(
    "SELECT COUNT(DISTINCT userid) FROM {certstudio_issues}"
);

echo '<div class="row mb-4">';
$stats = [
    ['icon' => 'fa-certificate', 'color' => 'primary', 'label' => get_string('reporttotalissued', 'mod_certstudio'), 'value' => $totalissued],
    ['icon' => 'fa-users', 'color' => 'success', 'label' => get_string('reportuniquerecipients', 'mod_certstudio'), 'value' => $totalusers],
    ['icon' => 'fa-book', 'color' => 'info', 'label' => get_string('reporttotalactivities', 'mod_certstudio'), 'value' => $totalactivities],
    ['icon' => 'fa-file-text-o', 'color' => 'warning', 'label' => get_string('reporttotaltemplates', 'mod_certstudio'), 'value' => $totaltemplates],
];
foreach ($stats as $stat) {
    echo '<div class="col-md-3 col-sm-6 mb-2">';
    echo '<div class="card border-' . $stat['color'] . '">';
    echo '<div class="card-body text-center">';
    echo '<i class="fa ' . $stat['icon'] . ' fa-2x text-' . $stat['color'] . ' mb-2"></i>';
    echo '<h3 class="mb-0">' . $stat['value'] . '</h3>';
    echo '<small class="text-muted">' . $stat['label'] . '</small>';
    echo '</div></div></div>';
}
echo '</div>';

// Certificates per course.
$percourse = $DB->get_records_sql(
    "SELECT c.id, c.fullname, c.shortname, COUNT(ci.id) AS certcount
     FROM {certstudio_issues} ci
     JOIN {certstudio} cs ON cs.id = ci.certstudioid
     JOIN {course} c ON c.id = cs.course
     GROUP BY c.id, c.fullname, c.shortname
     ORDER BY certcount DESC",
    [],
    0,
    20
);

echo '<div class="card mb-4"><div class="card-body">';
echo '<h5><i class="fa fa-bar-chart"></i> ' . get_string('reportpercourse', 'mod_certstudio') . '</h5>';
if (empty($percourse)) {
    echo '<p class="text-muted">' . get_string('nodata', 'mod_certstudio') . '</p>';
} else {
    echo '<table class="table table-sm table-striped">';
    echo '<thead><tr><th>' . get_string('course') . '</th><th class="text-right">'
        . get_string('issuedcertificates', 'mod_certstudio') . '</th></tr></thead><tbody>';
    foreach ($percourse as $row) {
        $courseurl = new moodle_url('/course/view.php', ['id' => $row->id]);
        echo '<tr>';
        echo '<td><a href="' . $courseurl->out(false) . '">' . s($row->fullname) . '</a></td>';
        echo '<td class="text-right"><strong>' . $row->certcount . '</strong></td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
echo '</div></div>';

// Recent certificates (last 30 days).
$recent = $DB->get_records_sql(
    "SELECT ci.id, ci.code, ci.timecreated, u.firstname, u.lastname,
            cs.name AS certname, c.fullname AS coursename
     FROM {certstudio_issues} ci
     JOIN {user} u ON u.id = ci.userid
     JOIN {certstudio} cs ON cs.id = ci.certstudioid
     JOIN {course} c ON c.id = cs.course
     WHERE ci.timecreated > ?
     ORDER BY ci.timecreated DESC",
    [time() - (30 * 86400)],
    0,
    50
);

echo '<div class="card mb-4"><div class="card-body">';
echo '<h5><i class="fa fa-clock-o"></i> ' . get_string('reportrecent', 'mod_certstudio') . '</h5>';
if (empty($recent)) {
    echo '<p class="text-muted">' . get_string('nodata', 'mod_certstudio') . '</p>';
} else {
    echo '<table class="table table-sm table-striped">';
    echo '<thead><tr><th>' . get_string('student', 'mod_certstudio') . '</th><th>'
        . get_string('certificate', 'mod_certstudio') . '</th><th>'
        . get_string('course') . '</th><th>'
        . get_string('dateissued', 'mod_certstudio') . '</th></tr></thead><tbody>';
    foreach ($recent as $row) {
        echo '<tr>';
        echo '<td>' . s($row->firstname . ' ' . $row->lastname) . '</td>';
        echo '<td>' . s($row->certname) . '</td>';
        echo '<td>' . s($row->coursename) . '</td>';
        echo '<td>' . userdate($row->timecreated, get_string('strftimedatetimeshort', 'langconfig')) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
echo '</div></div>';

// Monthly trend. Months are counted in PHP, in the user's timezone, so this works on every database Moodle supports.
$timezone = core_date::get_user_timezone_object();
$counts = [];
$rs = $DB->get_recordset_select('certstudio_issues', 'timecreated > ?', [time() - (365 * 86400)], '', 'id, timecreated');
foreach ($rs as $record) {
    $month = (new DateTime('@' . $record->timecreated))->setTimezone($timezone)->format('Y-m');
    $counts[$month] = ($counts[$month] ?? 0) + 1;
}
$rs->close();
krsort($counts);
$monthly = [];
foreach (array_slice($counts, 0, 12, true) as $month => $count) {
    $monthly[$month] = (object) ['month' => $month, 'certcount' => $count];
}

echo '<div class="card mb-4"><div class="card-body">';
echo '<h5><i class="fa fa-line-chart"></i> ' . get_string('reportmonthly', 'mod_certstudio') . '</h5>';
if (empty($monthly)) {
    echo '<p class="text-muted">' . get_string('nodata', 'mod_certstudio') . '</p>';
} else {
    echo '<table class="table table-sm">';
    echo '<thead><tr><th>' . get_string('month') . '</th><th class="text-right">'
        . get_string('issuedcertificates', 'mod_certstudio') . '</th><th></th></tr></thead><tbody>';
    $maxcount = max(array_column((array) $monthly, 'certcount'));
    foreach ($monthly as $row) {
        $pct = $maxcount > 0 ? round(($row->certcount / $maxcount) * 100) : 0;
        echo '<tr>';
        echo '<td>' . s($row->month) . '</td>';
        echo '<td class="text-right"><strong>' . $row->certcount . '</strong></td>';
        echo '<td style="width:50%"><div class="progress"><div class="progress-bar bg-primary" style="width:' . $pct . '%"></div></div></td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}
echo '</div></div>';

echo $OUTPUT->footer();
