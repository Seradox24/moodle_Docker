![Moodle Plugin](https://img.shields.io/badge/Moodle%20Plugin-mod__certstudio-blue)
![Moodle 4.5+](https://img.shields.io/badge/Moodle-4.5%2B-orange)
![PHP 8.1+](https://img.shields.io/badge/PHP-8.1%2B-777BB4)
![License GPL v3](https://img.shields.io/badge/License-GPL%20v3-green)
![Release](https://img.shields.io/badge/Release-1.0.1-brightgreen)
![Maturity](https://img.shields.io/badge/Maturity-Stable-success)

# Certificate Studio

**The most advanced visual certificate designer for Moodle.**

Certificate Studio (`mod_certstudio`) is a feature-rich activity module that brings professional-grade certificate design and management directly into your Moodle platform. With its intuitive drag-and-drop editor, 40+ built-in templates, AI-powered generation, and comprehensive issuance workflow, Certificate Studio eliminates the need for external design tools and complex certificate management processes.

---

## Table of Contents

- [Features](#features)
- [Screenshots](#screenshots)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
- [Element Types](#element-types)
- [Template Gallery](#template-gallery)
- [AI Template Generator](#ai-template-generator)
- [Approval Workflow](#approval-workflow)
- [Certificate Verification](#certificate-verification)
- [Email Notifications](#email-notifications)
- [Template Import & Export](#template-import--export)
- [Migration from Custom Certificate](#migration-from-custom-certificate)
- [Reports & Analytics](#reports--analytics)
- [API & Integration](#api--integration)
- [Supported Languages](#supported-languages)
- [Privacy & GDPR](#privacy--gdpr)
- [Backup & Restore](#backup--restore)
- [License](#license)
- [Credits](#credits)

---

## Features

### Visual Certificate Editor
- **Drag-and-drop editor** with live canvas preview -- design certificates directly in your browser
- **Real-time positioning** with pixel-perfect precision (mm-based coordinate system)
- **Zoom controls** for detailed editing
- **Grid and snap-to-grid** alignment tools
- **Undo/redo history** for non-destructive editing
- **Clipboard support** (copy/paste elements)
- **Autosave** with configurable interval (60-second default) and countdown indicator
- **Multi-page certificate** support -- create certificates with multiple pages
- **Page settings** including size (A4, Letter, custom), orientation, margins, background color, and background images

### 20+ Element Types
Place and customize a wide range of dynamic and static elements on your certificate canvas. Every text element supports custom fonts, sizes, colors, weight, and alignment. See the full [Element Types](#element-types) table below.

### 40+ Built-in Professional Templates
- **SVG background templates** organized in a gallery browser
- **Search and filter** by style, color scheme, and design category
- **Full-size preview** before applying
- One-click application to your certificate design

### AI-Powered Template Generation
- Generate complete certificate layouts from natural language descriptions
- Supports **OpenAI (GPT-4)** and **Anthropic (Claude)** providers
- Configurable model selection (e.g., `gpt-4o-mini`)
- Secure API key management with masked admin setting

### PDF Generation & Protection
- **Server-side PDF rendering** using TCPDF for pixel-perfect output
- **Real-time PDF preview** from the editor
- **PDF protection flags**: restrict printing, modification, and copying
- **Custom filenames** with dynamic placeholders: `{coursename}`, `{studentname}`, `{date}`
- Default filename pattern: `Certificate_{coursename}_{studentname}`

### Certificate Issuance & Lifecycle
- **Auto-issue on course completion** -- the certificate is issued when Moodle marks the course as complete
- **Bulk certificate issuance** for multiple students at once
- **Certificate revocation** with notification to the student
- **Certificate re-issuance** after revocation
- **Certificate expiry** with configurable validity period (days)
- **Required time** setting -- minimum time in course before certificate can be issued
- **Language override** -- force certificate language regardless of user preference

### Approval Workflow
- Optional **request-approve-reject** workflow
- Students submit requests; teachers review and approve or reject
- **Automatic notifications** to teachers on new requests
- **Automatic notifications** to students on approval or rejection
- Fully customizable **message templates** with placeholders

### Certificate Verification
- **QR code element** embedded directly on certificates
- **Verification code element** with two generation methods:
  - Alphanumeric random string (e.g., `6aOdbLEuoC`)
  - Digits with hyphens (e.g., `0123-4567-8901`)
- **Public verification page** (showcase) -- optionally allow anyone to verify without logging in
- **Custom verification URL** support with `{code}` placeholder
- Dedicated **showcase page** for certificate display and verification

### Email Notifications
- Notify **students** when certificates are issued, revoked, or re-issued
- Notify **teachers** when certificates are requested or issued
- Notify **custom email addresses** (comma-separated)
- Six fully customizable **email templates**:
  - Approval request notification
  - Approval granted notification
  - Approval rejected notification
  - Certificate issued notification
  - Certificate revoked notification
  - Certificate re-issued notification

### Template Management
- **Import/export templates** in JSON format with base64-embedded images
- **Template sharing** across courses via the admin management page
- **My Certificates page** for students to view and download all their certificates

### Migration Tool
- Built-in **migration tool from mod_customcert** (Custom Certificate plugin)
- Accessible from the admin settings page

### Mobile App Support
- Full **Moodle Mobile app** integration via `CoreCourseModuleDelegate`
- View and download certificates from the mobile app
- Offline function support

### Compliance & Standards
- **GDPR / Privacy API** compliance with full data provider implementation
- **Backup and restore** support for Moodle's standard backup system
- Standard Moodle **event system** integration with 13 event types

---

## Screenshots

> *Screenshots coming soon. Add your screenshots to the `pix/` directory and reference them here.*

| Editor View | Template Gallery | Issued Certificate |
|:-----------:|:----------------:|:------------------:|
| ![Editor](pix/screenshot-editor.png) | ![Gallery](pix/screenshot-gallery.png) | ![Certificate](pix/screenshot-certificate.png) |

---

## Requirements

| Requirement | Version |
|-------------|---------|
| **Moodle**  | 4.5 to 5.3 (build 2024100700 or later) |
| **PHP**     | 8.1 or later |

No additional PHP extensions beyond what Moodle requires are needed. PDF generation uses TCPDF, which is bundled with Moodle core.

---

## Installation

### Method 1: From the Moodle Plugin Directory

1. Download the plugin from [plugins.letstudy.gr](https://plugins.letstudy.gr)
2. Navigate to **Site administration > Plugins > Install plugins**
3. Upload the ZIP file and follow the on-screen instructions
4. Complete the upgrade process

### Method 2: Manual Installation

1. Extract the plugin archive
2. Copy the `certstudio` folder to `/path/to/moodle/mod/certstudio`
3. Navigate to **Site administration > Notifications** to trigger the database upgrade
4. Configure the plugin settings as described below

### Method 3: Git

```bash
cd /path/to/moodle/mod
git clone https://github.com/letstudy/moodle-mod_certstudio.git certstudio
```

Then visit **Site administration > Notifications** to complete the installation.

---

## Configuration

After installation, navigate to **Site administration > Plugins > Activity modules > Certificate Studio** to configure global settings.

### General Settings

| Setting | Description |
|---------|-------------|
| **Custom verification URL** | Override the default verification page URL. Use `{code}` as a placeholder for the verification code. |
| **Code generation method** | Choose between alphanumeric strings or digit-hyphen format for verification codes. |
| **Return to course** | Redirect students back to the course after downloading their certificate. |

### PDF Settings

| Setting | Description |
|---------|-------------|
| **Default filename** | Template for downloaded PDF filenames. Supports `{coursename}`, `{studentname}`, `{date}` placeholders. |
| **Prevent printing** | Disable the print function in PDF viewers. |
| **Prevent modification** | Prevent editing of the PDF document. |
| **Prevent copying** | Disable text selection and copying from the PDF. |

### Email Notification Settings

| Setting | Description |
|---------|-------------|
| **Email students** | Automatically email students when a certificate is issued. |
| **Email teachers** | Notify teachers when certificates are issued. |
| **Email others** | Send notifications to additional email addresses (comma-separated). |

### Approval Settings

| Setting | Description |
|---------|-------------|
| **Enable approval workflow** | Require teacher approval before certificates can be downloaded. |
| **Notify teacher on request** | Send a notification to teachers when a student submits a certificate request. |
| **Notify student on result** | Notify students when their request is approved or rejected. |

### Default Activity Values

| Setting | Description |
|---------|-------------|
| **Allow public verification** | Enable certificate verification without login by default. |
| **Auto-issue** | Automatically issue certificates on course completion by default. |
| **Required time** | Minimum time (in minutes) a student must spend in the course before receiving a certificate. |

### Message Templates

Customize the content of all notification messages using placeholders:
- `{student}` -- Student's full name
- `{activity}` -- Activity name

Templates available for: approval requests, approvals, rejections, issuance, revocation, and re-issuance.

### AI Template Generator Settings

| Setting | Description |
|---------|-------------|
| **AI Provider** | Choose between OpenAI (GPT-4) or Anthropic (Claude). |
| **API Key** | Your provider's API key (stored securely, displayed masked). |
| **Model** | The specific model to use (default: `gpt-4o-mini`). |

---

## Usage

### Basic Workflow

1. **Add the activity**: In your course, turn editing on and add a "Certificate Studio" activity.
2. **Select or create a template**: Choose an existing template or create a new one from scratch.
3. **Design your certificate**: Use the visual editor to place elements, set fonts, add images, and configure the layout.
4. **Configure issuance**: Set up auto-issue on completion, approval workflow, or manual issuance.
5. **Students receive certificates**: Based on your configuration, students can download their certificates directly or after approval.

### Editor Workflow

1. Open the certificate editor from the activity page.
2. Use the **element palette** on the left to drag elements onto the canvas.
3. Click any element to select it and edit its properties in the **properties panel**.
4. Use the **template gallery** button to browse and apply professional backgrounds.
5. Use the **AI generator** to create a layout from a text description.
6. Click **Preview PDF** to see the rendered output at any time.
7. The editor **autosaves** your work every 60 seconds. A manual save button is also available.

---

## Element Types

Certificate Studio provides 21 element types organized into five categories:

### Text Elements

| Element | Icon | Description |
|---------|------|-------------|
| **Text** | `fa-font` | Static text with full formatting control |
| **Statement** | `fa-file-text` | Multi-line certificate statement or body text |

### Data Elements

| Element | Icon | Description |
|---------|------|-------------|
| **Student Name** | `fa-user` | Automatically populated with the certificate recipient's full name |
| **Course Name** | `fa-book` | The name of the course the certificate is issued for |
| **Category Name** | `fa-folder` | The course category name |
| **Teacher Name** | `fa-graduation-cap` | The name of the teacher(s) in the course |
| **Date** | `fa-calendar` | The certificate issue date |
| **Date Range** | `fa-calendar-o` | A date range (e.g., course start to end) |
| **Expiry Date** | `fa-clock-o` | The certificate expiration date |
| **Localized Date** | `fa-map-marker` | Date formatted according to locale conventions |
| **Grade** | `fa-star` | The student's course grade |
| **Grade Item Name** | `fa-list` | The name of a specific grade item |
| **User Field** | `fa-id-card` | Any user profile field (standard or custom) |
| **Course Field** | `fa-info-circle` | Any course field (standard or custom) |

### Media Elements

| Element | Icon | Description |
|---------|------|-------------|
| **Image** | `fa-image` | Upload and place any image on the certificate |
| **Background Image** | `fa-picture-o` | Full-page background image |
| **User Picture** | `fa-camera` | The student's profile picture |
| **Digital Signature** | `fa-pencil` | Upload a signature image for authorized signatories |

### Layout Elements

| Element | Icon | Description |
|---------|------|-------------|
| **Border** | `fa-square-o` | Decorative border element with customizable style |

### Verification Elements

| Element | Icon | Description |
|---------|------|-------------|
| **QR Code** | `fa-qrcode` | Scannable QR code linking to the verification page |
| **Verification Code** | `fa-barcode` | Unique alphanumeric code for manual verification |

---

## Template Gallery

Certificate Studio ships with **40+ professionally designed SVG background templates**. The gallery provides:

- **Visual grid browser** with thumbnail previews
- **Search** by template name or keywords
- **Filter** by style (classic, modern, elegant, minimalist) and color scheme
- **Full-size preview** before applying
- **One-click application** to your current design

Templates cover a wide range of styles suitable for academic institutions, corporate training, professional development, and more.

---

## AI Template Generator

Generate complete certificate layouts using artificial intelligence. Simply describe what you want in plain language, and the AI will create a fully designed certificate template.

### Supported Providers

| Provider | Models |
|----------|--------|
| **OpenAI** | GPT-4, GPT-4o, GPT-4o-mini, and others |
| **Anthropic** | Claude models |

### How to Use

1. Configure your AI provider and API key in the plugin admin settings.
2. Open the certificate editor and click the **AI Generate** button.
3. Describe your desired certificate (e.g., "A modern, minimalist certificate with a blue color scheme for a data science course").
4. Review and apply the generated design.
5. Fine-tune with the visual editor as needed.

---

## Approval Workflow

The optional approval workflow adds a review step before certificates are issued:

1. **Student requests** a certificate from the activity page.
2. **Teacher is notified** (if enabled) and reviews the request in the approvals management panel.
3. **Teacher approves or rejects** the request.
4. **Student is notified** (if enabled) of the outcome.
5. On approval, the student can download their certificate.

Approval can be enabled globally (as default for new activities) or per activity instance.

---

## Certificate Verification

Certificate Studio provides a robust verification system:

- Each issued certificate receives a **unique verification code**.
- A **QR code** can be embedded directly on the certificate, linking to the verification page.
- The **showcase/verification page** allows anyone (or only logged-in users, depending on settings) to verify a certificate by entering its code.
- Administrators can configure a **custom verification URL** for use with external verification portals.

---

## Email Notifications

The plugin supports comprehensive email notifications throughout the certificate lifecycle:

| Event | Recipients | Template |
|-------|-----------|----------|
| Certificate requested | Teachers | Approval request template |
| Certificate approved | Students | Approved template |
| Certificate rejected | Students | Rejected template |
| Certificate issued | Students, Teachers, Custom | Issued template |
| Certificate revoked | Students | Revoked template |
| Certificate re-issued | Students | Re-issued template |

All templates support placeholders for dynamic content and can be customized from the admin settings.

---

## Template Import & Export

Certificate Studio supports full template portability:

- **Export**: Save any template as a JSON file with all images embedded as base64 data.
- **Import**: Load a previously exported template into any Certificate Studio instance.
- **Share**: Use the admin template management page to share templates across courses site-wide.

This makes it easy to standardize certificate designs across departments, share designs between Moodle instances, or create a library of reusable templates.

---

## Migration from Custom Certificate

If you are currently using `mod_customcert` (Custom Certificate), Certificate Studio includes a built-in migration tool:

1. Navigate to **Site administration > Plugins > Activity modules > Certificate Studio**.
2. Click the **Migration Tool** link in the settings page.
3. Follow the on-screen instructions to migrate your existing custom certificates.

> **Note**: Always back up your Moodle database before running migrations.

---

## Reports & Analytics

Access certificate reports and analytics from the admin settings page:

- View issuance statistics across the site
- Track certificates by course, student, and date
- Monitor approval workflow metrics
- Export report data

Teachers with the `mod/certstudio:viewreport` capability can access reports for their courses.

---

## API & Integration

### Web Services

Certificate Studio exposes the following web service functions:

| Function | Type | Description |
|----------|------|-------------|
| `mod_certstudio_delete_issue` | Write | Delete an issued certificate (AJAX-enabled, Mobile service) |
| `mod_certstudio_list_issues` | Read | List issued certificates (requires `viewallcertificates` capability) |

### Events

The plugin fires 13 events for integration with Moodle's event system, logging, and third-party plugins:

| Event | Description |
|-------|-------------|
| `certificate_issued` | A certificate was issued to a student |
| `certificate_revoked` | An issued certificate was revoked |
| `certificate_requested` | A student requested a certificate |
| `certificate_approved` | A certificate request was approved |
| `certificate_rejected` | A certificate request was rejected |
| `approval_requested` | An approval workflow request was submitted |
| `approval_approved` | An approval was granted |
| `approval_rejected` | An approval was denied |
| `template_created` | A new template was created |
| `template_updated` | A template was modified |
| `template_deleted` | A template was deleted |
| `page_created` | A new page was added to a certificate |
| `page_deleted` | A page was removed from a certificate |

### Background Tasks

The plugin has no scheduled tasks. When a certificate is issued, the ad hoc task `\mod_certstudio\task\email_certificate_task` is queued to email the teachers and other recipients, so cron must be running for these emails to be sent.

### Capabilities

| Capability | Default Roles |
|------------|---------------|
| `mod/certstudio:addinstance` | Editing Teacher, Manager |
| `mod/certstudio:view` | Student, Teacher, Editing Teacher, Manager |
| `mod/certstudio:manage` | Editing Teacher, Manager |
| `mod/certstudio:approvecertificate` | Teacher, Editing Teacher, Manager |
| `mod/certstudio:viewallcertificates` | Teacher, Editing Teacher, Manager |
| `mod/certstudio:manageemailstudents` | Editing Teacher, Manager |
| `mod/certstudio:manageprotection` | Editing Teacher, Manager |
| `mod/certstudio:managetemplates` | Editing Teacher, Manager |
| `mod/certstudio:viewreport` | Teacher, Editing Teacher, Manager |
| `mod/certstudio:revokecertificate` | Editing Teacher, Manager |
| `mod/certstudio:verifycertificate` | Guest, Student, Teacher, Editing Teacher, Manager |
| `mod/certstudio:receiveissue` | Student |

---

## Supported Languages

Certificate Studio is available in **11 languages**:

| Language | Code |
|----------|------|
| English | `en` |
| Greek | `el` |
| Spanish | `es` |
| French | `fr` |
| German | `de` |
| Portuguese (Brazil) | `pt_br` |
| Italian | `it` |
| Dutch | `nl` |
| Polish | `pl` |
| Turkish | `tr` |
| Russian | `ru` |

Community contributions for additional languages are welcome.

---

## Privacy & GDPR

Certificate Studio fully implements Moodle's **Privacy API** (GDPR compliance):

- Declares all stored personal data
- Supports data export requests
- Supports data deletion requests
- Properly categorizes data storage contexts

---

## Backup & Restore

The plugin integrates with Moodle's standard **backup and restore** system:

- All certificate activity settings are included in course backups
- Templates, issued certificates, and approval records are preserved
- Restore works correctly for both same-site and cross-site restores

---

## Troubleshooting

### Common Issues

**Certificates are not being auto-issued**
- Verify that course completion is properly configured. Moodle marks courses as complete from cron, so cron must be running.
- Check that the student meets the activity's access restrictions and required time in course.
- Check that the "Auto-issue" setting is enabled for the activity.

**PDF preview is blank**
- Ensure the template has at least one element placed on the canvas.
- Check PHP error logs for TCPDF-related issues.

**AI generation is not working**
- Verify your API key is correctly entered in the admin settings.
- Ensure your server can make outbound HTTPS requests to the AI provider's API.
- Check that the selected model is available on your API plan.

---

## License

Certificate Studio is licensed under the [GNU General Public License v3.0](http://www.gnu.org/copyleft/gpl.html) or later.

```
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
```

---

## Credits

**Certificate Studio** is developed and maintained by **[Letstudy Group](https://plugins.letstudy.gr)**.

- Website: [https://plugins.letstudy.gr](https://plugins.letstudy.gr)
- Plugin page: [mod_certstudio](https://plugins.letstudy.gr)

### Based on Custom certificate (mod_customcert)

Certificate Studio is based on [Custom certificate (mod_customcert)](https://github.com/mdjnelson/moodle-mod_customcert) by Mark Nelson and its contributors, which is licensed under the GNU GPL v3 or later. The activity module structure, database schema, element types, backup and restore, privacy provider, events, capabilities, web services and part of the language strings come from mod_customcert. The files based on mod_customcert keep their original copyright notices next to ours.

Many thanks to Mark Nelson and all the contributors of mod_customcert.

---

*Certificate Studio -- Professional certificate design, made simple.*
