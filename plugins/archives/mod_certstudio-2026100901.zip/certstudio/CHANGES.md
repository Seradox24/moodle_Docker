# Certificate Studio - Release Notes

## v1.0.1 (2026-10-12)

### Security
- Students could get a certificate without meeting the activity's rules. The "Get certificate" action and the `mod_certstudio_issue_cert` web service (used by the mobile app) did not check the approval workflow, the required time in course or whether the student's certificate had been revoked. Both now apply the same rules as the activity page.
- Teachers could approve or reject approval requests that belong to other courses. Requests are now checked against the activity.
- Teachers could change or delete the certificate designs of other courses, and of the site gallery, through the editor's web services. Changes are now limited to the activity's own design.
- Text, fonts, colours and image addresses in a design could run scripts in the editor of any teacher who opened that design. The editor preview now escapes them.
- The User field element could print any column of the user record, including the password hash. It now prints identity fields only, plus custom profile fields that teachers can already see.
- PDFs generated on the server could embed files from any course, such as assignment submissions, and fetch addresses on the server's own network. They now use only the plugin's own images; external images are downloaded by Moodle, which applies the site's blocked hosts.
- Uploads accepted any file type and size. Only PNG, JPEG, GIF and WebP images within the upload limit are accepted now.
- A grade hidden from students appeared on their certificate.
- The AI API key was written in plain text to the config changes report.
- Group mode was offered but never applied, so teachers in separate groups saw each other's students. The setting is removed until groups are supported.

### Fixed
- **Certificates issued to every enrolled user.** When any email setting was on, the "Issue certificates and send emails" scheduled task issued a certificate every 5 minutes to every enrolled user of every Certificate Studio activity, ignoring course completion, access restrictions, the approval workflow and suspended enrolments. The task has been removed:
  - The email settings now only control notifications, as their descriptions say.
  - Certificates are issued automatically only by "Auto-issue on course completion".
  - Teachers and other recipients are emailed when a certificate is issued.
- Bulk issue failed with an HTTP 500 error on every request. It now also issues only to the users it lists: students with an active enrolment who can receive a certificate.
- Approving a request now issues the certificate straight away, instead of when the student next opens the activity.
- Auto-issue on course completion now respects access restrictions and the required time in course.
- Students no longer receive two emails for one certificate.
- No emails are sent for certificates revoked or deleted before the email went out.
- The release package no longer contains the legacy `ajax.php`, which the External Services API replaced.
- The "Student must view this activity" completion condition was never met. Viewing the activity now completes it.
- The certificates report failed on PostgreSQL and SQL Server. It now works on every database Moodle supports.
- Migrating from Custom certificate created the new activity in the first section, visible to everyone and without the original's access restrictions. It is now placed right after the original activity, with the same visibility, access restrictions, completion and group settings.
- Bulk issue no longer offers a new certificate to students whose certificate was revoked; use Reissue for them.
- Reissued certificates now show as emailed once the student has been notified.
- Installing the plugin no longer writes files into the plugin's own directory.
- File upload fields in the editor and the template import page were unstyled.
- Fixed a fatal error when the approval table class was loaded, and warnings on PHP 8.4.
- On Moodle 5.3, the Previous/Next activity footer no longer overlaps the full-screen editor.
- The plugin's styles hid the header and stopped scrolling on every popup page of the site, such as quiz comments and overrides, question preview and the report builder. They now apply to the certificate editor only.
- PDFs generated on the server (email attachments, ZIP export, mobile app) printed Greek and other non-Latin text as "?", and failed for designs using Noto or GFS Didot fonts.
- Fresh installs did not store the page background colour.
- Element settings changed after reopening the editor, such as an uploaded image, a signature, a border or a user field name, were lost.
- Restoring or copying a course with user data on the same site failed.
- Choosing a template or starting from scratch could delete a design that another activity or the gallery still used. The gallery now also asks before replacing an activity's design.
- Saving the activity settings could bring back a design that had been replaced.
- A course module could stay stuck in "deletion in progress".
- Course reset kept approved requests, which then issued certificates again.
- Reissuing from an older version could leave a student with two active certificates.
- The certificate list showed "[[expired]]", and some error messages were missing.
- The Date range element printed nothing, or "{Start - End}" on the certificate downloaded from the activity page. It now prints the course start and end dates, in the format chosen in its new "Date format" setting.
- The Expiry date element printed nothing, or "{Expiry Date}". It now prints the certificate's expiry date, in the chosen date format, and nothing for a certificate that does not expire.
- The Grade item name element printed nothing. The Grade and Grade item name elements now have a "Grade item" setting: the course total, by default, or any grade item of the course.
- The Date and Greek date elements printed the date of each download instead of the issue date, so a certificate showed a different date every time it was downloaded. The Date element also ignored its "Date format" setting, which is now a list of formats.
- Dates on a certificate now use the student's time zone, so the certificate reads the same whoever downloads it.
- The Course field element had no setting for the field to print. It now offers the course full name, short name, ID number, start date and end date, and the custom course fields that everyone can see.
- User field and Course field elements migrated from Custom certificate printed nothing. Existing migrated designs work without changes.

### Credits
- Certificate Studio is based on Custom certificate (mod_customcert) by Mark Nelson and its contributors. The original mod_customcert copyright notices are restored in the files based on it, next to ours, and the README now credits mod_customcert.

### Upgrade notes
- Certificate Studio supports Moodle 4.5 LTS to 5.3 LTS, tested on each. Version 1.0.0 could not be installed on 4.5, because its element plugins required Moodle 5.0.
- Group mode is no longer offered for Certificate Studio activities.
- Image uploads are limited to PNG, JPEG, GIF and WebP. Images already uploaded are not changed.
- If you relied on the email settings to issue certificates to everyone, enable "Auto-issue on course completion" or use Bulk issue instead.
- Certificates already issued are not changed. If you had an email setting enabled, review the certificates listed in each activity.
- To stop a student from getting a certificate again, revoke it rather than deleting it.

## v1.0.0 (2026-03-08)

### Initial Release

**Visual Certificate Editor**
- Drag-and-drop certificate designer with live preview
- 21 element types: text, student name, course name, category, teacher name, date, date range, expiry, localized date, grade, grade item, user field, course field, statement, image, background image, user picture, digital signature, border, QR code, verification code
- Real-time property editing (font, size, color, alignment, opacity, rotation)
- Autosave with countdown timer
- Undo/redo support
- Grid and alignment guides
- Multi-page certificate support

**Template System**
- 40+ built-in professional SVG background templates
- Template gallery with search, style/color filters, and live preview
- AI-powered template generation (OpenAI GPT-4 / Anthropic Claude)
- Template import/export as JSON with base64 embedded assets
- Template sharing across courses

**Certificate Management**
- Certificate verification with QR codes and verification codes
- Public verification/showcase page
- Approval workflow (request, approve, reject) with email notifications
- Auto-issue on course completion
- Bulk certificate issuance
- Certificate revocation and re-issuance
- PDF protection (print, modify, copy restrictions)
- Custom download filenames with placeholders

**Integration**
- Migration tool from mod_customcert
- Moodle Mobile app support
- Web services API
- Event system (13 events)
- Scheduled tasks for auto-issuance and email delivery
- GDPR/Privacy API compliance
- Backup and restore support
- Global search integration

**Languages**
- English, Greek, Spanish, French, German, Brazilian Portuguese, Italian, Dutch, Polish, Turkish, Russian

**Administration**
- Configurable email notifications (students, teachers, custom recipients)
- Customizable message templates (approval, issued, revoked, re-issued)
- Report and analytics dashboard
- Template management page
