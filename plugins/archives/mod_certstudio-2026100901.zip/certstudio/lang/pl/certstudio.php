<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Polish language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Poziomy';
$string['actions'] = 'Akcje';
$string['actionsheading'] = 'Akcje';
$string['active'] = 'Aktywny';
$string['activities'] = 'Aktywności';
$string['aiapikey'] = 'Klucz API';
$string['aiapikey_desc'] = 'Twój klucz API dla wybranego dostawcy AI. Uzyskaj go od OpenAI lub Anthropic.';
$string['aierror'] = 'Błąd generowania AI: {$a}';
$string['aigeneratebutton'] = 'Generuj';
$string['aigeneratedesc'] = 'Opisz certyfikat, który chcesz utworzyć, a AI wygeneruje dla Ciebie szablon.';
$string['aigenerateplaceholder'] = 'np. formalny niebieski certyfikat dla kursu IT ze złotą ramką...';
$string['aigeneratesuccess'] = 'Szablon wygenerowany pomyślnie! Przekierowanie do edytora...';
$string['aigeneratetitle'] = 'Generator szablonów AI';
$string['aigenerating'] = 'Generowanie szablonu za pomocą AI...';
$string['aimodel'] = 'Model';
$string['aimodel_desc'] = 'Model AI do użycia. Dla OpenAI: gpt-4o-mini, gpt-4o. Dla Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'Klucz API AI nie jest skonfigurowany. Ustaw go w ustawieniach wtyczki.';
$string['aiparseerror'] = 'Nie udało się przetworzyć odpowiedzi AI. Spróbuj ponownie z innym opisem.';
$string['aiprovider'] = 'Dostawca AI';
$string['aiprovider_desc'] = 'Wybierz usługę AI do generowania szablonów.';
$string['aisettings'] = 'Generator szablonów AI';
$string['aisettings_desc'] = 'Konfiguracja automatycznego generowania szablonów z użyciem AI. Wymaga klucza API od OpenAI lub Anthropic.';
$string['aligncenter'] = 'Wyśrodkuj';
$string['alignleft'] = 'Do lewej';
$string['alignright'] = 'Do prawej';
$string['all'] = 'Wszystkie';
$string['allcolors'] = 'Wszystkie kolory';
$string['allstyles'] = 'Wszystkie style';
$string['alltemplates'] = 'Wszystkie szablony';
$string['appearance'] = 'Wygląd';
$string['apply'] = 'Zastosuj';
$string['approval'] = 'Proces zatwierdzania';
$string['approvalenabled'] = 'Włącz proces zatwierdzania';
$string['approvalenabled_desc'] = 'Domyślnie włączaj proces zatwierdzania dla nowych aktywności.';
$string['approvalenabled_help'] = 'Po włączeniu studenci muszą poprosić nauczyciela o zatwierdzenie certyfikatu przed jego pobraniem.';
$string['approvalnotifystudent'] = 'Powiadom studenta o wyniku';
$string['approvalnotifystudent_desc'] = 'Wyślij powiadomienie do studentów, gdy ich wniosek zostanie zatwierdzony lub odrzucony.';
$string['approvalnotifyteacher'] = 'Powiadom nauczyciela o wniosku';
$string['approvalnotifyteacher_desc'] = 'Wyślij powiadomienie do nauczycieli, gdy student złoży wniosek o certyfikat.';
$string['approvalrequestbody'] = '{$a->student} złożył/a wniosek o certyfikat dla „{$a->activity}".';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> złożył/a wniosek o certyfikat dla „<strong>{$a->activity}</strong>".</p><p><a href="{$a->url}">Przejrzyj wnioski o zatwierdzenie</a></p>';
$string['approvalrequestexists'] = 'Masz już oczekujący wniosek o zatwierdzenie.';
$string['approvalrequestnotfound'] = 'Nie znaleziono wniosku o zatwierdzenie.';
$string['approvalrequestnotpending'] = 'Ten wniosek o zatwierdzenie nie jest już oczekujący.';
$string['approvalrequests'] = 'Wnioski o zatwierdzenie';
$string['approvalrequestsmall'] = 'Nowy wniosek o certyfikat od {$a}';
$string['approvalrequestsubject'] = 'Wniosek o zatwierdzenie certyfikatu: {$a}';
$string['approvalrequesttemplate'] = 'Powiadomienie o wniosku (do nauczyciela)';
$string['approvalrequesttemplate_desc'] = 'Wiadomość wysyłana do nauczycieli, gdy student złoży wniosek o zatwierdzenie certyfikatu.';
$string['approvalresultbody'] = 'Twój wniosek o certyfikat dla „{$a->activity}" został {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Twój wniosek o certyfikat dla „<strong>{$a->activity}</strong>" został <strong>{$a->status}</strong>.</p><p>Recenzent: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Wyświetl certyfikat</a></p>';
$string['approvalresultsmall'] = 'Wniosek o certyfikat {$a}';
$string['approvalresultsubject'] = 'Wniosek o certyfikat {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Ustawienia zatwierdzania';
$string['approve'] = 'Zatwierdź';
$string['approved'] = 'zatwierdzony';
$string['approvedtemplate'] = 'Powiadomienie o zatwierdzeniu (do studenta)';
$string['approvedtemplate_desc'] = 'Wiadomość wysyłana do studenta, gdy jego wniosek zostanie zatwierdzony.';
$string['autoissue'] = 'Automatyczne wydawanie po ukończeniu kursu';
$string['autoissue_desc'] = 'Automatycznie wydawaj certyfikaty, gdy student ukończy kurs. Wymaga włączenia śledzenia ukończenia kursu. Nie dotyczy aktywności z procesem zatwierdzania.';
$string['back'] = 'Wstecz';
$string['backtoview'] = 'Wstecz';
$string['batchdownload'] = 'Pobierz wszystko jako ZIP';
$string['bgcolor'] = 'Kolor tła';
$string['bgimage'] = 'Obraz tła';
$string['bgimageopacity'] = 'Przezroczystość obrazu tła';
$string['bgimagesize'] = 'Rozmiar obrazu tła';
$string['bgimagesizeactual'] = 'Rzeczywisty rozmiar';
$string['bgimagesizecontain'] = 'Dopasuj (zmieść wewnątrz)';
$string['bgimagesizecover'] = 'Pokryj (wypełnij stronę)';
$string['bgimagesizestretch'] = 'Rozciągnij';
$string['bold'] = 'Pogrubienie';
$string['bordercolor'] = 'Kolor ramki';
$string['borderstyle'] = 'Styl ramki';
$string['borderwidth'] = 'Szerokość ramki';
$string['builtin'] = 'Wbudowane';
$string['builtintemplates'] = 'Szablony wbudowane';
$string['bulkactions'] = 'Operacje zbiorcze';
$string['bulkdelete'] = 'Usuń zaznaczone';
$string['bulkemail'] = 'Wyślij e-mail do zaznaczonych';
$string['bulkissue'] = 'Wydanie masowe';
$string['bulkissuealreadyissued'] = '{$a} student(ów) posiada już certyfikat (pominięto)';
$string['bulkissuecomplete'] = 'Pomyślnie wydano {$a} certyfikat(ów).';
$string['bulkissuedefaultmessage'] = 'Szanowny/a {studentname},

Gratulacje! Twój certyfikat „{certname}" w kursie „{coursename}" został wydany.

Możesz go pobrać tutaj: {url}

Z poważaniem';
$string['bulkissuedesc'] = 'Wydaj certyfikaty wszystkim uprawnionym zapisanym studentom, którzy jeszcze ich nie otrzymali.';
$string['bulkissuenoeligible'] = 'Wszyscy zapisani studenci otrzymali już certyfikat.';
$string['bulkissuenoselection'] = 'Nie wybrano żadnych studentów.';
$string['bulkissuenotified'] = 'Powiadomiono {$a} studenta(ów).';
$string['bulkissuenotify'] = 'Powiadom studentów';
$string['bulkissuenotifyemail'] = 'Wyślij powiadomienie e-mailem';
$string['bulkissuenotifymessage'] = 'Treść powiadomienia';
$string['bulkissuenotifymoodle'] = 'Wyślij powiadomienie przez Moodle';
$string['bulkissuenotifyplaceholders'] = 'Dostępne zmienne: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Twój certyfikat dla {$a} został wydany.';
$string['bulkissuenotifysubject'] = 'Twój certyfikat został wydany: {$a}';
$string['bulkissuesubmit'] = 'Wydaj certyfikaty dla {$a} studenta(ów)';
$string['bulkoperationcomplete'] = 'Przetworzono {$a->count} certyfikat(ów): {$a->action}.';
$string['bulkreissue'] = 'Wydaj ponownie zaznaczone';
$string['bulkrevoke'] = 'Unieważnij zaznaczone';
$string['certificate'] = 'Certyfikat';
$string['certificateexpired'] = 'Ten certyfikat wygasł dnia {$a}.';
$string['certificateexpiredverify'] = 'Ten certyfikat wygasł';
$string['certificateexpires'] = 'Ten certyfikat wygasa dnia {$a}.';
$string['certificateinvalid'] = 'Ten certyfikat jest nieważny';
$string['certificateissued'] = 'Twój certyfikat został wydany dnia {$a}.';
$string['certificatenotfound'] = 'Nie znaleziono certyfikatu z tym kodem weryfikacyjnym.';
$string['certificaterevoked'] = 'Ten certyfikat został unieważniony';
$string['certificaterevokedstudent'] = 'Twój certyfikat został unieważniony. Skontaktuj się z nauczycielem lub administratorem, aby uzyskać więcej informacji.';
$string['certificatevalid'] = 'Ten certyfikat jest ważny';
$string['certificateversion'] = 'To jest wersja {$a} Twojego certyfikatu (odnowiony).';
$string['certstudio:addinstance'] = 'Dodaj aktywność Certificate Studio';
$string['certstudio:approvecertificate'] = 'Zatwierdzaj wnioski o certyfikaty';
$string['certstudio:manage'] = 'Zarządzaj szablonami certyfikatów';
$string['certstudio:manageemailstudents'] = 'Zarządzaj ustawieniami powiadomień e-mail';
$string['certstudio:manageprotection'] = 'Zarządzaj ustawieniami ochrony PDF';
$string['certstudio:managetemplates'] = 'Zarządzaj szablonami certyfikatów';
$string['certstudio:receiveissue'] = 'Otrzymaj certyfikat';
$string['certstudio:revokecertificate'] = 'Unieważniaj wydane certyfikaty';
$string['certstudio:verifycertificate'] = 'Weryfikuj kody certyfikatów';
$string['certstudio:view'] = 'Wyświetl certyfikat';
$string['certstudio:viewallcertificates'] = 'Wyświetl wszystkie wydane certyfikaty';
$string['certstudio:viewreport'] = 'Wyświetl raporty i analizy certyfikatów';
$string['city'] = 'Miasto';
$string['clearbg'] = 'Wyczyść tło';
$string['clicktorenametemplate'] = 'Kliknij, aby zmienić nazwę szablonu';
$string['codegenerationmethod'] = 'Metoda generowania kodów';
$string['codegenerationmethod_desc'] = 'Wybierz jedną z dwóch metod generowania kodów weryfikacyjnych certyfikatów.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Cyfry z myślnikami)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Losowy ciąg wielkich/małych liter i cyfr)';
$string['color'] = 'Kolor';
$string['colorblue'] = 'Niebieski';
$string['colordark'] = 'Ciemny';
$string['colorgold'] = 'Złoty';
$string['colorgray'] = 'Szary';
$string['colorgreen'] = 'Zielony';
$string['colorpink'] = 'Różowy';
$string['colorpurple'] = 'Fioletowy';
$string['colorred'] = 'Czerwony';
$string['comment'] = 'Komentarz';
$string['confirmbulk'] = 'Czy na pewno chcesz wykonać tę operację zbiorczą na wybranych certyfikatach?';
$string['confirmdelete'] = 'Czy na pewno chcesz usunąć ten szablon? Tej operacji nie można cofnąć.';
$string['confirmdeleteissue'] = 'Czy na pewno chcesz trwale usunąć ten rekord certyfikatu?';
$string['confirmrevoke'] = 'Czy na pewno chcesz unieważnić ten certyfikat? Strona weryfikacji będzie go wyświetlać jako unieważniony.';
$string['copy'] = 'Kopiuj';
$string['course'] = 'Kurs';
$string['createblank'] = 'Pusty certyfikat';
$string['createblankdesc'] = 'Zacznij z pustym płótnem';
$string['created'] = 'Utworzono';
$string['createtemplate'] = '-- Utwórz nowy szablon --';
$string['current'] = 'Bieżący';
$string['currenttemplate'] = 'Bieżący szablon';
$string['custom'] = 'Niestandardowy';
$string['customsource'] = 'Własne';
$string['customtemplates'] = 'Szablony własne';
$string['dateformat'] = 'Format daty';
$string['dateissued'] = 'Data wydania';
$string['daterequested'] = 'Data złożenia wniosku';
$string['defaultfilename'] = 'Domyślna nazwa pliku PDF';
$string['defaultfilename_desc'] = 'Domyślny wzorzec nazwy pliku pobieranych plików PDF. Zmienne: {coursename}, {studentname}, {date}, {activityname}. Można nadpisać w ustawieniach aktywności.';
$string['defaultprotection'] = 'Domyślna ochrona PDF';
$string['defaultprotection_desc'] = 'Domyślne flagi ochrony PDF (rozdzielone przecinkami): print, modify, copy. Można nadpisać w ustawieniach aktywności.';
$string['defaultvalues'] = 'Wartości domyślne ustawień aktywności';
$string['defaultvalues_desc'] = 'Wartości domyślne są używane w formularzu ustawień podczas tworzenia nowej aktywności.';
$string['delete'] = 'Usuń';
$string['deleteissuedcertificates'] = 'Usuń wydane certyfikaty';
$string['downloadcertificate'] = 'Pobierz certyfikat';
$string['downloadfilename'] = 'Nazwa pliku PDF';
$string['downloadfilename_help'] = 'Niestandardowa nazwa pliku pobranego certyfikatu PDF. Możesz użyć zmiennych: {coursename}, {studentname}, {date}. Pozostaw puste, aby użyć nazwy aktywności. Przykład: Certyfikat_{coursename}_{studentname}';
$string['downloadsettings'] = 'Ustawienia pobierania';
$string['editcertstudio'] = 'Edytuj certyfikat';
$string['edittemplate'] = 'Edytuj szablon';
$string['elementcount'] = '{$a} elementów';
$string['elementname'] = 'Nazwa elementu';
$string['elements'] = 'Elementy';
$string['elementtype_bgimage'] = 'Obraz tła';
$string['elementtype_border'] = 'Ramka';
$string['elementtype_categoryname'] = 'Nazwa kategorii';
$string['elementtype_certdate'] = 'Data grecka';
$string['elementtype_certstatement'] = 'Oświadczenie greckie';
$string['elementtype_code'] = 'Kod weryfikacyjny';
$string['elementtype_coursefield'] = 'Pole kursu';
$string['elementtype_coursename'] = 'Nazwa kursu';
$string['elementtype_date'] = 'Data';
$string['elementtype_daterange'] = 'Zakres dat';
$string['elementtype_digitalsignature'] = 'Podpis cyfrowy';
$string['elementtype_expiry'] = 'Data wygaśnięcia';
$string['elementtype_grade'] = 'Ocena';
$string['elementtype_gradeitemname'] = 'Nazwa elementu oceny';
$string['elementtype_image'] = 'Obraz';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Imię i nazwisko studenta';
$string['elementtype_teachername'] = 'Imię i nazwisko nauczyciela';
$string['elementtype_text'] = 'Tekst';
$string['elementtype_userfield'] = 'Pole użytkownika';
$string['elementtype_userpicture'] = 'Zdjęcie użytkownika';
$string['emailcertbody'] = 'Szanowny/a {$a->studentname},

Twój certyfikat „{$a->certname}" w kursie „{$a->coursename}" jest załączony do tej wiadomości.

Kod weryfikacyjny: {$a->code}
Weryfikuj online: {$a->verifyurl}

Z poważaniem';
$string['emailcertificate'] = 'Wyślij certyfikat e-mailem';
$string['emailcertificatebody'] = 'Szanowny/a {$a->fullname},

Twój certyfikat „{$a->certname}" w kursie „{$a->coursename}" został wydany.

Możesz go zweryfikować za pomocą kodu: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Twój certyfikat dla {$a}';
$string['emailcertsubject'] = 'Twój certyfikat: {$a}';
$string['emailcerttemplate'] = 'Powiadomienie e-mail z certyfikatem';
$string['emailcerttemplate_default'] = 'Szanowny/a {studentname},

Twój certyfikat „{certname}" w kursie „{coursename}" jest załączony do tej wiadomości.

Kod weryfikacyjny: {code}
Weryfikuj online: {verifyurl}

Z poważaniem';
$string['emailcerttemplate_desc'] = 'Treść wiadomości e-mail z certyfikatem PDF w załączniku. Zmienne: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Wysyłaj e-mail do innych';
$string['emailothers_desc'] = 'Adresy e-mail rozdzielone przecinkami, które otrzymają kopię certyfikatu, gdy będzie dostępny.';
$string['emailsent'] = 'Certyfikat wysłany e-mailem pomyślnie.';
$string['emailsettings'] = 'Powiadomienia e-mail';
$string['emailstudents'] = 'Wysyłaj e-mail do studentów';
$string['emailstudents_desc'] = 'Jeśli włączone, studenci otrzymają kopię certyfikatu e-mailem, gdy będzie dostępny.';
$string['emailteacherbody'] = 'Certyfikat „{$a->certname}" został wydany użytkownikowi {$a->fullname} w kursie „{$a->coursename}".';
$string['emailteachers'] = 'Wysyłaj e-mail do nauczycieli';
$string['emailteachers_desc'] = 'Jeśli włączone, nauczyciele otrzymają kopię certyfikatu e-mailem, gdy będzie dostępny.';
$string['emailteachersubject'] = 'Wydano certyfikat: {$a->certname}';
$string['entercode'] = 'Wprowadź kod weryfikacyjny';
$string['eventcertificateapproved'] = 'Certyfikat zatwierdzony';
$string['eventcertificateissued'] = 'Certyfikat wydany';
$string['eventcertificaterejected'] = 'Certyfikat odrzucony';
$string['eventcertificaterequested'] = 'Złożono wniosek o certyfikat';
$string['eventcertificaterevoked'] = 'Certyfikat unieważniony';
$string['eventpagecreated'] = 'Strona utworzona';
$string['eventpagedeleted'] = 'Strona usunięta';
$string['eventtemplatecreated'] = 'Szablon utworzony';
$string['eventtemplatedeleted'] = 'Szablon usunięty';
$string['eventtemplateupdated'] = 'Szablon zaktualizowany';
$string['expired'] = 'Wygasły';
$string['expiredon'] = 'Wygasł dnia';
$string['expirydate'] = 'Data wygaśnięcia';
$string['expirydays'] = 'Ważność certyfikatu (dni)';
$string['expirydays_help'] = 'Liczba dni ważności certyfikatu od daty wydania. Ustaw 0, aby certyfikat nie wygasał.';
$string['expiryperiod'] = 'Okres ważności (dni)';
$string['expirysettings'] = 'Ustawienia wygasania';
$string['exportcsv'] = 'Eksportuj CSV';
$string['exportods'] = 'Eksportuj ODS';
$string['exporttemplate'] = 'Eksportuj szablon';
$string['exportxlsx'] = 'Eksportuj XLSX';
$string['fieldname'] = 'Nazwa pola';
$string['font'] = 'Czcionka';
$string['fontsize'] = 'Rozmiar czcionki';
$string['gallerydescription'] = 'Wybierz szablon, od którego chcesz zacząć, lub stwórz własny od podstaw';
$string['generalsettings'] = 'Ustawienia ogólne';
$string['getcertificate'] = 'Pobierz certyfikat';
$string['gradeitem'] = 'Element oceny';
$string['height'] = 'Wysokość';
$string['importtemplate'] = 'Importuj szablon';
$string['invalidaction'] = 'Nieprawidłowa akcja';
$string['invalidelementdata'] = 'Nieprawidłowe dane elementu';
$string['invalidfilearea'] = 'Nieprawidłowy obszar plików';
$string['issuedcertificates'] = 'Wydane certyfikaty';
$string['issuedcount'] = 'Wydano {$a} certyfikat(ów)';
$string['issuedtemplate'] = 'Powiadomienie o wydaniu certyfikatu';
$string['issuedtemplate_default'] = 'Szanowny/a {studentname},

Gratulacje! Twój certyfikat „{certname}" w kursie „{coursename}" został wydany.

Możesz go pobrać tutaj: {url}

Kod weryfikacyjny: {code}

Z poważaniem';
$string['issuedtemplate_desc'] = 'Wiadomość wysyłana do studenta po wydaniu certyfikatu. Zmienne: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Nie znaleziono wydanego certyfikatu';
$string['italic'] = 'Kursywa';
$string['landscape'] = 'Poziomo';
$string['layers'] = 'Warstwy';
$string['loading'] = 'Ładowanie...';
$string['lock'] = 'Zablokuj';
$string['manageapprovals'] = 'Zarządzaj zatwierdzeniami';
$string['managetemplates'] = 'Zarządzaj szablonami';
$string['managetemplates_desc'] = 'Wyświetlaj, eksportuj, importuj i usuwaj szablony. Zarządzaj wszystkimi wbudowanymi i niestandardowymi szablonami z jednego miejsca.';
$string['messageprovider:approval_request'] = 'Wniosek o zatwierdzenie certyfikatu';
$string['messageprovider:approval_result'] = 'Wynik zatwierdzenia certyfikatu';
$string['messagetemplates'] = 'Szablony wiadomości';
$string['messagetemplates_desc'] = 'Dostosuj treść powiadomień. Zmienne: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Migruj aktywności (moduły kursów)';
$string['migrateissues'] = 'Migruj wydane certyfikaty';
$string['migratetemplates'] = 'Migruj szablony (strony i elementy)';
$string['migrationcomplete'] = 'Migracja zakończona: zmigrowano {$a->templates} szablon(ów), {$a->activities} aktywność(i), {$a->issues} certyfikat(ów).';
$string['migrationlog'] = 'Dziennik migracji';
$string['migrationnodata'] = 'Nie znaleziono danych customcert do migracji.';
$string['migrationnotavailable'] = 'Wtyczka Custom Certificate (mod_customcert) nie jest zainstalowana. Brak danych do migracji.';
$string['migrationoptions'] = 'Opcje migracji';
$string['migrationsummary'] = 'Znaleziono dane Custom Certificate';
$string['migrationtool'] = 'Migracja z Custom Certificate';
$string['migrationwarning'] = 'Ta operacja utworzy nowe rekordy certstudio z danych customcert. Istniejące dane customcert NIE zostaną zmodyfikowane ani usunięte. Już zmigrowane elementy zostaną pominięte.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studio';
$string['multilang'] = 'Certyfikaty wielojęzyczne';
$string['multilang_desc'] = 'Wymuś język certyfikatu dla aktywności, nadpisując preferencje użytkownika.';
$string['mycertificates'] = 'Moje certyfikaty';
$string['name'] = 'Nazwa';
$string['nelements'] = '{$a} elementów';
$string['nocertificates'] = 'Nie otrzymałeś/aś jeszcze żadnych certyfikatów.';
$string['nocertificatesissued'] = 'Nie wydano jeszcze żadnego certyfikatu. Ukończ wymagane aktywności, aby otrzymać certyfikat.';
$string['nodata'] = 'Brak dostępnych danych.';
$string['norequests'] = 'Nie znaleziono wniosków o zatwierdzenie.';
$string['notapproved'] = 'Twój certyfikat nie został jeszcze zatwierdzony.';
$string['notemplates'] = 'Nie znaleziono szablonów.';
$string['notemplatesavailable'] = 'Brak dostępnych szablonów. Kliknij "Zacznij od zera", aby utworzyć własny certyfikat.';
$string['notissued'] = 'Nie wydano';
$string['opacity'] = 'Przezroczystość';
$string['optional'] = 'opcjonalne';
$string['pages'] = 'Strony';
$string['pagesettings'] = 'Ustawienia strony';
$string['pagesize'] = 'Rozmiar strony';
$string['pdfsettings'] = 'Ustawienia PDF';
$string['platform'] = 'Platforma';
$string['pluginadministration'] = 'Administracja Certificate Studio';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Pionowo';
$string['positionandsize'] = 'Pozycja i rozmiar';
$string['previewpdf'] = 'Podgląd PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Wnioski o zatwierdzenie certyfikatu.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'Komentarz recenzenta do wniosku.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'Użytkownik, który rozpatrzył wniosek.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'Status zatwierdzenia.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Data złożenia wniosku.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Data ostatniej aktualizacji wniosku.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'Użytkownik, który złożył wniosek o certyfikat.';
$string['privacy:metadata:certstudio_issues'] = 'Rekordy wydanych certyfikatów.';
$string['privacy:metadata:certstudio_issues:code'] = 'Unikalny kod weryfikacyjny.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'Migawka danych szablonu certyfikatu.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Data wydania certyfikatu.';
$string['privacy:metadata:certstudio_issues:userid'] = 'Użytkownik, który otrzymał certyfikat.';
$string['privacy:path:approvalrequests'] = 'Wnioski o zatwierdzenie';
$string['privacy:path:issues'] = 'Wydane certyfikaty';
$string['properties'] = 'Właściwości';
$string['protection'] = 'Ochrona PDF';
$string['protection_copy'] = 'Zablokuj kopiowanie';
$string['protection_copy_desc'] = 'Włącz ochronę przed kopiowaniem.';
$string['protection_modify'] = 'Zablokuj modyfikowanie';
$string['protection_modify_desc'] = 'Włącz ochronę przed modyfikowaniem.';
$string['protection_print'] = 'Zablokuj drukowanie';
$string['protection_print_desc'] = 'Włącz ochronę przed drukowaniem.';
$string['protectionflags'] = 'Flagi ochrony';
$string['protectionflags_help'] = 'Flagi ochrony rozdzielone przecinkami: print, modify, copy';
$string['publishtogallery'] = 'Opublikuj w galerii';
$string['publishtogallerytip'] = 'Opublikuj kopię w galerii szablonów, aby wszystkie kursy mogły z niej korzystać';
$string['reason'] = 'Powód';
$string['receiveddate'] = 'Data otrzymania';
$string['redo'] = 'Ponów';
$string['reissue'] = 'Wydaj ponownie';
$string['reissuedtemplate'] = 'Powiadomienie o ponownym wydaniu certyfikatu';
$string['reissuedtemplate_default'] = 'Szanowny/a {studentname},

Nowa wersja Twojego certyfikatu „{certname}" w kursie „{coursename}" została wydana.

Możesz go pobrać tutaj: {url}

Kod weryfikacyjny: {code}

Z poważaniem';
$string['reissuedtemplate_desc'] = 'Wiadomość wysyłana do studenta po wydaniu nowej wersji certyfikatu. Zmienne: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Odrzuć';
$string['rejected'] = 'odrzucony';
$string['rejectedtemplate'] = 'Powiadomienie o odrzuceniu (do studenta)';
$string['rejectedtemplate_desc'] = 'Wiadomość wysyłana do studenta, gdy jego wniosek zostanie odrzucony.';
$string['reportanalytics'] = 'Analityka certyfikatów';
$string['reportmonthly'] = 'Trend miesięczny (ostatnie 12 miesięcy)';
$string['reportpercourse'] = 'Certyfikaty na kurs';
$string['reportrecent'] = 'Ostatnie certyfikaty (ostatnie 30 dni)';
$string['reporttotalactivities'] = 'Łącznie aktywności';
$string['reporttotalissued'] = 'Łącznie wydanych';
$string['reporttotaltemplates'] = 'Łącznie szablonów';
$string['reportuniquerecipients'] = 'Unikalni odbiorcy';
$string['requestagain'] = 'Złóż nowy wniosek';
$string['requestapproved'] = 'Wniosek zatwierdzony pomyślnie.';
$string['requestcertificate'] = 'Złóż wniosek o certyfikat';
$string['requestpending'] = 'Twój wniosek o certyfikat oczekuje na zatwierdzenie.';
$string['requestrejected'] = 'Twój wniosek o certyfikat został odrzucony.';
$string['requestrejectedmsg'] = 'Wniosek odrzucony pomyślnie.';
$string['requestsubmitted'] = 'Twój wniosek o certyfikat został złożony.';
$string['requiredtime'] = 'Wymagany czas w kursie (minuty)';
$string['requiredtime_desc'] = 'Minimalny czas w minutach, przez jaki student musi być zalogowany w kursie, zanim będzie mógł otrzymać certyfikat. Ustaw 0, aby wyłączyć.';
$string['requiredtimenotmet'] = 'Musisz spędzić co najmniej {$a->required} minut w tym kursie, zanim będziesz mógł otrzymać certyfikat. Do tej pory spędziłeś/aś około {$a->spent} minut.';
$string['returncourse'] = 'Przycisk powrotu do kursu';
$string['returncourse_desc'] = 'Wyświetl przycisk „Wróć do kursu" na stronie wyświetlania certyfikatu.';
$string['returntocourse'] = 'Wróć do kursu';
$string['reviewer'] = 'Recenzent';
$string['revokecertificate'] = 'Unieważnij certyfikat';
$string['revoked'] = 'Unieważniony';
$string['revokeddate'] = 'Unieważniono dnia';
$string['revokedrenewal'] = 'Unieważniony w celu odnowienia (wydano nową wersję)';
$string['revokedtemplate'] = 'Powiadomienie o unieważnieniu certyfikatu';
$string['revokedtemplate_default'] = 'Szanowny/a {studentname},

Twój certyfikat „{certname}" w kursie „{coursename}" został unieważniony.

Powód: {reason}

W razie pytań skontaktuj się ze swoim prowadzącym.

Z poważaniem';
$string['revokedtemplate_desc'] = 'Wiadomość wysyłana do studenta po unieważnieniu certyfikatu. Zmienne: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Obrót';
$string['save'] = 'Zapisz';
$string['savechangestip'] = 'Zapisz zmiany tylko w tej aktywności';
$string['saved'] = 'Zmiany zapisane';
$string['saveerror'] = 'Błąd podczas zapisywania zmian';
$string['savestatussaved'] = 'Zapisano';
$string['searchbyname'] = 'Szukaj po nazwie...';
$string['selectelement'] = 'Kliknij element, aby edytować jego właściwości.';
$string['selecttemplate'] = 'Wybierz szablon';
$string['sharecertificate'] = 'Udostępnij';
$string['shareemailbody'] = 'Chciałem/am podzielić się informacją, że zdobyłem/am certyfikat „{$a->certname}".

Możesz go zweryfikować tutaj: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Mój certyfikat: {$a}';
$string['sharetext'] = 'Właśnie zdobyłem/am certyfikat „{$a}"!';
$string['showcasecourse'] = 'Kurs';
$string['showcasedownloadpdf'] = 'Pobierz PDF';
$string['showcaseissuedon'] = 'Wydano dnia';
$string['showcaserecipient'] = 'Przyznano';
$string['showcaseshare'] = 'Udostępnij ten certyfikat';
$string['showcasetitle'] = 'Certyfikat cyfrowy';
$string['showcaseverified'] = 'Certyfikat zweryfikowany';
$string['showposxy'] = 'Pokaż pozycję X i Y';
$string['showposxy_desc'] = 'Pokaż pozycję X i Y podczas edycji elementu, umożliwiając użytkownikowi dokładne określenie położenia.';
$string['startfromscratch'] = 'Zacznij od podstaw';
$string['startmigration'] = 'Rozpocznij migrację';
$string['status'] = 'Status';
$string['statusapproved'] = 'Zatwierdzony';
$string['statusexpired'] = 'Wygasły';
$string['statuspending'] = 'Oczekujący';
$string['statusrejected'] = 'Odrzucony';
$string['statusrevoked'] = 'Unieważniony';
$string['statusvalid'] = 'Ważny';
$string['student'] = 'Student';
$string['styleclassic'] = 'Klasyczny';
$string['styledark'] = 'Ciemny';
$string['styleelegant'] = 'Elegancki';
$string['stylegradient'] = 'Gradient';
$string['styleminimal'] = 'Minimalistyczny';
$string['stylemodern'] = 'Nowoczesny';
$string['stylespecial'] = 'Specjalny';
$string['subplugintype_certstudioselem'] = 'Typ elementu';
$string['subplugintype_certstudioselem_plural'] = 'Typy elementów';
$string['taskemailcertificate'] = 'Wyślij certyfikat e-mailem';
$string['taskissuecertificate'] = 'Wydawaj certyfikaty i wysyłaj e-maile';
$string['template'] = 'Szablon';
$string['templatedeleted'] = 'Szablon „{$a}" został usunięty.';
$string['templatefile'] = 'Plik szablonu (.json)';
$string['templatefilehelp'] = 'Prześlij plik .certstudio.json wyeksportowany z innej instalacji Certificate Studio.';
$string['templategallery'] = 'Galeria szablonów';
$string['templateimported'] = 'Szablon „{$a->name}" zaimportowany pomyślnie ({$a->pages} stron(a), {$a->elements} element(ów)).';
$string['templateimportinvalid'] = 'Nieprawidłowy plik szablonu. Prześlij prawidłowy plik .certstudio.json.';
$string['templateinuse'] = 'Ten szablon jest używany przez {$a} aktywność(i) i nie może zostać usunięty.';
$string['templatenameplaceholder'] = 'Nazwa szablonu...';
$string['templates'] = 'Szablony';
$string['templatesharing'] = 'Import/eksport szablonów';
$string['textcontent'] = 'Treść tekstowa';
$string['toggleelementspanel'] = 'Pokaż/ukryj panel elementów';
$string['togglegrid'] = 'Przełącz siatkę';
$string['toggleguides'] = 'Przełącz prowadnice';
$string['togglepropertiespanel'] = 'Pokaż/ukryj panel właściwości';
$string['typography'] = 'Typografia';
$string['undo'] = 'Cofnij';
$string['unknowncourse'] = 'Nieznany kurs';
$string['unknownuser'] = 'Nieznany użytkownik';
$string['unlock'] = 'Odblokuj';
$string['uploadbgimage'] = 'Prześlij';
$string['uploadbgimagetip'] = 'Prześlij obraz tła';
$string['usethisTemplate'] = 'Użyj tego szablonu';
$string['usethistemplate'] = 'Użyj tego szablonu';
$string['valid'] = 'Ważny';
$string['verificationcode'] = 'Kod weryfikacyjny';
$string['verify'] = 'Weryfikuj';
$string['verifyallcertificates'] = 'Zezwól na publiczną weryfikację';
$string['verifyallcertificates_desc'] = 'Zezwól każdemu na weryfikację certyfikatów bez logowania.';
$string['verifyanother'] = 'Weryfikuj inny certyfikat';
$string['verifyany'] = 'Zezwól każdemu na weryfikację certyfikatu';
$string['verifyany_desc'] = 'Zezwól każdemu posiadającemu link weryfikacyjny certyfikatu (w tym niezalogowanym użytkownikom) na weryfikację certyfikatu.';
$string['verifycertificate'] = 'Weryfikuj certyfikat';
$string['verifyintro'] = 'Wprowadź kod weryfikacyjny certyfikatu, aby sprawdzić jego autentyczność na {$a}.';
$string['verifylink_desc'] = 'Ten link przeniesie Cię na stronę, na której możesz zweryfikować certyfikaty w serwisie.';
$string['verifynotfound'] = 'Nie znaleziono certyfikatu z tym kodem weryfikacyjnym. Sprawdź i spróbuj ponownie.';
$string['verifyurl'] = 'Niestandardowy adres URL weryfikacji';
$string['verifyurl_desc'] = 'Niestandardowy adres URL dla linku weryfikacyjnego QR Code. Pozostaw puste, aby użyć domyślnej strony weryfikacji Moodle. Zmienne: {code}';
$string['version'] = 'Wersja';
$string['viewonline'] = 'Wyświetl online';
$string['width'] = 'Szerokość';
$string['zoomin'] = 'Powiększ';
$string['zoomout'] = 'Pomniejsz';
