<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Russian language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Альбомная';
$string['actions'] = 'Действия';
$string['actionsheading'] = 'Действия';
$string['active'] = 'Активен';
$string['activities'] = 'Элементы курса';
$string['aiapikey'] = 'API-ключ';
$string['aiapikey_desc'] = 'Ваш API-ключ для выбранного провайдера AI. Получите его от OpenAI или Anthropic.';
$string['aierror'] = 'Ошибка генерации AI: {$a}';
$string['aigeneratebutton'] = 'Сгенерировать';
$string['aigeneratedesc'] = 'Опишите желаемый сертификат, и AI создаст шаблон для вас.';
$string['aigenerateplaceholder'] = 'например, строгий синий сертификат для IT-курса с золотой рамкой...';
$string['aigeneratesuccess'] = 'Шаблон успешно сгенерирован! Перенаправление в редактор...';
$string['aigeneratetitle'] = 'Генератор шаблонов AI';
$string['aigenerating'] = 'Генерация шаблона с помощью AI...';
$string['aimodel'] = 'Модель';
$string['aimodel_desc'] = 'Используемая модель AI. Для OpenAI: gpt-4o-mini, gpt-4o. Для Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'API-ключ AI не настроен. Пожалуйста, укажите его в настройках плагина.';
$string['aiparseerror'] = 'Не удалось обработать ответ AI. Пожалуйста, попробуйте ещё раз с другим описанием.';
$string['aiprovider'] = 'Провайдер AI';
$string['aiprovider_desc'] = 'Выберите, какой сервис AI использовать для генерации шаблонов.';
$string['aisettings'] = 'Генератор шаблонов AI';
$string['aisettings_desc'] = 'Настройка автоматической генерации шаблонов с помощью AI. Требуется API-ключ от OpenAI или Anthropic.';
$string['aligncenter'] = 'По центру';
$string['alignleft'] = 'По левому краю';
$string['alignright'] = 'По правому краю';
$string['all'] = 'Все';
$string['allcolors'] = 'Все цвета';
$string['allstyles'] = 'Все стили';
$string['alltemplates'] = 'Все шаблоны';
$string['appearance'] = 'Внешний вид';
$string['apply'] = 'Применить';
$string['approval'] = 'Процесс утверждения';
$string['approvalenabled'] = 'Включить процесс утверждения';
$string['approvalenabled_desc'] = 'Включить процесс утверждения по умолчанию для новых элементов курса.';
$string['approvalenabled_help'] = 'Если включено, студенты должны запросить утверждение сертификата у преподавателя перед скачиванием.';
$string['approvalnotifystudent'] = 'Уведомлять студента о результате';
$string['approvalnotifystudent_desc'] = 'Отправлять уведомление студентам, когда их запрос утверждён или отклонён.';
$string['approvalnotifyteacher'] = 'Уведомлять преподавателя о запросе';
$string['approvalnotifyteacher_desc'] = 'Отправлять уведомление преподавателям, когда студент запрашивает сертификат.';
$string['approvalrequestbody'] = '{$a->student} запросил(а) сертификат для «{$a->activity}».';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> запросил(а) сертификат для «<strong>{$a->activity}</strong>».</p><p><a href="{$a->url}">Просмотреть запросы на утверждение</a></p>';
$string['approvalrequestexists'] = 'У вас уже есть запрос, ожидающий утверждения.';
$string['approvalrequestnotfound'] = 'Запрос на утверждение не найден.';
$string['approvalrequestnotpending'] = 'Этот запрос на утверждение больше не ожидает рассмотрения.';
$string['approvalrequests'] = 'Запросы на утверждение';
$string['approvalrequestsmall'] = 'Новый запрос на сертификат от {$a}';
$string['approvalrequestsubject'] = 'Запрос на утверждение сертификата: {$a}';
$string['approvalrequesttemplate'] = 'Уведомление о запросе (преподавателю)';
$string['approvalrequesttemplate_desc'] = 'Сообщение, отправляемое преподавателям, когда студент запрашивает утверждение сертификата.';
$string['approvalresultbody'] = 'Ваш запрос на сертификат для «{$a->activity}» был {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Ваш запрос на сертификат для «<strong>{$a->activity}</strong>» был <strong>{$a->status}</strong>.</p><p>Рецензент: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Просмотреть сертификат</a></p>';
$string['approvalresultsmall'] = 'Запрос на сертификат {$a}';
$string['approvalresultsubject'] = 'Запрос на сертификат {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Настройки утверждения';
$string['approve'] = 'Утвердить';
$string['approved'] = 'утверждён';
$string['approvedtemplate'] = 'Уведомление об утверждении (студенту)';
$string['approvedtemplate_desc'] = 'Сообщение, отправляемое студенту, когда его запрос утверждён.';
$string['autoissue'] = 'Автоматическая выдача при завершении курса';
$string['autoissue_desc'] = 'Автоматически выдавать сертификаты при завершении курса студентом. Требуется включение отслеживания завершения курса. Не применяется к элементам с процессом утверждения.';
$string['back'] = 'Назад';
$string['backtoview'] = 'Назад';
$string['batchdownload'] = 'Скачать все в ZIP';
$string['bgcolor'] = 'Цвет фона';
$string['bgimage'] = 'Фоновое изображение';
$string['bgimageopacity'] = 'Прозрачность фонового изображения';
$string['bgimagesize'] = 'Размер фонового изображения';
$string['bgimagesizeactual'] = 'Реальный размер';
$string['bgimagesizecontain'] = 'Вместить (подогнать внутрь)';
$string['bgimagesizecover'] = 'Покрыть (заполнить страницу)';
$string['bgimagesizestretch'] = 'Растянуть';
$string['bold'] = 'Жирный';
$string['bordercolor'] = 'Цвет рамки';
$string['borderstyle'] = 'Стиль рамки';
$string['borderwidth'] = 'Толщина рамки';
$string['builtin'] = 'Встроенные';
$string['builtintemplates'] = 'Встроенные шаблоны';
$string['bulkactions'] = 'Массовые действия';
$string['bulkdelete'] = 'Удалить выбранные';
$string['bulkemail'] = 'Отправить выбранные по почте';
$string['bulkissue'] = 'Массовая выдача';
$string['bulkissuealreadyissued'] = '{$a} студент(ов) уже имеют сертификат (пропущены)';
$string['bulkissuecomplete'] = 'Успешно выдано сертификатов: {$a}.';
$string['bulkissuedefaultmessage'] = 'Уважаемый(ая) {studentname},

Поздравляем! Ваш сертификат «{certname}» по курсу «{coursename}» был выдан.

Вы можете скачать его здесь: {url}

С уважением';
$string['bulkissuedesc'] = 'Выдать сертификаты всем подходящим зачисленным студентам, которые ещё не получили сертификат.';
$string['bulkissuenoeligible'] = 'Все зачисленные студенты уже получили сертификат.';
$string['bulkissuenoselection'] = 'Студенты не выбраны.';
$string['bulkissuenotified'] = 'Уведомлено студентов: {$a}.';
$string['bulkissuenotify'] = 'Уведомить студентов';
$string['bulkissuenotifyemail'] = 'Отправить уведомление по электронной почте';
$string['bulkissuenotifymessage'] = 'Текст уведомления';
$string['bulkissuenotifymoodle'] = 'Отправить уведомление через Moodle';
$string['bulkissuenotifyplaceholders'] = 'Доступные заполнители: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Ваш сертификат для {$a} был выдан.';
$string['bulkissuenotifysubject'] = 'Ваш сертификат выдан: {$a}';
$string['bulkissuesubmit'] = 'Выдать сертификаты {$a} студенту(ам)';
$string['bulkoperationcomplete'] = 'Обработано сертификатов: {$a->count}. Действие: {$a->action}.';
$string['bulkreissue'] = 'Выдать повторно выбранные';
$string['bulkrevoke'] = 'Отозвать выбранные';
$string['certificate'] = 'Сертификат';
$string['certificateexpired'] = 'Срок действия этого сертификата истёк {$a}.';
$string['certificateexpiredverify'] = 'Срок действия этого сертификата истёк';
$string['certificateexpires'] = 'Срок действия этого сертификата истекает {$a}.';
$string['certificateinvalid'] = 'Этот сертификат недействителен';
$string['certificateissued'] = 'Ваш сертификат был выдан {$a}.';
$string['certificatenotfound'] = 'Сертификат с таким кодом подтверждения не найден.';
$string['certificaterevoked'] = 'Этот сертификат был отозван';
$string['certificaterevokedstudent'] = 'Ваш сертификат был отозван. Пожалуйста, свяжитесь с преподавателем или администратором для получения дополнительной информации.';
$string['certificatevalid'] = 'Этот сертификат действителен';
$string['certificateversion'] = 'Это версия {$a} вашего сертификата (обновлённая).';
$string['certstudio:addinstance'] = 'Добавить элемент Certificate Studio';
$string['certstudio:approvecertificate'] = 'Утверждение запросов на сертификаты';
$string['certstudio:manage'] = 'Управление шаблонами сертификатов';
$string['certstudio:manageemailstudents'] = 'Управление настройками уведомлений по электронной почте';
$string['certstudio:manageprotection'] = 'Управление настройками защиты PDF';
$string['certstudio:managetemplates'] = 'Управление шаблонами сертификатов';
$string['certstudio:receiveissue'] = 'Получение сертификата';
$string['certstudio:revokecertificate'] = 'Отзыв выданных сертификатов';
$string['certstudio:verifycertificate'] = 'Проверка кодов сертификатов';
$string['certstudio:view'] = 'Просмотр сертификата';
$string['certstudio:viewallcertificates'] = 'Просмотр всех выданных сертификатов';
$string['certstudio:viewreport'] = 'Просмотр отчётов и аналитики сертификатов';
$string['city'] = 'Город';
$string['clearbg'] = 'Очистить фон';
$string['clicktorenametemplate'] = 'Нажмите для переименования шаблона';
$string['codegenerationmethod'] = 'Метод генерации кода';
$string['codegenerationmethod_desc'] = 'Выберите один из двух методов генерации кодов подтверждения сертификатов.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Цифры с дефисами)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Случайная строка из заглавных/строчных букв и цифр)';
$string['color'] = 'Цвет';
$string['colorblue'] = 'Синий';
$string['colordark'] = 'Тёмный';
$string['colorgold'] = 'Золотой';
$string['colorgray'] = 'Серый';
$string['colorgreen'] = 'Зелёный';
$string['colorpink'] = 'Розовый';
$string['colorpurple'] = 'Фиолетовый';
$string['colorred'] = 'Красный';
$string['comment'] = 'Комментарий';
$string['confirmbulk'] = 'Вы уверены, что хотите выполнить массовое действие над выбранными сертификатами?';
$string['confirmdelete'] = 'Вы уверены, что хотите удалить этот шаблон? Это действие нельзя отменить.';
$string['confirmdeleteissue'] = 'Вы уверены, что хотите безвозвратно удалить эту запись о сертификате?';
$string['confirmrevoke'] = 'Вы уверены, что хотите отозвать этот сертификат? На странице проверки он будет отображаться как отозванный.';
$string['copy'] = 'Копировать';
$string['course'] = 'Курс';
$string['createblank'] = 'Пустой сертификат';
$string['createblankdesc'] = 'Начать с пустого холста';
$string['created'] = 'Создан';
$string['createtemplate'] = '-- Создать новый шаблон --';
$string['current'] = 'Текущий';
$string['currenttemplate'] = 'Текущий шаблон';
$string['custom'] = 'Пользовательский';
$string['customsource'] = 'Пользовательские';
$string['customtemplates'] = 'Пользовательские шаблоны';
$string['dateformat'] = 'Формат даты';
$string['dateissued'] = 'Дата выдачи';
$string['daterequested'] = 'Дата запроса';
$string['defaultfilename'] = 'Имя файла PDF по умолчанию';
$string['defaultfilename_desc'] = 'Шаблон имени файла по умолчанию для скачиваемых PDF. Заполнители: {coursename}, {studentname}, {date}, {activityname}. Может быть переопределён для каждого элемента курса.';
$string['defaultprotection'] = 'Защита PDF по умолчанию';
$string['defaultprotection_desc'] = 'Флаги защиты PDF по умолчанию (через запятую): print, modify, copy. Может быть переопределено для каждого элемента курса.';
$string['defaultvalues'] = 'Значения по умолчанию для настроек элемента курса';
$string['defaultvalues_desc'] = 'Значения по умолчанию используются в форме настроек при создании нового элемента курса.';
$string['delete'] = 'Удалить';
$string['deleteissuedcertificates'] = 'Удалить выданные сертификаты';
$string['downloadcertificate'] = 'Скачать сертификат';
$string['downloadfilename'] = 'Имя файла PDF';
$string['downloadfilename_help'] = 'Пользовательское имя файла для скачиваемого PDF-сертификата. Можно использовать заполнители: {coursename}, {studentname}, {date}. Оставьте пустым, чтобы использовать название элемента курса. Пример: Certificate_{coursename}_{studentname}';
$string['downloadsettings'] = 'Настройки скачивания';
$string['editcertstudio'] = 'Редактировать сертификат';
$string['edittemplate'] = 'Редактировать шаблон';
$string['elementcount'] = 'Элементов: {$a}';
$string['elementname'] = 'Имя элемента';
$string['elements'] = 'Элементы';
$string['elementtype_bgimage'] = 'Фоновое изображение';
$string['elementtype_border'] = 'Рамка';
$string['elementtype_categoryname'] = 'Название категории';
$string['elementtype_certdate'] = 'Дата (греческий формат)';
$string['elementtype_certstatement'] = 'Заявление (греческий формат)';
$string['elementtype_code'] = 'Код подтверждения';
$string['elementtype_coursefield'] = 'Поле курса';
$string['elementtype_coursename'] = 'Название курса';
$string['elementtype_date'] = 'Дата';
$string['elementtype_daterange'] = 'Диапазон дат';
$string['elementtype_digitalsignature'] = 'Цифровая подпись';
$string['elementtype_expiry'] = 'Дата истечения срока';
$string['elementtype_grade'] = 'Оценка';
$string['elementtype_gradeitemname'] = 'Название элемента оценивания';
$string['elementtype_image'] = 'Изображение';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Имя студента';
$string['elementtype_teachername'] = 'Имя преподавателя';
$string['elementtype_text'] = 'Текст';
$string['elementtype_userfield'] = 'Поле пользователя';
$string['elementtype_userpicture'] = 'Фотография пользователя';
$string['emailcertbody'] = 'Уважаемый(ая) {$a->studentname},

Ваш сертификат «{$a->certname}» по курсу «{$a->coursename}» прикреплён к этому письму.

Код подтверждения: {$a->code}
Проверить онлайн: {$a->verifyurl}

С уважением';
$string['emailcertificate'] = 'Отправить сертификат по почте';
$string['emailcertificatebody'] = 'Уважаемый(ая) {$a->fullname},

Ваш сертификат «{$a->certname}» по курсу «{$a->coursename}» был выдан.

Вы можете проверить его по коду: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Ваш сертификат для {$a}';
$string['emailcertsubject'] = 'Ваш сертификат: {$a}';
$string['emailcerttemplate'] = 'Уведомление с сертификатом по электронной почте';
$string['emailcerttemplate_default'] = 'Уважаемый(ая) {studentname},

Ваш сертификат «{certname}» по курсу «{coursename}» прикреплён к этому письму.

Код подтверждения: {code}
Проверить онлайн: {verifyurl}

С уважением';
$string['emailcerttemplate_desc'] = 'Текст письма при отправке PDF-сертификата в виде вложения. Заполнители: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Отправлять другим';
$string['emailothers_desc'] = 'Адреса электронной почты через запятую, на которые будет отправлена копия сертификата, когда он станет доступен.';
$string['emailsent'] = 'Сертификат успешно отправлен по электронной почте.';
$string['emailsettings'] = 'Уведомления по электронной почте';
$string['emailstudents'] = 'Отправлять студентам';
$string['emailstudents_desc'] = 'Если включено, студенты получат копию сертификата по электронной почте, когда он станет доступен.';
$string['emailteacherbody'] = 'Сертификат «{$a->certname}» был выдан пользователю {$a->fullname} в курсе «{$a->coursename}».';
$string['emailteachers'] = 'Отправлять преподавателям';
$string['emailteachers_desc'] = 'Если включено, преподаватели получат копию сертификата по электронной почте, когда он станет доступен.';
$string['emailteachersubject'] = 'Сертификат выдан: {$a->certname}';
$string['entercode'] = 'Введите код подтверждения';
$string['eventcertificateapproved'] = 'Сертификат утверждён';
$string['eventcertificateissued'] = 'Сертификат выдан';
$string['eventcertificaterejected'] = 'Сертификат отклонён';
$string['eventcertificaterequested'] = 'Сертификат запрошен';
$string['eventcertificaterevoked'] = 'Сертификат отозван';
$string['eventpagecreated'] = 'Страница создана';
$string['eventpagedeleted'] = 'Страница удалена';
$string['eventtemplatecreated'] = 'Шаблон создан';
$string['eventtemplatedeleted'] = 'Шаблон удалён';
$string['eventtemplateupdated'] = 'Шаблон обновлён';
$string['expired'] = 'Истёк';
$string['expiredon'] = 'Срок истёк';
$string['expirydate'] = 'Дата истечения срока';
$string['expirydays'] = 'Срок действия сертификата (дней)';
$string['expirydays_help'] = 'Количество дней действия сертификата с даты выдачи. Установите 0, чтобы не ограничивать срок действия.';
$string['expiryperiod'] = 'Срок действия (дней)';
$string['expirysettings'] = 'Настройки срока действия';
$string['exportcsv'] = 'Экспорт CSV';
$string['exportods'] = 'Экспорт ODS';
$string['exporttemplate'] = 'Экспортировать шаблон';
$string['exportxlsx'] = 'Экспорт XLSX';
$string['fieldname'] = 'Имя поля';
$string['font'] = 'Шрифт';
$string['fontsize'] = 'Размер шрифта';
$string['gallerydescription'] = 'Выберите шаблон для начала работы или создайте собственный с нуля';
$string['generalsettings'] = 'Общие настройки';
$string['getcertificate'] = 'Получить сертификат';
$string['gradeitem'] = 'Элемент оценивания';
$string['height'] = 'Высота';
$string['importtemplate'] = 'Импортировать шаблон';
$string['invalidaction'] = 'Недопустимое действие';
$string['invalidelementdata'] = 'Недопустимые данные элемента';
$string['invalidfilearea'] = 'Недопустимая файловая область';
$string['issuedcertificates'] = 'Выданные сертификаты';
$string['issuedcount'] = 'Выдано сертификатов: {$a}';
$string['issuedtemplate'] = 'Уведомление о выдаче сертификата';
$string['issuedtemplate_default'] = 'Уважаемый(ая) {studentname},

Поздравляем! Ваш сертификат «{certname}» по курсу «{coursename}» был выдан.

Вы можете скачать его здесь: {url}

Код подтверждения: {code}

С уважением';
$string['issuedtemplate_desc'] = 'Сообщение, отправляемое студенту при выдаче сертификата. Заполнители: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Выданный сертификат не найден';
$string['italic'] = 'Курсив';
$string['landscape'] = 'Альбомная';
$string['layers'] = 'Слои';
$string['loading'] = 'Загрузка...';
$string['lock'] = 'Заблокировать';
$string['manageapprovals'] = 'Управление утверждениями';
$string['managetemplates'] = 'Управление шаблонами';
$string['managetemplates_desc'] = 'Просмотр, экспорт, импорт и удаление шаблонов. Управление всеми встроенными и пользовательскими шаблонами из одного места.';
$string['messageprovider:approval_request'] = 'Запрос на утверждение сертификата';
$string['messageprovider:approval_result'] = 'Результат утверждения сертификата';
$string['messagetemplates'] = 'Шаблоны сообщений';
$string['messagetemplates_desc'] = 'Настройте тексты уведомлений. Заполнители: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Мигрировать элементы курса (модули курса)';
$string['migrateissues'] = 'Мигрировать выданные сертификаты';
$string['migratetemplates'] = 'Мигрировать шаблоны (страницы и элементы)';
$string['migrationcomplete'] = 'Миграция завершена: мигрировано шаблонов — {$a->templates}, элементов курса — {$a->activities}, выданных сертификатов — {$a->issues}.';
$string['migrationlog'] = 'Журнал миграции';
$string['migrationnodata'] = 'Данные customcert для миграции не найдены.';
$string['migrationnotavailable'] = 'Плагин Custom Certificate (mod_customcert) не установлен. Нечего мигрировать.';
$string['migrationoptions'] = 'Параметры миграции';
$string['migrationsummary'] = 'Найдены данные Custom Certificate';
$string['migrationtool'] = 'Миграция из Custom Certificate';
$string['migrationwarning'] = 'Будут созданы новые записи certstudio из ваших данных customcert. Существующие данные customcert НЕ будут изменены или удалены. Уже мигрированные элементы будут пропущены.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studio';
$string['multilang'] = 'Многоязычные сертификаты';
$string['multilang_desc'] = 'Принудительно задать язык сертификата для каждого элемента курса, переопределяя настройки пользователя.';
$string['mycertificates'] = 'Мои сертификаты';
$string['name'] = 'Название';
$string['nelements'] = '{$a} элементов';
$string['nocertificates'] = 'Вы ещё не получили ни одного сертификата.';
$string['nocertificatesissued'] = 'Сертификат ещё не выдан. Пожалуйста, выполните необходимые задания, чтобы получить сертификат.';
$string['nodata'] = 'Данные отсутствуют.';
$string['norequests'] = 'Запросов на утверждение не найдено.';
$string['notapproved'] = 'Ваш сертификат ещё не утверждён.';
$string['notemplates'] = 'Шаблоны не найдены.';
$string['notemplatesavailable'] = 'Нет доступных шаблонов. Нажмите «Начать с нуля», чтобы создать свой сертификат.';
$string['notissued'] = 'Не выдан';
$string['opacity'] = 'Прозрачность';
$string['optional'] = 'необязательно';
$string['pages'] = 'Страницы';
$string['pagesettings'] = 'Настройки страницы';
$string['pagesize'] = 'Размер страницы';
$string['pdfsettings'] = 'Настройки PDF';
$string['platform'] = 'Платформа';
$string['pluginadministration'] = 'Администрирование Certificate Studio';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Книжная';
$string['positionandsize'] = 'Позиция и размер';
$string['previewpdf'] = 'Предпросмотр PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Запросы на утверждение сертификатов.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'Комментарий рецензента к запросу.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'Пользователь, рассмотревший запрос.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'Статус утверждения.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Дата и время создания запроса.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Дата и время последнего обновления запроса.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'Пользователь, запросивший сертификат.';
$string['privacy:metadata:certstudio_issues'] = 'Записи о выданных сертификатах.';
$string['privacy:metadata:certstudio_issues:code'] = 'Уникальный код подтверждения.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'Снимок данных шаблона сертификата.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Дата и время выдачи сертификата.';
$string['privacy:metadata:certstudio_issues:userid'] = 'Пользователь, получивший сертификат.';
$string['privacy:path:approvalrequests'] = 'Запросы на утверждение';
$string['privacy:path:issues'] = 'Выданные сертификаты';
$string['properties'] = 'Свойства';
$string['protection'] = 'Защита PDF';
$string['protection_copy'] = 'Запретить копирование';
$string['protection_copy_desc'] = 'Включить защиту от копирования.';
$string['protection_modify'] = 'Запретить изменение';
$string['protection_modify_desc'] = 'Включить защиту от изменения.';
$string['protection_print'] = 'Запретить печать';
$string['protection_print_desc'] = 'Включить защиту от печати.';
$string['protectionflags'] = 'Флаги защиты';
$string['protectionflags_help'] = 'Флаги защиты через запятую: print, modify, copy';
$string['publishtogallery'] = 'Опубликовать в галерее';
$string['publishtogallerytip'] = 'Опубликовать копию в галерее шаблонов, чтобы все курсы могли её использовать';
$string['reason'] = 'Причина';
$string['receiveddate'] = 'Дата получения';
$string['redo'] = 'Повторить';
$string['reissue'] = 'Выдать повторно';
$string['reissuedtemplate'] = 'Уведомление о повторной выдаче сертификата';
$string['reissuedtemplate_default'] = 'Уважаемый(ая) {studentname},

Новая версия вашего сертификата «{certname}» по курсу «{coursename}» была выдана.

Вы можете скачать его здесь: {url}

Код подтверждения: {code}

С уважением';
$string['reissuedtemplate_desc'] = 'Сообщение, отправляемое студенту при выдаче новой версии сертификата. Заполнители: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Отклонить';
$string['rejected'] = 'отклонён';
$string['rejectedtemplate'] = 'Уведомление об отклонении (студенту)';
$string['rejectedtemplate_desc'] = 'Сообщение, отправляемое студенту, когда его запрос отклонён.';
$string['reportanalytics'] = 'Аналитика сертификатов';
$string['reportmonthly'] = 'Ежемесячная динамика (за 12 месяцев)';
$string['reportpercourse'] = 'Сертификатов по курсам';
$string['reportrecent'] = 'Последние сертификаты (за 30 дней)';
$string['reporttotalactivities'] = 'Всего элементов курса';
$string['reporttotalissued'] = 'Всего выдано';
$string['reporttotaltemplates'] = 'Всего шаблонов';
$string['reportuniquerecipients'] = 'Уникальных получателей';
$string['requestagain'] = 'Отправить новый запрос';
$string['requestapproved'] = 'Запрос успешно утверждён.';
$string['requestcertificate'] = 'Запросить сертификат';
$string['requestpending'] = 'Ваш запрос на сертификат ожидает утверждения.';
$string['requestrejected'] = 'Ваш запрос на сертификат был отклонён.';
$string['requestrejectedmsg'] = 'Запрос успешно отклонён.';
$string['requestsubmitted'] = 'Ваш запрос на сертификат отправлен.';
$string['requiredtime'] = 'Необходимое время в курсе (минуты)';
$string['requiredtime_desc'] = 'Минимальное время в минутах, которое студент должен провести в курсе, прежде чем сможет получить сертификат. Установите 0 для отключения.';
$string['requiredtimenotmet'] = 'Вам необходимо провести не менее {$a->required} минут в этом курсе, прежде чем вы сможете получить сертификат. На данный момент вы провели примерно {$a->spent} минут.';
$string['returncourse'] = 'Кнопка возврата к курсу';
$string['returncourse_desc'] = 'Отображать кнопку «Вернуться к курсу» на странице просмотра сертификата.';
$string['returntocourse'] = 'Вернуться к курсу';
$string['reviewer'] = 'Рецензент';
$string['revokecertificate'] = 'Отозвать сертификат';
$string['revoked'] = 'Отозван';
$string['revokeddate'] = 'Дата отзыва';
$string['revokedrenewal'] = 'Отозван для обновления (выдана новая версия)';
$string['revokedtemplate'] = 'Уведомление об отзыве сертификата';
$string['revokedtemplate_default'] = 'Уважаемый(ая) {studentname},

Ваш сертификат «{certname}» по курсу «{coursename}» был отозван.

Причина: {reason}

Если у вас есть вопросы, пожалуйста, свяжитесь с вашим преподавателем.

С уважением';
$string['revokedtemplate_desc'] = 'Сообщение, отправляемое студенту при отзыве сертификата. Заполнители: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Вращение';
$string['save'] = 'Сохранить';
$string['savechangestip'] = 'Сохранить изменения только для этой активности';
$string['saved'] = 'Изменения сохранены';
$string['saveerror'] = 'Ошибка сохранения изменений';
$string['savestatussaved'] = 'Сохранено';
$string['searchbyname'] = 'Поиск по названию...';
$string['selectelement'] = 'Нажмите на элемент, чтобы изменить его свойства.';
$string['selecttemplate'] = 'Выберите шаблон';
$string['sharecertificate'] = 'Поделиться';
$string['shareemailbody'] = 'Хочу сообщить, что я получил(а) сертификат «{$a->certname}».

Вы можете проверить его здесь: {$a->verifyurl}

— {$a->fullname}';
$string['shareemailsubject'] = 'Мой сертификат: {$a}';
$string['sharetext'] = 'Я только что получил(а) сертификат «{$a}»!';
$string['showcasecourse'] = 'Курс';
$string['showcasedownloadpdf'] = 'Скачать PDF';
$string['showcaseissuedon'] = 'Дата выдачи';
$string['showcaserecipient'] = 'Награждён(а)';
$string['showcaseshare'] = 'Поделиться этим сертификатом';
$string['showcasetitle'] = 'Цифровой сертификат';
$string['showcaseverified'] = 'Подтверждённый сертификат';
$string['showposxy'] = 'Показывать позицию X и Y';
$string['showposxy_desc'] = 'Показывать позицию X и Y при редактировании элемента, позволяя пользователю точно указать расположение.';
$string['startfromscratch'] = 'Создать с нуля';
$string['startmigration'] = 'Начать миграцию';
$string['status'] = 'Статус';
$string['statusapproved'] = 'Утверждён';
$string['statusexpired'] = 'Истёк';
$string['statuspending'] = 'Ожидает';
$string['statusrejected'] = 'Отклонён';
$string['statusrevoked'] = 'Отозван';
$string['statusvalid'] = 'Действителен';
$string['student'] = 'Студент';
$string['styleclassic'] = 'Классический';
$string['styledark'] = 'Тёмный';
$string['styleelegant'] = 'Элегантный';
$string['stylegradient'] = 'Градиент';
$string['styleminimal'] = 'Минималистичный';
$string['stylemodern'] = 'Современный';
$string['stylespecial'] = 'Особый';
$string['subplugintype_certstudioselem'] = 'Тип элемента';
$string['subplugintype_certstudioselem_plural'] = 'Типы элементов';
$string['taskemailcertificate'] = 'Отправка сертификата по электронной почте';
$string['taskissuecertificate'] = 'Выдача сертификатов и отправка писем';
$string['template'] = 'Шаблон';
$string['templatedeleted'] = 'Шаблон «{$a}» был удалён.';
$string['templatefile'] = 'Файл шаблона (.json)';
$string['templatefilehelp'] = 'Загрузите файл .certstudio.json, экспортированный из другой установки Certificate Studio.';
$string['templategallery'] = 'Галерея шаблонов';
$string['templateimported'] = 'Шаблон «{$a->name}» успешно импортирован (страниц: {$a->pages}, элементов: {$a->elements}).';
$string['templateimportinvalid'] = 'Недопустимый файл шаблона. Пожалуйста, загрузите корректный файл .certstudio.json.';
$string['templateinuse'] = 'Этот шаблон используется в {$a} элементах курса и не может быть удалён.';
$string['templatenameplaceholder'] = 'Название шаблона...';
$string['templates'] = 'Шаблоны';
$string['templatesharing'] = 'Импорт/Экспорт шаблонов';
$string['textcontent'] = 'Содержимое текста';
$string['toggleelementspanel'] = 'Показать/скрыть панель элементов';
$string['togglegrid'] = 'Показать/скрыть сетку';
$string['toggleguides'] = 'Показать/скрыть направляющие';
$string['togglepropertiespanel'] = 'Показать/скрыть панель свойств';
$string['typography'] = 'Типографика';
$string['undo'] = 'Отменить';
$string['unknowncourse'] = 'Неизвестный курс';
$string['unknownuser'] = 'Неизвестный пользователь';
$string['unlock'] = 'Разблокировать';
$string['uploadbgimage'] = 'Загрузить';
$string['uploadbgimagetip'] = 'Загрузить фоновое изображение';
$string['usethisTemplate'] = 'Использовать этот шаблон';
$string['usethistemplate'] = 'Использовать этот шаблон';
$string['valid'] = 'Действителен';
$string['verificationcode'] = 'Код подтверждения';
$string['verify'] = 'Проверить';
$string['verifyallcertificates'] = 'Разрешить публичную проверку';
$string['verifyallcertificates_desc'] = 'Разрешить любому проверять сертификаты без входа в систему.';
$string['verifyanother'] = 'Проверить другой сертификат';
$string['verifyany'] = 'Разрешить любому проверять сертификат';
$string['verifyany_desc'] = 'Разрешить любому, у кого есть ссылка для проверки сертификата (включая неавторизованных пользователей), проверять сертификат.';
$string['verifycertificate'] = 'Проверить сертификат';
$string['verifyintro'] = 'Введите код подтверждения сертификата, чтобы проверить его подлинность на сайте {$a}.';
$string['verifylink_desc'] = 'Эта ссылка перенаправит вас на страницу, где можно проверить сертификаты на сайте.';
$string['verifynotfound'] = 'Сертификат с таким кодом подтверждения не найден. Пожалуйста, проверьте код и попробуйте снова.';
$string['verifyurl'] = 'Пользовательский URL проверки';
$string['verifyurl_desc'] = 'Пользовательский URL для ссылки проверки QR Code. Оставьте пустым для использования стандартной страницы проверки Moodle. Заполнители: {code}';
$string['version'] = 'Версия';
$string['viewonline'] = 'Просмотреть онлайн';
$string['width'] = 'Ширина';
$string['zoomin'] = 'Увеличить';
$string['zoomout'] = 'Уменьшить';
