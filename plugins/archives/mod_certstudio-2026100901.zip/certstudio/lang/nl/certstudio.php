<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Dutch language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['a4landscape'] = 'A4 Liggend';
$string['actions'] = 'Acties';
$string['actionsheading'] = 'Acties';
$string['active'] = 'Actief';
$string['activities'] = 'Activiteiten';
$string['aiapikey'] = 'API-sleutel';
$string['aiapikey_desc'] = 'Uw API-sleutel voor de geselecteerde AI-provider. Verkrijg er een bij OpenAI of Anthropic.';
$string['aierror'] = 'AI-generatiefout: {$a}';
$string['aigeneratebutton'] = 'Genereren';
$string['aigeneratedesc'] = 'Beschrijf het certificaat dat u wilt en AI genereert een sjabloon voor u.';
$string['aigenerateplaceholder'] = 'bijv. formeel blauw certificaat voor IT-cursus met gouden rand...';
$string['aigeneratesuccess'] = 'Sjabloon succesvol gegenereerd! Doorsturen naar editor...';
$string['aigeneratetitle'] = 'AI-sjabloongenerator';
$string['aigenerating'] = 'Sjabloon genereren met AI...';
$string['aimodel'] = 'Model';
$string['aimodel_desc'] = 'Het te gebruiken AI-model. Voor OpenAI: gpt-4o-mini, gpt-4o. Voor Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'AI API-sleutel is niet geconfigureerd. Stel deze in bij de plugin-instellingen.';
$string['aiparseerror'] = 'Kan het AI-antwoord niet verwerken. Probeer het opnieuw met een andere beschrijving.';
$string['aiprovider'] = 'AI-provider';
$string['aiprovider_desc'] = 'Kies welke AI-dienst u wilt gebruiken voor sjabloongeneratie.';
$string['aisettings'] = 'AI-sjabloongenerator';
$string['aisettings_desc'] = 'Configureer AI-gestuurde automatische sjabloongeneratie. Vereist een API-sleutel van OpenAI of Anthropic.';
$string['aligncenter'] = 'Gecentreerd';
$string['alignleft'] = 'Links';
$string['alignright'] = 'Rechts';
$string['all'] = 'Alle';
$string['allcolors'] = 'Alle kleuren';
$string['allstyles'] = 'Alle stijlen';
$string['alltemplates'] = 'Alle sjablonen';
$string['appearance'] = 'Uiterlijk';
$string['apply'] = 'Toepassen';
$string['approval'] = 'Goedkeuringsworkflow';
$string['approvalenabled'] = 'Goedkeuringsworkflow inschakelen';
$string['approvalenabled_desc'] = 'Goedkeuringsworkflow standaard inschakelen voor nieuwe activiteiten.';
$string['approvalenabled_help'] = 'Wanneer ingeschakeld, moeten studenten goedkeuring van een docent aanvragen voordat ze het certificaat kunnen downloaden.';
$string['approvalnotifystudent'] = 'Student op de hoogte stellen van resultaat';
$string['approvalnotifystudent_desc'] = 'Melding sturen naar studenten wanneer hun aanvraag is goedgekeurd of afgewezen.';
$string['approvalnotifyteacher'] = 'Docent op de hoogte stellen bij aanvraag';
$string['approvalnotifyteacher_desc'] = 'Melding sturen naar docenten wanneer een student een certificaat aanvraagt.';
$string['approvalrequestbody'] = '{$a->student} heeft een certificaat aangevraagd voor "{$a->activity}".';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> heeft een certificaat aangevraagd voor "<strong>{$a->activity}</strong>".</p><p><a href="{$a->url}">Goedkeuringsaanvragen bekijken</a></p>';
$string['approvalrequestexists'] = 'U heeft al een goedkeuringsaanvraag in behandeling.';
$string['approvalrequestnotfound'] = 'Goedkeuringsaanvraag niet gevonden.';
$string['approvalrequestnotpending'] = 'Deze goedkeuringsaanvraag is niet meer in behandeling.';
$string['approvalrequests'] = 'Goedkeuringsaanvragen';
$string['approvalrequestsmall'] = 'Nieuwe certificaataanvraag van {$a}';
$string['approvalrequestsubject'] = 'Goedkeuringsaanvraag certificaat: {$a}';
$string['approvalrequesttemplate'] = 'Aanvraagmelding (naar docent)';
$string['approvalrequesttemplate_desc'] = 'Bericht dat naar docenten wordt gestuurd wanneer een student certificaatgoedkeuring aanvraagt.';
$string['approvalresultbody'] = 'Uw certificaataanvraag voor "{$a->activity}" is {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Uw certificaataanvraag voor "<strong>{$a->activity}</strong>" is <strong>{$a->status}</strong>.</p><p>Beoordelaar: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Certificaat bekijken</a></p>';
$string['approvalresultsmall'] = 'Certificaataanvraag {$a}';
$string['approvalresultsubject'] = 'Certificaataanvraag {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Goedkeuringsinstellingen';
$string['approve'] = 'Goedkeuren';
$string['approved'] = 'goedgekeurd';
$string['approvedtemplate'] = 'Goedkeuringsmelding (naar student)';
$string['approvedtemplate_desc'] = 'Bericht dat naar de student wordt gestuurd wanneer de aanvraag is goedgekeurd.';
$string['autoissue'] = 'Automatisch uitgeven bij cursusafronding';
$string['autoissue_desc'] = 'Certificaten automatisch uitgeven wanneer een student de cursus afrond. Cursusafronding moet zijn ingeschakeld. Niet van toepassing op activiteiten met goedkeuringsworkflow.';
$string['back'] = 'Terug';
$string['backtoview'] = 'Terug';
$string['batchdownload'] = 'Alles downloaden als ZIP';
$string['bgcolor'] = 'Achtergrondkleur';
$string['bgimage'] = 'Achtergrondafbeelding';
$string['bgimageopacity'] = 'Dekking achtergrondafbeelding';
$string['bgimagesize'] = 'Achtergrondafbeeldingsgrootte';
$string['bgimagesizeactual'] = 'Werkelijke grootte';
$string['bgimagesizecontain'] = 'Bevatten (binnen passen)';
$string['bgimagesizecover'] = 'Bedekken (pagina vullen)';
$string['bgimagesizestretch'] = 'Uitrekken';
$string['bold'] = 'Vet';
$string['bordercolor'] = 'Randkleur';
$string['borderstyle'] = 'Randstijl';
$string['borderwidth'] = 'Randbreedte';
$string['builtin'] = 'Ingebouwd';
$string['builtintemplates'] = 'Ingebouwde sjablonen';
$string['bulkactions'] = 'Bulkacties';
$string['bulkdelete'] = 'Geselecteerde verwijderen';
$string['bulkemail'] = 'Geselecteerde e-mailen';
$string['bulkissue'] = 'Bulkuitgifte';
$string['bulkissuealreadyissued'] = '{$a} student(en) hebben al een certificaat (overgeslagen)';
$string['bulkissuecomplete'] = '{$a} certificaat/certificaten succesvol uitgegeven.';
$string['bulkissuedefaultmessage'] = 'Beste {studentname},

Gefeliciteerd! Uw certificaat voor "{certname}" in de cursus "{coursename}" is uitgegeven.

U kunt het hier downloaden: {url}

Met vriendelijke groet';
$string['bulkissuedesc'] = 'Certificaten uitgeven aan alle in aanmerking komende ingeschreven studenten die er nog geen hebben ontvangen.';
$string['bulkissuenoeligible'] = 'Alle ingeschreven studenten hebben al een certificaat ontvangen.';
$string['bulkissuenoselection'] = 'Geen studenten geselecteerd.';
$string['bulkissuenotified'] = '{$a} student(en) op de hoogte gesteld.';
$string['bulkissuenotify'] = 'Studenten op de hoogte stellen';
$string['bulkissuenotifyemail'] = 'Melding per e-mail versturen';
$string['bulkissuenotifymessage'] = 'Meldingsbericht';
$string['bulkissuenotifymoodle'] = 'Melding via Moodle versturen';
$string['bulkissuenotifyplaceholders'] = 'Beschikbare tijdelijke aanduidingen: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Uw certificaat voor {$a} is uitgegeven.';
$string['bulkissuenotifysubject'] = 'Uw certificaat is uitgegeven: {$a}';
$string['bulkissuesubmit'] = 'Certificaten uitgeven aan {$a} student(en)';
$string['bulkoperationcomplete'] = '{$a->count} certificaat/certificaten verwerkt: {$a->action}.';
$string['bulkreissue'] = 'Geselecteerde opnieuw uitgeven';
$string['bulkrevoke'] = 'Geselecteerde intrekken';
$string['certificate'] = 'Certificaat';
$string['certificateexpired'] = 'Dit certificaat is verlopen op {$a}.';
$string['certificateexpiredverify'] = 'Dit certificaat is verlopen';
$string['certificateexpires'] = 'Dit certificaat verloopt op {$a}.';
$string['certificateinvalid'] = 'Dit certificaat is ongeldig';
$string['certificateissued'] = 'Uw certificaat is uitgegeven op {$a}.';
$string['certificatenotfound'] = 'Geen certificaat gevonden met deze verificatiecode.';
$string['certificaterevoked'] = 'Dit certificaat is ingetrokken';
$string['certificaterevokedstudent'] = 'Uw certificaat is ingetrokken. Neem contact op met uw docent of beheerder voor meer informatie.';
$string['certificatevalid'] = 'Dit certificaat is geldig';
$string['certificateversion'] = 'Dit is versie {$a} van uw certificaat (vernieuwd).';
$string['certstudio:addinstance'] = 'Een Certificate Studio activiteit toevoegen';
$string['certstudio:approvecertificate'] = 'Certificaataanvragen goedkeuren';
$string['certstudio:manage'] = 'Certificaatsjablonen beheren';
$string['certstudio:manageemailstudents'] = 'E-mailmeldingsinstellingen beheren';
$string['certstudio:manageprotection'] = 'PDF-beveiligingsinstellingen beheren';
$string['certstudio:managetemplates'] = 'Certificaatsjablonen beheren';
$string['certstudio:receiveissue'] = 'Een certificaat ontvangen';
$string['certstudio:revokecertificate'] = 'Uitgegeven certificaten intrekken';
$string['certstudio:verifycertificate'] = 'Certificaatcodes verifiëren';
$string['certstudio:view'] = 'Certificaat bekijken';
$string['certstudio:viewallcertificates'] = 'Alle uitgegeven certificaten bekijken';
$string['certstudio:viewreport'] = 'Certificaatrapporten en analyses bekijken';
$string['city'] = 'Stad';
$string['clearbg'] = 'Achtergrond wissen';
$string['clicktorenametemplate'] = 'Klik om sjabloon te hernoemen';
$string['codegenerationmethod'] = 'Methode voor codegeneratie';
$string['codegenerationmethod_desc'] = 'Kies tussen de twee methoden voor het genereren van certificaatverificatiecodes.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Cijfers met streepjes)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Willekeurige reeks van hoofd-/kleine letters en cijfers)';
$string['color'] = 'Kleur';
$string['colorblue'] = 'Blauw';
$string['colordark'] = 'Donker';
$string['colorgold'] = 'Goud';
$string['colorgray'] = 'Grijs';
$string['colorgreen'] = 'Groen';
$string['colorpink'] = 'Roze';
$string['colorpurple'] = 'Paars';
$string['colorred'] = 'Rood';
$string['comment'] = 'Opmerking';
$string['confirmbulk'] = 'Weet u zeker dat u deze bulkactie wilt uitvoeren op de geselecteerde certificaten?';
$string['confirmdelete'] = 'Weet u zeker dat u dit sjabloon wilt verwijderen? Deze actie kan niet ongedaan worden gemaakt.';
$string['confirmdeleteissue'] = 'Weet u zeker dat u deze certificaatregistratie permanent wilt verwijderen?';
$string['confirmrevoke'] = 'Weet u zeker dat u dit certificaat wilt intrekken? De verificatiepagina zal het als ingetrokken weergeven.';
$string['copy'] = 'Kopiëren';
$string['course'] = 'Cursus';
$string['createblank'] = 'Leeg certificaat';
$string['createblankdesc'] = 'Begin met een leeg canvas';
$string['created'] = 'Aangemaakt';
$string['createtemplate'] = '-- Nieuw sjabloon aanmaken --';
$string['current'] = 'Huidig';
$string['currenttemplate'] = 'Huidig sjabloon';
$string['custom'] = 'Aangepast';
$string['customsource'] = 'Aangepast';
$string['customtemplates'] = 'Aangepaste sjablonen';
$string['dateformat'] = 'Datumnotatie';
$string['dateissued'] = 'Datum uitgegeven';
$string['daterequested'] = 'Datum aangevraagd';
$string['defaultfilename'] = 'Standaard PDF-bestandsnaam';
$string['defaultfilename_desc'] = 'Standaard bestandsnaampatroon voor gedownloade PDF\'s. Tijdelijke aanduidingen: {coursename}, {studentname}, {date}, {activityname}. Kan per activiteit worden overschreven.';
$string['defaultprotection'] = 'Standaard PDF-beveiliging';
$string['defaultprotection_desc'] = 'Standaard beveiligingsvlaggen voor PDF\'s (door komma\'s gescheiden): print, modify, copy. Kan per activiteit worden overschreven.';
$string['defaultvalues'] = 'Standaardwaarden voor activiteitinstellingen';
$string['defaultvalues_desc'] = 'Standaardwaarden worden gebruikt in het instellingenformulier bij het aanmaken van een nieuwe activiteit.';
$string['delete'] = 'Verwijderen';
$string['deleteissuedcertificates'] = 'Uitgegeven certificaten verwijderen';
$string['downloadcertificate'] = 'Certificaat downloaden';
$string['downloadfilename'] = 'PDF-bestandsnaam';
$string['downloadfilename_help'] = 'Aangepaste bestandsnaam voor het gedownloade PDF-certificaat. U kunt tijdelijke aanduidingen gebruiken: {coursename}, {studentname}, {date}. Laat leeg om de activiteitnaam te gebruiken. Voorbeeld: Certificaat_{coursename}_{studentname}';
$string['downloadsettings'] = 'Downloadinstellingen';
$string['editcertstudio'] = 'Certificaat bewerken';
$string['edittemplate'] = 'Sjabloon bewerken';
$string['elementcount'] = '{$a} elementen';
$string['elementname'] = 'Elementnaam';
$string['elements'] = 'Elementen';
$string['elementtype_bgimage'] = 'Achtergrondafbeelding';
$string['elementtype_border'] = 'Rand';
$string['elementtype_categoryname'] = 'Categorienaam';
$string['elementtype_certdate'] = 'Griekse datum';
$string['elementtype_certstatement'] = 'Griekse verklaring';
$string['elementtype_code'] = 'Verificatiecode';
$string['elementtype_coursefield'] = 'Cursusveld';
$string['elementtype_coursename'] = 'Cursusnaam';
$string['elementtype_date'] = 'Datum';
$string['elementtype_daterange'] = 'Datumbereik';
$string['elementtype_digitalsignature'] = 'Digitale handtekening';
$string['elementtype_expiry'] = 'Vervaldatum';
$string['elementtype_grade'] = 'Cijfer';
$string['elementtype_gradeitemname'] = 'Beoordelingsonderdeelnaam';
$string['elementtype_image'] = 'Afbeelding';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Studentnaam';
$string['elementtype_teachername'] = 'Docentnaam';
$string['elementtype_text'] = 'Tekst';
$string['elementtype_userfield'] = 'Gebruikersveld';
$string['elementtype_userpicture'] = 'Gebruikersfoto';
$string['emailcertbody'] = 'Beste {$a->studentname},

Uw certificaat voor "{$a->certname}" in de cursus "{$a->coursename}" is bijgevoegd bij deze e-mail.

Verificatiecode: {$a->code}
Online verifiëren: {$a->verifyurl}

Met vriendelijke groet';
$string['emailcertificate'] = 'Certificaat e-mailen';
$string['emailcertificatebody'] = 'Beste {$a->fullname},

Uw certificaat voor "{$a->certname}" in de cursus "{$a->coursename}" is uitgegeven.

U kunt het verifiëren met code: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Uw certificaat voor {$a}';
$string['emailcertsubject'] = 'Uw certificaat: {$a}';
$string['emailcerttemplate'] = 'E-mailmelding certificaat';
$string['emailcerttemplate_default'] = 'Beste {studentname},

Uw certificaat voor "{certname}" in de cursus "{coursename}" is bijgevoegd bij deze e-mail.

Verificatiecode: {code}
Online verifiëren: {verifyurl}

Met vriendelijke groet';
$string['emailcerttemplate_desc'] = 'Berichttekst bij het e-mailen van een certificaat-PDF als bijlage. Tijdelijke aanduidingen: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Anderen e-mailen';
$string['emailothers_desc'] = 'Door komma\'s gescheiden e-mailadressen die een kopie van het certificaat ontvangen zodra het beschikbaar is.';
$string['emailsent'] = 'Certificaat succesvol per e-mail verzonden.';
$string['emailsettings'] = 'E-mailmeldingen';
$string['emailstudents'] = 'Studenten e-mailen';
$string['emailstudents_desc'] = 'Indien ingeschakeld, ontvangen studenten een kopie van het certificaat per e-mail zodra het beschikbaar is.';
$string['emailteacherbody'] = 'Een certificaat voor "{$a->certname}" is uitgegeven aan {$a->fullname} in de cursus "{$a->coursename}".';
$string['emailteachers'] = 'Docenten e-mailen';
$string['emailteachers_desc'] = 'Indien ingeschakeld, ontvangen docenten een kopie van het certificaat per e-mail zodra het beschikbaar is.';
$string['emailteachersubject'] = 'Certificaat uitgegeven: {$a->certname}';
$string['entercode'] = 'Voer de verificatiecode in';
$string['eventcertificateapproved'] = 'Certificaat goedgekeurd';
$string['eventcertificateissued'] = 'Certificaat uitgegeven';
$string['eventcertificaterejected'] = 'Certificaat afgewezen';
$string['eventcertificaterequested'] = 'Certificaat aangevraagd';
$string['eventcertificaterevoked'] = 'Certificaat ingetrokken';
$string['eventpagecreated'] = 'Pagina aangemaakt';
$string['eventpagedeleted'] = 'Pagina verwijderd';
$string['eventtemplatecreated'] = 'Sjabloon aangemaakt';
$string['eventtemplatedeleted'] = 'Sjabloon verwijderd';
$string['eventtemplateupdated'] = 'Sjabloon bijgewerkt';
$string['expired'] = 'Verlopen';
$string['expiredon'] = 'Verlopen op';
$string['expirydate'] = 'Vervaldatum';
$string['expirydays'] = 'Geldigheid certificaat (dagen)';
$string['expirydays_help'] = 'Aantal dagen dat het certificaat geldig is vanaf de datum van uitgifte. Stel in op 0 voor geen vervaldatum.';
$string['expiryperiod'] = 'Vervalperiode (dagen)';
$string['expirysettings'] = 'Vervalinstellingen';
$string['exportcsv'] = 'CSV exporteren';
$string['exportods'] = 'ODS exporteren';
$string['exporttemplate'] = 'Sjabloon exporteren';
$string['exportxlsx'] = 'XLSX exporteren';
$string['fieldname'] = 'Veldnaam';
$string['font'] = 'Lettertype';
$string['fontsize'] = 'Lettergrootte';
$string['gallerydescription'] = 'Kies een sjabloon om mee te beginnen of maak uw eigen sjabloon vanaf nul';
$string['generalsettings'] = 'Algemene instellingen';
$string['getcertificate'] = 'Certificaat ophalen';
$string['gradeitem'] = 'Beoordelingsonderdeel';
$string['height'] = 'Hoogte';
$string['importtemplate'] = 'Sjabloon importeren';
$string['invalidaction'] = 'Ongeldige actie';
$string['invalidelementdata'] = 'Ongeldige elementgegevens';
$string['invalidfilearea'] = 'Ongeldig bestandsgebied';
$string['issuedcertificates'] = 'Uitgegeven certificaten';
$string['issuedcount'] = '{$a} certificaat/certificaten uitgegeven';
$string['issuedtemplate'] = 'Melding certificaat uitgegeven';
$string['issuedtemplate_default'] = 'Beste {studentname},

Gefeliciteerd! Uw certificaat voor "{certname}" in de cursus "{coursename}" is uitgegeven.

U kunt het hier downloaden: {url}

Verificatiecode: {code}

Met vriendelijke groet';
$string['issuedtemplate_desc'] = 'Bericht dat naar de student wordt gestuurd wanneer een certificaat is uitgegeven. Tijdelijke aanduidingen: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Certificaatuitgifte niet gevonden';
$string['italic'] = 'Cursief';
$string['landscape'] = 'Liggend';
$string['layers'] = 'Lagen';
$string['loading'] = 'Laden...';
$string['lock'] = 'Vergrendelen';
$string['manageapprovals'] = 'Goedkeuringen beheren';
$string['managetemplates'] = 'Sjablonen beheren';
$string['managetemplates_desc'] = 'Sjablonen bekijken, exporteren, importeren en verwijderen. Beheer alle ingebouwde en aangepaste sjablonen vanuit één plek.';
$string['messageprovider:approval_request'] = 'Goedkeuringsaanvraag certificaat';
$string['messageprovider:approval_result'] = 'Resultaat goedkeuring certificaat';
$string['messagetemplates'] = 'Berichtsjablonen';
$string['messagetemplates_desc'] = 'Pas de meldingsberichten aan. Tijdelijke aanduidingen: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Activiteiten migreren (cursusmodules)';
$string['migrateissues'] = 'Uitgegeven certificaten migreren';
$string['migratetemplates'] = 'Sjablonen migreren (pagina\'s en elementen)';
$string['migrationcomplete'] = 'Migratie voltooid: {$a->templates} sjablo(o)n(en), {$a->activities} activiteit(en), {$a->issues} uitgifte(n) gemigreerd.';
$string['migrationlog'] = 'Migratielogboek';
$string['migrationnodata'] = 'Geen customcert-gegevens gevonden om te migreren.';
$string['migrationnotavailable'] = 'De Custom Certificate (mod_customcert) plugin is niet geïnstalleerd. Er is niets om te migreren.';
$string['migrationoptions'] = 'Migratieopties';
$string['migrationsummary'] = 'Custom Certificate gegevens gevonden';
$string['migrationtool'] = 'Migreren vanuit Custom Certificate';
$string['migrationwarning'] = 'Dit maakt nieuwe certstudio-records aan op basis van uw customcert-gegevens. Bestaande customcert-gegevens worden NIET gewijzigd of verwijderd. Reeds gemigreerde items worden overgeslagen.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studios';
$string['multilang'] = 'Meertalige certificaten';
$string['multilang_desc'] = 'Certificaattaal per activiteit forceren, waarbij de gebruikersvoorkeur wordt overschreven.';
$string['mycertificates'] = 'Mijn certificaten';
$string['name'] = 'Naam';
$string['nelements'] = '{$a} elementen';
$string['nocertificates'] = 'U heeft nog geen certificaten ontvangen.';
$string['nocertificatesissued'] = 'Er is nog geen certificaat uitgegeven. Voltooi de vereiste activiteiten om uw certificaat te ontvangen.';
$string['nodata'] = 'Geen gegevens beschikbaar.';
$string['norequests'] = 'Geen goedkeuringsaanvragen gevonden.';
$string['notapproved'] = 'Uw certificaat is nog niet goedgekeurd.';
$string['notemplates'] = 'Geen sjablonen gevonden.';
$string['notemplatesavailable'] = 'Geen sjablonen beschikbaar. Klik op "Vanaf nul beginnen" om uw eigen certificaat te maken.';
$string['notissued'] = 'Niet uitgegeven';
$string['opacity'] = 'Dekking';
$string['optional'] = 'optioneel';
$string['pages'] = 'Pagina\'s';
$string['pagesettings'] = 'Pagina-instellingen';
$string['pagesize'] = 'Paginaformaat';
$string['pdfsettings'] = 'PDF-instellingen';
$string['platform'] = 'Platform';
$string['pluginadministration'] = 'Certificate Studio beheer';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Staand';
$string['positionandsize'] = 'Positie & Grootte';
$string['previewpdf'] = 'PDF-voorbeeld';
$string['privacy:metadata:certstudio_approval_requests'] = 'Goedkeuringsaanvragen voor certificaten.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'De opmerking van de beoordelaar bij de aanvraag.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'De gebruiker die de aanvraag heeft beoordeeld.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'De goedkeuringsstatus.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Wanneer de aanvraag is gedaan.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Wanneer de aanvraag voor het laatst is bijgewerkt.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'De gebruiker die het certificaat heeft aangevraagd.';
$string['privacy:metadata:certstudio_issues'] = 'Registraties van uitgegeven certificaten.';
$string['privacy:metadata:certstudio_issues:code'] = 'De unieke verificatiecode.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'De momentopname van de certificaatsjabloongegevens.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Wanneer het certificaat is uitgegeven.';
$string['privacy:metadata:certstudio_issues:userid'] = 'De gebruiker die het certificaat heeft ontvangen.';
$string['privacy:path:approvalrequests'] = 'Goedkeuringsaanvragen';
$string['privacy:path:issues'] = 'Uitgegeven certificaten';
$string['properties'] = 'Eigenschappen';
$string['protection'] = 'PDF-beveiliging';
$string['protection_copy'] = 'Kopiëren voorkomen';
$string['protection_copy_desc'] = 'Beveiliging tegen kopiëren inschakelen.';
$string['protection_modify'] = 'Wijzigen voorkomen';
$string['protection_modify_desc'] = 'Beveiliging tegen wijzigen inschakelen.';
$string['protection_print'] = 'Afdrukken voorkomen';
$string['protection_print_desc'] = 'Beveiliging tegen afdrukken inschakelen.';
$string['protectionflags'] = 'Beveiligingsvlaggen';
$string['protectionflags_help'] = 'Door komma\'s gescheiden beveiligingsvlaggen: print, modify, copy';
$string['publishtogallery'] = 'Publiceren in galerij';
$string['publishtogallerytip'] = 'Publiceer een kopie in de sjabloongalerij zodat alle cursussen het kunnen gebruiken';
$string['reason'] = 'Reden';
$string['receiveddate'] = 'Datum ontvangen';
$string['redo'] = 'Opnieuw';
$string['reissue'] = 'Opnieuw uitgeven';
$string['reissuedtemplate'] = 'Melding certificaat opnieuw uitgegeven';
$string['reissuedtemplate_default'] = 'Beste {studentname},

Een nieuwe versie van uw certificaat voor "{certname}" in de cursus "{coursename}" is uitgegeven.

U kunt het hier downloaden: {url}

Verificatiecode: {code}

Met vriendelijke groet';
$string['reissuedtemplate_desc'] = 'Bericht dat naar de student wordt gestuurd wanneer een nieuwe versie van het certificaat is uitgegeven. Tijdelijke aanduidingen: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Afwijzen';
$string['rejected'] = 'afgewezen';
$string['rejectedtemplate'] = 'Afwijzingsmelding (naar student)';
$string['rejectedtemplate_desc'] = 'Bericht dat naar de student wordt gestuurd wanneer de aanvraag is afgewezen.';
$string['reportanalytics'] = 'Certificaatanalyses';
$string['reportmonthly'] = 'Maandelijkse trend (laatste 12 maanden)';
$string['reportpercourse'] = 'Certificaten per cursus';
$string['reportrecent'] = 'Recente certificaten (laatste 30 dagen)';
$string['reporttotalactivities'] = 'Totaal activiteiten';
$string['reporttotalissued'] = 'Totaal uitgegeven';
$string['reporttotaltemplates'] = 'Totaal sjablonen';
$string['reportuniquerecipients'] = 'Unieke ontvangers';
$string['requestagain'] = 'Nieuwe aanvraag indienen';
$string['requestapproved'] = 'Aanvraag succesvol goedgekeurd.';
$string['requestcertificate'] = 'Certificaat aanvragen';
$string['requestpending'] = 'Uw certificaataanvraag wacht op goedkeuring.';
$string['requestrejected'] = 'Uw certificaataanvraag is afgewezen.';
$string['requestrejectedmsg'] = 'Aanvraag succesvol afgewezen.';
$string['requestsubmitted'] = 'Uw certificaataanvraag is ingediend.';
$string['requiredtime'] = 'Vereiste minuten in cursus';
$string['requiredtime_desc'] = 'Minimale tijd in minuten die een student in de cursus moet zijn ingelogd voordat het certificaat kan worden ontvangen. Stel in op 0 om uit te schakelen.';
$string['requiredtimenotmet'] = 'U moet minimaal {$a->required} minuten in deze cursus doorbrengen voordat u een certificaat kunt ontvangen. U heeft tot nu toe ongeveer {$a->spent} minuten besteed.';
$string['returncourse'] = 'Knop terug naar cursus';
$string['returncourse_desc'] = 'Een knop "Terug naar cursus" weergeven op de certificaatpagina.';
$string['returntocourse'] = 'Terug naar cursus';
$string['reviewer'] = 'Beoordelaar';
$string['revokecertificate'] = 'Certificaat intrekken';
$string['revoked'] = 'Ingetrokken';
$string['revokeddate'] = 'Ingetrokken op';
$string['revokedrenewal'] = 'Ingetrokken voor vernieuwing (nieuwe versie uitgegeven)';
$string['revokedtemplate'] = 'Melding certificaat ingetrokken';
$string['revokedtemplate_default'] = 'Beste {studentname},

Uw certificaat voor "{certname}" in de cursus "{coursename}" is ingetrokken.

Reden: {reason}

Als u vragen heeft, neem dan contact op met uw docent.

Met vriendelijke groet';
$string['revokedtemplate_desc'] = 'Bericht dat naar de student wordt gestuurd wanneer het certificaat is ingetrokken. Tijdelijke aanduidingen: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Rotatie';
$string['save'] = 'Opslaan';
$string['savechangestip'] = 'Wijzigingen alleen voor deze activiteit opslaan';
$string['saved'] = 'Wijzigingen opgeslagen';
$string['saveerror'] = 'Fout bij het opslaan van wijzigingen';
$string['savestatussaved'] = 'Opgeslagen';
$string['searchbyname'] = 'Zoeken op naam...';
$string['selectelement'] = 'Klik op een element om de eigenschappen te bewerken.';
$string['selecttemplate'] = 'Sjabloon selecteren';
$string['sharecertificate'] = 'Delen';
$string['shareemailbody'] = 'Ik wilde delen dat ik het certificaat "{$a->certname}" heb behaald.

U kunt het hier verifiëren: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Mijn certificaat: {$a}';
$string['sharetext'] = 'Ik heb zojuist het certificaat "{$a}" behaald!';
$string['showcasecourse'] = 'Cursus';
$string['showcasedownloadpdf'] = 'PDF downloaden';
$string['showcaseissuedon'] = 'Uitgegeven op';
$string['showcaserecipient'] = 'Toegekend aan';
$string['showcaseshare'] = 'Dit certificaat delen';
$string['showcasetitle'] = 'Digitaal certificaat';
$string['showcaseverified'] = 'Geverifieerd certificaat';
$string['showposxy'] = 'Positie X en Y tonen';
$string['showposxy_desc'] = 'De X- en Y-positie tonen bij het bewerken van een element, zodat de gebruiker de locatie nauwkeurig kan opgeven.';
$string['startfromscratch'] = 'Vanaf nul beginnen';
$string['startmigration'] = 'Migratie starten';
$string['status'] = 'Status';
$string['statusapproved'] = 'Goedgekeurd';
$string['statusexpired'] = 'Verlopen';
$string['statuspending'] = 'In behandeling';
$string['statusrejected'] = 'Afgewezen';
$string['statusrevoked'] = 'Ingetrokken';
$string['statusvalid'] = 'Geldig';
$string['student'] = 'Student';
$string['styleclassic'] = 'Klassiek';
$string['styledark'] = 'Donker';
$string['styleelegant'] = 'Elegant';
$string['stylegradient'] = 'Verloop';
$string['styleminimal'] = 'Minimalistisch';
$string['stylemodern'] = 'Modern';
$string['stylespecial'] = 'Speciaal';
$string['subplugintype_certstudioselem'] = 'Elementtype';
$string['subplugintype_certstudioselem_plural'] = 'Elementtypen';
$string['taskemailcertificate'] = 'Certificaat e-mailen';
$string['taskissuecertificate'] = 'Certificaten uitgeven en e-mails versturen';
$string['template'] = 'Sjabloon';
$string['templatedeleted'] = 'Sjabloon "{$a}" is verwijderd.';
$string['templatefile'] = 'Sjabloonbestand (.json)';
$string['templatefilehelp'] = 'Upload een .certstudio.json-bestand dat is geëxporteerd vanuit een andere Certificate Studio-installatie.';
$string['templategallery'] = 'Sjabloongalerij';
$string['templateimported'] = 'Sjabloon "{$a->name}" succesvol geïmporteerd ({$a->pages} pagina(\'s), {$a->elements} element(en)).';
$string['templateimportinvalid'] = 'Ongeldig sjabloonbestand. Upload een geldig .certstudio.json-bestand.';
$string['templateinuse'] = 'Dit sjabloon wordt gebruikt door {$a} activiteit(en) en kan niet worden verwijderd.';
$string['templatenameplaceholder'] = 'Sjabloonnaam...';
$string['templates'] = 'Sjablonen';
$string['templatesharing'] = 'Sjabloon importeren/exporteren';
$string['textcontent'] = 'Tekstinhoud';
$string['toggleelementspanel'] = 'Elementenpaneel tonen/verbergen';
$string['togglegrid'] = 'Raster aan/uit';
$string['toggleguides'] = 'Hulplijnen aan/uit';
$string['togglepropertiespanel'] = 'Eigenschappenpaneel tonen/verbergen';
$string['typography'] = 'Typografie';
$string['undo'] = 'Ongedaan maken';
$string['unknowncourse'] = 'Onbekende cursus';
$string['unknownuser'] = 'Onbekende gebruiker';
$string['unlock'] = 'Ontgrendelen';
$string['uploadbgimage'] = 'Uploaden';
$string['uploadbgimagetip'] = 'Achtergrondafbeelding uploaden';
$string['usethisTemplate'] = 'Dit sjabloon gebruiken';
$string['usethistemplate'] = 'Dit sjabloon gebruiken';
$string['valid'] = 'Geldig';
$string['verificationcode'] = 'Verificatiecode';
$string['verify'] = 'Verifiëren';
$string['verifyallcertificates'] = 'Openbare verificatie toestaan';
$string['verifyallcertificates_desc'] = 'Iedereen toestaan certificaten te verifiëren zonder in te loggen.';
$string['verifyanother'] = 'Nog een certificaat verifiëren';
$string['verifyany'] = 'Iedereen toestaan een certificaat te verifiëren';
$string['verifyany_desc'] = 'Iedereen met de certificaatverificatielink (inclusief niet-ingelogde gebruikers) toestaan een certificaat te verifiëren.';
$string['verifycertificate'] = 'Certificaat verifiëren';
$string['verifyintro'] = 'Voer een verificatiecode van een certificaat in om de echtheid ervan te verifiëren op {$a}.';
$string['verifylink_desc'] = 'Deze link brengt u naar een pagina waar u certificaten op de site kunt verifiëren.';
$string['verifynotfound'] = 'Er is geen certificaat gevonden met deze verificatiecode. Controleer de code en probeer het opnieuw.';
$string['verifyurl'] = 'Aangepaste verificatie-URL';
$string['verifyurl_desc'] = 'Aangepaste URL voor de QR Code verificatielink. Laat leeg om de standaard Moodle-verificatiepagina te gebruiken. Tijdelijke aanduidingen: {code}';
$string['version'] = 'Versie';
$string['viewonline'] = 'Online bekijken';
$string['width'] = 'Breedte';
$string['zoomin'] = 'Inzoomen';
$string['zoomout'] = 'Uitzoomen';
