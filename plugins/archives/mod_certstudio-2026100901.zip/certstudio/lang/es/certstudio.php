<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Spanish language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Horizontal';
$string['actions'] = 'Acciones';
$string['actionsheading'] = 'Acciones';
$string['active'] = 'Activo';
$string['activities'] = 'Actividades';
$string['aiapikey'] = 'Clave API';
$string['aiapikey_desc'] = 'Su clave API para el proveedor de AI seleccionado. Obtenga una de OpenAI o Anthropic.';
$string['aierror'] = 'Error de generación con AI: {$a}';
$string['aigeneratebutton'] = 'Generar';
$string['aigeneratedesc'] = 'Describa el certificado que desea y la AI generará una plantilla para usted.';
$string['aigenerateplaceholder'] = 'ej., certificado formal azul para curso de informática con borde dorado...';
$string['aigeneratesuccess'] = '¡Plantilla generada correctamente! Redirigiendo al editor...';
$string['aigeneratetitle'] = 'Generador de plantillas con AI';
$string['aigenerating'] = 'Generando plantilla con AI...';
$string['aimodel'] = 'Modelo';
$string['aimodel_desc'] = 'El modelo de AI a utilizar. Para OpenAI: gpt-4o-mini, gpt-4o. Para Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'La clave API de AI no está configurada. Por favor, configúrela en los ajustes del complemento.';
$string['aiparseerror'] = 'Error al analizar la respuesta de AI. Por favor, intente de nuevo con una descripción diferente.';
$string['aiprovider'] = 'Proveedor de AI';
$string['aiprovider_desc'] = 'Elija qué servicio de AI utilizar para la generación de plantillas.';
$string['aisettings'] = 'Generador de plantillas con AI';
$string['aisettings_desc'] = 'Configure la generación automática de plantillas con AI. Requiere una clave API de OpenAI o Anthropic.';
$string['aligncenter'] = 'Centro';
$string['alignleft'] = 'Izquierda';
$string['alignright'] = 'Derecha';
$string['all'] = 'Todos';
$string['allcolors'] = 'Todos los colores';
$string['allstyles'] = 'Todos los estilos';
$string['alltemplates'] = 'Todas las plantillas';
$string['appearance'] = 'Apariencia';
$string['apply'] = 'Aplicar';
$string['approval'] = 'Flujo de aprobación';
$string['approvalenabled'] = 'Habilitar flujo de aprobación';
$string['approvalenabled_desc'] = 'Habilitar el flujo de aprobación por defecto para nuevas actividades.';
$string['approvalenabled_help'] = 'Cuando está habilitado, los estudiantes deben solicitar la aprobación del certificado por parte de un profesor antes de descargarlo.';
$string['approvalnotifystudent'] = 'Notificar al estudiante sobre el resultado';
$string['approvalnotifystudent_desc'] = 'Enviar notificación a los estudiantes cuando su solicitud es aprobada o rechazada.';
$string['approvalnotifyteacher'] = 'Notificar al profesor sobre la solicitud';
$string['approvalnotifyteacher_desc'] = 'Enviar notificación a los profesores cuando un estudiante solicita un certificado.';
$string['approvalrequestbody'] = '{$a->student} ha solicitado un certificado para "{$a->activity}".';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> ha solicitado un certificado para "<strong>{$a->activity}</strong>".</p><p><a href="{$a->url}">Revisar solicitudes de aprobación</a></p>';
$string['approvalrequestexists'] = 'Ya tiene una solicitud de aprobación pendiente.';
$string['approvalrequestnotfound'] = 'Solicitud de aprobación no encontrada.';
$string['approvalrequestnotpending'] = 'Esta solicitud de aprobación ya no está pendiente.';
$string['approvalrequests'] = 'Solicitudes de aprobación';
$string['approvalrequestsmall'] = 'Nueva solicitud de certificado de {$a}';
$string['approvalrequestsubject'] = 'Solicitud de aprobación de certificado: {$a}';
$string['approvalrequesttemplate'] = 'Notificación de solicitud (al profesor)';
$string['approvalrequesttemplate_desc'] = 'Mensaje enviado a los profesores cuando un estudiante solicita la aprobación del certificado.';
$string['approvalresultbody'] = 'Su solicitud de certificado para "{$a->activity}" ha sido {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Su solicitud de certificado para "<strong>{$a->activity}</strong>" ha sido <strong>{$a->status}</strong>.</p><p>Revisor: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Ver certificado</a></p>';
$string['approvalresultsmall'] = 'Solicitud de certificado {$a}';
$string['approvalresultsubject'] = 'Solicitud de certificado {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Configuración de aprobación';
$string['approve'] = 'Aprobar';
$string['approved'] = 'aprobada';
$string['approvedtemplate'] = 'Notificación de aprobación (al estudiante)';
$string['approvedtemplate_desc'] = 'Mensaje enviado al estudiante cuando su solicitud es aprobada.';
$string['autoissue'] = 'Emisión automática al completar el curso';
$string['autoissue_desc'] = 'Emitir certificados automáticamente cuando un estudiante completa el curso. Requiere que la finalización del curso esté habilitada. No se aplica a actividades con flujo de aprobación.';
$string['back'] = 'Atrás';
$string['backtoview'] = 'Volver';
$string['batchdownload'] = 'Descargar todo como ZIP';
$string['bgcolor'] = 'Color de fondo';
$string['bgimage'] = 'Imagen de fondo';
$string['bgimageopacity'] = 'Opacidad de imagen de fondo';
$string['bgimagesize'] = 'Tamaño de imagen de fondo';
$string['bgimagesizeactual'] = 'Tamaño real';
$string['bgimagesizecontain'] = 'Contener (ajustar dentro)';
$string['bgimagesizecover'] = 'Cubrir (llenar página)';
$string['bgimagesizestretch'] = 'Estirar';
$string['bold'] = 'Negrita';
$string['bordercolor'] = 'Color del borde';
$string['borderstyle'] = 'Estilo del borde';
$string['borderwidth'] = 'Ancho del borde';
$string['builtin'] = 'Integradas';
$string['builtintemplates'] = 'Plantillas integradas';
$string['bulkactions'] = 'Acciones masivas';
$string['bulkdelete'] = 'Eliminar seleccionados';
$string['bulkemail'] = 'Enviar correo a seleccionados';
$string['bulkissue'] = 'Emisión masiva';
$string['bulkissuealreadyissued'] = '{$a} estudiante(s) ya tienen un certificado (omitidos)';
$string['bulkissuecomplete'] = '{$a} certificado(s) emitido(s) correctamente.';
$string['bulkissuedefaultmessage'] = 'Estimado/a {studentname}:

¡Felicidades! Su certificado de "{certname}" en el curso "{coursename}" ha sido emitido.

Puede descargarlo aquí: {url}

Atentamente';
$string['bulkissuedesc'] = 'Emitir certificados a todos los estudiantes inscritos elegibles que aún no hayan recibido uno.';
$string['bulkissuenoeligible'] = 'Todos los estudiantes inscritos ya han recibido un certificado.';
$string['bulkissuenoselection'] = 'No se seleccionaron estudiantes.';
$string['bulkissuenotified'] = '{$a} estudiante(s) notificado(s).';
$string['bulkissuenotify'] = 'Notificar a los estudiantes';
$string['bulkissuenotifyemail'] = 'Enviar notificación por correo electrónico';
$string['bulkissuenotifymessage'] = 'Mensaje de notificación';
$string['bulkissuenotifymoodle'] = 'Enviar notificación por Moodle';
$string['bulkissuenotifyplaceholders'] = 'Marcadores de posición disponibles: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Su certificado de {$a} ha sido emitido.';
$string['bulkissuenotifysubject'] = 'Su certificado ha sido emitido: {$a}';
$string['bulkissuesubmit'] = 'Emitir certificados a {$a} estudiante(s)';
$string['bulkoperationcomplete'] = '{$a->count} certificado(s) procesado(s): {$a->action}.';
$string['bulkreissue'] = 'Reemitir seleccionados';
$string['bulkrevoke'] = 'Revocar seleccionados';
$string['certificate'] = 'Certificado';
$string['certificateexpired'] = 'Este certificado venció el {$a}.';
$string['certificateexpiredverify'] = 'Este certificado ha vencido';
$string['certificateexpires'] = 'Este certificado vence el {$a}.';
$string['certificateinvalid'] = 'Este certificado no es válido';
$string['certificateissued'] = 'Su certificado fue emitido el {$a}.';
$string['certificatenotfound'] = 'No se encontró ningún certificado con este código de verificación.';
$string['certificaterevoked'] = 'Este certificado ha sido revocado';
$string['certificaterevokedstudent'] = 'Su certificado ha sido revocado. Por favor, contacte a su profesor o administrador para más información.';
$string['certificatevalid'] = 'Este certificado es válido';
$string['certificateversion'] = 'Esta es la versión {$a} de su certificado (renovado).';
$string['certstudio:addinstance'] = 'Añadir una actividad de Certificate Studio';
$string['certstudio:approvecertificate'] = 'Aprobar solicitudes de certificados';
$string['certstudio:manage'] = 'Gestionar plantillas de certificados';
$string['certstudio:manageemailstudents'] = 'Controlar la configuración de notificaciones por correo electrónico';
$string['certstudio:manageprotection'] = 'Controlar la configuración de protección PDF';
$string['certstudio:managetemplates'] = 'Gestionar plantillas de certificados';
$string['certstudio:receiveissue'] = 'Recibir un certificado';
$string['certstudio:revokecertificate'] = 'Revocar certificados emitidos';
$string['certstudio:verifycertificate'] = 'Verificar códigos de certificados';
$string['certstudio:view'] = 'Ver certificado';
$string['certstudio:viewallcertificates'] = 'Ver todos los certificados emitidos';
$string['certstudio:viewreport'] = 'Ver informes y analíticas de certificados';
$string['city'] = 'Ciudad';
$string['clearbg'] = 'Limpiar fondo';
$string['clicktorenametemplate'] = 'Haga clic para renombrar la plantilla';
$string['codegenerationmethod'] = 'Método de generación de código';
$string['codegenerationmethod_desc'] = 'Elija entre los dos métodos para generar códigos de verificación de certificados.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Dígitos con guiones)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Cadena aleatoria de mayúsculas/minúsculas/dígitos)';
$string['color'] = 'Color';
$string['colorblue'] = 'Azul';
$string['colordark'] = 'Oscuro';
$string['colorgold'] = 'Dorado';
$string['colorgray'] = 'Gris';
$string['colorgreen'] = 'Verde';
$string['colorpink'] = 'Rosa';
$string['colorpurple'] = 'Púrpura';
$string['colorred'] = 'Rojo';
$string['comment'] = 'Comentario';
$string['confirmbulk'] = '¿Está seguro de que desea realizar esta acción masiva sobre los certificados seleccionados?';
$string['confirmdelete'] = '¿Está seguro de que desea eliminar esta plantilla? Esta acción no se puede deshacer.';
$string['confirmdeleteissue'] = '¿Está seguro de que desea eliminar permanentemente este registro de certificado?';
$string['confirmrevoke'] = '¿Está seguro de que desea revocar este certificado? La página de verificación lo mostrará como revocado.';
$string['copy'] = 'Copiar';
$string['course'] = 'Curso';
$string['createblank'] = 'Certificado en blanco';
$string['createblankdesc'] = 'Comenzar con un lienzo vacío';
$string['created'] = 'Creado';
$string['createtemplate'] = '-- Crear nueva plantilla --';
$string['current'] = 'Actual';
$string['currenttemplate'] = 'Plantilla actual';
$string['custom'] = 'Personalizado';
$string['customsource'] = 'Personalizadas';
$string['customtemplates'] = 'Plantillas personalizadas';
$string['dateformat'] = 'Formato de fecha';
$string['dateissued'] = 'Fecha de emisión';
$string['daterequested'] = 'Fecha de solicitud';
$string['defaultfilename'] = 'Nombre de archivo PDF predeterminado';
$string['defaultfilename_desc'] = 'Patrón de nombre de archivo predeterminado para los PDF descargados. Marcadores de posición: {coursename}, {studentname}, {date}, {activityname}. Se puede anular por actividad.';
$string['defaultprotection'] = 'Protección PDF predeterminada';
$string['defaultprotection_desc'] = 'Indicadores de protección predeterminados para los PDF (separados por comas): print, modify, copy. Se puede anular por actividad.';
$string['defaultvalues'] = 'Valores predeterminados para la configuración de actividades';
$string['defaultvalues_desc'] = 'Los valores predeterminados se utilizan en el formulario de configuración al crear una nueva actividad.';
$string['delete'] = 'Eliminar';
$string['deleteissuedcertificates'] = 'Eliminar certificados emitidos';
$string['downloadcertificate'] = 'Descargar certificado';
$string['downloadfilename'] = 'Nombre del archivo PDF';
$string['downloadfilename_help'] = 'Nombre de archivo personalizado para el certificado PDF descargado. Puede usar marcadores de posición: {coursename}, {studentname}, {date}. Deje vacío para usar el nombre de la actividad.';
$string['downloadsettings'] = 'Configuración de descarga';
$string['editcertstudio'] = 'Editar certificado';
$string['edittemplate'] = 'Editar plantilla';
$string['elementcount'] = '{$a} elementos';
$string['elementname'] = 'Nombre del elemento';
$string['elements'] = 'Elementos';
$string['elementtype_bgimage'] = 'Imagen de fondo';
$string['elementtype_border'] = 'Borde';
$string['elementtype_categoryname'] = 'Nombre de la categoría';
$string['elementtype_certdate'] = 'Fecha en griego';
$string['elementtype_certstatement'] = 'Declaración en griego';
$string['elementtype_code'] = 'Código de verificación';
$string['elementtype_coursefield'] = 'Campo del curso';
$string['elementtype_coursename'] = 'Nombre del curso';
$string['elementtype_date'] = 'Fecha';
$string['elementtype_daterange'] = 'Rango de fechas';
$string['elementtype_digitalsignature'] = 'Firma digital';
$string['elementtype_expiry'] = 'Fecha de vencimiento';
$string['elementtype_grade'] = 'Calificación';
$string['elementtype_gradeitemname'] = 'Nombre del ítem de calificación';
$string['elementtype_image'] = 'Imagen';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Nombre del estudiante';
$string['elementtype_teachername'] = 'Nombre del profesor';
$string['elementtype_text'] = 'Texto';
$string['elementtype_userfield'] = 'Campo del usuario';
$string['elementtype_userpicture'] = 'Foto del usuario';
$string['emailcertbody'] = 'Estimado/a {$a->studentname}:

Su certificado de "{$a->certname}" en el curso "{$a->coursename}" está adjunto a este correo electrónico.

Código de verificación: {$a->code}
Verificar en línea: {$a->verifyurl}

Atentamente';
$string['emailcertificate'] = 'Enviar certificado por correo';
$string['emailcertificatebody'] = 'Estimado/a {$a->fullname}:

Su certificado de "{$a->certname}" en el curso "{$a->coursename}" ha sido emitido.

Puede verificarlo usando el código: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Su certificado de {$a}';
$string['emailcertsubject'] = 'Su certificado: {$a}';
$string['emailcerttemplate'] = 'Notificación de certificado por correo electrónico';
$string['emailcerttemplate_default'] = 'Estimado/a {studentname}:

Su certificado de "{certname}" en el curso "{coursename}" está adjunto a este correo electrónico.

Código de verificación: {code}
Verificar en línea: {verifyurl}

Atentamente';
$string['emailcerttemplate_desc'] = 'Cuerpo del mensaje al enviar un certificado PDF como adjunto por correo electrónico. Marcadores de posición: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Enviar correo a otros';
$string['emailothers_desc'] = 'Direcciones de correo electrónico separadas por comas que recibirán una copia del certificado cuando esté disponible.';
$string['emailsent'] = 'Certificado enviado por correo electrónico correctamente.';
$string['emailsettings'] = 'Notificaciones por correo electrónico';
$string['emailstudents'] = 'Enviar correo a estudiantes';
$string['emailstudents_desc'] = 'Si está habilitado, los estudiantes recibirán una copia del certificado por correo electrónico cuando esté disponible.';
$string['emailteacherbody'] = 'Se ha emitido un certificado de "{$a->certname}" a {$a->fullname} en el curso "{$a->coursename}".';
$string['emailteachers'] = 'Enviar correo a profesores';
$string['emailteachers_desc'] = 'Si está habilitado, los profesores recibirán una copia del certificado por correo electrónico cuando esté disponible.';
$string['emailteachersubject'] = 'Certificado emitido: {$a->certname}';
$string['entercode'] = 'Introduzca el código de verificación';
$string['eventcertificateapproved'] = 'Certificado aprobado';
$string['eventcertificateissued'] = 'Certificado emitido';
$string['eventcertificaterejected'] = 'Certificado rechazado';
$string['eventcertificaterequested'] = 'Certificado solicitado';
$string['eventcertificaterevoked'] = 'Certificado revocado';
$string['eventpagecreated'] = 'Página creada';
$string['eventpagedeleted'] = 'Página eliminada';
$string['eventtemplatecreated'] = 'Plantilla creada';
$string['eventtemplatedeleted'] = 'Plantilla eliminada';
$string['eventtemplateupdated'] = 'Plantilla actualizada';
$string['expired'] = 'Vencido';
$string['expiredon'] = 'Venció el';
$string['expirydate'] = 'Fecha de vencimiento';
$string['expirydays'] = 'Validez del certificado (días)';
$string['expirydays_help'] = 'Número de días que el certificado es válido desde la fecha de emisión. Establezca 0 para sin vencimiento.';
$string['expiryperiod'] = 'Período de vencimiento (días)';
$string['expirysettings'] = 'Configuración de vencimiento';
$string['exportcsv'] = 'Exportar CSV';
$string['exportods'] = 'Exportar ODS';
$string['exporttemplate'] = 'Exportar plantilla';
$string['exportxlsx'] = 'Exportar XLSX';
$string['fieldname'] = 'Nombre del campo';
$string['font'] = 'Fuente';
$string['fontsize'] = 'Tamaño de fuente';
$string['gallerydescription'] = 'Elija una plantilla para comenzar o cree la suya desde cero';
$string['generalsettings'] = 'Configuración general';
$string['getcertificate'] = 'Obtener certificado';
$string['gradeitem'] = 'Ítem de calificación';
$string['height'] = 'Alto';
$string['importtemplate'] = 'Importar plantilla';
$string['invalidaction'] = 'Acción no válida';
$string['invalidelementdata'] = 'Datos de elemento no válidos';
$string['invalidfilearea'] = 'Área de archivo no válida';
$string['issuedcertificates'] = 'Certificados emitidos';
$string['issuedcount'] = '{$a} certificado(s) emitido(s)';
$string['issuedtemplate'] = 'Notificación de certificado emitido';
$string['issuedtemplate_default'] = 'Estimado/a {studentname}:

¡Felicidades! Su certificado de "{certname}" en el curso "{coursename}" ha sido emitido.

Puede descargarlo aquí: {url}

Código de verificación: {code}

Atentamente';
$string['issuedtemplate_desc'] = 'Mensaje enviado al estudiante cuando se emite un certificado. Marcadores de posición: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Certificado emitido no encontrado';
$string['italic'] = 'Cursiva';
$string['landscape'] = 'Horizontal';
$string['layers'] = 'Capas';
$string['loading'] = 'Cargando...';
$string['lock'] = 'Bloquear';
$string['manageapprovals'] = 'Gestionar aprobaciones';
$string['managetemplates'] = 'Gestionar plantillas';
$string['managetemplates_desc'] = 'Ver, exportar, importar y eliminar plantillas. Gestione todas las plantillas integradas y personalizadas desde un solo lugar.';
$string['messageprovider:approval_request'] = 'Solicitud de aprobación de certificado';
$string['messageprovider:approval_result'] = 'Resultado de aprobación de certificado';
$string['messagetemplates'] = 'Plantillas de mensajes';
$string['messagetemplates_desc'] = 'Personalice los mensajes de notificación. Marcadores de posición: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Migrar actividades (módulos del curso)';
$string['migrateissues'] = 'Migrar certificados emitidos';
$string['migratetemplates'] = 'Migrar plantillas (páginas y elementos)';
$string['migrationcomplete'] = 'Migración completa: {$a->templates} plantilla(s), {$a->activities} actividad(es), {$a->issues} certificado(s) emitido(s) migrado(s).';
$string['migrationlog'] = 'Registro de migración';
$string['migrationnodata'] = 'No se encontraron datos de customcert para migrar.';
$string['migrationnotavailable'] = 'El complemento Custom Certificate (mod_customcert) no está instalado. No hay nada que migrar.';
$string['migrationoptions'] = 'Opciones de migración';
$string['migrationsummary'] = 'Datos de Custom Certificate encontrados';
$string['migrationtool'] = 'Migrar desde Custom Certificate';
$string['migrationwarning'] = 'Esto creará nuevos registros de certstudio a partir de sus datos de customcert. Los datos existentes de customcert NO serán modificados ni eliminados. Los elementos ya migrados serán omitidos.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studios';
$string['multilang'] = 'Certificados multiidioma';
$string['multilang_desc'] = 'Forzar el idioma del certificado por actividad, anulando la preferencia del usuario.';
$string['mycertificates'] = 'Mis certificados';
$string['name'] = 'Nombre';
$string['nelements'] = '{$a} elementos';
$string['nocertificates'] = 'Aún no ha recibido ningún certificado.';
$string['nocertificatesissued'] = 'Aún no se ha emitido ningún certificado. Por favor, complete las actividades requeridas para recibir su certificado.';
$string['nodata'] = 'No hay datos disponibles.';
$string['norequests'] = 'No se encontraron solicitudes de aprobación.';
$string['notapproved'] = 'Su certificado aún no ha sido aprobado.';
$string['notemplates'] = 'No se encontraron plantillas.';
$string['notemplatesavailable'] = 'No hay plantillas disponibles. Haga clic en "Empezar desde cero" para crear su propio certificado.';
$string['notissued'] = 'No emitido';
$string['opacity'] = 'Opacidad';
$string['optional'] = 'opcional';
$string['pages'] = 'Páginas';
$string['pagesettings'] = 'Configuración de página';
$string['pagesize'] = 'Tamaño de página';
$string['pdfsettings'] = 'Configuración PDF';
$string['platform'] = 'Plataforma';
$string['pluginadministration'] = 'Administración de Certificate Studio';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Vertical';
$string['positionandsize'] = 'Posición y tamaño';
$string['previewpdf'] = 'Vista previa del PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Solicitudes de aprobación de certificados.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'El comentario del revisor sobre la solicitud.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'El usuario que revisó la solicitud.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'El estado de aprobación.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Cuándo se realizó la solicitud.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Cuándo se actualizó la solicitud por última vez.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'El usuario que solicitó el certificado.';
$string['privacy:metadata:certstudio_issues'] = 'Registros de certificados emitidos.';
$string['privacy:metadata:certstudio_issues:code'] = 'El código de verificación único.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'La instantánea de datos de la plantilla del certificado.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Cuándo se emitió el certificado.';
$string['privacy:metadata:certstudio_issues:userid'] = 'El usuario que recibió el certificado.';
$string['privacy:path:approvalrequests'] = 'Solicitudes de aprobación';
$string['privacy:path:issues'] = 'Certificados emitidos';
$string['properties'] = 'Propiedades';
$string['protection'] = 'Protección PDF';
$string['protection_copy'] = 'Impedir copia';
$string['protection_copy_desc'] = 'Habilitar la protección contra la acción de copiar.';
$string['protection_modify'] = 'Impedir modificación';
$string['protection_modify_desc'] = 'Habilitar la protección contra la acción de modificar.';
$string['protection_print'] = 'Impedir impresión';
$string['protection_print_desc'] = 'Habilitar la protección contra la acción de imprimir.';
$string['protectionflags'] = 'Indicadores de protección';
$string['protectionflags_help'] = 'Indicadores de protección separados por comas: print, modify, copy';
$string['publishtogallery'] = 'Publicar en la galería';
$string['publishtogallerytip'] = 'Publicar una copia en la galería de plantillas para que todos los cursos puedan usarla';
$string['reason'] = 'Motivo';
$string['receiveddate'] = 'Fecha de recepción';
$string['redo'] = 'Rehacer';
$string['reissue'] = 'Reemitir';
$string['reissuedtemplate'] = 'Notificación de certificado reemitido';
$string['reissuedtemplate_default'] = 'Estimado/a {studentname}:

Se ha emitido una nueva versión de su certificado de "{certname}" en el curso "{coursename}".

Puede descargarlo aquí: {url}

Código de verificación: {code}

Atentamente';
$string['reissuedtemplate_desc'] = 'Mensaje enviado al estudiante cuando se emite una nueva versión de su certificado. Marcadores de posición: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Rechazar';
$string['rejected'] = 'rechazada';
$string['rejectedtemplate'] = 'Notificación de rechazo (al estudiante)';
$string['rejectedtemplate_desc'] = 'Mensaje enviado al estudiante cuando su solicitud es rechazada.';
$string['reportanalytics'] = 'Analíticas de certificados';
$string['reportmonthly'] = 'Tendencia mensual (últimos 12 meses)';
$string['reportpercourse'] = 'Certificados por curso';
$string['reportrecent'] = 'Certificados recientes (últimos 30 días)';
$string['reporttotalactivities'] = 'Total de actividades';
$string['reporttotalissued'] = 'Total emitidos';
$string['reporttotaltemplates'] = 'Total de plantillas';
$string['reportuniquerecipients'] = 'Destinatarios únicos';
$string['requestagain'] = 'Enviar nueva solicitud';
$string['requestapproved'] = 'Solicitud aprobada correctamente.';
$string['requestcertificate'] = 'Solicitar certificado';
$string['requestpending'] = 'Su solicitud de certificado está pendiente de aprobación.';
$string['requestrejected'] = 'Su solicitud de certificado fue rechazada.';
$string['requestrejectedmsg'] = 'Solicitud rechazada correctamente.';
$string['requestsubmitted'] = 'Su solicitud de certificado ha sido enviada.';
$string['requiredtime'] = 'Minutos requeridos en el curso';
$string['requiredtime_desc'] = 'Tiempo mínimo en minutos que un estudiante debe estar conectado al curso antes de poder recibir el certificado. Establezca 0 para desactivar.';
$string['requiredtimenotmet'] = 'Necesita pasar al menos {$a->required} minutos en este curso antes de poder recibir un certificado. Hasta ahora ha pasado aproximadamente {$a->spent} minutos.';
$string['returncourse'] = 'Botón de regreso al curso';
$string['returncourse_desc'] = 'Mostrar un botón "Volver al curso" en la página de visualización del certificado.';
$string['returntocourse'] = 'Volver al curso';
$string['reviewer'] = 'Revisor';
$string['revokecertificate'] = 'Revocar certificado';
$string['revoked'] = 'Revocado';
$string['revokeddate'] = 'Revocado el';
$string['revokedrenewal'] = 'Revocado para renovación (nueva versión emitida)';
$string['revokedtemplate'] = 'Notificación de certificado revocado';
$string['revokedtemplate_default'] = 'Estimado/a {studentname}:

Su certificado de "{certname}" en el curso "{coursename}" ha sido revocado.

Motivo: {reason}

Si tiene alguna pregunta, por favor contacte a su instructor.

Atentamente';
$string['revokedtemplate_desc'] = 'Mensaje enviado al estudiante cuando su certificado es revocado. Marcadores de posición: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Rotación';
$string['save'] = 'Guardar';
$string['savechangestip'] = 'Guardar cambios solo en esta actividad';
$string['saved'] = 'Cambios guardados';
$string['saveerror'] = 'Error al guardar los cambios';
$string['savestatussaved'] = 'Guardado';
$string['searchbyname'] = 'Buscar por nombre...';
$string['selectelement'] = 'Haga clic en un elemento para editar sus propiedades.';
$string['selecttemplate'] = 'Seleccionar plantilla';
$string['sharecertificate'] = 'Compartir';
$string['shareemailbody'] = 'Quería compartir que obtuve el certificado "{$a->certname}".

Puede verificarlo aquí: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Mi certificado: {$a}';
$string['sharetext'] = '¡Acabo de obtener el certificado "{$a}"!';
$string['showcasecourse'] = 'Curso';
$string['showcasedownloadpdf'] = 'Descargar PDF';
$string['showcaseissuedon'] = 'Emitido el';
$string['showcaserecipient'] = 'Otorgado a';
$string['showcaseshare'] = 'Compartir este certificado';
$string['showcasetitle'] = 'Certificado digital';
$string['showcaseverified'] = 'Certificado verificado';
$string['showposxy'] = 'Mostrar posición X e Y';
$string['showposxy_desc'] = 'Mostrar la posición X e Y al editar un elemento, permitiendo al usuario especificar la ubicación con precisión.';
$string['startfromscratch'] = 'Empezar desde cero';
$string['startmigration'] = 'Iniciar migración';
$string['status'] = 'Estado';
$string['statusapproved'] = 'Aprobado';
$string['statusexpired'] = 'Vencido';
$string['statuspending'] = 'Pendiente';
$string['statusrejected'] = 'Rechazado';
$string['statusrevoked'] = 'Revocado';
$string['statusvalid'] = 'Válido';
$string['student'] = 'Estudiante';
$string['styleclassic'] = 'Clásico';
$string['styledark'] = 'Oscuro';
$string['styleelegant'] = 'Elegante';
$string['stylegradient'] = 'Degradado';
$string['styleminimal'] = 'Minimalista';
$string['stylemodern'] = 'Moderno';
$string['stylespecial'] = 'Especial';
$string['subplugintype_certstudioselem'] = 'Tipo de elemento';
$string['subplugintype_certstudioselem_plural'] = 'Tipos de elementos';
$string['taskemailcertificate'] = 'Enviar certificado por correo electrónico';
$string['taskissuecertificate'] = 'Emitir certificados y enviar correos electrónicos';
$string['template'] = 'Plantilla';
$string['templatedeleted'] = 'La plantilla "{$a}" ha sido eliminada.';
$string['templatefile'] = 'Archivo de plantilla (.json)';
$string['templatefilehelp'] = 'Suba un archivo .certstudio.json exportado desde otra instalación de Certificate Studio.';
$string['templategallery'] = 'Galería de plantillas';
$string['templateimported'] = 'Plantilla "{$a->name}" importada correctamente ({$a->pages} página(s), {$a->elements} elemento(s)).';
$string['templateimportinvalid'] = 'Archivo de plantilla no válido. Por favor, suba un archivo .certstudio.json válido.';
$string['templateinuse'] = 'Esta plantilla es utilizada por {$a} actividad(es) y no puede ser eliminada.';
$string['templatenameplaceholder'] = 'Nombre de la plantilla...';
$string['templates'] = 'Plantillas';
$string['templatesharing'] = 'Importar/Exportar plantillas';
$string['textcontent'] = 'Contenido de texto';
$string['toggleelementspanel'] = 'Mostrar/ocultar panel de elementos';
$string['togglegrid'] = 'Alternar cuadrícula';
$string['toggleguides'] = 'Alternar guías';
$string['togglepropertiespanel'] = 'Mostrar/ocultar panel de propiedades';
$string['typography'] = 'Tipografía';
$string['undo'] = 'Deshacer';
$string['unknowncourse'] = 'Curso desconocido';
$string['unknownuser'] = 'Usuario desconocido';
$string['unlock'] = 'Desbloquear';
$string['uploadbgimage'] = 'Subir';
$string['uploadbgimagetip'] = 'Subir imagen de fondo';
$string['usethisTemplate'] = 'Usar esta plantilla';
$string['usethistemplate'] = 'Usar esta plantilla';
$string['valid'] = 'Válido';
$string['verificationcode'] = 'Código de verificación';
$string['verify'] = 'Verificar';
$string['verifyallcertificates'] = 'Permitir verificación pública';
$string['verifyallcertificates_desc'] = 'Permitir que cualquier persona verifique certificados sin iniciar sesión.';
$string['verifyanother'] = 'Verificar otro certificado';
$string['verifyany'] = 'Permitir que cualquiera verifique un certificado';
$string['verifyany_desc'] = 'Permitir que cualquier persona con el enlace de verificación del certificado (incluidos usuarios que no han iniciado sesión) verifique un certificado.';
$string['verifycertificate'] = 'Verificar certificado';
$string['verifyintro'] = 'Introduzca un código de verificación de certificado para verificar su autenticidad en {$a}.';
$string['verifylink_desc'] = 'Este enlace le llevará a una página donde puede verificar certificados en el sitio.';
$string['verifynotfound'] = 'No se encontró ningún certificado con este código de verificación. Por favor, revise e intente de nuevo.';
$string['verifyurl'] = 'URL de verificación personalizada';
$string['verifyurl_desc'] = 'URL personalizada para el enlace de verificación del QR Code. Deje vacío para usar la página de verificación predeterminada de Moodle. Marcadores de posición: {code}';
$string['version'] = 'Versión';
$string['viewonline'] = 'Ver en línea';
$string['width'] = 'Ancho';
$string['zoomin'] = 'Acercar';
$string['zoomout'] = 'Alejar';
