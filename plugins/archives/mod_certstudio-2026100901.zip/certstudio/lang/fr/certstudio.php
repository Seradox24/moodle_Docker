<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * French language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['a4landscape'] = 'A4 Paysage';
$string['actions'] = 'Actions';
$string['actionsheading'] = 'Actions';
$string['active'] = 'Actif';
$string['activities'] = 'Activités';
$string['aiapikey'] = 'Clé API';
$string['aiapikey_desc'] = 'Votre clé API pour le fournisseur AI sélectionné.';
$string['aierror'] = 'Erreur de génération AI : {$a}';
$string['aigeneratebutton'] = 'Générer';
$string['aigeneratedesc'] = 'Décrivez le certificat souhaité et l\'AI générera un modèle pour vous.';
$string['aigenerateplaceholder'] = 'ex. : certificat formel bleu pour un cours informatique avec bordure dorée...';
$string['aigeneratesuccess'] = 'Modèle généré avec succès ! Redirection vers l\'éditeur...';
$string['aigeneratetitle'] = 'Générateur de modèles par AI';
$string['aigenerating'] = 'Génération du modèle avec l\'AI en cours...';
$string['aimodel'] = 'Modèle';
$string['aimodel_desc'] = 'Le modèle AI à utiliser. Pour OpenAI : gpt-4o-mini, gpt-4o. Pour Anthropic : claude-sonnet-4-20250514.';
$string['ainokey'] = 'La clé API AI n\'est pas configurée. Veuillez la définir dans les paramètres du plugin.';
$string['aiparseerror'] = 'Impossible d\'analyser la réponse de l\'AI. Veuillez réessayer avec une description différente.';
$string['aiprovider'] = 'Fournisseur AI';
$string['aiprovider_desc'] = 'Choisissez le service AI à utiliser pour la génération de modèles.';
$string['aisettings'] = 'Générateur de modèles par AI';
$string['aisettings_desc'] = 'Configurer la génération automatique de modèles par AI. Nécessite une clé API d\'OpenAI ou d\'Anthropic.';
$string['aligncenter'] = 'Centre';
$string['alignleft'] = 'Gauche';
$string['alignright'] = 'Droite';
$string['all'] = 'Tous';
$string['allcolors'] = 'Toutes les couleurs';
$string['allstyles'] = 'Tous les styles';
$string['alltemplates'] = 'Tous les modèles';
$string['appearance'] = 'Apparence';
$string['apply'] = 'Appliquer';
$string['approval'] = 'Processus d\'approbation';
$string['approvalenabled'] = 'Activer le processus d\'approbation';
$string['approvalenabled_desc'] = 'Activer le processus d\'approbation par défaut pour les nouvelles activités.';
$string['approvalenabled_help'] = 'Lorsque cette option est activée, les étudiants doivent demander l\'approbation d\'un enseignant avant de pouvoir télécharger leur certificat.';
$string['approvalnotifystudent'] = 'Notifier l\'étudiant du résultat';
$string['approvalnotifystudent_desc'] = 'Envoyer une notification aux étudiants lorsque leur demande est approuvée ou rejetée.';
$string['approvalnotifyteacher'] = 'Notifier l\'enseignant lors d\'une demande';
$string['approvalnotifyteacher_desc'] = 'Envoyer une notification aux enseignants lorsqu\'un étudiant demande un certificat.';
$string['approvalrequestbody'] = '{$a->student} a demandé un certificat pour « {$a->activity} ».';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> a demandé un certificat pour « <strong>{$a->activity}</strong> ».</p><p><a href="{$a->url}">Examiner les demandes d\'approbation</a></p>';
$string['approvalrequestexists'] = 'Vous avez déjà une demande d\'approbation en attente.';
$string['approvalrequestnotfound'] = 'Demande d\'approbation introuvable.';
$string['approvalrequestnotpending'] = 'Cette demande d\'approbation n\'est plus en attente.';
$string['approvalrequests'] = 'Demandes d\'approbation';
$string['approvalrequestsmall'] = 'Nouvelle demande de certificat de {$a}';
$string['approvalrequestsubject'] = 'Demande d\'approbation de certificat : {$a}';
$string['approvalrequesttemplate'] = 'Notification de demande (à l\'enseignant)';
$string['approvalrequesttemplate_desc'] = 'Message envoyé aux enseignants lorsqu\'un étudiant demande l\'approbation d\'un certificat.';
$string['approvalresultbody'] = 'Votre demande de certificat pour « {$a->activity} » a été {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Votre demande de certificat pour « <strong>{$a->activity}</strong> » a été <strong>{$a->status}</strong>.</p><p>Évaluateur : {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Voir le certificat</a></p>';
$string['approvalresultsmall'] = 'Demande de certificat {$a}';
$string['approvalresultsubject'] = 'Demande de certificat {$a->status} : {$a->activity}';
$string['approvalsettings'] = 'Paramètres d\'approbation';
$string['approve'] = 'Approuver';
$string['approved'] = 'approuvée';
$string['approvedtemplate'] = 'Notification d\'approbation (à l\'étudiant)';
$string['approvedtemplate_desc'] = 'Message envoyé à l\'étudiant lorsque sa demande est approuvée.';
$string['autoissue'] = 'Délivrance automatique à l\'achèvement du cours';
$string['autoissue_desc'] = 'Délivrer automatiquement les certificats lorsqu\'un étudiant termine le cours. L\'achèvement du cours doit être activé.';
$string['back'] = 'Retour';
$string['backtoview'] = 'Retour';
$string['batchdownload'] = 'Télécharger tout en ZIP';
$string['bgcolor'] = 'Couleur de fond';
$string['bgimage'] = 'Image de fond';
$string['bgimageopacity'] = 'Opacité de l\'image de fond';
$string['bgimagesize'] = 'Taille de l\'image de fond';
$string['bgimagesizeactual'] = 'Taille réelle';
$string['bgimagesizecontain'] = 'Contenir (ajuster à l\'intérieur)';
$string['bgimagesizecover'] = 'Couvrir (remplir la page)';
$string['bgimagesizestretch'] = 'Étirer';
$string['bold'] = 'Gras';
$string['bordercolor'] = 'Couleur de la bordure';
$string['borderstyle'] = 'Style de la bordure';
$string['borderwidth'] = 'Épaisseur de la bordure';
$string['builtin'] = 'Intégrés';
$string['builtintemplates'] = 'Modèles intégrés';
$string['bulkactions'] = 'Actions groupées';
$string['bulkdelete'] = 'Supprimer la sélection';
$string['bulkemail'] = 'Envoyer par courriel la sélection';
$string['bulkissue'] = 'Délivrance groupée';
$string['bulkissuealreadyissued'] = '{$a} étudiant(s) possèdent déjà un certificat (ignoré(s))';
$string['bulkissuecomplete'] = '{$a} certificat(s) délivré(s) avec succès.';
$string['bulkissuedefaultmessage'] = 'Cher/Chère {studentname},

Félicitations ! Votre certificat pour « {certname} » dans le cours « {coursename} » a été délivré.

Vous pouvez le télécharger ici : {url}

Cordialement';
$string['bulkissuedesc'] = 'Délivrer des certificats à tous les étudiants inscrits éligibles qui n\'en ont pas encore reçu.';
$string['bulkissuenoeligible'] = 'Tous les étudiants inscrits ont déjà reçu un certificat.';
$string['bulkissuenoselection'] = 'Aucun étudiant sélectionné.';
$string['bulkissuenotified'] = '{$a} étudiant(s) notifié(s).';
$string['bulkissuenotify'] = 'Notifier les étudiants';
$string['bulkissuenotifyemail'] = 'Envoyer la notification par courriel';
$string['bulkissuenotifymessage'] = 'Message de notification';
$string['bulkissuenotifymoodle'] = 'Envoyer la notification via Moodle';
$string['bulkissuenotifyplaceholders'] = 'Variables disponibles : {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Votre certificat pour {$a} a été délivré.';
$string['bulkissuenotifysubject'] = 'Votre certificat a été délivré : {$a}';
$string['bulkissuesubmit'] = 'Délivrer des certificats à {$a} étudiant(s)';
$string['bulkoperationcomplete'] = '{$a->count} certificat(s) traité(s) : {$a->action}.';
$string['bulkreissue'] = 'Redélivrer la sélection';
$string['bulkrevoke'] = 'Révoquer la sélection';
$string['certificate'] = 'Certificat';
$string['certificateexpired'] = 'Ce certificat a expiré le {$a}.';
$string['certificateexpiredverify'] = 'Ce certificat a expiré';
$string['certificateexpires'] = 'Ce certificat expire le {$a}.';
$string['certificateinvalid'] = 'Ce certificat est invalide';
$string['certificateissued'] = 'Votre certificat a été délivré le {$a}.';
$string['certificatenotfound'] = 'Aucun certificat trouvé avec ce code de vérification.';
$string['certificaterevoked'] = 'Ce certificat a été révoqué';
$string['certificaterevokedstudent'] = 'Votre certificat a été révoqué. Veuillez contacter votre enseignant ou administrateur.';
$string['certificatevalid'] = 'Ce certificat est valide';
$string['certificateversion'] = 'Ceci est la version {$a} de votre certificat (renouvelé).';
$string['certstudio:addinstance'] = 'Ajouter une activité Certificate Studio';
$string['certstudio:approvecertificate'] = 'Approuver les demandes de certificats';
$string['certstudio:manage'] = 'Gérer les modèles de certificats';
$string['certstudio:manageemailstudents'] = 'Contrôler les paramètres de notification par courriel';
$string['certstudio:manageprotection'] = 'Contrôler les paramètres de protection PDF';
$string['certstudio:managetemplates'] = 'Gérer les modèles de certificats';
$string['certstudio:receiveissue'] = 'Recevoir un certificat';
$string['certstudio:revokecertificate'] = 'Révoquer les certificats délivrés';
$string['certstudio:verifycertificate'] = 'Vérifier les codes de certificats';
$string['certstudio:view'] = 'Voir le certificat';
$string['certstudio:viewallcertificates'] = 'Voir tous les certificats délivrés';
$string['certstudio:viewreport'] = 'Voir les rapports et analyses de certificats';
$string['city'] = 'Ville';
$string['clearbg'] = 'Effacer le fond';
$string['clicktorenametemplate'] = 'Cliquez pour renommer le modèle';
$string['codegenerationmethod'] = 'Méthode de génération de code';
$string['codegenerationmethod_desc'] = 'Choisissez entre les deux méthodes de génération des codes de vérification des certificats.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Chiffres avec tirets)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Chaîne aléatoire majuscules/minuscules/chiffres)';
$string['color'] = 'Couleur';
$string['colorblue'] = 'Bleu';
$string['colordark'] = 'Sombre';
$string['colorgold'] = 'Or';
$string['colorgray'] = 'Gris';
$string['colorgreen'] = 'Vert';
$string['colorpink'] = 'Rose';
$string['colorpurple'] = 'Violet';
$string['colorred'] = 'Rouge';
$string['comment'] = 'Commentaire';
$string['confirmbulk'] = 'Êtes-vous sûr de vouloir effectuer cette action groupée sur les certificats sélectionnés ?';
$string['confirmdelete'] = 'Êtes-vous sûr de vouloir supprimer ce modèle ? Cette action est irréversible.';
$string['confirmdeleteissue'] = 'Êtes-vous sûr de vouloir supprimer définitivement cet enregistrement de certificat ?';
$string['confirmrevoke'] = 'Êtes-vous sûr de vouloir révoquer ce certificat ?';
$string['copy'] = 'Copier';
$string['course'] = 'Cours';
$string['createblank'] = 'Certificat vierge';
$string['createblankdesc'] = 'Commencer avec un canevas vide';
$string['created'] = 'Créé';
$string['createtemplate'] = '-- Créer un nouveau modèle --';
$string['current'] = 'Actuel';
$string['currenttemplate'] = 'Modèle actuel';
$string['custom'] = 'Personnalisé';
$string['customsource'] = 'Personnalisés';
$string['customtemplates'] = 'Modèles personnalisés';
$string['dateformat'] = 'Format de date';
$string['dateissued'] = 'Date de délivrance';
$string['daterequested'] = 'Date de la demande';
$string['defaultfilename'] = 'Nom de fichier PDF par défaut';
$string['defaultfilename_desc'] = 'Modèle de nom de fichier par défaut pour les PDF téléchargés. Variables : {coursename}, {studentname}, {date}, {activityname}. Peut être remplacé par activité.';
$string['defaultprotection'] = 'Protection PDF par défaut';
$string['defaultprotection_desc'] = 'Options de protection par défaut pour les PDF (séparées par des virgules) : print, modify, copy. Peut être remplacé par activité.';
$string['defaultvalues'] = 'Valeurs par défaut des paramètres d\'activité';
$string['defaultvalues_desc'] = 'Les valeurs par défaut sont utilisées dans le formulaire de paramètres lors de la création d\'une nouvelle activité.';
$string['delete'] = 'Supprimer';
$string['deleteissuedcertificates'] = 'Supprimer les certificats délivrés';
$string['downloadcertificate'] = 'Télécharger le certificat';
$string['downloadfilename'] = 'Nom du fichier PDF';
$string['downloadfilename_help'] = 'Nom de fichier personnalisé pour le certificat PDF téléchargé. Vous pouvez utiliser les variables : {coursename}, {studentname}, {date}. Laissez vide pour utiliser le nom de l\'activité.';
$string['downloadsettings'] = 'Paramètres de téléchargement';
$string['editcertstudio'] = 'Modifier le certificat';
$string['edittemplate'] = 'Modifier le modèle';
$string['elementcount'] = '{$a} éléments';
$string['elementname'] = 'Nom de l\'élément';
$string['elements'] = 'Éléments';
$string['elementtype_bgimage'] = 'Image d\'arrière-plan';
$string['elementtype_border'] = 'Bordure';
$string['elementtype_categoryname'] = 'Nom de la catégorie';
$string['elementtype_certdate'] = 'Date grecque';
$string['elementtype_certstatement'] = 'Déclaration grecque';
$string['elementtype_code'] = 'Code de vérification';
$string['elementtype_coursefield'] = 'Champ de cours';
$string['elementtype_coursename'] = 'Nom du cours';
$string['elementtype_date'] = 'Date';
$string['elementtype_daterange'] = 'Plage de dates';
$string['elementtype_digitalsignature'] = 'Signature numérique';
$string['elementtype_expiry'] = 'Date d\'expiration';
$string['elementtype_grade'] = 'Note';
$string['elementtype_gradeitemname'] = 'Nom de l\'élément de note';
$string['elementtype_image'] = 'Image';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Nom de l\'étudiant';
$string['elementtype_teachername'] = 'Nom de l\'enseignant';
$string['elementtype_text'] = 'Texte';
$string['elementtype_userfield'] = 'Champ utilisateur';
$string['elementtype_userpicture'] = 'Photo de l\'utilisateur';
$string['emailcertbody'] = 'Cher/Chère {$a->studentname},

Votre certificat pour « {$a->certname} » dans le cours « {$a->coursename} » est joint à ce courriel.

Code de vérification : {$a->code}
Vérifier en ligne : {$a->verifyurl}

Cordialement';
$string['emailcertificate'] = 'Envoyer le certificat par courriel';
$string['emailcertificatebody'] = 'Cher/Chère {$a->fullname},

Votre certificat pour « {$a->certname} » dans le cours « {$a->coursename} » a été délivré.

Vous pouvez le vérifier avec le code : {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Votre certificat pour {$a}';
$string['emailcertsubject'] = 'Votre certificat : {$a}';
$string['emailcerttemplate'] = 'Notification de certificat par courriel';
$string['emailcerttemplate_default'] = 'Cher/Chère {studentname},

Votre certificat pour « {certname} » dans le cours « {coursename} » est joint à ce courriel.

Code de vérification : {code}
Vérifier en ligne : {verifyurl}

Cordialement';
$string['emailcerttemplate_desc'] = 'Corps du message lors de l\'envoi d\'un certificat PDF en pièce jointe.';
$string['emailothers'] = 'Envoyer un courriel à d\'autres personnes';
$string['emailothers_desc'] = 'Adresses courriel séparées par des virgules qui recevront une copie du certificat lorsqu\'il sera disponible.';
$string['emailsent'] = 'Certificat envoyé par courriel avec succès.';
$string['emailsettings'] = 'Notifications par courriel';
$string['emailstudents'] = 'Envoyer un courriel aux étudiants';
$string['emailstudents_desc'] = 'Si activé, les étudiants recevront une copie du certificat par courriel lorsqu\'il sera disponible.';
$string['emailteacherbody'] = 'Un certificat pour « {$a->certname} » a été délivré à {$a->fullname} dans le cours « {$a->coursename} ».';
$string['emailteachers'] = 'Envoyer un courriel aux enseignants';
$string['emailteachers_desc'] = 'Si activé, les enseignants recevront une copie du certificat par courriel lorsqu\'il sera disponible.';
$string['emailteachersubject'] = 'Certificat délivré : {$a->certname}';
$string['entercode'] = 'Entrez le code de vérification';
$string['eventcertificateapproved'] = 'Certificat approuvé';
$string['eventcertificateissued'] = 'Certificat délivré';
$string['eventcertificaterejected'] = 'Certificat rejeté';
$string['eventcertificaterequested'] = 'Certificat demandé';
$string['eventcertificaterevoked'] = 'Certificat révoqué';
$string['eventpagecreated'] = 'Page créée';
$string['eventpagedeleted'] = 'Page supprimée';
$string['eventtemplatecreated'] = 'Modèle créé';
$string['eventtemplatedeleted'] = 'Modèle supprimé';
$string['eventtemplateupdated'] = 'Modèle mis à jour';
$string['expired'] = 'Expiré';
$string['expiredon'] = 'Expiré le';
$string['expirydate'] = 'Date d\'expiration';
$string['expirydays'] = 'Validité du certificat (jours)';
$string['expirydays_help'] = 'Nombre de jours pendant lesquels le certificat est valide à compter de la date de délivrance. Mettre à 0 pour aucune expiration.';
$string['expiryperiod'] = 'Période d\'expiration (jours)';
$string['expirysettings'] = 'Paramètres d\'expiration';
$string['exportcsv'] = 'Exporter en CSV';
$string['exportods'] = 'Exporter en ODS';
$string['exporttemplate'] = 'Exporter le modèle';
$string['exportxlsx'] = 'Exporter en XLSX';
$string['fieldname'] = 'Nom du champ';
$string['font'] = 'Police';
$string['fontsize'] = 'Taille de la police';
$string['gallerydescription'] = 'Choisissez un modèle pour commencer ou créez le vôtre de zéro';
$string['generalsettings'] = 'Paramètres généraux';
$string['getcertificate'] = 'Obtenir le certificat';
$string['gradeitem'] = 'Élément de note';
$string['height'] = 'Hauteur';
$string['importtemplate'] = 'Importer un modèle';
$string['invalidaction'] = 'Action invalide';
$string['invalidelementdata'] = 'Données d\'élément invalides';
$string['invalidfilearea'] = 'Zone de fichier invalide';
$string['issuedcertificates'] = 'Certificats délivrés';
$string['issuedcount'] = '{$a} certificat(s) délivré(s)';
$string['issuedtemplate'] = 'Notification de délivrance de certificat';
$string['issuedtemplate_default'] = 'Cher/Chère {studentname},

Félicitations ! Votre certificat pour « {certname} » dans le cours « {coursename} » a été délivré.

Vous pouvez le télécharger ici : {url}

Code de vérification : {code}

Cordialement';
$string['issuedtemplate_desc'] = 'Message envoyé à l\'étudiant lorsqu\'un certificat est délivré.';
$string['issuenotfound'] = 'Certificat délivré introuvable';
$string['italic'] = 'Italique';
$string['landscape'] = 'Paysage';
$string['layers'] = 'Calques';
$string['loading'] = 'Chargement...';
$string['lock'] = 'Verrouiller';
$string['manageapprovals'] = 'Gérer les approbations';
$string['managetemplates'] = 'Gérer les modèles';
$string['managetemplates_desc'] = 'Afficher, exporter, importer et supprimer des modèles. Gérez tous les modèles intégrés et personnalisés depuis un seul endroit.';
$string['messageprovider:approval_request'] = 'Demande d\'approbation de certificat';
$string['messageprovider:approval_result'] = 'Résultat de la demande d\'approbation de certificat';
$string['messagetemplates'] = 'Modèles de messages';
$string['messagetemplates_desc'] = 'Personnalisez les messages de notification. Variables : {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Migrer les activités (modules de cours)';
$string['migrateissues'] = 'Migrer les certificats délivrés';
$string['migratetemplates'] = 'Migrer les modèles (pages et éléments)';
$string['migrationcomplete'] = 'Migration terminée : {$a->templates} modèle(s), {$a->activities} activité(s), {$a->issues} certificat(s) délivré(s) migré(s).';
$string['migrationlog'] = 'Journal de migration';
$string['migrationnodata'] = 'Aucune donnée customcert trouvée à migrer.';
$string['migrationnotavailable'] = 'Le plugin Custom Certificate (mod_customcert) n\'est pas installé. Rien à migrer.';
$string['migrationoptions'] = 'Options de migration';
$string['migrationsummary'] = 'Données Custom Certificate trouvées';
$string['migrationtool'] = 'Migrer depuis Custom Certificate';
$string['migrationwarning'] = 'Cela créera de nouveaux enregistrements certstudio à partir de vos données customcert. Les données customcert existantes ne seront PAS modifiées ni supprimées.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studios';
$string['multilang'] = 'Certificats multilingues';
$string['multilang_desc'] = 'Forcer la langue du certificat par activité, en remplaçant la préférence de l\'utilisateur.';
$string['mycertificates'] = 'Mes certificats';
$string['name'] = 'Nom';
$string['nelements'] = '{$a} éléments';
$string['nocertificates'] = 'Vous n\'avez encore reçu aucun certificat.';
$string['nocertificatesissued'] = 'Aucun certificat n\'a encore été délivré. Veuillez compléter les activités requises pour recevoir votre certificat.';
$string['nodata'] = 'Aucune donnée disponible.';
$string['norequests'] = 'Aucune demande d\'approbation trouvée.';
$string['notapproved'] = 'Votre certificat n\'a pas encore été approuvé.';
$string['notemplates'] = 'Aucun modèle trouvé.';
$string['notemplatesavailable'] = 'Aucun modèle disponible. Cliquez sur « Créer de zéro » pour créer votre propre certificat.';
$string['notissued'] = 'Non délivré';
$string['opacity'] = 'Opacité';
$string['optional'] = 'facultatif';
$string['pages'] = 'Pages';
$string['pagesettings'] = 'Paramètres de la page';
$string['pagesize'] = 'Taille de la page';
$string['pdfsettings'] = 'Paramètres PDF';
$string['platform'] = 'Plateforme';
$string['pluginadministration'] = 'Administration de Certificate Studio';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Portrait';
$string['positionandsize'] = 'Position et taille';
$string['previewpdf'] = 'Aperçu PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Demandes d\'approbation de certificats.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'Le commentaire de l\'évaluateur sur la demande.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'L\'utilisateur qui a examiné la demande.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'Le statut de l\'approbation.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Date de soumission de la demande.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Date de la dernière mise à jour de la demande.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'L\'utilisateur qui a demandé le certificat.';
$string['privacy:metadata:certstudio_issues'] = 'Enregistrements des certificats délivrés.';
$string['privacy:metadata:certstudio_issues:code'] = 'Le code de vérification unique.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'L\'instantané des données du modèle de certificat.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Date de délivrance du certificat.';
$string['privacy:metadata:certstudio_issues:userid'] = 'L\'utilisateur qui a reçu le certificat.';
$string['privacy:path:approvalrequests'] = 'Demandes d\'approbation';
$string['privacy:path:issues'] = 'Certificats délivrés';
$string['properties'] = 'Propriétés';
$string['protection'] = 'Protection PDF';
$string['protection_copy'] = 'Empêcher la copie';
$string['protection_copy_desc'] = 'Activer la protection contre la copie.';
$string['protection_modify'] = 'Empêcher la modification';
$string['protection_modify_desc'] = 'Activer la protection contre la modification.';
$string['protection_print'] = 'Empêcher l\'impression';
$string['protection_print_desc'] = 'Activer la protection contre l\'impression.';
$string['protectionflags'] = 'Options de protection';
$string['protectionflags_help'] = 'Options de protection séparées par des virgules : print, modify, copy';
$string['publishtogallery'] = 'Publier dans la galerie';
$string['publishtogallerytip'] = 'Publier une copie dans la galerie de modèles pour que tous les cours puissent l\'utiliser';
$string['reason'] = 'Motif';
$string['receiveddate'] = 'Date de réception';
$string['redo'] = 'Rétablir';
$string['reissue'] = 'Redélivrer';
$string['reissuedtemplate'] = 'Notification de renouvellement de certificat';
$string['reissuedtemplate_default'] = 'Cher/Chère {studentname},

Une nouvelle version de votre certificat pour « {certname} » dans le cours « {coursename} » a été délivrée.

Vous pouvez le télécharger ici : {url}

Code de vérification : {code}

Cordialement';
$string['reissuedtemplate_desc'] = 'Message envoyé à l\'étudiant lorsqu\'une nouvelle version de son certificat est délivrée.';
$string['reject'] = 'Rejeter';
$string['rejected'] = 'rejetée';
$string['rejectedtemplate'] = 'Notification de rejet (à l\'étudiant)';
$string['rejectedtemplate_desc'] = 'Message envoyé à l\'étudiant lorsque sa demande est rejetée.';
$string['reportanalytics'] = 'Analyses des certificats';
$string['reportmonthly'] = 'Tendance mensuelle (12 derniers mois)';
$string['reportpercourse'] = 'Certificats par cours';
$string['reportrecent'] = 'Certificats récents (30 derniers jours)';
$string['reporttotalactivities'] = 'Total des activités';
$string['reporttotalissued'] = 'Total délivré';
$string['reporttotaltemplates'] = 'Total des modèles';
$string['reportuniquerecipients'] = 'Bénéficiaires uniques';
$string['requestagain'] = 'Soumettre une nouvelle demande';
$string['requestapproved'] = 'Demande approuvée avec succès.';
$string['requestcertificate'] = 'Demander un certificat';
$string['requestpending'] = 'Votre demande de certificat est en attente d\'approbation.';
$string['requestrejected'] = 'Votre demande de certificat a été rejetée.';
$string['requestrejectedmsg'] = 'Demande rejetée avec succès.';
$string['requestsubmitted'] = 'Votre demande de certificat a été soumise.';
$string['requiredtime'] = 'Temps minimum requis dans le cours (minutes)';
$string['requiredtime_desc'] = 'Durée minimale en minutes qu\'un étudiant doit passer connecté au cours avant de pouvoir recevoir le certificat. Mettre à 0 pour désactiver.';
$string['requiredtimenotmet'] = 'Vous devez passer au moins {$a->required} minutes dans ce cours avant de pouvoir recevoir un certificat. Vous avez passé environ {$a->spent} minutes jusqu\'à présent.';
$string['returncourse'] = 'Bouton de retour au cours';
$string['returncourse_desc'] = 'Afficher un bouton « Retour au cours » sur la page de visualisation du certificat.';
$string['returntocourse'] = 'Retour au cours';
$string['reviewer'] = 'Évaluateur';
$string['revokecertificate'] = 'Révoquer le certificat';
$string['revoked'] = 'Révoqué';
$string['revokeddate'] = 'Révoqué le';
$string['revokedrenewal'] = 'Révoqué pour renouvellement (nouvelle version délivrée)';
$string['revokedtemplate'] = 'Notification de révocation de certificat';
$string['revokedtemplate_default'] = 'Cher/Chère {studentname},

Votre certificat pour « {certname} » dans le cours « {coursename} » a été révoqué.

Motif : {reason}

Si vous avez des questions, veuillez contacter votre enseignant.

Cordialement';
$string['revokedtemplate_desc'] = 'Message envoyé à l\'étudiant lorsque son certificat est révoqué.';
$string['rotation'] = 'Rotation';
$string['save'] = 'Enregistrer';
$string['savechangestip'] = 'Enregistrer les modifications uniquement pour cette activité';
$string['saved'] = 'Modifications enregistrées';
$string['saveerror'] = 'Erreur lors de l\'enregistrement des modifications';
$string['savestatussaved'] = 'Enregistré';
$string['searchbyname'] = 'Rechercher par nom...';
$string['selectelement'] = 'Cliquez sur un élément pour modifier ses propriétés.';
$string['selecttemplate'] = 'Sélectionner un modèle';
$string['sharecertificate'] = 'Partager';
$string['shareemailbody'] = 'Je souhaitais partager avec vous que j\'ai obtenu le certificat « {$a->certname} ».

Vous pouvez le vérifier ici : {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Mon certificat : {$a}';
$string['sharetext'] = 'Je viens d\'obtenir le certificat « {$a} » !';
$string['showcasecourse'] = 'Cours';
$string['showcasedownloadpdf'] = 'Télécharger le PDF';
$string['showcaseissuedon'] = 'Délivré le';
$string['showcaserecipient'] = 'Décerné à';
$string['showcaseshare'] = 'Partager ce certificat';
$string['showcasetitle'] = 'Certificat numérique';
$string['showcaseverified'] = 'Certificat vérifié';
$string['showposxy'] = 'Afficher la position X et Y';
$string['showposxy_desc'] = 'Afficher la position X et Y lors de la modification d\'un élément, permettant à l\'utilisateur de spécifier précisément l\'emplacement.';
$string['startfromscratch'] = 'Partir de zéro';
$string['startmigration'] = 'Démarrer la migration';
$string['status'] = 'Statut';
$string['statusapproved'] = 'Approuvé';
$string['statusexpired'] = 'Expiré';
$string['statuspending'] = 'En attente';
$string['statusrejected'] = 'Rejeté';
$string['statusrevoked'] = 'Révoqué';
$string['statusvalid'] = 'Valide';
$string['student'] = 'Étudiant';
$string['styleclassic'] = 'Classique';
$string['styledark'] = 'Sombre';
$string['styleelegant'] = 'Élégant';
$string['stylegradient'] = 'Dégradé';
$string['styleminimal'] = 'Minimaliste';
$string['stylemodern'] = 'Moderne';
$string['stylespecial'] = 'Spécial';
$string['subplugintype_certstudioselem'] = 'Type d\'élément';
$string['subplugintype_certstudioselem_plural'] = 'Types d\'éléments';
$string['taskemailcertificate'] = 'Envoyer le certificat par courriel';
$string['taskissuecertificate'] = 'Délivrer les certificats et envoyer les courriels';
$string['template'] = 'Modèle';
$string['templatedeleted'] = 'Le modèle « {$a} » a été supprimé.';
$string['templatefile'] = 'Fichier de modèle (.json)';
$string['templatefilehelp'] = 'Déposez un fichier .certstudio.json exporté depuis une autre installation de Certificate Studio.';
$string['templategallery'] = 'Galerie de modèles';
$string['templateimported'] = 'Modèle « {$a->name} » importé avec succès ({$a->pages} page(s), {$a->elements} élément(s)).';
$string['templateimportinvalid'] = 'Fichier de modèle invalide. Veuillez déposer un fichier .certstudio.json valide.';
$string['templateinuse'] = 'Ce modèle est utilisé par {$a} activité(s) et ne peut pas être supprimé.';
$string['templatenameplaceholder'] = 'Nom du modèle...';
$string['templates'] = 'Modèles';
$string['templatesharing'] = 'Import/Export de modèles';
$string['textcontent'] = 'Contenu du texte';
$string['toggleelementspanel'] = 'Afficher/masquer le panneau des éléments';
$string['togglegrid'] = 'Afficher/masquer la grille';
$string['toggleguides'] = 'Afficher/masquer les repères';
$string['togglepropertiespanel'] = 'Afficher/masquer le panneau des propriétés';
$string['typography'] = 'Typographie';
$string['undo'] = 'Annuler';
$string['unknowncourse'] = 'Cours inconnu';
$string['unknownuser'] = 'Utilisateur inconnu';
$string['unlock'] = 'Déverrouiller';
$string['uploadbgimage'] = 'Télécharger';
$string['uploadbgimagetip'] = 'Télécharger une image de fond';
$string['usethisTemplate'] = 'Utiliser ce modèle';
$string['usethistemplate'] = 'Utiliser ce modèle';
$string['valid'] = 'Valide';
$string['verificationcode'] = 'Code de vérification';
$string['verify'] = 'Vérifier';
$string['verifyallcertificates'] = 'Autoriser la vérification publique';
$string['verifyallcertificates_desc'] = 'Permettre à quiconque de vérifier les certificats sans se connecter.';
$string['verifyanother'] = 'Vérifier un autre certificat';
$string['verifyany'] = 'Permettre à quiconque de vérifier un certificat';
$string['verifyany_desc'] = 'Permettre à quiconque disposant du lien de vérification (y compris les utilisateurs non connectés) de vérifier un certificat.';
$string['verifycertificate'] = 'Vérifier le certificat';
$string['verifyintro'] = 'Entrez un code de vérification de certificat pour vérifier son authenticité sur {$a}.';
$string['verifylink_desc'] = 'Ce lien vous mènera à une page où vous pourrez vérifier les certificats sur le site.';
$string['verifynotfound'] = 'Aucun certificat n\'a été trouvé avec ce code de vérification. Veuillez vérifier et réessayer.';
$string['verifyurl'] = 'URL de vérification personnalisée';
$string['verifyurl_desc'] = 'URL personnalisée pour le lien de vérification du QR Code. Laissez vide pour utiliser la page de vérification Moodle par défaut. Variables : {code}';
$string['version'] = 'Version';
$string['viewonline'] = 'Voir en ligne';
$string['width'] = 'Largeur';
$string['zoomin'] = 'Zoom avant';
$string['zoomout'] = 'Zoom arrière';
