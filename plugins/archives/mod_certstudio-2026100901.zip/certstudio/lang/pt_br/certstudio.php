<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Brazilian Portuguese language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Paisagem';
$string['actions'] = 'Ações';
$string['actionsheading'] = 'Ações';
$string['active'] = 'Ativo';
$string['activities'] = 'Atividades';
$string['aiapikey'] = 'Chave de API';
$string['aiapikey_desc'] = 'Sua chave de API para o provedor de AI selecionado. Obtenha uma no OpenAI ou Anthropic.';
$string['aierror'] = 'Erro na geração com AI: {$a}';
$string['aigeneratebutton'] = 'Gerar';
$string['aigeneratedesc'] = 'Descreva o certificado que você deseja e a AI gerará um modelo para você.';
$string['aigenerateplaceholder'] = 'ex.: certificado formal azul para curso de TI com borda dourada...';
$string['aigeneratesuccess'] = 'Modelo gerado com sucesso! Redirecionando para o editor...';
$string['aigeneratetitle'] = 'Gerador de Modelos com AI';
$string['aigenerating'] = 'Gerando modelo com AI...';
$string['aimodel'] = 'Modelo';
$string['aimodel_desc'] = 'O modelo de AI a ser usado. Para OpenAI: gpt-4o-mini, gpt-4o. Para Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'A chave de API da AI não está configurada. Defina-a nas configurações do plugin.';
$string['aiparseerror'] = 'Falha ao interpretar a resposta da AI. Tente novamente com uma descrição diferente.';
$string['aiprovider'] = 'Provedor de AI';
$string['aiprovider_desc'] = 'Escolha qual serviço de AI usar para geração de modelos.';
$string['aisettings'] = 'Gerador de Modelos com AI';
$string['aisettings_desc'] = 'Configure a geração automática de modelos com AI. Requer uma chave de API do OpenAI ou Anthropic.';
$string['aligncenter'] = 'Centro';
$string['alignleft'] = 'Esquerda';
$string['alignright'] = 'Direita';
$string['all'] = 'Todos';
$string['allcolors'] = 'Todas as cores';
$string['allstyles'] = 'Todos os estilos';
$string['alltemplates'] = 'Todos os Modelos';
$string['appearance'] = 'Aparência';
$string['apply'] = 'Aplicar';
$string['approval'] = 'Fluxo de aprovação';
$string['approvalenabled'] = 'Habilitar fluxo de aprovação';
$string['approvalenabled_desc'] = 'Habilitar fluxo de aprovação por padrão para novas atividades.';
$string['approvalenabled_help'] = 'Quando habilitado, os alunos devem solicitar a aprovação do certificado a um professor antes de fazer o download.';
$string['approvalnotifystudent'] = 'Notificar aluno sobre o resultado';
$string['approvalnotifystudent_desc'] = 'Enviar notificação aos alunos quando sua solicitação for aprovada ou rejeitada.';
$string['approvalnotifyteacher'] = 'Notificar professor ao receber solicitação';
$string['approvalnotifyteacher_desc'] = 'Enviar notificação aos professores quando um aluno solicitar um certificado.';
$string['approvalrequestbody'] = '{$a->student} solicitou um certificado para "{$a->activity}".';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> solicitou um certificado para "<strong>{$a->activity}</strong>".</p><p><a href="{$a->url}">Revisar solicitações de aprovação</a></p>';
$string['approvalrequestexists'] = 'Você já possui uma solicitação de aprovação pendente.';
$string['approvalrequestnotfound'] = 'Solicitação de aprovação não encontrada.';
$string['approvalrequestnotpending'] = 'Esta solicitação de aprovação não está mais pendente.';
$string['approvalrequests'] = 'Solicitações de aprovação';
$string['approvalrequestsmall'] = 'Nova solicitação de certificado de {$a}';
$string['approvalrequestsubject'] = 'Solicitação de aprovação de certificado: {$a}';
$string['approvalrequesttemplate'] = 'Notificação de solicitação (para o professor)';
$string['approvalrequesttemplate_desc'] = 'Mensagem enviada aos professores quando um aluno solicita aprovação do certificado.';
$string['approvalresultbody'] = 'Sua solicitação de certificado para "{$a->activity}" foi {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Sua solicitação de certificado para "<strong>{$a->activity}</strong>" foi <strong>{$a->status}</strong>.</p><p>Revisor: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Ver certificado</a></p>';
$string['approvalresultsmall'] = 'Solicitação de certificado {$a}';
$string['approvalresultsubject'] = 'Solicitação de certificado {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Configurações de aprovação';
$string['approve'] = 'Aprovar';
$string['approved'] = 'aprovada';
$string['approvedtemplate'] = 'Notificação de aprovação (para o aluno)';
$string['approvedtemplate_desc'] = 'Mensagem enviada ao aluno quando sua solicitação é aprovada.';
$string['autoissue'] = 'Emissão automática na conclusão do curso';
$string['autoissue_desc'] = 'Emitir certificados automaticamente quando um aluno concluir o curso. Requer que a conclusão de curso esteja habilitada. Não se aplica a atividades com fluxo de aprovação.';
$string['back'] = 'Voltar';
$string['backtoview'] = 'Voltar';
$string['batchdownload'] = 'Baixar tudo como ZIP';
$string['bgcolor'] = 'Cor de fundo';
$string['bgimage'] = 'Imagem de fundo';
$string['bgimageopacity'] = 'Opacidade da imagem de fundo';
$string['bgimagesize'] = 'Tamanho da imagem de fundo';
$string['bgimagesizeactual'] = 'Tamanho real';
$string['bgimagesizecontain'] = 'Conter (ajustar dentro)';
$string['bgimagesizecover'] = 'Cobrir (preencher página)';
$string['bgimagesizestretch'] = 'Esticar';
$string['bold'] = 'Negrito';
$string['bordercolor'] = 'Cor da borda';
$string['borderstyle'] = 'Estilo da borda';
$string['borderwidth'] = 'Largura da borda';
$string['builtin'] = 'Integrados';
$string['builtintemplates'] = 'Modelos integrados';
$string['bulkactions'] = 'Ações em lote';
$string['bulkdelete'] = 'Excluir selecionados';
$string['bulkemail'] = 'Enviar e-mail aos selecionados';
$string['bulkissue'] = 'Emissão em Lote';
$string['bulkissuealreadyissued'] = '{$a} aluno(s) já possuem um certificado (ignorados)';
$string['bulkissuecomplete'] = '{$a} certificado(s) emitido(s) com sucesso.';
$string['bulkissuedefaultmessage'] = 'Prezado(a) {studentname},

Parabéns! Seu certificado de "{certname}" no curso "{coursename}" foi emitido.

Você pode baixá-lo aqui: {url}

Atenciosamente';
$string['bulkissuedesc'] = 'Emitir certificados para todos os alunos inscritos elegíveis que ainda não receberam um.';
$string['bulkissuenoeligible'] = 'Todos os alunos inscritos já receberam um certificado.';
$string['bulkissuenoselection'] = 'Nenhum aluno selecionado.';
$string['bulkissuenotified'] = '{$a} aluno(s) notificado(s).';
$string['bulkissuenotify'] = 'Notificar alunos';
$string['bulkissuenotifyemail'] = 'Enviar notificação por e-mail';
$string['bulkissuenotifymessage'] = 'Mensagem de notificação';
$string['bulkissuenotifymoodle'] = 'Enviar notificação pelo Moodle';
$string['bulkissuenotifyplaceholders'] = 'Espaços reservados disponíveis: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Seu certificado de {$a} foi emitido.';
$string['bulkissuenotifysubject'] = 'Seu certificado foi emitido: {$a}';
$string['bulkissuesubmit'] = 'Emitir certificados para {$a} aluno(s)';
$string['bulkoperationcomplete'] = '{$a->count} certificado(s) processado(s): {$a->action}.';
$string['bulkreissue'] = 'Reemitir selecionados';
$string['bulkrevoke'] = 'Revogar selecionados';
$string['certificate'] = 'Certificado';
$string['certificateexpired'] = 'Este certificado expirou em {$a}.';
$string['certificateexpiredverify'] = 'Este certificado expirou';
$string['certificateexpires'] = 'Este certificado expira em {$a}.';
$string['certificateinvalid'] = 'Este certificado é inválido';
$string['certificateissued'] = 'Seu certificado foi emitido em {$a}.';
$string['certificatenotfound'] = 'Nenhum certificado encontrado com este código de verificação.';
$string['certificaterevoked'] = 'Este certificado foi revogado';
$string['certificaterevokedstudent'] = 'Seu certificado foi revogado. Entre em contato com seu professor ou administrador para mais informações.';
$string['certificatevalid'] = 'Este certificado é válido';
$string['certificateversion'] = 'Esta é a versão {$a} do seu certificado (renovado).';
$string['certstudio:addinstance'] = 'Adicionar uma atividade Certificate Studio';
$string['certstudio:approvecertificate'] = 'Aprovar solicitações de certificado';
$string['certstudio:manage'] = 'Gerenciar modelos de certificado';
$string['certstudio:manageemailstudents'] = 'Controlar configurações de notificação por e-mail';
$string['certstudio:manageprotection'] = 'Controlar configurações de proteção de PDF';
$string['certstudio:managetemplates'] = 'Gerenciar modelos de certificado';
$string['certstudio:receiveissue'] = 'Receber um certificado';
$string['certstudio:revokecertificate'] = 'Revogar certificados emitidos';
$string['certstudio:verifycertificate'] = 'Verificar códigos de certificado';
$string['certstudio:view'] = 'Visualizar certificado';
$string['certstudio:viewallcertificates'] = 'Visualizar todos os certificados emitidos';
$string['certstudio:viewreport'] = 'Visualizar relatórios e análises de certificados';
$string['city'] = 'Cidade';
$string['clearbg'] = 'Limpar fundo';
$string['clicktorenametemplate'] = 'Clique para renomear o modelo';
$string['codegenerationmethod'] = 'Método de geração de código';
$string['codegenerationmethod_desc'] = 'Escolha entre os dois métodos para gerar códigos de verificação de certificado.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Dígitos com hífens)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (String aleatória com maiúsculas/minúsculas/dígitos)';
$string['color'] = 'Cor';
$string['colorblue'] = 'Azul';
$string['colordark'] = 'Escuro';
$string['colorgold'] = 'Dourado';
$string['colorgray'] = 'Cinza';
$string['colorgreen'] = 'Verde';
$string['colorpink'] = 'Rosa';
$string['colorpurple'] = 'Roxo';
$string['colorred'] = 'Vermelho';
$string['comment'] = 'Comentário';
$string['confirmbulk'] = 'Tem certeza de que deseja executar esta ação em lote nos certificados selecionados?';
$string['confirmdelete'] = 'Tem certeza de que deseja excluir este modelo? Esta ação não pode ser desfeita.';
$string['confirmdeleteissue'] = 'Tem certeza de que deseja excluir permanentemente este registro de certificado?';
$string['confirmrevoke'] = 'Tem certeza de que deseja revogar este certificado? A página de verificação mostrará que ele foi revogado.';
$string['copy'] = 'Copiar';
$string['course'] = 'Curso';
$string['createblank'] = 'Certificado em Branco';
$string['createblankdesc'] = 'Comece com uma tela vazia';
$string['created'] = 'Criado';
$string['createtemplate'] = '-- Criar novo modelo --';
$string['current'] = 'Atual';
$string['currenttemplate'] = 'Modelo atual';
$string['custom'] = 'Personalizado';
$string['customsource'] = 'Personalizados';
$string['customtemplates'] = 'Modelos personalizados';
$string['dateformat'] = 'Formato de data';
$string['dateissued'] = 'Data de emissão';
$string['daterequested'] = 'Data da solicitação';
$string['defaultfilename'] = 'Nome de arquivo PDF padrão';
$string['defaultfilename_desc'] = 'Padrão de nome de arquivo para PDFs baixados. Espaços reservados: {coursename}, {studentname}, {date}, {activityname}. Pode ser substituído por atividade.';
$string['defaultprotection'] = 'Proteção de PDF padrão';
$string['defaultprotection_desc'] = 'Flags de proteção padrão para PDFs (separadas por vírgula): print, modify, copy. Pode ser substituído por atividade.';
$string['defaultvalues'] = 'Valores padrão para configurações de atividade';
$string['defaultvalues_desc'] = 'Os valores padrão são utilizados no formulário de configurações ao criar uma nova atividade.';
$string['delete'] = 'Excluir';
$string['deleteissuedcertificates'] = 'Excluir certificados emitidos';
$string['downloadcertificate'] = 'Baixar Certificado';
$string['downloadfilename'] = 'Nome do arquivo PDF';
$string['downloadfilename_help'] = 'Nome de arquivo personalizado para o certificado PDF baixado. Você pode usar espaços reservados: {coursename}, {studentname}, {date}. Deixe em branco para usar o nome da atividade. Exemplo: Certificado_{coursename}_{studentname}';
$string['downloadsettings'] = 'Configurações de download';
$string['editcertstudio'] = 'Editar certificado';
$string['edittemplate'] = 'Editar Modelo';
$string['elementcount'] = '{$a} elementos';
$string['elementname'] = 'Nome do elemento';
$string['elements'] = 'Elementos';
$string['elementtype_bgimage'] = 'Imagem de fundo';
$string['elementtype_border'] = 'Borda';
$string['elementtype_categoryname'] = 'Nome da categoria';
$string['elementtype_certdate'] = 'Data grega';
$string['elementtype_certstatement'] = 'Declaração grega';
$string['elementtype_code'] = 'Código de verificação';
$string['elementtype_coursefield'] = 'Campo do curso';
$string['elementtype_coursename'] = 'Nome do curso';
$string['elementtype_date'] = 'Data';
$string['elementtype_daterange'] = 'Intervalo de datas';
$string['elementtype_digitalsignature'] = 'Assinatura digital';
$string['elementtype_expiry'] = 'Data de validade';
$string['elementtype_grade'] = 'Nota';
$string['elementtype_gradeitemname'] = 'Nome do item de nota';
$string['elementtype_image'] = 'Imagem';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Nome do aluno';
$string['elementtype_teachername'] = 'Nome do professor';
$string['elementtype_text'] = 'Texto';
$string['elementtype_userfield'] = 'Campo do usuário';
$string['elementtype_userpicture'] = 'Foto do usuário';
$string['emailcertbody'] = 'Prezado(a) {$a->studentname},

Seu certificado de "{$a->certname}" no curso "{$a->coursename}" está anexado a este e-mail.

Código de verificação: {$a->code}
Verificar online: {$a->verifyurl}

Atenciosamente';
$string['emailcertificate'] = 'Enviar certificado por e-mail';
$string['emailcertificatebody'] = 'Prezado(a) {$a->fullname},

Seu certificado de "{$a->certname}" no curso "{$a->coursename}" foi emitido.

Você pode verificá-lo usando o código: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Seu certificado de {$a}';
$string['emailcertsubject'] = 'Seu Certificado: {$a}';
$string['emailcerttemplate'] = 'Notificação de certificado por e-mail';
$string['emailcerttemplate_default'] = 'Prezado(a) {studentname},

Seu certificado de "{certname}" no curso "{coursename}" está anexado a este e-mail.

Código de verificação: {code}
Verificar online: {verifyurl}

Atenciosamente';
$string['emailcerttemplate_desc'] = 'Corpo da mensagem ao enviar um certificado PDF como anexo por e-mail. Espaços reservados: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Enviar e-mail a outros';
$string['emailothers_desc'] = 'Endereços de e-mail separados por vírgula que receberão uma cópia do certificado quando estiver disponível.';
$string['emailsent'] = 'Certificado enviado por e-mail com sucesso.';
$string['emailsettings'] = 'Notificações por e-mail';
$string['emailstudents'] = 'Enviar e-mail aos alunos';
$string['emailstudents_desc'] = 'Se habilitado, os alunos receberão uma cópia do certificado por e-mail quando estiver disponível.';
$string['emailteacherbody'] = 'Um certificado de "{$a->certname}" foi emitido para {$a->fullname} no curso "{$a->coursename}".';
$string['emailteachers'] = 'Enviar e-mail aos professores';
$string['emailteachers_desc'] = 'Se habilitado, os professores receberão uma cópia do certificado por e-mail quando estiver disponível.';
$string['emailteachersubject'] = 'Certificado emitido: {$a->certname}';
$string['entercode'] = 'Insira o código de verificação';
$string['eventcertificateapproved'] = 'Certificado aprovado';
$string['eventcertificateissued'] = 'Certificado emitido';
$string['eventcertificaterejected'] = 'Certificado rejeitado';
$string['eventcertificaterequested'] = 'Certificado solicitado';
$string['eventcertificaterevoked'] = 'Certificado revogado';
$string['eventpagecreated'] = 'Página criada';
$string['eventpagedeleted'] = 'Página excluída';
$string['eventtemplatecreated'] = 'Modelo criado';
$string['eventtemplatedeleted'] = 'Modelo excluído';
$string['eventtemplateupdated'] = 'Modelo atualizado';
$string['expired'] = 'Expirado';
$string['expiredon'] = 'Expirou em';
$string['expirydate'] = 'Data de validade';
$string['expirydays'] = 'Validade do certificado (dias)';
$string['expirydays_help'] = 'Número de dias de validade do certificado a partir da data de emissão. Defina como 0 para sem validade.';
$string['expiryperiod'] = 'Período de validade (dias)';
$string['expirysettings'] = 'Configurações de validade';
$string['exportcsv'] = 'Exportar CSV';
$string['exportods'] = 'Exportar ODS';
$string['exporttemplate'] = 'Exportar modelo';
$string['exportxlsx'] = 'Exportar XLSX';
$string['fieldname'] = 'Nome do campo';
$string['font'] = 'Fonte';
$string['fontsize'] = 'Tamanho da fonte';
$string['gallerydescription'] = 'Escolha um modelo para começar ou crie o seu do zero';
$string['generalsettings'] = 'Configurações gerais';
$string['getcertificate'] = 'Obter Certificado';
$string['gradeitem'] = 'Item de nota';
$string['height'] = 'Altura';
$string['importtemplate'] = 'Importar modelo';
$string['invalidaction'] = 'Ação inválida';
$string['invalidelementdata'] = 'Dados de elemento inválidos';
$string['invalidfilearea'] = 'Área de arquivo inválida';
$string['issuedcertificates'] = 'Certificados emitidos';
$string['issuedcount'] = '{$a} certificado(s) emitido(s)';
$string['issuedtemplate'] = 'Notificação de certificado emitido';
$string['issuedtemplate_default'] = 'Prezado(a) {studentname},

Parabéns! Seu certificado de "{certname}" no curso "{coursename}" foi emitido.

Você pode baixá-lo aqui: {url}

Código de verificação: {code}

Atenciosamente';
$string['issuedtemplate_desc'] = 'Mensagem enviada ao aluno quando um certificado é emitido. Espaços reservados: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Emissão de certificado não encontrada';
$string['italic'] = 'Itálico';
$string['landscape'] = 'Paisagem';
$string['layers'] = 'Camadas';
$string['loading'] = 'Carregando...';
$string['lock'] = 'Bloquear';
$string['manageapprovals'] = 'Gerenciar aprovações';
$string['managetemplates'] = 'Gerenciar Modelos';
$string['managetemplates_desc'] = 'Visualizar, exportar, importar e excluir modelos. Gerencie todos os modelos integrados e personalizados em um só lugar.';
$string['messageprovider:approval_request'] = 'Solicitação de aprovação de certificado';
$string['messageprovider:approval_result'] = 'Resultado da aprovação de certificado';
$string['messagetemplates'] = 'Modelos de mensagem';
$string['messagetemplates_desc'] = 'Personalize as mensagens de notificação. Espaços reservados: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Migrar atividades (módulos do curso)';
$string['migrateissues'] = 'Migrar certificados emitidos';
$string['migratetemplates'] = 'Migrar modelos (páginas e elementos)';
$string['migrationcomplete'] = 'Migração concluída: {$a->templates} modelo(s), {$a->activities} atividade(s), {$a->issues} emissão(ões) migrada(s).';
$string['migrationlog'] = 'Log de migração';
$string['migrationnodata'] = 'Nenhum dado do customcert encontrado para migrar.';
$string['migrationnotavailable'] = 'O plugin Custom Certificate (mod_customcert) não está instalado. Nada para migrar.';
$string['migrationoptions'] = 'Opções de migração';
$string['migrationsummary'] = 'Dados do Custom Certificate encontrados';
$string['migrationtool'] = 'Migrar do Custom Certificate';
$string['migrationwarning'] = 'Isso criará novos registros do certstudio a partir dos seus dados do customcert. Os dados existentes do customcert NÃO serão modificados ou excluídos. Itens já migrados serão ignorados.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studios';
$string['multilang'] = 'Certificados multilíngues';
$string['multilang_desc'] = 'Forçar o idioma do certificado por atividade, substituindo a preferência do usuário.';
$string['mycertificates'] = 'Meus Certificados';
$string['name'] = 'Nome';
$string['nelements'] = '{$a} elementos';
$string['nocertificates'] = 'Você ainda não recebeu nenhum certificado.';
$string['nocertificatesissued'] = 'Nenhum certificado foi emitido ainda. Conclua as atividades obrigatórias para receber seu certificado.';
$string['nodata'] = 'Nenhum dado disponível.';
$string['norequests'] = 'Nenhuma solicitação de aprovação encontrada.';
$string['notapproved'] = 'Seu certificado ainda não foi aprovado.';
$string['notemplates'] = 'Nenhum modelo encontrado.';
$string['notemplatesavailable'] = 'Nenhum modelo disponível. Clique em "Começar do zero" para criar seu próprio certificado.';
$string['notissued'] = 'Não emitido';
$string['opacity'] = 'Opacidade';
$string['optional'] = 'opcional';
$string['pages'] = 'Páginas';
$string['pagesettings'] = 'Configurações da página';
$string['pagesize'] = 'Tamanho da página';
$string['pdfsettings'] = 'Configurações de PDF';
$string['platform'] = 'Plataforma';
$string['pluginadministration'] = 'Administração do Certificate Studio';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Retrato';
$string['positionandsize'] = 'Posição e tamanho';
$string['previewpdf'] = 'Pré-visualizar PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Solicitações de aprovação de certificado.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'O comentário do revisor sobre a solicitação.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'O usuário que revisou a solicitação.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'O status da aprovação.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Quando a solicitação foi feita.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Quando a solicitação foi atualizada pela última vez.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'O usuário que solicitou o certificado.';
$string['privacy:metadata:certstudio_issues'] = 'Registros de certificados emitidos.';
$string['privacy:metadata:certstudio_issues:code'] = 'O código de verificação único.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'O snapshot dos dados do modelo do certificado.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Quando o certificado foi emitido.';
$string['privacy:metadata:certstudio_issues:userid'] = 'O usuário que recebeu o certificado.';
$string['privacy:path:approvalrequests'] = 'Solicitações de aprovação';
$string['privacy:path:issues'] = 'Certificados emitidos';
$string['properties'] = 'Propriedades';
$string['protection'] = 'Proteção de PDF';
$string['protection_copy'] = 'Impedir cópia';
$string['protection_copy_desc'] = 'Habilitar proteção contra ação de cópia.';
$string['protection_modify'] = 'Impedir modificação';
$string['protection_modify_desc'] = 'Habilitar proteção contra ação de modificação.';
$string['protection_print'] = 'Impedir impressão';
$string['protection_print_desc'] = 'Habilitar proteção contra ação de impressão.';
$string['protectionflags'] = 'Flags de proteção';
$string['protectionflags_help'] = 'Flags de proteção separadas por vírgula: print, modify, copy';
$string['publishtogallery'] = 'Publicar na galeria';
$string['publishtogallerytip'] = 'Publicar uma cópia na galeria de modelos para que todos os cursos possam usá-la';
$string['reason'] = 'Motivo';
$string['receiveddate'] = 'Data de recebimento';
$string['redo'] = 'Refazer';
$string['reissue'] = 'Reemitir';
$string['reissuedtemplate'] = 'Notificação de certificado reemitido';
$string['reissuedtemplate_default'] = 'Prezado(a) {studentname},

Uma nova versão do seu certificado de "{certname}" no curso "{coursename}" foi emitida.

Você pode baixá-lo aqui: {url}

Código de verificação: {code}

Atenciosamente';
$string['reissuedtemplate_desc'] = 'Mensagem enviada ao aluno quando uma nova versão de seu certificado é emitida. Espaços reservados: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Rejeitar';
$string['rejected'] = 'rejeitada';
$string['rejectedtemplate'] = 'Notificação de rejeição (para o aluno)';
$string['rejectedtemplate_desc'] = 'Mensagem enviada ao aluno quando sua solicitação é rejeitada.';
$string['reportanalytics'] = 'Análise de Certificados';
$string['reportmonthly'] = 'Tendência mensal (últimos 12 meses)';
$string['reportpercourse'] = 'Certificados por curso';
$string['reportrecent'] = 'Certificados recentes (últimos 30 dias)';
$string['reporttotalactivities'] = 'Total de atividades';
$string['reporttotalissued'] = 'Total emitido';
$string['reporttotaltemplates'] = 'Total de modelos';
$string['reportuniquerecipients'] = 'Destinatários únicos';
$string['requestagain'] = 'Enviar nova solicitação';
$string['requestapproved'] = 'Solicitação aprovada com sucesso.';
$string['requestcertificate'] = 'Solicitar Certificado';
$string['requestpending'] = 'Sua solicitação de certificado está aguardando aprovação.';
$string['requestrejected'] = 'Sua solicitação de certificado foi rejeitada.';
$string['requestrejectedmsg'] = 'Solicitação rejeitada com sucesso.';
$string['requestsubmitted'] = 'Sua solicitação de certificado foi enviada.';
$string['requiredtime'] = 'Minutos obrigatórios no curso';
$string['requiredtime_desc'] = 'Tempo mínimo em minutos que um aluno deve estar conectado ao curso antes de poder receber o certificado. Defina como 0 para desabilitar.';
$string['requiredtimenotmet'] = 'Você precisa passar pelo menos {$a->required} minutos neste curso antes de poder receber um certificado. Você passou aproximadamente {$a->spent} minutos até agora.';
$string['returncourse'] = 'Botão Voltar ao curso';
$string['returncourse_desc'] = 'Exibir um botão "Voltar ao curso" na página de visualização do certificado.';
$string['returntocourse'] = 'Voltar ao curso';
$string['reviewer'] = 'Revisor';
$string['revokecertificate'] = 'Revogar certificado';
$string['revoked'] = 'Revogado';
$string['revokeddate'] = 'Revogado em';
$string['revokedrenewal'] = 'Revogado para renovação (nova versão emitida)';
$string['revokedtemplate'] = 'Notificação de certificado revogado';
$string['revokedtemplate_default'] = 'Prezado(a) {studentname},

Seu certificado de "{certname}" no curso "{coursename}" foi revogado.

Motivo: {reason}

Se você tiver alguma dúvida, entre em contato com seu instrutor.

Atenciosamente';
$string['revokedtemplate_desc'] = 'Mensagem enviada ao aluno quando seu certificado é revogado. Espaços reservados: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Rotação';
$string['save'] = 'Salvar';
$string['savechangestip'] = 'Salvar alterações apenas nesta atividade';
$string['saved'] = 'Alterações salvas';
$string['saveerror'] = 'Erro ao salvar alterações';
$string['savestatussaved'] = 'Salvo';
$string['searchbyname'] = 'Buscar por nome...';
$string['selectelement'] = 'Clique em um elemento para editar suas propriedades.';
$string['selecttemplate'] = 'Selecionar modelo';
$string['sharecertificate'] = 'Compartilhar';
$string['shareemailbody'] = 'Gostaria de compartilhar que conquistei o certificado "{$a->certname}".

Você pode verificá-lo aqui: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Meu Certificado: {$a}';
$string['sharetext'] = 'Acabei de conquistar o certificado "{$a}"!';
$string['showcasecourse'] = 'Curso';
$string['showcasedownloadpdf'] = 'Baixar PDF';
$string['showcaseissuedon'] = 'Emitido em';
$string['showcaserecipient'] = 'Concedido a';
$string['showcaseshare'] = 'Compartilhar este certificado';
$string['showcasetitle'] = 'Certificado Digital';
$string['showcaseverified'] = 'Certificado Verificado';
$string['showposxy'] = 'Mostrar posição X e Y';
$string['showposxy_desc'] = 'Mostrar a posição X e Y ao editar um elemento, permitindo que o usuário especifique a localização com precisão.';
$string['startfromscratch'] = 'Começar do Zero';
$string['startmigration'] = 'Iniciar migração';
$string['status'] = 'Status';
$string['statusapproved'] = 'Aprovado';
$string['statusexpired'] = 'Expirado';
$string['statuspending'] = 'Pendente';
$string['statusrejected'] = 'Rejeitado';
$string['statusrevoked'] = 'Revogado';
$string['statusvalid'] = 'Válido';
$string['student'] = 'Aluno';
$string['styleclassic'] = 'Clássico';
$string['styledark'] = 'Escuro';
$string['styleelegant'] = 'Elegante';
$string['stylegradient'] = 'Gradiente';
$string['styleminimal'] = 'Minimalista';
$string['stylemodern'] = 'Moderno';
$string['stylespecial'] = 'Especial';
$string['subplugintype_certstudioselem'] = 'Tipo de elemento';
$string['subplugintype_certstudioselem_plural'] = 'Tipos de elementos';
$string['taskemailcertificate'] = 'Enviar certificado por e-mail';
$string['taskissuecertificate'] = 'Emitir certificados e enviar e-mails';
$string['template'] = 'Modelo';
$string['templatedeleted'] = 'O modelo "{$a}" foi excluído.';
$string['templatefile'] = 'Arquivo de modelo (.json)';
$string['templatefilehelp'] = 'Faça upload de um arquivo .certstudio.json exportado de outra instalação do Certificate Studio.';
$string['templategallery'] = 'Galeria de Modelos';
$string['templateimported'] = 'Modelo "{$a->name}" importado com sucesso ({$a->pages} página(s), {$a->elements} elemento(s)).';
$string['templateimportinvalid'] = 'Arquivo de modelo inválido. Faça upload de um arquivo .certstudio.json válido.';
$string['templateinuse'] = 'Este modelo é utilizado por {$a} atividade(s) e não pode ser excluído.';
$string['templatenameplaceholder'] = 'Nome do modelo...';
$string['templates'] = 'Modelos';
$string['templatesharing'] = 'Importar/Exportar Modelos';
$string['textcontent'] = 'Conteúdo do texto';
$string['toggleelementspanel'] = 'Alternar painel de elementos';
$string['togglegrid'] = 'Alternar grade';
$string['toggleguides'] = 'Alternar guias';
$string['togglepropertiespanel'] = 'Alternar painel de propriedades';
$string['typography'] = 'Tipografia';
$string['undo'] = 'Desfazer';
$string['unknowncourse'] = 'Curso desconhecido';
$string['unknownuser'] = 'Usuário desconhecido';
$string['unlock'] = 'Desbloquear';
$string['uploadbgimage'] = 'Enviar';
$string['uploadbgimagetip'] = 'Enviar imagem de fundo';
$string['usethisTemplate'] = 'Usar este modelo';
$string['usethistemplate'] = 'Usar este modelo';
$string['valid'] = 'Válido';
$string['verificationcode'] = 'Código de verificação';
$string['verify'] = 'Verificar';
$string['verifyallcertificates'] = 'Permitir verificação pública';
$string['verifyallcertificates_desc'] = 'Permitir que qualquer pessoa verifique certificados sem fazer login.';
$string['verifyanother'] = 'Verificar outro certificado';
$string['verifyany'] = 'Permitir que qualquer pessoa verifique um certificado';
$string['verifyany_desc'] = 'Permitir que qualquer pessoa com o link de verificação do certificado (incluindo usuários não autenticados) verifique um certificado.';
$string['verifycertificate'] = 'Verificar Certificado';
$string['verifyintro'] = 'Insira um código de verificação de certificado para verificar sua autenticidade em {$a}.';
$string['verifylink_desc'] = 'Este link levará você a uma página onde é possível verificar certificados no site.';
$string['verifynotfound'] = 'Nenhum certificado foi encontrado com este código de verificação. Verifique e tente novamente.';
$string['verifyurl'] = 'URL de verificação personalizada';
$string['verifyurl_desc'] = 'URL personalizada para o link de verificação do QR Code. Deixe em branco para usar a página de verificação padrão do Moodle. Espaços reservados: {code}';
$string['version'] = 'Versão';
$string['viewonline'] = 'Ver Online';
$string['width'] = 'Largura';
$string['zoomin'] = 'Aumentar zoom';
$string['zoomout'] = 'Diminuir zoom';
