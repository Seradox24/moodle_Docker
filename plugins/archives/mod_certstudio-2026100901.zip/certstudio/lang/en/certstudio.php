<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Landscape';
$string['actions'] = 'Actions';
$string['actionsheading'] = 'Actions';
$string['active'] = 'Active';
$string['activities'] = 'Activities';
$string['aiapikey'] = 'API key';
$string['aiapikey_desc'] = 'Your API key for the selected AI provider. Get one from OpenAI or Anthropic.';
$string['aierror'] = 'AI generation error: {$a}';
$string['aigeneratebutton'] = 'Generate';
$string['aigeneratedesc'] = 'Describe the certificate you want and AI will generate a template for you.';
$string['aigenerateplaceholder'] = 'e.g., formal blue certificate for IT course with gold border...';
$string['aigeneratesuccess'] = 'Template generated successfully! Redirecting to editor...';
$string['aigeneratetitle'] = 'AI Template Generator';
$string['aigenerating'] = 'Generating template with AI...';
$string['aimodel'] = 'Model';
$string['aimodel_desc'] = 'The AI model to use. For OpenAI: gpt-4o-mini, gpt-4o. For Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'AI API key is not configured. Please set it in the plugin settings.';
$string['aiparseerror'] = 'Failed to parse AI response. Please try again with a different description.';
$string['aiprovider'] = 'AI provider';
$string['aiprovider_desc'] = 'Choose which AI service to use for template generation.';
$string['aisettings'] = 'AI Template Generator';
$string['aisettings_desc'] = 'Configure AI-powered automatic template generation. Requires an API key from OpenAI or Anthropic.';
$string['aligncenter'] = 'Center';
$string['alignleft'] = 'Left';
$string['alignright'] = 'Right';
$string['all'] = 'All';
$string['allcolors'] = 'All colors';
$string['allstyles'] = 'All styles';
$string['alltemplates'] = 'All Templates';
$string['appearance'] = 'Appearance';
$string['apply'] = 'Apply';
$string['approval'] = 'Approval workflow';
$string['approvalenabled'] = 'Enable approval workflow';
$string['approvalenabled_desc'] = 'Enable approval workflow by default for new activities.';
$string['approvalenabled_help'] = 'When enabled, students must request certificate approval from a teacher before downloading.';
$string['approvalnotifystudent'] = 'Notify student on result';
$string['approvalnotifystudent_desc'] = 'Send notification to students when their request is approved or rejected.';
$string['approvalnotifyteacher'] = 'Notify teacher on request';
$string['approvalnotifyteacher_desc'] = 'Send notification to teachers when a student requests a certificate.';
$string['approvalrequestbody'] = '{$a->student} has requested a certificate for "{$a->activity}".';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> has requested a certificate for "<strong>{$a->activity}</strong>".</p><p><a href="{$a->url}">Review approval requests</a></p>';
$string['approvalrequestexists'] = 'You already have a pending approval request.';
$string['approvalrequestnotfound'] = 'Approval request not found.';
$string['approvalrequestnotpending'] = 'This approval request is no longer pending.';
$string['approvalrequests'] = 'Approval requests';
$string['approvalrequestsmall'] = 'New certificate request from {$a}';
$string['approvalrequestsubject'] = 'Certificate approval request: {$a}';
$string['approvalrequesttemplate'] = 'Request notification (to teacher)';
$string['approvalrequesttemplate_desc'] = 'Message sent to teachers when a student requests certificate approval.';
$string['approvalresultbody'] = 'Your certificate request for "{$a->activity}" has been {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Your certificate request for "<strong>{$a->activity}</strong>" has been <strong>{$a->status}</strong>.</p><p>Reviewer: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">View certificate</a></p>';
$string['approvalresultsmall'] = 'Certificate request {$a}';
$string['approvalresultsubject'] = 'Certificate request {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Approval settings';
$string['approve'] = 'Approve';
$string['approved'] = 'approved';
$string['approvedtemplate'] = 'Approved notification (to student)';
$string['approvedtemplate_desc'] = 'Message sent to the student when their request is approved.';
$string['autoissue'] = 'Auto-issue on course completion';
$string['autoissue_desc'] = 'Automatically issue certificates when a student completes the course. Requires course completion to be enabled. Does not apply to activities with approval workflow.';
$string['back'] = 'Back';
$string['backtoview'] = 'Back';
$string['batchdownload'] = 'Download all as ZIP';
$string['bgcolor'] = 'Background Color';
$string['bgimage'] = 'Background Image';
$string['bgimageopacity'] = 'BG Image Opacity';
$string['bgimagesize'] = 'BG Image Size';
$string['bgimagesizeactual'] = 'Actual Size';
$string['bgimagesizecontain'] = 'Contain (fit inside)';
$string['bgimagesizecover'] = 'Cover (fill page)';
$string['bgimagesizestretch'] = 'Stretch';
$string['bold'] = 'Bold';
$string['bordercolor'] = 'Border color';
$string['borderstyle'] = 'Border style';
$string['borderwidth'] = 'Border width';
$string['builtin'] = 'Built-in';
$string['builtintemplates'] = 'Built-in Templates';
$string['bulkactions'] = 'Bulk actions';
$string['bulkdelete'] = 'Delete selected';
$string['bulkemail'] = 'Email selected';
$string['bulkissue'] = 'Bulk Issue';
$string['bulkissuealreadyissued'] = '{$a} student(s) already have a certificate (skipped)';
$string['bulkissuecomplete'] = '{$a} certificate(s) issued successfully.';
$string['bulkissuedefaultmessage'] = 'Dear {studentname},

Congratulations! Your certificate for "{certname}" in the course "{coursename}" has been issued.

You can download it here: {url}

Best regards';
$string['bulkissuedesc'] = 'Issue certificates to all eligible enrolled students who have not yet received one.';
$string['bulkissuenoeligible'] = 'All enrolled students have already received a certificate.';
$string['bulkissuenoselection'] = 'No students selected.';
$string['bulkissuenotified'] = '{$a} student(s) notified.';
$string['bulkissuenotify'] = 'Notify students';
$string['bulkissuenotifyemail'] = 'Send notification via email';
$string['bulkissuenotifymessage'] = 'Notification message';
$string['bulkissuenotifymoodle'] = 'Send notification via Moodle';
$string['bulkissuenotifyplaceholders'] = 'Available placeholders: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Your certificate for {$a} has been issued.';
$string['bulkissuenotifysubject'] = 'Your certificate has been issued: {$a}';
$string['bulkissuesubmit'] = 'Issue certificates to {$a} student(s)';
$string['bulkoperationcomplete'] = '{$a->count} certificate(s) processed: {$a->action}.';
$string['bulkreissue'] = 'Reissue selected';
$string['bulkrevoke'] = 'Revoke selected';
$string['cannotissue_alreadyissued'] = 'You already have a certificate for this activity.';
$string['cannotissue_approval'] = 'This certificate needs to be approved by your teacher first.';
$string['cannotissue_nopermission'] = 'You are not allowed to receive this certificate.';
$string['cannotissue_notavailable'] = 'This certificate is not available to you yet.';
$string['cannotissue_notenrolled'] = 'You need an active enrolment in this course to receive this certificate.';
$string['cannotissue_requiredtime'] = 'You have not yet spent the required time in this course.';
$string['cannotissue_revoked'] = 'Your certificate for this activity has been revoked. Please contact your teacher.';
$string['certificate'] = 'Certificate';
$string['certificateexpired'] = 'This certificate expired on {$a}.';
$string['certificateexpiredverify'] = 'This certificate has expired';
$string['certificateexpires'] = 'This certificate expires on {$a}.';
$string['certificateinvalid'] = 'This certificate is invalid';
$string['certificateissued'] = 'Your certificate was issued on {$a}.';
$string['certificatenotfound'] = 'No certificate found with this verification code.';
$string['certificaterevoked'] = 'This certificate has been revoked';
$string['certificaterevokedstudent'] = 'Your certificate has been revoked. Please contact your teacher or administrator for more information.';
$string['certificatevalid'] = 'This certificate is valid';
$string['certificateversion'] = 'This is version {$a} of your certificate (renewed).';
$string['certstudio:addinstance'] = 'Add a Certificate Studio activity';
$string['certstudio:approvecertificate'] = 'Approve certificate requests';
$string['certstudio:manage'] = 'Manage certificate templates';
$string['certstudio:manageemailstudents'] = 'Control email notification settings';
$string['certstudio:manageprotection'] = 'Control PDF protection settings';
$string['certstudio:managetemplates'] = 'Manage certificate templates';
$string['certstudio:receiveissue'] = 'Receive a certificate';
$string['certstudio:revokecertificate'] = 'Revoke issued certificates';
$string['certstudio:verifycertificate'] = 'Verify certificate codes';
$string['certstudio:view'] = 'View certificate';
$string['certstudio:viewallcertificates'] = 'View all issued certificates';
$string['certstudio:viewreport'] = 'View certificate reports and analytics';
$string['clearfilters'] = 'Clear';
$string['city'] = 'City';
$string['clearbg'] = 'Clear background';
$string['clicktorenametemplate'] = 'Click to rename template';
$string['codegenerationmethod'] = 'Code generation method';
$string['codegenerationmethod_desc'] = 'Choose between the two methods for generating certificate verification codes.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Digits with hyphens)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Upper/lower/digits random string)';
$string['color'] = 'Color';
$string['colorblue'] = 'Blue';
$string['colordark'] = 'Dark';
$string['colorgold'] = 'Gold';
$string['colorgray'] = 'Gray';
$string['colorgreen'] = 'Green';
$string['colorpink'] = 'Pink';
$string['colorpurple'] = 'Purple';
$string['colorred'] = 'Red';
$string['comment'] = 'Comment';
$string['confirmbulk'] = 'Are you sure you want to perform this bulk action on the selected certificates?';
$string['confirmdelete'] = 'Are you sure you want to delete this template? This action cannot be undone.';
$string['confirmdeleteissue'] = 'Are you sure you want to permanently delete this certificate record?';
$string['confirmrevoke'] = 'Are you sure you want to revoke this certificate? The verification page will show it as revoked.';
$string['copy'] = 'Copy';
$string['course'] = 'Course';
$string['createblank'] = 'Blank Certificate';
$string['createblankdesc'] = 'Start with an empty canvas';
$string['created'] = 'Created';
$string['createtemplate'] = '-- Create new template --';
$string['current'] = 'Current';
$string['currenttemplate'] = 'Current template';
$string['custom'] = 'Custom';
$string['customsource'] = 'Custom';
$string['customtemplates'] = 'Custom Templates';
$string['dateformat'] = 'Date format';
$string['dateissued'] = 'Date issued';
$string['daterequested'] = 'Date requested';
$string['defaultfilename'] = 'Default PDF filename';
$string['defaultfilename_desc'] = 'Default filename pattern for downloaded PDFs. Placeholders: {coursename}, {studentname}, {date}, {activityname}. Can be overridden per activity.';
$string['defaultprotection'] = 'Default PDF protection';
$string['defaultprotection_desc'] = 'Default protection flags for PDFs (comma-separated): print, modify, copy. Can be overridden per activity.';
$string['defaultvalues'] = 'Default values for activity settings';
$string['defaultvalues_desc'] = 'Default values are used in the settings form when creating a new activity.';
$string['delete'] = 'Delete';
$string['deleteissuedcertificates'] = 'Delete issued certificates';
$string['downloadcertificate'] = 'Download Certificate';
$string['downloadpdf'] = 'Download PDF';
$string['downloadfilename'] = 'PDF filename';
$string['downloadfilename_help'] = 'Custom filename for the downloaded PDF certificate. You can use placeholders: {coursename}, {studentname}, {date}. Leave empty to use the activity name. Example: Certificate_{coursename}_{studentname}';
$string['downloadsettings'] = 'Download settings';
$string['editcertstudio'] = 'Edit certificate';
$string['edittemplate'] = 'Edit Template';
$string['elementcount'] = '{$a} elements';
$string['elementname'] = 'Element name';
$string['elements'] = 'Elements';
$string['elementtype_bgimage'] = 'Background image';
$string['elementtype_border'] = 'Border';
$string['elementtype_categoryname'] = 'Category name';
$string['elementtype_certdate'] = 'Greek date';
$string['elementtype_certstatement'] = 'Greek statement';
$string['elementtype_code'] = 'Verification code';
$string['elementtype_coursefield'] = 'Course field';
$string['elementtype_coursename'] = 'Course name';
$string['elementtype_date'] = 'Date';
$string['elementtype_daterange'] = 'Date range';
$string['elementtype_digitalsignature'] = 'Digital signature';
$string['elementtype_expiry'] = 'Expiry date';
$string['elementtype_grade'] = 'Grade';
$string['elementtype_gradeitemname'] = 'Grade item name';
$string['elementtype_image'] = 'Image';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Student name';
$string['elementtype_teachername'] = 'Teacher name';
$string['elementtype_text'] = 'Text';
$string['elementtype_userfield'] = 'User field';
$string['elementtype_userpicture'] = 'User picture';
$string['emailcertbody'] = 'Dear {$a->studentname},

Your certificate for "{$a->certname}" in the course "{$a->coursename}" is attached to this email.

Verification code: {$a->code}
Verify online: {$a->verifyurl}

Best regards';
$string['emailcertificate'] = 'Email certificate';
$string['emailed'] = 'Emailed';
$string['emailcertificatebody'] = 'Dear {$a->fullname},

Your certificate for "{$a->certname}" in course "{$a->coursename}" has been issued.

You can verify it using code: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Your certificate for {$a}';
$string['emailcertsubject'] = 'Your Certificate: {$a}';
$string['emailcerttemplate'] = 'Email certificate notification';
$string['emailcerttemplate_default'] = 'Dear {studentname},

Your certificate for "{certname}" in the course "{coursename}" is attached to this email.

Verification code: {code}
Verify online: {verifyurl}

Best regards';
$string['emailcerttemplate_desc'] = 'Message body when emailing a certificate PDF as attachment. Placeholders: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Email others';
$string['emailothers_desc'] = 'Comma-separated email addresses that will receive a copy of the certificate when it becomes available.';
$string['emailsent'] = 'Certificate emailed successfully.';
$string['emailsettings'] = 'Email notifications';
$string['emailstudents'] = 'Email students';
$string['emailstudents_desc'] = 'If enabled, students will receive a copy of the certificate by email when it becomes available.';
$string['emailteacherbody'] = 'A certificate for "{$a->certname}" has been issued to {$a->fullname} in course "{$a->coursename}".';
$string['emailteachers'] = 'Email teachers';
$string['emailteachers_desc'] = 'If enabled, teachers will receive a copy of the certificate by email when it becomes available.';
$string['emailteachersubject'] = 'Certificate issued: {$a->certname}';
$string['entercode'] = 'Enter verification code';
$string['eventcertificateapproved'] = 'Certificate approved';
$string['eventcoursemoduleviewed'] = 'Certificate Studio viewed';
$string['eventcertificateissued'] = 'Certificate issued';
$string['eventcertificaterejected'] = 'Certificate rejected';
$string['eventcertificaterequested'] = 'Certificate requested';
$string['eventcertificaterevoked'] = 'Certificate revoked';
$string['eventpagecreated'] = 'Page created';
$string['eventpagedeleted'] = 'Page deleted';
$string['eventtemplatecreated'] = 'Template created';
$string['eventtemplatedeleted'] = 'Template deleted';
$string['eventtemplateupdated'] = 'Template updated';
$string['expired'] = 'Expired';
$string['expiredon'] = 'Expired on';
$string['expirynever'] = 'Never';
$string['expirydate'] = 'Expiry date';
$string['expirydays'] = 'Certificate validity (days)';
$string['expirydays_help'] = 'Number of days the certificate is valid from the date of issue. Set to 0 for no expiry.';
$string['expiryperiod'] = 'Expiry period (days)';
$string['expirysettings'] = 'Expiry settings';
$string['exportcsv'] = 'Export CSV';
$string['exportods'] = 'Export ODS';
$string['exporttemplate'] = 'Export template';
$string['exportxlsx'] = 'Export XLSX';
$string['fieldname'] = 'Field name';
$string['font'] = 'Font';
$string['fontsize'] = 'Font size';
$string['gallerydescription'] = 'Choose a template to start with or create your own from scratch';
$string['generalsettings'] = 'General settings';
$string['getcertificate'] = 'Get Certificate';
$string['gradeitem'] = 'Grade item';
$string['height'] = 'Height';
$string['importtemplate'] = 'Import template';
$string['invalidaction'] = 'Invalid action';
$string['invalidname'] = 'Invalid name';
$string['invalidelementdata'] = 'Invalid element data';
$string['invalidimage'] = 'Upload a PNG, JPEG, GIF or WebP image within the size limit.';
$string['invalidjsontemplate'] = 'The file is not a valid Certificate Studio template.';
$string['invalidpagedata'] = 'Invalid page data';
$string['invalidfilearea'] = 'Invalid file area';
$string['issuedcertificates'] = 'Issued certificates';
$string['issuedcount'] = '{$a} certificate(s) issued';
$string['issuedtemplate'] = 'Certificate issued notification';
$string['issuedtemplate_default'] = 'Dear {studentname},

Congratulations! Your certificate for "{certname}" in the course "{coursename}" has been issued.

You can download it here: {url}

Verification code: {code}

Best regards';
$string['issuedtemplate_desc'] = 'Message sent to the student when a certificate is issued. Placeholders: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Certificate issue not found';
$string['italic'] = 'Italic';
$string['landscape'] = 'Landscape';
$string['layers'] = 'Layers';
$string['loading'] = 'Loading...';
$string['lock'] = 'Lock';
$string['lockunlock'] = 'Lock/Unlock';
$string['manageapprovals'] = 'Manage approvals';
$string['managetemplates'] = 'Manage Templates';
$string['managetemplates_desc'] = 'View, export, import, and delete templates. Manage all built-in and custom templates from one place.';
$string['movedown'] = 'Move down';
$string['moveup'] = 'Move up';
$string['messageprovider:approval_request'] = 'Certificate approval request';
$string['messageprovider:approval_result'] = 'Certificate approval result';
$string['messagetemplates'] = 'Message templates';
$string['messagetemplates_desc'] = 'Customize the notification messages. Placeholders: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Migrate activities (course modules)';
$string['migrateissues'] = 'Migrate issued certificates';
$string['migratetemplates'] = 'Migrate templates (pages and elements)';
$string['migrationcomplete'] = 'Migration complete: {$a->templates} template(s), {$a->activities} activity(ies), {$a->issues} issue(s) migrated.';
$string['migrationlog'] = 'Migration log';
$string['migrationnodata'] = 'No customcert data found to migrate.';
$string['migrationnotavailable'] = 'The Custom Certificate (mod_customcert) plugin is not installed. Nothing to migrate.';
$string['migrationoptions'] = 'Migration options';
$string['migrationsummary'] = 'Custom Certificate data found';
$string['migrationtool'] = 'Migrate from Custom Certificate';
$string['migrationwarning'] = 'This will create new certstudio records from your customcert data. Existing customcert data will NOT be modified or deleted. Already-migrated items will be skipped.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studios';
$string['multilang'] = 'Multi-language certificates';
$string['multilang_desc'] = 'Force certificate language per activity, overriding user preference.';
$string['mycertificates'] = 'My Certificates';
$string['name'] = 'Name';
$string['nelements'] = '{$a} elements';
$string['nocertificates'] = 'You have not received any certificates yet.';
$string['nocertificatesissued'] = 'No certificate has been issued yet. Please complete the required activities to receive your certificate.';
$string['nodata'] = 'No data available.';
$string['notemplateselected'] = 'No template selected yet. A blank template will be created automatically.';
$string['notemplateselectedhelp'] = 'After saving, use the Template Gallery from the activity view page to choose a template.';
$string['norequests'] = 'No approval requests found.';
$string['pending'] = 'Pending';
$string['notapproved'] = 'Your certificate has not been approved yet.';
$string['notemplates'] = 'No templates found.';
$string['notemplatesavailable'] = 'No templates available. Click "Start from Scratch" to create your own certificate.';
$string['notissued'] = 'Not issued';
$string['opacity'] = 'Opacity';
$string['optional'] = 'optional';
$string['pages'] = 'Pages';
$string['pagesettings'] = 'Page settings';
$string['pagesize'] = 'Page size';
$string['pdfsettings'] = 'PDF settings';
$string['platform'] = 'Platform';
$string['pluginadministration'] = 'Certificate Studio administration';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Portrait';
$string['positionandsize'] = 'Position & Size';
$string['previewpdf'] = 'Preview PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Certificate approval requests.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'The reviewer comment on the request.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'The user who reviewed the request.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'The approval status.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'When the request was made.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'When the request was last updated.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'The user who requested the certificate.';
$string['privacy:metadata:certstudio_issues'] = 'Records of issued certificates.';
$string['privacy:metadata:certstudio_issues:code'] = 'The unique verification code.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'The certificate template data snapshot.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'When the certificate was issued.';
$string['privacy:metadata:certstudio_issues:userid'] = 'The user who received the certificate.';
$string['privacy:metadata:ai_provider'] = 'When the AI template generator feature is used, a text description is sent to an external AI service (OpenAI or Anthropic) to generate certificate layouts.';
$string['privacy:metadata:ai_provider:description'] = 'The text description entered by the user to generate a certificate template.';
$string['privacy:path:approvalrequests'] = 'Approval requests';
$string['privacy:path:issues'] = 'Issued certificates';
$string['properties'] = 'Properties';
$string['protection'] = 'PDF protection';
$string['protection_copy'] = 'Prevent copy';
$string['protection_copy_desc'] = 'Enable protection from copy action.';
$string['protection_modify'] = 'Prevent modify';
$string['protection_modify_desc'] = 'Enable protection from modify action.';
$string['protection_print'] = 'Prevent print';
$string['protection_print_desc'] = 'Enable protection from print action.';
$string['protectionflags'] = 'Protection flags';
$string['protectionflags_help'] = 'Comma-separated protection flags: print, modify, copy';
$string['publishtogallery'] = 'Publish to Gallery';
$string['publishtogallerytip'] = 'Publish a copy to the Template Gallery so all courses can use it';
$string['reason'] = 'Reason';
$string['receiveddate'] = 'Date received';
$string['redo'] = 'Redo';
$string['reissue'] = 'Reissue';
$string['reissuedtemplate'] = 'Certificate reissued notification';
$string['reissuedtemplate_default'] = 'Dear {studentname},

A new version of your certificate for "{certname}" in the course "{coursename}" has been issued.

You can download it here: {url}

Verification code: {code}

Best regards';
$string['reissuedtemplate_desc'] = 'Message sent to the student when a new version of their certificate is issued. Placeholders: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Reject';
$string['rejected'] = 'rejected';
$string['rejectedtemplate'] = 'Rejected notification (to student)';
$string['rejectedtemplate_desc'] = 'Message sent to the student when their request is rejected.';
$string['replacetemplate'] = 'Replace the certificate design?';
$string['replacetemplatebutton'] = 'Replace';
$string['replacetemplateconfirm'] = 'This replaces the current design of this activity. Certificates already issued will also show the new design.';
$string['reportanalytics'] = 'Certificate Analytics';
$string['reportmonthly'] = 'Monthly trend (last 12 months)';
$string['reportpercourse'] = 'Certificates per course';
$string['reportrecent'] = 'Recent certificates (last 30 days)';
$string['reporttotalactivities'] = 'Total activities';
$string['reporttotalissued'] = 'Total issued';
$string['reporttotaltemplates'] = 'Total templates';
$string['reportuniquerecipients'] = 'Unique recipients';
$string['requestagain'] = 'Submit new request';
$string['requestapproved'] = 'Request approved successfully.';
$string['requestcertificate'] = 'Request Certificate';
$string['requestpending'] = 'Your certificate request is pending approval.';
$string['requestrejected'] = 'Your certificate request was rejected.';
$string['requestrejectedmsg'] = 'Request rejected successfully.';
$string['requestsubmitted'] = 'Your certificate request has been submitted.';
$string['requiredtime'] = 'Required minutes in course';
$string['requiredtime_desc'] = 'Minimum time in minutes a student must be logged into the course before they can receive the certificate. Set to 0 to disable.';
$string['requiredtimenotmet'] = 'You need to spend at least {$a->required} minutes in this course before you can receive a certificate. You have spent approximately {$a->spent} minutes so far.';
$string['returncourse'] = 'Return to course button';
$string['returncourse_desc'] = 'Display a "Return to course" button on the view certificate page.';
$string['returntocourse'] = 'Return to course';
$string['reviewer'] = 'Reviewer';
$string['revokecertificate'] = 'Revoke certificate';
$string['revoked'] = 'Revoked';
$string['revokeddate'] = 'Revoked on';
$string['revokedrenewal'] = 'Revoked for renewal (new version issued)';
$string['revokedtemplate'] = 'Certificate revoked notification';
$string['revokedtemplate_default'] = 'Dear {studentname},

Your certificate for "{certname}" in the course "{coursename}" has been revoked.

Reason: {reason}

If you have any questions, please contact your instructor.

Best regards';
$string['revokedtemplate_desc'] = 'Message sent to the student when their certificate is revoked. Placeholders: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Rotation';
$string['save'] = 'Save';
$string['savechangestip'] = 'Save changes to this activity only';
$string['saved'] = 'Changes saved';
$string['saveerror'] = 'Error saving changes';
$string['savestatussaved'] = 'Saved';
$string['search:activity'] = 'Certificate Studio - activity information';
$string['searchbyname'] = 'Search by name...';
$string['selectall'] = 'Select all';
$string['selectelement'] = 'Click an element to edit its properties.';
$string['selecttemplate'] = 'Select template';
$string['sharecertificate'] = 'Share';
$string['shareemail'] = 'Email';
$string['sharefacebook'] = 'Facebook';
$string['sharelinkedin'] = 'LinkedIn';
$string['sharetwitter'] = 'Twitter/X';
$string['shareemailbody'] = 'I wanted to share that I earned the certificate "{$a->certname}".

You can verify it here: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'My Certificate: {$a}';
$string['sharetext'] = 'I just earned the certificate "{$a}"!';
$string['showcasecourse'] = 'Course';
$string['showcasedownloadpdf'] = 'Download PDF';
$string['showcaseissuedon'] = 'Issued on';
$string['showcaserecipient'] = 'Awarded to';
$string['showcaseshare'] = 'Share this certificate';
$string['showcasetitle'] = 'Digital Certificate';
$string['showcaseverified'] = 'Verified Certificate';
$string['showposxy'] = 'Show position X and Y';
$string['showposxy_desc'] = 'Show the X and Y position when editing an element, allowing the user to accurately specify the location.';
$string['startfromscratch'] = 'Start from Scratch';
$string['startmigration'] = 'Start migration';
$string['status'] = 'Status';
$string['statusapproved'] = 'Approved';
$string['statusexpired'] = 'Expired';
$string['statuspending'] = 'Pending';
$string['statusrejected'] = 'Rejected';
$string['statusrevoked'] = 'Revoked';
$string['statusvalid'] = 'Valid';
$string['student'] = 'Student';
$string['styleclassic'] = 'Classic';
$string['styledark'] = 'Dark';
$string['styleelegant'] = 'Elegant';
$string['stylegradient'] = 'Gradient';
$string['styleminimal'] = 'Minimal';
$string['stylemodern'] = 'Modern';
$string['stylespecial'] = 'Special';
$string['subplugintype_certstudioselem'] = 'Element type';
$string['subplugintype_certstudioselem_plural'] = 'Element types';
$string['taskemailcertificate'] = 'Email certificate';
$string['taskissuecertificate'] = 'Issue certificates and send emails';
$string['template'] = 'Template';
$string['templatenotfound'] = 'Template not found';
$string['templatedeleted'] = 'Template "{$a}" has been deleted.';
$string['templatefile'] = 'Template file (.json)';
$string['templatefilehelp'] = 'Upload a .certstudio.json file exported from another Certificate Studio installation.';
$string['templategallery'] = 'Template Gallery';
$string['templategalleryhelp'] = 'Use the Template Gallery from the activity view page to change the template.';
$string['templateimported'] = 'Template "{$a->name}" imported successfully ({$a->pages} page(s), {$a->elements} element(s)).';
$string['templateimportinvalid'] = 'Invalid template file. Please upload a valid .certstudio.json file.';
$string['templateinuse'] = 'This template is used by {$a} activity(ies) and cannot be deleted.';
$string['templatenameplaceholder'] = 'Template name...';
$string['templates'] = 'Templates';
$string['templatesharing'] = 'Template Import/Export';
$string['textcontent'] = 'Text content';
$string['toggleelementspanel'] = 'Toggle elements panel';
$string['togglegrid'] = 'Toggle grid';
$string['toggleguides'] = 'Toggle guides';
$string['togglepropertiespanel'] = 'Toggle properties panel';
$string['typography'] = 'Typography';
$string['undo'] = 'Undo';
$string['unknown'] = 'Unknown';
$string['unknownelementtype'] = 'Unknown element type: {$a}';
$string['unknowncourse'] = 'Unknown course';
$string['unknownuser'] = 'Unknown user';
$string['unlock'] = 'Unlock';
$string['uploadbgimage'] = 'Upload';
$string['uploadbgimagetip'] = 'Upload background image';
$string['usethisTemplate'] = 'Use this template';
$string['usethistemplate'] = 'Use this template';
$string['valid'] = 'Valid';
$string['verificationcode'] = 'Verification code';
$string['verify'] = 'Verify';
$string['verifyallcertificates'] = 'Allow public verification';
$string['verifyallcertificates_desc'] = 'Allow anyone to verify certificates without logging in.';
$string['verifyanother'] = 'Verify another certificate';
$string['verifyany'] = 'Allow anyone to verify a certificate';
$string['verifyany_desc'] = 'Allow anyone with the certificate verification link (including users not logged in) to verify a certificate.';
$string['verifycertificate'] = 'Verify Certificate';
$string['verifyintro'] = 'Enter a certificate verification code to verify its authenticity on {$a}.';
$string['verifylink_desc'] = 'This link will take you to a page where you can verify certificates on the site.';
$string['verifynotfound'] = 'No certificate was found with this verification code. Please check and try again.';
$string['verifyurl'] = 'Custom verification URL';
$string['verifyurl_desc'] = 'Custom URL for the QR code verification link. Leave empty to use the default Moodle verification page. Placeholders: {code}';
$string['version'] = 'Version';
$string['viewonline'] = 'View Online';
$string['width'] = 'Width';
$string['zoomin'] = 'Zoom in';
$string['zoomout'] = 'Zoom out';

