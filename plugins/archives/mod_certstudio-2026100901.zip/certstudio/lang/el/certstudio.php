<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Greek language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Οριζόντιο';
$string['actions'] = 'Ενέργειες';
$string['actionsheading'] = 'Ενέργειες';
$string['active'] = 'Ενεργό';
$string['activities'] = 'Δραστηριότητες';
$string['aiapikey'] = 'API κλειδί';
$string['aiapikey_desc'] = 'Το API κλειδί σας για τον επιλεγμένο πάροχο AI.';
$string['aierror'] = 'Σφάλμα AI: {$a}';
$string['aigeneratebutton'] = 'Δημιουργία';
$string['aigeneratedesc'] = 'Περιγράψτε το πιστοποιητικό που θέλετε και το AI θα δημιουργήσει ένα template για εσάς.';
$string['aigenerateplaceholder'] = 'π.χ., επίσημο μπλε πιστοποιητικό για μάθημα πληροφορικής με χρυσό πλαίσιο...';
$string['aigeneratesuccess'] = 'Το template δημιουργήθηκε! Μετάβαση στον editor...';
$string['aigeneratetitle'] = 'Δημιουργία Template με AI';
$string['aigenerating'] = 'Δημιουργία template με AI...';
$string['aimodel'] = 'Μοντέλο';
$string['aimodel_desc'] = 'Το μοντέλο AI. Για OpenAI: gpt-4o-mini, gpt-4o. Για Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'Δεν έχει οριστεί API κλειδί AI. Ορίστε το στις ρυθμίσεις.';
$string['aiparseerror'] = 'Αποτυχία ανάλυσης απάντησης AI. Δοκιμάστε διαφορετική περιγραφή.';
$string['aiprovider'] = 'Πάροχος AI';
$string['aiprovider_desc'] = 'Επιλέξτε ποια υπηρεσία AI θα χρησιμοποιηθεί.';
$string['aisettings'] = 'AI Δημιουργία Template';
$string['aisettings_desc'] = 'Ρυθμίσεις για αυτόματη δημιουργία template με τεχνητή νοημοσύνη. Απαιτείται API key από OpenAI ή Anthropic.';
$string['aligncenter'] = 'Κέντρο';
$string['alignleft'] = 'Αριστερά';
$string['alignright'] = 'Δεξιά';
$string['all'] = 'Όλα';
$string['allcolors'] = 'Όλα τα χρώματα';
$string['allstyles'] = 'Όλα τα στυλ';
$string['alltemplates'] = 'Όλα τα πρότυπα ({$a})';
$string['appearance'] = 'Εμφάνιση';
$string['apply'] = 'Εφαρμογή';
$string['approval'] = 'Ροή έγκρισης';
$string['approvalenabled'] = 'Ενεργοποίηση ροής έγκρισης';
$string['approvalenabled_desc'] = 'Ενεργοποίηση ροής έγκρισης ως προεπιλογή για νέες δραστηριότητες.';
$string['approvalenabled_help'] = 'Όταν είναι ενεργοποιημένο, οι φοιτητές πρέπει να ζητήσουν έγκριση από τον καθηγητή πριν κατεβάσουν το πιστοποιητικό.';
$string['approvalnotifystudent'] = 'Ειδοποίηση φοιτητή στο αποτέλεσμα';
$string['approvalnotifystudent_desc'] = 'Αποστολή ειδοποίησης στους φοιτητές όταν η αίτησή τους εγκρίνεται ή απορρίπτεται.';
$string['approvalnotifyteacher'] = 'Ειδοποίηση καθηγητή σε αίτηση';
$string['approvalnotifyteacher_desc'] = 'Αποστολή ειδοποίησης στους καθηγητές όταν ένας φοιτητής ζητά πιστοποιητικό.';
$string['approvalrequestbody'] = 'Ο/Η {$a->student} ζήτησε πιστοποιητικό για "{$a->activity}".';
$string['approvalrequestbodyhtml'] = '<p>Ο/Η <strong>{$a->student}</strong> ζήτησε πιστοποιητικό για "<strong>{$a->activity}</strong>".</p><p><a href="{$a->url}">Εξέταση αιτήσεων</a></p>';
$string['approvalrequestexists'] = 'Έχετε ήδη μια εκκρεμή αίτηση.';
$string['approvalrequestnotfound'] = 'Η αίτηση δεν βρέθηκε.';
$string['approvalrequestnotpending'] = 'Η αίτηση δεν είναι πλέον εκκρεμής.';
$string['approvalrequests'] = 'Αιτήσεις έγκρισης';
$string['approvalrequestsmall'] = 'Νέα αίτηση πιστοποιητικού από {$a}';
$string['approvalrequestsubject'] = 'Αίτηση έγκρισης πιστοποιητικού: {$a}';
$string['approvalrequesttemplate'] = 'Ειδοποίηση αίτησης (προς καθηγητή)';
$string['approvalrequesttemplate_desc'] = 'Μήνυμα που αποστέλλεται στους καθηγητές όταν ένας φοιτητής ζητά έγκριση πιστοποιητικού.';
$string['approvalresultbody'] = 'Η αίτησή σας για πιστοποιητικό "{$a->activity}" {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Η αίτησή σας για πιστοποιητικό "<strong>{$a->activity}</strong>" <strong>{$a->status}</strong>.</p><p>Αξιολογητής: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Προβολή πιστοποιητικού</a></p>';
$string['approvalresultsmall'] = 'Αίτηση πιστοποιητικού {$a}';
$string['approvalresultsubject'] = 'Αίτηση πιστοποιητικού {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Ρυθμίσεις έγκρισης';
$string['approve'] = 'Έγκριση';
$string['approved'] = 'εγκρίθηκε';
$string['approvedtemplate'] = 'Ειδοποίηση έγκρισης (προς φοιτητή)';
$string['approvedtemplate_desc'] = 'Μήνυμα που αποστέλλεται στον φοιτητή όταν η αίτησή του εγκρίνεται.';
$string['autoissue'] = 'Αυτόματη έκδοση κατά ολοκλήρωση μαθήματος';
$string['autoissue_desc'] = 'Αυτόματη έκδοση πιστοποιητικών όταν ο μαθητής ολοκληρώσει το μάθημα. Απαιτεί ενεργοποίηση ολοκλήρωσης μαθήματος.';
$string['back'] = 'Πίσω';
$string['backtoview'] = 'Πίσω';
$string['batchdownload'] = 'Λήψη όλων ως ZIP';
$string['bgcolor'] = 'Χρώμα φόντου';
$string['bgimage'] = 'Εικόνα φόντου';
$string['bgimageopacity'] = 'Αδιαφάνεια εικόνας φόντου';
$string['bgimagesize'] = 'Μέγεθος εικόνας φόντου';
$string['bgimagesizeactual'] = 'Πραγματικό μέγεθος';
$string['bgimagesizecontain'] = 'Περιεχόμενο (χωράει μέσα)';
$string['bgimagesizecover'] = 'Κάλυψη (γέμισμα σελίδας)';
$string['bgimagesizestretch'] = 'Τέντωμα';
$string['bold'] = 'Έντονα';
$string['bordercolor'] = 'Χρώμα πλαισίου';
$string['borderstyle'] = 'Στυλ πλαισίου';
$string['borderwidth'] = 'Πάχος πλαισίου';
$string['builtin'] = 'Ενσωματωμένα';
$string['builtintemplates'] = 'Ενσωματωμένα πρότυπα';
$string['bulkactions'] = 'Μαζικές ενέργειες';
$string['bulkdelete'] = 'Διαγραφή';
$string['bulkemail'] = 'Αποστολή email';
$string['bulkissue'] = 'Μαζική Έκδοση';
$string['bulkissuealreadyissued'] = '{$a} μαθητής(ές) έχουν ήδη πιστοποιητικό (παραλείφθηκαν)';
$string['bulkissuecomplete'] = '{$a} πιστοποιητικό(ά) εκδόθηκαν επιτυχώς.';
$string['bulkissuedefaultmessage'] = 'Αγαπητέ/ή {studentname},

Συγχαρητήρια! Το πιστοποιητικό σας για "{certname}" στο μάθημα "{coursename}" έχει εκδοθεί.

Μπορείτε να το κατεβάσετε εδώ: {url}

Με εκτίμηση';
$string['bulkissuedesc'] = 'Έκδοση πιστοποιητικών σε όλους τους εγγεγραμμένους μαθητές που δεν έχουν λάβει ακόμα.';
$string['bulkissuenoeligible'] = 'Όλοι οι εγγεγραμμένοι μαθητές έχουν ήδη λάβει πιστοποιητικό.';
$string['bulkissuenoselection'] = 'Δεν επιλέχθηκαν μαθητές.';
$string['bulkissuenotified'] = '{$a} μαθητής(ές) ειδοποιήθηκαν.';
$string['bulkissuenotify'] = 'Ενημέρωση μαθητών';
$string['bulkissuenotifyemail'] = 'Αποστολή ειδοποίησης μέσω email';
$string['bulkissuenotifymessage'] = 'Μήνυμα ειδοποίησης';
$string['bulkissuenotifymoodle'] = 'Αποστολή ειδοποίησης μέσω Moodle';
$string['bulkissuenotifyplaceholders'] = 'Διαθέσιμα placeholders: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Το πιστοποιητικό σας για {$a} έχει εκδοθεί.';
$string['bulkissuenotifysubject'] = 'Το πιστοποιητικό σας εκδόθηκε: {$a}';
$string['bulkissuesubmit'] = 'Έκδοση πιστοποιητικών σε {$a} μαθητή(ές)';
$string['bulkoperationcomplete'] = '{$a->count} πιστοποιητικό(ά) επηρεάστηκαν ({$a->action}).';
$string['bulkreissue'] = 'Επανέκδοση';
$string['bulkrevoke'] = 'Ανάκληση';
$string['cannotissue_alreadyissued'] = 'Έχετε ήδη πιστοποιητικό για αυτή τη δραστηριότητα.';
$string['cannotissue_approval'] = 'Το πιστοποιητικό χρειάζεται πρώτα έγκριση από τον καθηγητή σας.';
$string['cannotissue_nopermission'] = 'Δεν έχετε δικαίωμα να λάβετε αυτό το πιστοποιητικό.';
$string['cannotissue_notavailable'] = 'Το πιστοποιητικό δεν είναι ακόμη διαθέσιμο για εσάς.';
$string['cannotissue_notenrolled'] = 'Χρειάζεστε ενεργή εγγραφή στο μάθημα για να λάβετε αυτό το πιστοποιητικό.';
$string['cannotissue_requiredtime'] = 'Δεν έχετε συμπληρώσει ακόμη τον απαιτούμενο χρόνο στο μάθημα.';
$string['cannotissue_revoked'] = 'Το πιστοποιητικό σας για αυτή τη δραστηριότητα έχει ανακληθεί. Επικοινωνήστε με τον καθηγητή σας.';
$string['certificate'] = 'Πιστοποιητικό';
$string['certificateexpired'] = 'Αυτό το πιστοποιητικό έληξε στις {$a}.';
$string['certificateexpiredverify'] = 'Αυτό το πιστοποιητικό έχει λήξει';
$string['certificateexpires'] = 'Αυτό το πιστοποιητικό λήγει στις {$a}.';
$string['certificateinvalid'] = 'Αυτό το πιστοποιητικό δεν είναι έγκυρο';
$string['certificateissued'] = 'Το πιστοποιητικό σας εκδόθηκε στις {$a}.';
$string['certificatenotfound'] = 'Δεν βρέθηκε πιστοποιητικό με αυτόν τον κωδικό.';
$string['certificaterevoked'] = 'Το πιστοποιητικό ανακλήθηκε';
$string['certificaterevokedstudent'] = 'Το πιστοποιητικό σας έχει ανακληθεί.';
$string['certificatevalid'] = 'Αυτό το πιστοποιητικό είναι έγκυρο';
$string['certificateversion'] = 'Έκδοση πιστοποιητικού';
$string['certstudio:addinstance'] = 'Προσθήκη δραστηριότητας Certificate Studio';
$string['certstudio:approvecertificate'] = 'Έγκριση αιτήσεων πιστοποιητικών';
$string['certstudio:manage'] = 'Διαχείριση προτύπων πιστοποιητικών';
$string['certstudio:manageemailstudents'] = 'Διαχείριση ρυθμίσεων ειδοποιήσεων email';
$string['certstudio:manageprotection'] = 'Διαχείριση ρυθμίσεων προστασίας PDF';
$string['certstudio:managetemplates'] = 'Διαχείριση προτύπων πιστοποιητικών';
$string['certstudio:receiveissue'] = 'Λήψη πιστοποιητικού';
$string['certstudio:revokecertificate'] = 'Ανάκληση εκδοθέντων πιστοποιητικών';
$string['certstudio:verifycertificate'] = 'Επαλήθευση κωδικών πιστοποιητικών';
$string['certstudio:view'] = 'Προβολή πιστοποιητικού';
$string['certstudio:viewallcertificates'] = 'Προβολή όλων των πιστοποιητικών';
$string['certstudio:viewreport'] = 'Προβολή αναφορών και αναλυτικών πιστοποιητικών';
$string['city'] = 'Πόλη';
$string['clearbg'] = 'Καθαρισμός φόντου';
$string['clicktorenametemplate'] = 'Κλικ για μετονομασία προτύπου';
$string['codegenerationmethod'] = 'Μέθοδος δημιουργίας κωδικού';
$string['codegenerationmethod_desc'] = 'Επιλέξτε τη μέθοδο δημιουργίας κωδικών επαλήθευσης πιστοποιητικών.';
$string['codegenerationmethod_digitshyphens'] = 'Αριθμοί με παύλες (π.χ. 1234-5678-9012)';
$string['codegenerationmethod_upperlowerdigits'] = 'Τυχαίο αλφαριθμητικό (π.χ. 6aOdbLEuoC)';
$string['color'] = 'Χρώμα';
$string['colorblue'] = 'Μπλε';
$string['colordark'] = 'Σκούρο';
$string['colorgold'] = 'Χρυσό';
$string['colorgray'] = 'Γκρι';
$string['colorgreen'] = 'Πράσινο';
$string['colorpink'] = 'Ροζ';
$string['colorpurple'] = 'Μωβ';
$string['colorred'] = 'Κόκκινο';
$string['comment'] = 'Σχόλιο';
$string['confirmbulk'] = 'Είστε σίγουροι ότι θέλετε να εφαρμόσετε αυτήν την ενέργεια στα επιλεγμένα πιστοποιητικά;';
$string['confirmdelete'] = 'Είστε σίγουροι ότι θέλετε να διαγράψετε αυτό το πρότυπο;';
$string['confirmdeleteissue'] = 'Είστε σίγουροι ότι θέλετε να διαγράψετε μόνιμα αυτό το πιστοποιητικό;';
$string['confirmrevoke'] = 'Είστε σίγουροι ότι θέλετε να ανακαλέσετε αυτό το πιστοποιητικό;';
$string['copy'] = 'Αντιγραφή';
$string['course'] = 'Μάθημα';
$string['createblank'] = 'Δημιουργία κενού';
$string['createblankdesc'] = 'Ξεκινήστε με ένα κενό πρότυπο και σχεδιάστε από την αρχή.';
$string['created'] = 'Δημιουργήθηκε';
$string['createtemplate'] = '-- Δημιουργία νέου προτύπου --';
$string['current'] = 'Τρέχον';
$string['currenttemplate'] = 'Τρέχον πρότυπο';
$string['custom'] = 'Προσαρμοσμένο';
$string['customsource'] = 'Προσαρμοσμένα';
$string['customtemplates'] = 'Προσαρμοσμένα πρότυπα';
$string['dateformat'] = 'Μορφή ημερομηνίας';
$string['dateissued'] = 'Ημερομηνία έκδοσης';
$string['daterequested'] = 'Ημερομηνία αίτησης';
$string['defaultfilename'] = 'Προεπιλεγμένο όνομα αρχείου PDF';
$string['defaultfilename_desc'] = 'Προεπιλεγμένο μοτίβο ονόματος για τα PDF. Placeholders: {coursename}, {studentname}, {date}, {activityname}. Μπορεί να αλλάξει ανά δραστηριότητα.';
$string['defaultprotection'] = 'Προεπιλεγμένη προστασία PDF';
$string['defaultprotection_desc'] = 'Προεπιλεγμένες σημαίες προστασίας (χωρισμένες με κόμμα): print, modify, copy. Μπορεί να αλλάξει ανά δραστηριότητα.';
$string['defaultvalues'] = 'Προεπιλεγμένες τιμές δραστηριοτήτων';
$string['defaultvalues_desc'] = 'Οι προεπιλεγμένες τιμές χρησιμοποιούνται στη φόρμα ρυθμίσεων κατά τη δημιουργία νέας δραστηριότητας.';
$string['delete'] = 'Διαγραφή';
$string['deleteissuedcertificates'] = 'Διαγραφή εκδομένων πιστοποιητικών';
$string['downloadcertificate'] = 'Λήψη Πιστοποιητικού';
$string['downloadfilename'] = 'Όνομα αρχείου PDF';
$string['downloadfilename_help'] = 'Προσαρμοσμένο όνομα αρχείου για το PDF πιστοποιητικό. Μπορείτε να χρησιμοποιήσετε placeholders: {coursename}, {studentname}, {date}. Αφήστε κενό για να χρησιμοποιηθεί το όνομα της δραστηριότητας. Παράδειγμα: Πιστοποιητικό_{coursename}_{studentname}';
$string['downloadsettings'] = 'Ρυθμίσεις λήψης';
$string['editcertstudio'] = 'Επεξεργασία πιστοποιητικού';
$string['edittemplate'] = 'Επεξεργασία Προτύπου';
$string['elementcount'] = '{$a} στοιχεία';
$string['elementname'] = 'Όνομα στοιχείου';
$string['elements'] = 'Στοιχεία';
$string['elementtype_bgimage'] = 'Εικόνα φόντου';
$string['elementtype_border'] = 'Πλαίσιο';
$string['elementtype_categoryname'] = 'Κατηγορία μαθήματος';
$string['elementtype_certdate'] = 'Ελληνική ημερομηνία';
$string['elementtype_certstatement'] = 'Βεβαίωση';
$string['elementtype_code'] = 'Κωδικός επαλήθευσης';
$string['elementtype_coursefield'] = 'Πεδίο μαθήματος';
$string['elementtype_coursename'] = 'Όνομα μαθήματος';
$string['elementtype_date'] = 'Ημερομηνία';
$string['elementtype_daterange'] = 'Εύρος ημερομηνιών';
$string['elementtype_digitalsignature'] = 'Ψηφιακή υπογραφή';
$string['elementtype_expiry'] = 'Ημερομηνία λήξης';
$string['elementtype_grade'] = 'Βαθμός';
$string['elementtype_gradeitemname'] = 'Όνομα στοιχείου βαθμολογίας';
$string['elementtype_image'] = 'Εικόνα';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Όνομα φοιτητή';
$string['elementtype_teachername'] = 'Όνομα καθηγητή';
$string['elementtype_text'] = 'Κείμενο';
$string['elementtype_userfield'] = 'Πεδίο χρήστη';
$string['elementtype_userpicture'] = 'Φωτογραφία χρήστη';
$string['emailcertbody'] = 'Αγαπητέ/ή {$a->studentname},

Το πιστοποιητικό σας για "{$a->certname}" στο μάθημα "{$a->coursename}" είναι συνημμένο σε αυτό το email.

Κωδικός επαλήθευσης: {$a->code}
Επαλήθευση online: {$a->verifyurl}

Με εκτίμηση';
$string['emailcertificate'] = 'Αποστολή πιστοποιητικού';
$string['emailcertificatebody'] = 'Αγαπητέ/ή {$a->fullname},

Το πιστοποιητικό σας για "{$a->certname}" στο μάθημα "{$a->coursename}" εκδόθηκε.

Μπορείτε να το επαληθεύσετε με τον κωδικό: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Το πιστοποιητικό σας για {$a}';
$string['emailcertsubject'] = 'Το πιστοποιητικό σας: {$a}';
$string['emailcerttemplate'] = 'Ειδοποίηση αποστολής πιστοποιητικού';
$string['emailcerttemplate_default'] = 'Αγαπητέ/ή {studentname},

Το πιστοποιητικό σας για "{certname}" στο μάθημα "{coursename}" είναι συνημμένο σε αυτό το email.

Κωδικός επαλήθευσης: {code}
Επαλήθευση online: {verifyurl}

Με εκτίμηση';
$string['emailcerttemplate_desc'] = 'Σώμα μηνύματος κατά την αποστολή PDF πιστοποιητικού ως συνημμένο. Placeholders: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Email σε άλλους';
$string['emailothers_desc'] = 'Διευθύνσεις email (χωρισμένες με κόμμα) που θα λαμβάνουν αντίγραφο του πιστοποιητικού.';
$string['emailsent'] = 'Το email στάλθηκε επιτυχώς.';
$string['emailsettings'] = 'Ειδοποιήσεις email';
$string['emailstudents'] = 'Email σε μαθητές';
$string['emailstudents_desc'] = 'Αν ενεργοποιηθεί, οι μαθητές θα λαμβάνουν αντίγραφο του πιστοποιητικού μέσω email.';
$string['emailteacherbody'] = 'Ένα πιστοποιητικό για "{$a->certname}" εκδόθηκε στον/στην {$a->fullname} στο μάθημα "{$a->coursename}".';
$string['emailteachers'] = 'Email σε εκπαιδευτές';
$string['emailteachers_desc'] = 'Αν ενεργοποιηθεί, οι εκπαιδευτές θα λαμβάνουν αντίγραφο του πιστοποιητικού μέσω email.';
$string['emailteachersubject'] = 'Πιστοποιητικό εκδόθηκε: {$a->certname}';
$string['entercode'] = 'Εισάγετε τον κωδικό επαλήθευσης';
$string['eventcertificateapproved'] = 'Έγκριση πιστοποιητικού';
$string['eventcertificateissued'] = 'Έκδοση πιστοποιητικού';
$string['eventcertificaterejected'] = 'Απόρριψη πιστοποιητικού';
$string['eventcertificaterequested'] = 'Αίτηση πιστοποιητικού';
$string['eventcertificaterevoked'] = 'Ανάκληση πιστοποιητικού';
$string['eventpagecreated'] = 'Δημιουργία σελίδας';
$string['eventpagedeleted'] = 'Διαγραφή σελίδας';
$string['eventtemplatecreated'] = 'Δημιουργία προτύπου';
$string['eventtemplatedeleted'] = 'Διαγραφή προτύπου';
$string['eventtemplateupdated'] = 'Ενημέρωση προτύπου';
$string['expired'] = 'Ληγμένο';
$string['expiredon'] = 'Έληξε στις {$a}';
$string['expirydate'] = 'Ημερομηνία λήξης';
$string['expirydays'] = 'Ισχύς πιστοποιητικού (ημέρες)';
$string['expirydays_help'] = 'Αριθμός ημερών που ισχύει το πιστοποιητικό από την ημερομηνία έκδοσης. 0 = χωρίς λήξη.';
$string['expiryperiod'] = 'Περίοδος λήξης (ημέρες)';
$string['expirysettings'] = 'Ρυθμίσεις λήξης';
$string['exporttemplate'] = 'Εξαγωγή template';
$string['fieldname'] = 'Όνομα πεδίου';
$string['font'] = 'Γραμματοσειρά';
$string['fontsize'] = 'Μέγεθος γραμματοσειράς';
$string['gallerydescription'] = 'Επιλέξτε ένα πρότυπο για να ξεκινήσετε ή δημιουργήστε ένα κενό.';
$string['generalsettings'] = 'Γενικές ρυθμίσεις';
$string['getcertificate'] = 'Λήψη Πιστοποιητικού';
$string['gradeitem'] = 'Στοιχείο βαθμολογίας';
$string['height'] = 'Ύψος';
$string['importtemplate'] = 'Εισαγωγή template';
$string['invalidaction'] = 'Μη έγκυρη ενέργεια';
$string['invalidelementdata'] = 'Μη έγκυρα δεδομένα στοιχείου';
$string['invalidimage'] = 'Ανεβάστε εικόνα PNG, JPEG, GIF ή WebP εντός του ορίου μεγέθους.';
$string['invalidjsontemplate'] = 'Το αρχείο δεν είναι έγκυρο template του Certificate Studio.';
$string['invalidpagedata'] = 'Μη έγκυρα δεδομένα σελίδας';
$string['invalidfilearea'] = 'Μη έγκυρη περιοχή αρχείου';
$string['issuedcertificates'] = 'Εκδοθέντα πιστοποιητικά';
$string['issuedcount'] = '{$a} πιστοποιητικά εκδόθηκαν';
$string['issuedtemplate'] = 'Ειδοποίηση έκδοσης πιστοποιητικού';
$string['issuedtemplate_default'] = 'Αγαπητέ/ή {studentname},

Συγχαρητήρια! Το πιστοποιητικό σας για "{certname}" στο μάθημα "{coursename}" έχει εκδοθεί.

Μπορείτε να το κατεβάσετε εδώ: {url}

Κωδικός επαλήθευσης: {code}

Με εκτίμηση';
$string['issuedtemplate_desc'] = 'Μήνυμα που αποστέλλεται στον μαθητή όταν εκδίδεται πιστοποιητικό. Placeholders: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Δεν βρέθηκε πιστοποιητικό.';
$string['italic'] = 'Πλάγια';
$string['landscape'] = 'Οριζόντιο';
$string['layers'] = 'Επίπεδα';
$string['loading'] = 'Φόρτωση...';
$string['lock'] = 'Κλείδωμα';
$string['manageapprovals'] = 'Διαχείριση εγκρίσεων';
$string['managetemplates'] = 'Διαχείριση Templates';
$string['managetemplates_desc'] = 'Προβολή, εξαγωγή, εισαγωγή και διαγραφή templates. Διαχειριστείτε όλα τα ενσωματωμένα και προσαρμοσμένα templates από ένα σημείο.';
$string['messageprovider:approval_request'] = 'Αίτηση έγκρισης πιστοποιητικού';
$string['messageprovider:approval_result'] = 'Αποτέλεσμα έγκρισης πιστοποιητικού';
$string['messagetemplates'] = 'Πρότυπα μηνυμάτων';
$string['messagetemplates_desc'] = 'Προσαρμόστε τα μηνύματα ειδοποίησης που αποστέλλονται κατά τη ροή έγκρισης. Placeholders: {student}, {activity}, {course}, {status}, {reviewer}, {comment}, {url}';
$string['migrateactivities'] = 'Μετάβαση δραστηριοτήτων (course modules)';
$string['migrateissues'] = 'Μετάβαση εκδοθέντων πιστοποιητικών';
$string['migratetemplates'] = 'Μετάβαση templates (σελίδες και στοιχεία)';
$string['migrationcomplete'] = 'Μετάβαση ολοκληρώθηκε: {$a->templates} template(s), {$a->activities} δραστηριότητα(ες), {$a->issues} πιστοποιητικό(ά) μεταφέρθηκαν.';
$string['migrationlog'] = 'Αρχείο καταγραφής μετάβασης';
$string['migrationnodata'] = 'Δεν βρέθηκαν δεδομένα customcert προς μετάβαση.';
$string['migrationnotavailable'] = 'Το plugin Custom Certificate (mod_customcert) δεν είναι εγκατεστημένο. Δεν υπάρχει τίποτα να μεταφερθεί.';
$string['migrationoptions'] = 'Επιλογές μετάβασης';
$string['migrationsummary'] = 'Δεδομένα Custom Certificate που βρέθηκαν';
$string['migrationtool'] = 'Μετάβαση από Custom Certificate';
$string['migrationwarning'] = 'Αυτό θα δημιουργήσει νέα certstudio records από τα δεδομένα customcert. Τα υπάρχοντα δεδομένα customcert ΔΕΝ θα τροποποιηθούν ή διαγραφούν. Ήδη μεταφερθέντα στοιχεία θα παραλειφθούν.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studios';
$string['multilang'] = 'Πολύγλωσσα πιστοποιητικά';
$string['multilang_desc'] = 'Ενεργοποίηση υποστήριξης πολλαπλών γλωσσών για στοιχεία πιστοποιητικού.';
$string['mycertificates'] = 'Τα Πιστοποιητικά μου';
$string['name'] = 'Όνομα';
$string['nelements'] = '{$a} στοιχεία';
$string['nocertificates'] = 'Δεν έχετε λάβει πιστοποιητικά ακόμα.';
$string['nocertificatesissued'] = 'Δεν έχουν εκδοθεί πιστοποιητικά ακόμα.';
$string['nodata'] = 'Δεν υπάρχουν δεδομένα.';
$string['norequests'] = 'Δεν βρέθηκαν αιτήσεις έγκρισης.';
$string['notapproved'] = 'Το πιστοποιητικό σας δεν έχει εγκριθεί ακόμα.';
$string['notemplates'] = 'Δεν βρέθηκαν templates.';
$string['notemplatesavailable'] = 'Δεν υπάρχουν διαθέσιμα πρότυπα. Κάντε κλικ στο "Ξεκινήστε από την αρχή" για να δημιουργήσετε το δικό σας πιστοποιητικό.';
$string['notissued'] = 'Δεν εκδόθηκε';
$string['opacity'] = 'Διαφάνεια';
$string['optional'] = 'Προαιρετικό';
$string['pages'] = 'Σελίδες';
$string['pagesettings'] = 'Ρυθμίσεις σελίδας';
$string['pagesize'] = 'Μέγεθος σελίδας';
$string['pdfsettings'] = 'Ρυθμίσεις PDF';
$string['platform'] = 'Πλατφόρμα';
$string['pluginadministration'] = 'Διαχείριση Certificate Studio';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Κατακόρυφο';
$string['positionandsize'] = 'Θέση & Μέγεθος';
$string['previewpdf'] = 'Προεπισκόπηση PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Αιτήσεις έγκρισης πιστοποιητικών.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'Σχόλιο αξιολόγησης.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'Ο χρήστης που αξιολόγησε την αίτηση.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'Η κατάσταση έγκρισης.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Πότε υποβλήθηκε η αίτηση.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Πότε τροποποιήθηκε η αίτηση.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'Ο χρήστης που ζήτησε το πιστοποιητικό.';
$string['privacy:metadata:certstudio_issues'] = 'Εγγραφές εκδοθέντων πιστοποιητικών.';
$string['privacy:metadata:certstudio_issues:code'] = 'Ο μοναδικός κωδικός επαλήθευσης.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'Τα δεδομένα του προτύπου τη στιγμή της έκδοσης.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Πότε εκδόθηκε το πιστοποιητικό.';
$string['privacy:metadata:certstudio_issues:userid'] = 'Ο χρήστης που έλαβε το πιστοποιητικό.';
$string['privacy:path:approvalrequests'] = 'Αιτήσεις έγκρισης';
$string['privacy:path:issues'] = 'Εκδοθέντα πιστοποιητικά';
$string['properties'] = 'Ιδιότητες';
$string['protection'] = 'Προστασία PDF';
$string['protection_copy'] = 'Αποτροπή αντιγραφής';
$string['protection_copy_desc'] = 'Ενεργοποίηση προστασίας από αντιγραφή.';
$string['protection_modify'] = 'Αποτροπή τροποποίησης';
$string['protection_modify_desc'] = 'Ενεργοποίηση προστασίας από τροποποίηση.';
$string['protection_print'] = 'Αποτροπή εκτύπωσης';
$string['protection_print_desc'] = 'Ενεργοποίηση προστασίας από εκτύπωση.';
$string['protectionflags'] = 'Σημαίες προστασίας';
$string['protectionflags_help'] = 'Σημαίες προστασίας χωρισμένες με κόμμα: print, modify, copy';
$string['publishtogallery'] = 'Δημοσίευση στη Συλλογή';
$string['publishtogallerytip'] = 'Δημοσίευση αντιγράφου στη Συλλογή Προτύπων ώστε να το χρησιμοποιήσουν όλα τα μαθήματα';
$string['reason'] = 'Λόγος';
$string['receiveddate'] = 'Ημερομηνία λήψης';
$string['redo'] = 'Επανάληψη';
$string['reissue'] = 'Επανέκδοση';
$string['reissuedtemplate'] = 'Ειδοποίηση επανέκδοσης πιστοποιητικού';
$string['reissuedtemplate_default'] = 'Αγαπητέ/ή {studentname},

Μια νέα έκδοση του πιστοποιητικού σας για "{certname}" στο μάθημα "{coursename}" έχει εκδοθεί.

Μπορείτε να το κατεβάσετε εδώ: {url}

Κωδικός επαλήθευσης: {code}

Με εκτίμηση';
$string['reissuedtemplate_desc'] = 'Μήνυμα που αποστέλλεται στον μαθητή όταν επανεκδίδεται το πιστοποιητικό. Placeholders: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Απόρριψη';
$string['rejected'] = 'απορρίφθηκε';
$string['rejectedtemplate'] = 'Ειδοποίηση απόρριψης (προς φοιτητή)';
$string['rejectedtemplate_desc'] = 'Μήνυμα που αποστέλλεται στον φοιτητή όταν η αίτησή του απορρίπτεται.';
$string['replacetemplate'] = 'Αντικατάσταση του σχεδίου πιστοποιητικού;';
$string['replacetemplatebutton'] = 'Αντικατάσταση';
$string['replacetemplateconfirm'] = 'Το τρέχον σχέδιο αυτής της δραστηριότητας θα αντικατασταθεί. Τα πιστοποιητικά που έχουν ήδη εκδοθεί θα εμφανίζουν επίσης το νέο σχέδιο.';
$string['reportanalytics'] = 'Αναλυτικά Πιστοποιητικών';
$string['reportmonthly'] = 'Μηνιαία τάση (τελευταίοι 12 μήνες)';
$string['reportpercourse'] = 'Πιστοποιητικά ανά μάθημα';
$string['reportrecent'] = 'Πρόσφατα πιστοποιητικά (τελευταίες 30 ημέρες)';
$string['reporttotalactivities'] = 'Συνολικές δραστηριότητες';
$string['reporttotalissued'] = 'Συνολικά εκδοθέντα';
$string['reporttotaltemplates'] = 'Συνολικά templates';
$string['reportuniquerecipients'] = 'Μοναδικοί παραλήπτες';
$string['requestagain'] = 'Υποβολή νέας αίτησης';
$string['requestapproved'] = 'Η αίτηση εγκρίθηκε επιτυχώς.';
$string['requestcertificate'] = 'Αίτηση Πιστοποιητικού';
$string['requestpending'] = 'Η αίτησή σας εκκρεμεί προς έγκριση.';
$string['requestrejected'] = 'Η αίτησή σας απορρίφθηκε.';
$string['requestrejectedmsg'] = 'Η αίτηση απορρίφθηκε επιτυχώς.';
$string['requestsubmitted'] = 'Η αίτησή σας υποβλήθηκε.';
$string['requiredtime'] = 'Απαιτούμενα λεπτά στο μάθημα';
$string['requiredtime_desc'] = 'Ελάχιστος χρόνος σε λεπτά που πρέπει να είναι συνδεδεμένος ο μαθητής πριν λάβει το πιστοποιητικό. 0 = απενεργοποιημένο.';
$string['requiredtimenotmet'] = 'Πρέπει να περάσετε τουλάχιστον {$a->required} λεπτά σε αυτό το μάθημα πριν μπορέσετε να λάβετε πιστοποιητικό. Έχετε περάσει περίπου {$a->spent} λεπτά μέχρι στιγμής.';
$string['returncourse'] = 'Κουμπί επιστροφής στο μάθημα';
$string['returncourse_desc'] = 'Εμφάνιση κουμπιού "Επιστροφή στο μάθημα" στη σελίδα προβολής πιστοποιητικού.';
$string['returntocourse'] = 'Επιστροφή στο μάθημα';
$string['reviewer'] = 'Αξιολογητής';
$string['revokecertificate'] = 'Ανάκληση πιστοποιητικού';
$string['revoked'] = 'Ανακλημένο';
$string['revokeddate'] = 'Ημ/νία ανάκλησης';
$string['revokedrenewal'] = 'Ανακλήθηκε λόγω ανανέωσης';
$string['revokedtemplate'] = 'Ειδοποίηση ανάκλησης πιστοποιητικού';
$string['revokedtemplate_default'] = 'Αγαπητέ/ή {studentname},

Το πιστοποιητικό σας για "{certname}" στο μάθημα "{coursename}" ανακλήθηκε.

Λόγος: {reason}

Εάν έχετε ερωτήσεις, επικοινωνήστε με τον εκπαιδευτή σας.

Με εκτίμηση';
$string['revokedtemplate_desc'] = 'Μήνυμα που αποστέλλεται στον μαθητή όταν ανακαλείται το πιστοποιητικό. Placeholders: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Περιστροφή';
$string['save'] = 'Αποθήκευση';
$string['savechangestip'] = 'Αποθήκευση αλλαγών μόνο σε αυτή τη δραστηριότητα';
$string['saved'] = 'Οι αλλαγές αποθηκεύτηκαν';
$string['saveerror'] = 'Σφάλμα αποθήκευσης';
$string['savestatussaved'] = 'Αποθηκεύτηκε';
$string['searchbyname'] = 'Αναζήτηση με όνομα...';
$string['selectelement'] = 'Κάντε κλικ σε ένα στοιχείο για επεξεργασία.';
$string['selecttemplate'] = 'Επιλογή προτύπου';
$string['sharecertificate'] = 'Κοινοποίηση';
$string['shareemailbody'] = 'Θέλω να μοιραστώ ότι απέκτησα το πιστοποιητικό "{$a->certname}".

Μπορείτε να το επαληθεύσετε εδώ: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Το πιστοποιητικό μου: {$a}';
$string['sharetext'] = 'Μόλις απέκτησα το πιστοποιητικό "{$a}"!';
$string['showcasecourse'] = 'Μάθημα';
$string['showcasedownloadpdf'] = 'Λήψη PDF';
$string['showcaseissuedon'] = 'Εκδόθηκε στις';
$string['showcaserecipient'] = 'Απονεμήθηκε στον/στην';
$string['showcaseshare'] = 'Κοινοποίηση πιστοποιητικού';
$string['showcasetitle'] = 'Ψηφιακό Πιστοποιητικό';
$string['showcaseverified'] = 'Επαληθευμένο Πιστοποιητικό';
$string['showposxy'] = 'Εμφάνιση θέσης X και Y';
$string['showposxy_desc'] = 'Εμφάνιση της θέσης X και Y κατά την επεξεργασία στοιχείου, επιτρέποντας ακριβή τοποθέτηση.';
$string['startfromscratch'] = 'Ξεκινήστε από την αρχή';
$string['startmigration'] = 'Έναρξη μετάβασης';
$string['status'] = 'Κατάσταση';
$string['statusapproved'] = 'Εγκεκριμένη';
$string['statusexpired'] = 'Ληγμένο';
$string['statuspending'] = 'Εκκρεμής';
$string['statusrejected'] = 'Απορριφθείσα';
$string['statusrevoked'] = 'Ανακλημένο';
$string['statusvalid'] = 'Έγκυρο';
$string['student'] = 'Φοιτητής';
$string['styleclassic'] = 'Κλασικό';
$string['styledark'] = 'Σκούρο';
$string['styleelegant'] = 'Κομψό';
$string['stylegradient'] = 'Ντεγκραντέ';
$string['styleminimal'] = 'Μινιμαλιστικό';
$string['stylemodern'] = 'Μοντέρνο';
$string['stylespecial'] = 'Ειδικό';
$string['taskemailcertificate'] = 'Αποστολή πιστοποιητικού μέσω email';
$string['taskissuecertificate'] = 'Έκδοση πιστοποιητικών και αποστολή email';
$string['template'] = 'Πρότυπο';
$string['templatedeleted'] = 'Το πρότυπο διαγράφηκε.';
$string['templatefile'] = 'Αρχείο template (.json)';
$string['templatefilehelp'] = 'Ανεβάστε ένα .certstudio.json αρχείο που εξήχθη από άλλη εγκατάσταση Certificate Studio.';
$string['templategallery'] = 'Συλλογή προτύπων';
$string['templateimported'] = 'Το template "{$a->name}" εισήχθη επιτυχώς ({$a->pages} σελίδα(ες), {$a->elements} στοιχείο(α)).';
$string['templateimportinvalid'] = 'Μη έγκυρο αρχείο template. Ανεβάστε ένα έγκυρο .certstudio.json αρχείο.';
$string['templateinuse'] = 'Αυτό το πρότυπο χρησιμοποιείται σε {$a} δραστηριότητα(ες) και δεν μπορεί να διαγραφεί.';
$string['templatenameplaceholder'] = 'Όνομα προτύπου...';
$string['templates'] = 'Templates';
$string['templatesharing'] = 'Εισαγωγή/Εξαγωγή Templates';
$string['textcontent'] = 'Περιεχόμενο κειμένου';
$string['toggleelementspanel'] = 'Εναλλαγή πίνακα στοιχείων';
$string['togglegrid'] = 'Εμφάνιση/Απόκρυψη πλέγματος';
$string['toggleguides'] = 'Εμφάνιση/Απόκρυψη οδηγών';
$string['togglepropertiespanel'] = 'Εναλλαγή πίνακα ιδιοτήτων';
$string['typography'] = 'Τυπογραφία';
$string['undo'] = 'Αναίρεση';
$string['unknowncourse'] = 'Άγνωστο μάθημα';
$string['unknownelementtype'] = 'Άγνωστος τύπος στοιχείου: {$a}';
$string['unknownuser'] = 'Άγνωστος χρήστης';
$string['unlock'] = 'Ξεκλείδωμα';
$string['uploadbgimage'] = 'Μεταφόρτωση';
$string['uploadbgimagetip'] = 'Μεταφόρτωση εικόνας φόντου';
$string['usethisTemplate'] = 'Χρήση αυτού του προτύπου';
$string['usethistemplate'] = 'Χρήση αυτού του προτύπου';
$string['valid'] = 'Έγκυρο';
$string['verificationcode'] = 'Κωδικός επαλήθευσης';
$string['verify'] = 'Επαλήθευση';
$string['verifyallcertificates'] = 'Δημόσια επαλήθευση';
$string['verifyallcertificates_desc'] = 'Να επιτρέπεται η επαλήθευση πιστοποιητικών χωρίς σύνδεση.';
$string['verifyanother'] = 'Επαλήθευση άλλου πιστοποιητικού';
$string['verifyany'] = 'Επιτροπή επαλήθευσης από οποιονδήποτε';
$string['verifyany_desc'] = 'Επιτρέπει σε οποιονδήποτε με τον σύνδεσμο επαλήθευσης να επαληθεύσει ένα πιστοποιητικό.';
$string['verifycertificate'] = 'Επαλήθευση Πιστοποιητικού';
$string['verifyintro'] = 'Εισάγετε τον κωδικό επαλήθευσης πιστοποιητικού για να επαληθεύσετε τη γνησιότητά του στο {$a}.';
$string['verifylink_desc'] = 'Αυτός ο σύνδεσμος θα σας μεταφέρει σε σελίδα όπου μπορείτε να επαληθεύσετε πιστοποιητικά.';
$string['verifynotfound'] = 'Δεν βρέθηκε πιστοποιητικό με αυτόν τον κωδικό. Ελέγξτε και δοκιμάστε ξανά.';
$string['verifyurl'] = 'Προσαρμοσμένη διεύθυνση επαλήθευσης';
$string['verifyurl_desc'] = 'Προσαρμοσμένη διεύθυνση URL για τον σύνδεσμο επαλήθευσης QR code. Αφήστε κενό για χρήση της προεπιλεγμένης σελίδας. Placeholders: {code}';
$string['version'] = 'Έκδοση';
$string['viewonline'] = 'Προβολή Online';
$string['width'] = 'Πλάτος';
$string['zoomin'] = 'Μεγέθυνση';
$string['zoomout'] = 'Σμίκρυνση';
