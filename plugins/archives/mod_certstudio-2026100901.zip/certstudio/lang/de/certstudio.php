<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * German language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Querformat';
$string['actions'] = 'Aktionen';
$string['actionsheading'] = 'Aktionen';
$string['active'] = 'Aktiv';
$string['activities'] = 'Aktivitäten';
$string['aiapikey'] = 'API-Schlüssel';
$string['aiapikey_desc'] = 'Ihr API-Schlüssel für den ausgewählten AI-Anbieter. Erhalten Sie einen von OpenAI oder Anthropic.';
$string['aierror'] = 'AI-Generierungsfehler: {$a}';
$string['aigeneratebutton'] = 'Generieren';
$string['aigeneratedesc'] = 'Beschreiben Sie das gewünschte Zertifikat und AI generiert eine Vorlage für Sie.';
$string['aigenerateplaceholder'] = 'z. B. formelles blaues Zertifikat für IT-Kurs mit goldenem Rahmen...';
$string['aigeneratesuccess'] = 'Vorlage erfolgreich generiert! Weiterleitung zum Editor...';
$string['aigeneratetitle'] = 'AI-Vorlagengenerator';
$string['aigenerating'] = 'Vorlage wird mit AI generiert...';
$string['aimodel'] = 'Modell';
$string['aimodel_desc'] = 'Das zu verwendende AI-Modell. Für OpenAI: gpt-4o-mini, gpt-4o. Für Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'Der AI-API-Schlüssel ist nicht konfiguriert. Bitte legen Sie ihn in den Plugin-Einstellungen fest.';
$string['aiparseerror'] = 'Die AI-Antwort konnte nicht verarbeitet werden. Bitte versuchen Sie es mit einer anderen Beschreibung erneut.';
$string['aiprovider'] = 'AI-Anbieter';
$string['aiprovider_desc'] = 'Wählen Sie den AI-Dienst für die Vorlagengenerierung.';
$string['aisettings'] = 'AI-Vorlagengenerator';
$string['aisettings_desc'] = 'Konfigurieren Sie die AI-gestützte automatische Vorlagengenerierung. Erfordert einen API-Schlüssel von OpenAI oder Anthropic.';
$string['aligncenter'] = 'Zentriert';
$string['alignleft'] = 'Links';
$string['alignright'] = 'Rechts';
$string['all'] = 'Alle';
$string['allcolors'] = 'Alle Farben';
$string['allstyles'] = 'Alle Stile';
$string['alltemplates'] = 'Alle Vorlagen';
$string['appearance'] = 'Darstellung';
$string['apply'] = 'Anwenden';
$string['approval'] = 'Genehmigungsworkflow';
$string['approvalenabled'] = 'Genehmigungsworkflow aktivieren';
$string['approvalenabled_desc'] = 'Genehmigungsworkflow standardmäßig für neue Aktivitäten aktivieren.';
$string['approvalenabled_help'] = 'Wenn aktiviert, müssen Teilnehmer/innen eine Genehmigung von einer Lehrkraft anfordern, bevor sie das Zertifikat herunterladen können.';
$string['approvalnotifystudent'] = 'Teilnehmer/in über Ergebnis benachrichtigen';
$string['approvalnotifystudent_desc'] = 'Benachrichtigung an Teilnehmer/innen senden, wenn ihr Antrag genehmigt oder abgelehnt wird.';
$string['approvalnotifyteacher'] = 'Lehrkraft bei Anfrage benachrichtigen';
$string['approvalnotifyteacher_desc'] = 'Benachrichtigung an Lehrkräfte senden, wenn ein/e Teilnehmer/in ein Zertifikat anfordert.';
$string['approvalrequestbody'] = '{$a->student} hat ein Zertifikat für „{$a->activity}" angefordert.';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> hat ein Zertifikat für „<strong>{$a->activity}</strong>" angefordert.</p><p><a href="{$a->url}">Genehmigungsanträge prüfen</a></p>';
$string['approvalrequestexists'] = 'Sie haben bereits einen ausstehenden Genehmigungsantrag.';
$string['approvalrequestnotfound'] = 'Genehmigungsantrag nicht gefunden.';
$string['approvalrequestnotpending'] = 'Dieser Genehmigungsantrag ist nicht mehr ausstehend.';
$string['approvalrequests'] = 'Genehmigungsanträge';
$string['approvalrequestsmall'] = 'Neuer Zertifikatsantrag von {$a}';
$string['approvalrequestsubject'] = 'Zertifikatsgenehmigungsantrag: {$a}';
$string['approvalrequesttemplate'] = 'Antragsbenachrichtigung (an Lehrkraft)';
$string['approvalrequesttemplate_desc'] = 'Nachricht an Lehrkräfte, wenn ein/e Teilnehmer/in eine Zertifikatsgenehmigung anfordert.';
$string['approvalresultbody'] = 'Ihr Zertifikatsantrag für „{$a->activity}" wurde {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>Ihr Zertifikatsantrag für „<strong>{$a->activity}</strong>" wurde <strong>{$a->status}</strong>.</p><p>Prüfer/in: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Zertifikat anzeigen</a></p>';
$string['approvalresultsmall'] = 'Zertifikatsantrag {$a}';
$string['approvalresultsubject'] = 'Zertifikatsantrag {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Genehmigungseinstellungen';
$string['approve'] = 'Genehmigen';
$string['approved'] = 'genehmigt';
$string['approvedtemplate'] = 'Genehmigungsbenachrichtigung (an Teilnehmer/in)';
$string['approvedtemplate_desc'] = 'Nachricht an den/die Teilnehmer/in, wenn der Antrag genehmigt wurde.';
$string['autoissue'] = 'Automatische Ausstellung bei Kursabschluss';
$string['autoissue_desc'] = 'Zertifikate automatisch ausstellen, wenn ein/e Teilnehmer/in den Kurs abschließt. Erfordert, dass der Kursabschluss aktiviert ist. Gilt nicht für Aktivitäten mit Genehmigungsworkflow.';
$string['back'] = 'Zurück';
$string['backtoview'] = 'Zurück';
$string['batchdownload'] = 'Alle als ZIP herunterladen';
$string['bgcolor'] = 'Hintergrundfarbe';
$string['bgimage'] = 'Hintergrundbild';
$string['bgimageopacity'] = 'Hintergrundbild-Deckkraft';
$string['bgimagesize'] = 'Hintergrundbildgröße';
$string['bgimagesizeactual'] = 'Originalgröße';
$string['bgimagesizecontain'] = 'Einpassen (innerhalb anpassen)';
$string['bgimagesizecover'] = 'Abdecken (Seite füllen)';
$string['bgimagesizestretch'] = 'Strecken';
$string['bold'] = 'Fett';
$string['bordercolor'] = 'Rahmenfarbe';
$string['borderstyle'] = 'Rahmenstil';
$string['borderwidth'] = 'Rahmenbreite';
$string['builtin'] = 'Integriert';
$string['builtintemplates'] = 'Integrierte Vorlagen';
$string['bulkactions'] = 'Massenaktionen';
$string['bulkdelete'] = 'Ausgewählte löschen';
$string['bulkemail'] = 'Ausgewählte per E-Mail senden';
$string['bulkissue'] = 'Sammelausstellung';
$string['bulkissuealreadyissued'] = '{$a} Teilnehmer/in(nen) haben bereits ein Zertifikat (übersprungen)';
$string['bulkissuecomplete'] = '{$a} Zertifikat(e) erfolgreich ausgestellt.';
$string['bulkissuedefaultmessage'] = 'Sehr geehrte/r {studentname},

herzlichen Glückwunsch! Ihr Zertifikat für „{certname}" im Kurs „{coursename}" wurde ausgestellt.

Sie können es hier herunterladen: {url}

Mit freundlichen Grüßen';
$string['bulkissuedesc'] = 'Zertifikate an alle berechtigten eingeschriebenen Teilnehmer/innen ausstellen, die noch keines erhalten haben.';
$string['bulkissuenoeligible'] = 'Alle eingeschriebenen Teilnehmer/innen haben bereits ein Zertifikat erhalten.';
$string['bulkissuenoselection'] = 'Keine Teilnehmer/innen ausgewählt.';
$string['bulkissuenotified'] = '{$a} Teilnehmer/in(nen) benachrichtigt.';
$string['bulkissuenotify'] = 'Teilnehmer/innen benachrichtigen';
$string['bulkissuenotifyemail'] = 'Benachrichtigung per E-Mail senden';
$string['bulkissuenotifymessage'] = 'Benachrichtigungstext';
$string['bulkissuenotifymoodle'] = 'Benachrichtigung über Moodle senden';
$string['bulkissuenotifyplaceholders'] = 'Verfügbare Platzhalter: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Ihr Zertifikat für {$a} wurde ausgestellt.';
$string['bulkissuenotifysubject'] = 'Ihr Zertifikat wurde ausgestellt: {$a}';
$string['bulkissuesubmit'] = 'Zertifikate an {$a} Teilnehmer/in(nen) ausstellen';
$string['bulkoperationcomplete'] = '{$a->count} Zertifikat(e) verarbeitet: {$a->action}.';
$string['bulkreissue'] = 'Ausgewählte erneut ausstellen';
$string['bulkrevoke'] = 'Ausgewählte widerrufen';
$string['certificate'] = 'Zertifikat';
$string['certificateexpired'] = 'Dieses Zertifikat ist am {$a} abgelaufen.';
$string['certificateexpiredverify'] = 'Dieses Zertifikat ist abgelaufen';
$string['certificateexpires'] = 'Dieses Zertifikat läuft am {$a} ab.';
$string['certificateinvalid'] = 'Dieses Zertifikat ist ungültig';
$string['certificateissued'] = 'Ihr Zertifikat wurde am {$a} ausgestellt.';
$string['certificatenotfound'] = 'Es wurde kein Zertifikat mit diesem Verifizierungscode gefunden.';
$string['certificaterevoked'] = 'Dieses Zertifikat wurde widerrufen';
$string['certificaterevokedstudent'] = 'Ihr Zertifikat wurde widerrufen. Bitte wenden Sie sich an Ihre Lehrkraft oder die Administration für weitere Informationen.';
$string['certificatevalid'] = 'Dieses Zertifikat ist gültig';
$string['certificateversion'] = 'Dies ist Version {$a} Ihres Zertifikats (erneuert).';
$string['certstudio:addinstance'] = 'Eine Certificate Studio-Aktivität hinzufügen';
$string['certstudio:approvecertificate'] = 'Zertifikatsanträge genehmigen';
$string['certstudio:manage'] = 'Zertifikatsvorlagen verwalten';
$string['certstudio:manageemailstudents'] = 'E-Mail-Benachrichtigungseinstellungen verwalten';
$string['certstudio:manageprotection'] = 'PDF-Schutzeinstellungen verwalten';
$string['certstudio:managetemplates'] = 'Zertifikatsvorlagen verwalten';
$string['certstudio:receiveissue'] = 'Ein Zertifikat erhalten';
$string['certstudio:revokecertificate'] = 'Ausgestellte Zertifikate widerrufen';
$string['certstudio:verifycertificate'] = 'Zertifikatscodes verifizieren';
$string['certstudio:view'] = 'Zertifikat anzeigen';
$string['certstudio:viewallcertificates'] = 'Alle ausgestellten Zertifikate anzeigen';
$string['certstudio:viewreport'] = 'Zertifikatsberichte und Analysen anzeigen';
$string['city'] = 'Stadt';
$string['clearbg'] = 'Hintergrund entfernen';
$string['clicktorenametemplate'] = 'Klicken zum Umbenennen der Vorlage';
$string['codegenerationmethod'] = 'Code-Generierungsmethode';
$string['codegenerationmethod_desc'] = 'Wählen Sie zwischen zwei Methoden zur Generierung von Zertifikatsprüfcodes.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Ziffern mit Bindestrichen)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Zufällige Zeichenkette aus Groß-/Kleinbuchstaben und Ziffern)';
$string['color'] = 'Farbe';
$string['colorblue'] = 'Blau';
$string['colordark'] = 'Dunkel';
$string['colorgold'] = 'Gold';
$string['colorgray'] = 'Grau';
$string['colorgreen'] = 'Grün';
$string['colorpink'] = 'Rosa';
$string['colorpurple'] = 'Lila';
$string['colorred'] = 'Rot';
$string['comment'] = 'Kommentar';
$string['confirmbulk'] = 'Möchten Sie diese Massenaktion wirklich auf die ausgewählten Zertifikate anwenden?';
$string['confirmdelete'] = 'Möchten Sie diese Vorlage wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.';
$string['confirmdeleteissue'] = 'Möchten Sie diesen Zertifikatsdatensatz wirklich dauerhaft löschen?';
$string['confirmrevoke'] = 'Möchten Sie dieses Zertifikat wirklich widerrufen? Die Verifizierungsseite wird es als widerrufen anzeigen.';
$string['copy'] = 'Kopieren';
$string['course'] = 'Kurs';
$string['createblank'] = 'Leeres Zertifikat';
$string['createblankdesc'] = 'Mit einer leeren Arbeitsfläche beginnen';
$string['created'] = 'Erstellt';
$string['createtemplate'] = '-- Neue Vorlage erstellen --';
$string['current'] = 'Aktuell';
$string['currenttemplate'] = 'Aktuelle Vorlage';
$string['custom'] = 'Benutzerdefiniert';
$string['customsource'] = 'Benutzerdefiniert';
$string['customtemplates'] = 'Benutzerdefinierte Vorlagen';
$string['dateformat'] = 'Datumsformat';
$string['dateissued'] = 'Ausstellungsdatum';
$string['daterequested'] = 'Antragsdatum';
$string['defaultfilename'] = 'Standard-PDF-Dateiname';
$string['defaultfilename_desc'] = 'Standard-Dateinamenmuster für heruntergeladene PDFs. Platzhalter: {coursename}, {studentname}, {date}, {activityname}. Kann pro Aktivität überschrieben werden.';
$string['defaultprotection'] = 'Standard-PDF-Schutz';
$string['defaultprotection_desc'] = 'Standard-Schutzoptionen für PDFs (kommagetrennt): print, modify, copy. Kann pro Aktivität überschrieben werden.';
$string['defaultvalues'] = 'Standardwerte für Aktivitätseinstellungen';
$string['defaultvalues_desc'] = 'Standardwerte werden im Einstellungsformular beim Erstellen einer neuen Aktivität verwendet.';
$string['delete'] = 'Löschen';
$string['deleteissuedcertificates'] = 'Ausgestellte Zertifikate löschen';
$string['downloadcertificate'] = 'Zertifikat herunterladen';
$string['downloadfilename'] = 'PDF-Dateiname';
$string['downloadfilename_help'] = 'Benutzerdefinierter Dateiname für das heruntergeladene PDF-Zertifikat. Sie können Platzhalter verwenden: {coursename}, {studentname}, {date}. Leer lassen, um den Aktivitätsnamen zu verwenden. Beispiel: Zertifikat_{coursename}_{studentname}';
$string['downloadsettings'] = 'Download-Einstellungen';
$string['editcertstudio'] = 'Zertifikat bearbeiten';
$string['edittemplate'] = 'Vorlage bearbeiten';
$string['elementcount'] = '{$a} Elemente';
$string['elementname'] = 'Elementname';
$string['elements'] = 'Elemente';
$string['elementtype_bgimage'] = 'Hintergrundbild';
$string['elementtype_border'] = 'Rahmen';
$string['elementtype_categoryname'] = 'Kategoriename';
$string['elementtype_certdate'] = 'Griechisches Datum';
$string['elementtype_certstatement'] = 'Griechische Erklärung';
$string['elementtype_code'] = 'Verifizierungscode';
$string['elementtype_coursefield'] = 'Kursfeld';
$string['elementtype_coursename'] = 'Kursname';
$string['elementtype_date'] = 'Datum';
$string['elementtype_daterange'] = 'Datumsbereich';
$string['elementtype_digitalsignature'] = 'Digitale Signatur';
$string['elementtype_expiry'] = 'Ablaufdatum';
$string['elementtype_grade'] = 'Bewertung';
$string['elementtype_gradeitemname'] = 'Bewertungsbezeichnung';
$string['elementtype_image'] = 'Bild';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Name des/der Teilnehmer/in';
$string['elementtype_teachername'] = 'Name der Lehrkraft';
$string['elementtype_text'] = 'Text';
$string['elementtype_userfield'] = 'Nutzerfeld';
$string['elementtype_userpicture'] = 'Nutzerbild';
$string['emailcertbody'] = 'Sehr geehrte/r {$a->studentname},

Ihr Zertifikat für „{$a->certname}" im Kurs „{$a->coursename}" ist dieser E-Mail als Anhang beigefügt.

Verifizierungscode: {$a->code}
Online verifizieren: {$a->verifyurl}

Mit freundlichen Grüßen';
$string['emailcertificate'] = 'Zertifikat per E-Mail senden';
$string['emailcertificatebody'] = 'Sehr geehrte/r {$a->fullname},

Ihr Zertifikat für „{$a->certname}" im Kurs „{$a->coursename}" wurde ausgestellt.

Sie können es mit folgendem Code verifizieren: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Ihr Zertifikat für {$a}';
$string['emailcertsubject'] = 'Ihr Zertifikat: {$a}';
$string['emailcerttemplate'] = 'E-Mail-Zertifikatsbenachrichtigung';
$string['emailcerttemplate_default'] = 'Sehr geehrte/r {studentname},

Ihr Zertifikat für „{certname}" im Kurs „{coursename}" ist dieser E-Mail als Anhang beigefügt.

Verifizierungscode: {code}
Online verifizieren: {verifyurl}

Mit freundlichen Grüßen';
$string['emailcerttemplate_desc'] = 'Nachrichtentext beim Versenden eines Zertifikats als PDF-Anhang per E-Mail. Platzhalter: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Weitere Personen per E-Mail benachrichtigen';
$string['emailothers_desc'] = 'Kommagetrennte E-Mail-Adressen, die eine Kopie des Zertifikats erhalten, sobald es verfügbar ist.';
$string['emailsent'] = 'Zertifikat erfolgreich per E-Mail versendet.';
$string['emailsettings'] = 'E-Mail-Benachrichtigungen';
$string['emailstudents'] = 'Teilnehmer/innen per E-Mail benachrichtigen';
$string['emailstudents_desc'] = 'Wenn aktiviert, erhalten Teilnehmer/innen eine Kopie des Zertifikats per E-Mail, sobald es verfügbar ist.';
$string['emailteacherbody'] = 'Ein Zertifikat für „{$a->certname}" wurde an {$a->fullname} im Kurs „{$a->coursename}" ausgestellt.';
$string['emailteachers'] = 'Lehrkräfte per E-Mail benachrichtigen';
$string['emailteachers_desc'] = 'Wenn aktiviert, erhalten Lehrkräfte eine Kopie des Zertifikats per E-Mail, sobald es verfügbar ist.';
$string['emailteachersubject'] = 'Zertifikat ausgestellt: {$a->certname}';
$string['entercode'] = 'Verifizierungscode eingeben';
$string['eventcertificateapproved'] = 'Zertifikat genehmigt';
$string['eventcertificateissued'] = 'Zertifikat ausgestellt';
$string['eventcertificaterejected'] = 'Zertifikat abgelehnt';
$string['eventcertificaterequested'] = 'Zertifikat angefordert';
$string['eventcertificaterevoked'] = 'Zertifikat widerrufen';
$string['eventpagecreated'] = 'Seite erstellt';
$string['eventpagedeleted'] = 'Seite gelöscht';
$string['eventtemplatecreated'] = 'Vorlage erstellt';
$string['eventtemplatedeleted'] = 'Vorlage gelöscht';
$string['eventtemplateupdated'] = 'Vorlage aktualisiert';
$string['expired'] = 'Abgelaufen';
$string['expiredon'] = 'Abgelaufen am';
$string['expirydate'] = 'Ablaufdatum';
$string['expirydays'] = 'Zertifikatsgültigkeit (Tage)';
$string['expirydays_help'] = 'Anzahl der Tage, die das Zertifikat ab dem Ausstellungsdatum gültig ist. Auf 0 setzen für unbegrenzte Gültigkeit.';
$string['expiryperiod'] = 'Gültigkeitsdauer (Tage)';
$string['expirysettings'] = 'Ablaufeinstellungen';
$string['exportcsv'] = 'CSV exportieren';
$string['exportods'] = 'ODS exportieren';
$string['exporttemplate'] = 'Vorlage exportieren';
$string['exportxlsx'] = 'XLSX exportieren';
$string['fieldname'] = 'Feldname';
$string['font'] = 'Schriftart';
$string['fontsize'] = 'Schriftgröße';
$string['gallerydescription'] = 'Wählen Sie eine Vorlage als Ausgangspunkt oder erstellen Sie eine eigene von Grund auf';
$string['generalsettings'] = 'Allgemeine Einstellungen';
$string['getcertificate'] = 'Zertifikat erhalten';
$string['gradeitem'] = 'Bewertungsaspekt';
$string['height'] = 'Höhe';
$string['importtemplate'] = 'Vorlage importieren';
$string['invalidaction'] = 'Ungültige Aktion';
$string['invalidelementdata'] = 'Ungültige Elementdaten';
$string['invalidfilearea'] = 'Ungültiger Dateibereich';
$string['issuedcertificates'] = 'Ausgestellte Zertifikate';
$string['issuedcount'] = '{$a} Zertifikat(e) ausgestellt';
$string['issuedtemplate'] = 'Benachrichtigung über Zertifikatsausstellung';
$string['issuedtemplate_default'] = 'Sehr geehrte/r {studentname},

herzlichen Glückwunsch! Ihr Zertifikat für „{certname}" im Kurs „{coursename}" wurde ausgestellt.

Sie können es hier herunterladen: {url}

Verifizierungscode: {code}

Mit freundlichen Grüßen';
$string['issuedtemplate_desc'] = 'Nachricht an den/die Teilnehmer/in, wenn ein Zertifikat ausgestellt wird. Platzhalter: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Zertifikatsausstellung nicht gefunden';
$string['italic'] = 'Kursiv';
$string['landscape'] = 'Querformat';
$string['layers'] = 'Ebenen';
$string['loading'] = 'Wird geladen...';
$string['lock'] = 'Sperren';
$string['manageapprovals'] = 'Genehmigungen verwalten';
$string['managetemplates'] = 'Vorlagen verwalten';
$string['managetemplates_desc'] = 'Vorlagen anzeigen, exportieren, importieren und löschen. Verwalten Sie alle integrierten und benutzerdefinierten Vorlagen an einem Ort.';
$string['messageprovider:approval_request'] = 'Zertifikatsgenehmigungsantrag';
$string['messageprovider:approval_result'] = 'Ergebnis des Zertifikatsgenehmigungsantrags';
$string['messagetemplates'] = 'Nachrichtenvorlagen';
$string['messagetemplates_desc'] = 'Benachrichtigungstexte anpassen. Platzhalter: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Aktivitäten migrieren (Kursmodule)';
$string['migrateissues'] = 'Ausgestellte Zertifikate migrieren';
$string['migratetemplates'] = 'Vorlagen migrieren (Seiten und Elemente)';
$string['migrationcomplete'] = 'Migration abgeschlossen: {$a->templates} Vorlage(n), {$a->activities} Aktivität(en), {$a->issues} Zertifikat(e) migriert.';
$string['migrationlog'] = 'Migrationsprotokoll';
$string['migrationnodata'] = 'Keine Custom Certificate-Daten zur Migration gefunden.';
$string['migrationnotavailable'] = 'Das Plugin Custom Certificate (mod_customcert) ist nicht installiert. Es gibt nichts zu migrieren.';
$string['migrationoptions'] = 'Migrationsoptionen';
$string['migrationsummary'] = 'Custom Certificate-Daten gefunden';
$string['migrationtool'] = 'Von Custom Certificate migrieren';
$string['migrationwarning'] = 'Es werden neue Certificate Studio-Datensätze aus Ihren Custom Certificate-Daten erstellt. Bestehende Custom Certificate-Daten werden NICHT geändert oder gelöscht. Bereits migrierte Einträge werden übersprungen.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studios';
$string['multilang'] = 'Mehrsprachige Zertifikate';
$string['multilang_desc'] = 'Zertifikatssprache pro Aktivität erzwingen und die Nutzereinstellung überschreiben.';
$string['mycertificates'] = 'Meine Zertifikate';
$string['name'] = 'Name';
$string['nelements'] = '{$a} Elemente';
$string['nocertificates'] = 'Sie haben noch keine Zertifikate erhalten.';
$string['nocertificatesissued'] = 'Es wurde noch kein Zertifikat ausgestellt. Bitte schließen Sie die erforderlichen Aktivitäten ab, um Ihr Zertifikat zu erhalten.';
$string['nodata'] = 'Keine Daten verfügbar.';
$string['norequests'] = 'Keine Genehmigungsanträge gefunden.';
$string['notapproved'] = 'Ihr Zertifikat wurde noch nicht genehmigt.';
$string['notemplates'] = 'Keine Vorlagen gefunden.';
$string['notemplatesavailable'] = 'Keine Vorlagen verfügbar. Klicken Sie auf „Von Grund auf erstellen", um Ihr eigenes Zertifikat zu erstellen.';
$string['notissued'] = 'Nicht ausgestellt';
$string['opacity'] = 'Deckkraft';
$string['optional'] = 'optional';
$string['pages'] = 'Seiten';
$string['pagesettings'] = 'Seiteneinstellungen';
$string['pagesize'] = 'Seitengröße';
$string['pdfsettings'] = 'PDF-Einstellungen';
$string['platform'] = 'Plattform';
$string['pluginadministration'] = 'Certificate Studio-Verwaltung';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Hochformat';
$string['positionandsize'] = 'Position & Größe';
$string['previewpdf'] = 'PDF-Vorschau';
$string['privacy:metadata:certstudio_approval_requests'] = 'Zertifikatsgenehmigungsanträge.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'Der Kommentar der prüfenden Person zum Antrag.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'Die Person, die den Antrag geprüft hat.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'Der Genehmigungsstatus.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Zeitpunkt der Antragstellung.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Zeitpunkt der letzten Aktualisierung des Antrags.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'Die Person, die das Zertifikat angefordert hat.';
$string['privacy:metadata:certstudio_issues'] = 'Datensätze der ausgestellten Zertifikate.';
$string['privacy:metadata:certstudio_issues:code'] = 'Der eindeutige Verifizierungscode.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'Der Schnappschuss der Zertifikatsvorlagendaten.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Zeitpunkt der Zertifikatsausstellung.';
$string['privacy:metadata:certstudio_issues:userid'] = 'Die Person, die das Zertifikat erhalten hat.';
$string['privacy:path:approvalrequests'] = 'Genehmigungsanträge';
$string['privacy:path:issues'] = 'Ausgestellte Zertifikate';
$string['properties'] = 'Eigenschaften';
$string['protection'] = 'PDF-Schutz';
$string['protection_copy'] = 'Kopieren verhindern';
$string['protection_copy_desc'] = 'Schutz vor dem Kopieren aktivieren.';
$string['protection_modify'] = 'Bearbeiten verhindern';
$string['protection_modify_desc'] = 'Schutz vor dem Bearbeiten aktivieren.';
$string['protection_print'] = 'Drucken verhindern';
$string['protection_print_desc'] = 'Schutz vor dem Drucken aktivieren.';
$string['protectionflags'] = 'Schutzoptionen';
$string['protectionflags_help'] = 'Kommagetrennte Schutzoptionen: print, modify, copy';
$string['publishtogallery'] = 'In Galerie veröffentlichen';
$string['publishtogallerytip'] = 'Eine Kopie in der Vorlagengalerie veröffentlichen, damit alle Kurse sie nutzen können';
$string['reason'] = 'Grund';
$string['receiveddate'] = 'Empfangsdatum';
$string['redo'] = 'Wiederherstellen';
$string['reissue'] = 'Erneut ausstellen';
$string['reissuedtemplate'] = 'Benachrichtigung über Zertifikatsneuausstellung';
$string['reissuedtemplate_default'] = 'Sehr geehrte/r {studentname},

eine neue Version Ihres Zertifikats für „{certname}" im Kurs „{coursename}" wurde ausgestellt.

Sie können es hier herunterladen: {url}

Verifizierungscode: {code}

Mit freundlichen Grüßen';
$string['reissuedtemplate_desc'] = 'Nachricht an den/die Teilnehmer/in, wenn eine neue Version des Zertifikats ausgestellt wird. Platzhalter: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Ablehnen';
$string['rejected'] = 'abgelehnt';
$string['rejectedtemplate'] = 'Ablehnungsbenachrichtigung (an Teilnehmer/in)';
$string['rejectedtemplate_desc'] = 'Nachricht an den/die Teilnehmer/in, wenn der Antrag abgelehnt wurde.';
$string['reportanalytics'] = 'Zertifikatsanalysen';
$string['reportmonthly'] = 'Monatlicher Trend (letzte 12 Monate)';
$string['reportpercourse'] = 'Zertifikate pro Kurs';
$string['reportrecent'] = 'Aktuelle Zertifikate (letzte 30 Tage)';
$string['reporttotalactivities'] = 'Aktivitäten insgesamt';
$string['reporttotalissued'] = 'Insgesamt ausgestellt';
$string['reporttotaltemplates'] = 'Vorlagen insgesamt';
$string['reportuniquerecipients'] = 'Einzelne Empfänger/innen';
$string['requestagain'] = 'Neuen Antrag einreichen';
$string['requestapproved'] = 'Antrag erfolgreich genehmigt.';
$string['requestcertificate'] = 'Zertifikat anfordern';
$string['requestpending'] = 'Ihr Zertifikatsantrag wartet auf Genehmigung.';
$string['requestrejected'] = 'Ihr Zertifikatsantrag wurde abgelehnt.';
$string['requestrejectedmsg'] = 'Antrag erfolgreich abgelehnt.';
$string['requestsubmitted'] = 'Ihr Zertifikatsantrag wurde eingereicht.';
$string['requiredtime'] = 'Erforderliche Minuten im Kurs';
$string['requiredtime_desc'] = 'Mindestzeit in Minuten, die ein/e Teilnehmer/in im Kurs angemeldet sein muss, bevor das Zertifikat ausgestellt werden kann. Auf 0 setzen, um diese Funktion zu deaktivieren.';
$string['requiredtimenotmet'] = 'Sie müssen mindestens {$a->required} Minuten in diesem Kurs verbringen, bevor Sie ein Zertifikat erhalten können. Sie haben bisher ungefähr {$a->spent} Minuten verbracht.';
$string['returncourse'] = 'Zurück-zum-Kurs-Schaltfläche';
$string['returncourse_desc'] = 'Eine Schaltfläche „Zurück zum Kurs" auf der Zertifikatsansichtsseite anzeigen.';
$string['returntocourse'] = 'Zurück zum Kurs';
$string['reviewer'] = 'Prüfer/in';
$string['revokecertificate'] = 'Zertifikat widerrufen';
$string['revoked'] = 'Widerrufen';
$string['revokeddate'] = 'Widerrufen am';
$string['revokedrenewal'] = 'Widerrufen zur Erneuerung (neue Version ausgestellt)';
$string['revokedtemplate'] = 'Benachrichtigung über Zertifikatswiderruf';
$string['revokedtemplate_default'] = 'Sehr geehrte/r {studentname},

Ihr Zertifikat für „{certname}" im Kurs „{coursename}" wurde widerrufen.

Grund: {reason}

Bei Fragen wenden Sie sich bitte an Ihre Lehrkraft.

Mit freundlichen Grüßen';
$string['revokedtemplate_desc'] = 'Nachricht an den/die Teilnehmer/in, wenn das Zertifikat widerrufen wird. Platzhalter: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Drehung';
$string['save'] = 'Speichern';
$string['savechangestip'] = 'Änderungen nur für diese Aktivität speichern';
$string['saved'] = 'Änderungen gespeichert';
$string['saveerror'] = 'Fehler beim Speichern der Änderungen';
$string['savestatussaved'] = 'Gespeichert';
$string['searchbyname'] = 'Nach Name suchen...';
$string['selectelement'] = 'Klicken Sie auf ein Element, um seine Eigenschaften zu bearbeiten.';
$string['selecttemplate'] = 'Vorlage auswählen';
$string['sharecertificate'] = 'Teilen';
$string['shareemailbody'] = 'Ich möchte Ihnen mitteilen, dass ich das Zertifikat „{$a->certname}" erhalten habe.

Sie können es hier verifizieren: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Mein Zertifikat: {$a}';
$string['sharetext'] = 'Ich habe gerade das Zertifikat „{$a}" erhalten!';
$string['showcasecourse'] = 'Kurs';
$string['showcasedownloadpdf'] = 'PDF herunterladen';
$string['showcaseissuedon'] = 'Ausgestellt am';
$string['showcaserecipient'] = 'Verliehen an';
$string['showcaseshare'] = 'Dieses Zertifikat teilen';
$string['showcasetitle'] = 'Digitales Zertifikat';
$string['showcaseverified'] = 'Verifiziertes Zertifikat';
$string['showposxy'] = 'Position X und Y anzeigen';
$string['showposxy_desc'] = 'Die X- und Y-Position beim Bearbeiten eines Elements anzeigen, sodass die Position genau angegeben werden kann.';
$string['startfromscratch'] = 'Von Grund auf erstellen';
$string['startmigration'] = 'Migration starten';
$string['status'] = 'Status';
$string['statusapproved'] = 'Genehmigt';
$string['statusexpired'] = 'Abgelaufen';
$string['statuspending'] = 'Ausstehend';
$string['statusrejected'] = 'Abgelehnt';
$string['statusrevoked'] = 'Widerrufen';
$string['statusvalid'] = 'Gültig';
$string['student'] = 'Teilnehmer/in';
$string['styleclassic'] = 'Klassisch';
$string['styledark'] = 'Dunkel';
$string['styleelegant'] = 'Elegant';
$string['stylegradient'] = 'Verlauf';
$string['styleminimal'] = 'Minimalistisch';
$string['stylemodern'] = 'Modern';
$string['stylespecial'] = 'Spezial';
$string['subplugintype_certstudioselem'] = 'Elementtyp';
$string['subplugintype_certstudioselem_plural'] = 'Elementtypen';
$string['taskemailcertificate'] = 'Zertifikat per E-Mail versenden';
$string['taskissuecertificate'] = 'Zertifikate ausstellen und E-Mails versenden';
$string['template'] = 'Vorlage';
$string['templatedeleted'] = 'Vorlage „{$a}" wurde gelöscht.';
$string['templatefile'] = 'Vorlagendatei (.json)';
$string['templatefilehelp'] = 'Laden Sie eine .certstudio.json-Datei hoch, die aus einer anderen Certificate Studio-Installation exportiert wurde.';
$string['templategallery'] = 'Vorlagengalerie';
$string['templateimported'] = 'Vorlage „{$a->name}" erfolgreich importiert ({$a->pages} Seite(n), {$a->elements} Element(e)).';
$string['templateimportinvalid'] = 'Ungültige Vorlagendatei. Bitte laden Sie eine gültige .certstudio.json-Datei hoch.';
$string['templateinuse'] = 'Diese Vorlage wird von {$a} Aktivität(en) verwendet und kann nicht gelöscht werden.';
$string['templatenameplaceholder'] = 'Vorlagenname...';
$string['templates'] = 'Vorlagen';
$string['templatesharing'] = 'Vorlagen importieren/exportieren';
$string['textcontent'] = 'Textinhalt';
$string['toggleelementspanel'] = 'Elementebereich ein-/ausblenden';
$string['togglegrid'] = 'Raster ein-/ausblenden';
$string['toggleguides'] = 'Hilfslinien ein-/ausblenden';
$string['togglepropertiespanel'] = 'Eigenschaftenbereich ein-/ausblenden';
$string['typography'] = 'Typografie';
$string['undo'] = 'Rückgängig';
$string['unknowncourse'] = 'Unbekannter Kurs';
$string['unknownuser'] = 'Unbekannte/r Nutzer/in';
$string['unlock'] = 'Entsperren';
$string['uploadbgimage'] = 'Hochladen';
$string['uploadbgimagetip'] = 'Hintergrundbild hochladen';
$string['usethisTemplate'] = 'Diese Vorlage verwenden';
$string['usethistemplate'] = 'Diese Vorlage verwenden';
$string['valid'] = 'Gültig';
$string['verificationcode'] = 'Verifizierungscode';
$string['verify'] = 'Verifizieren';
$string['verifyallcertificates'] = 'Öffentliche Verifizierung erlauben';
$string['verifyallcertificates_desc'] = 'Jedem erlauben, Zertifikate ohne Anmeldung zu verifizieren.';
$string['verifyanother'] = 'Weiteres Zertifikat verifizieren';
$string['verifyany'] = 'Jedem die Verifizierung eines Zertifikats erlauben';
$string['verifyany_desc'] = 'Jedem mit dem Zertifikatsverifizierungslink (einschließlich nicht angemeldeter Nutzer/innen) erlauben, ein Zertifikat zu verifizieren.';
$string['verifycertificate'] = 'Zertifikat verifizieren';
$string['verifyintro'] = 'Geben Sie einen Verifizierungscode ein, um die Echtheit eines Zertifikats auf {$a} zu überprüfen.';
$string['verifylink_desc'] = 'Dieser Link führt Sie zu einer Seite, auf der Sie Zertifikate auf dieser Website verifizieren können.';
$string['verifynotfound'] = 'Es wurde kein Zertifikat mit diesem Verifizierungscode gefunden. Bitte überprüfen Sie den Code und versuchen Sie es erneut.';
$string['verifyurl'] = 'Benutzerdefinierte Verifizierungs-URL';
$string['verifyurl_desc'] = 'Benutzerdefinierte URL für den QR Code-Verifizierungslink. Leer lassen, um die Standard-Moodle-Verifizierungsseite zu verwenden. Platzhalter: {code}';
$string['version'] = 'Version';
$string['viewonline'] = 'Online ansehen';
$string['width'] = 'Breite';
$string['zoomin'] = 'Vergrößern';
$string['zoomout'] = 'Verkleinern';
