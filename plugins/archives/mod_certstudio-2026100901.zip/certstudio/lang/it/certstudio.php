<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Italian language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['a4landscape'] = 'A4 Orizzontale';
$string['actions'] = 'Azioni';
$string['actionsheading'] = 'Azioni';
$string['active'] = 'Attivo';
$string['activities'] = 'Attivit\u00e0';
$string['aiapikey'] = 'Chiave API';
$string['aiapikey_desc'] = 'La tua chiave API per il provider AI selezionato. Ottienine una da OpenAI o Anthropic.';
$string['aierror'] = 'Errore nella generazione AI: {$a}';
$string['aigeneratebutton'] = 'Genera';
$string['aigeneratedesc'] = 'Descrivi il certificato che desideri e l\'AI generer\u00e0 un modello per te.';
$string['aigenerateplaceholder'] = 'es., certificato formale blu per un corso IT con bordo dorato...';
$string['aigeneratesuccess'] = 'Modello generato con successo! Reindirizzamento all\'editor...';
$string['aigeneratetitle'] = 'Generatore di modelli AI';
$string['aigenerating'] = 'Generazione del modello con AI in corso...';
$string['aimodel'] = 'Modello';
$string['aimodel_desc'] = 'Il modello AI da utilizzare. Per OpenAI: gpt-4o-mini, gpt-4o. Per Anthropic: claude-sonnet-4-20250514.';
$string['ainokey'] = 'La chiave API AI non \u00e8 configurata. Impostala nelle impostazioni del plugin.';
$string['aiparseerror'] = 'Impossibile analizzare la risposta dell\'AI. Riprova con una descrizione diversa.';
$string['aiprovider'] = 'Provider AI';
$string['aiprovider_desc'] = 'Scegli quale servizio AI utilizzare per la generazione dei modelli.';
$string['aisettings'] = 'Generatore di modelli AI';
$string['aisettings_desc'] = 'Configura la generazione automatica di modelli basata su AI. Richiede una chiave API da OpenAI o Anthropic.';
$string['aligncenter'] = 'Centro';
$string['alignleft'] = 'Sinistra';
$string['alignright'] = 'Destra';
$string['all'] = 'Tutti';
$string['allcolors'] = 'Tutti i colori';
$string['allstyles'] = 'Tutti gli stili';
$string['alltemplates'] = 'Tutti i modelli';
$string['appearance'] = 'Aspetto';
$string['apply'] = 'Applica';
$string['approval'] = 'Flusso di approvazione';
$string['approvalenabled'] = 'Abilita flusso di approvazione';
$string['approvalenabled_desc'] = 'Abilita il flusso di approvazione per impostazione predefinita per le nuove attivit\u00e0.';
$string['approvalenabled_help'] = 'Se abilitato, gli studenti devono richiedere l\'approvazione del certificato da parte di un docente prima di poterlo scaricare.';
$string['approvalnotifystudent'] = 'Notifica allo studente sull\'esito';
$string['approvalnotifystudent_desc'] = 'Invia una notifica agli studenti quando la loro richiesta viene approvata o rifiutata.';
$string['approvalnotifyteacher'] = 'Notifica al docente alla richiesta';
$string['approvalnotifyteacher_desc'] = 'Invia una notifica ai docenti quando uno studente richiede un certificato.';
$string['approvalrequestbody'] = '{$a->student} ha richiesto un certificato per "{$a->activity}".';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong> ha richiesto un certificato per "<strong>{$a->activity}</strong>".</p><p><a href="{$a->url}">Esamina le richieste di approvazione</a></p>';
$string['approvalrequestexists'] = 'Hai gi\u00e0 una richiesta di approvazione in sospeso.';
$string['approvalrequestnotfound'] = 'Richiesta di approvazione non trovata.';
$string['approvalrequestnotpending'] = 'Questa richiesta di approvazione non \u00e8 pi\u00f9 in sospeso.';
$string['approvalrequests'] = 'Richieste di approvazione';
$string['approvalrequestsmall'] = 'Nuova richiesta di certificato da {$a}';
$string['approvalrequestsubject'] = 'Richiesta di approvazione del certificato: {$a}';
$string['approvalrequesttemplate'] = 'Notifica di richiesta (al docente)';
$string['approvalrequesttemplate_desc'] = 'Messaggio inviato ai docenti quando uno studente richiede l\'approvazione del certificato.';
$string['approvalresultbody'] = 'La tua richiesta di certificato per "{$a->activity}" \u00e8 stata {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>La tua richiesta di certificato per "<strong>{$a->activity}</strong>" \u00e8 stata <strong>{$a->status}</strong>.</p><p>Revisore: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Visualizza certificato</a></p>';
$string['approvalresultsmall'] = 'Richiesta di certificato {$a}';
$string['approvalresultsubject'] = 'Richiesta di certificato {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Impostazioni di approvazione';
$string['approve'] = 'Approva';
$string['approved'] = 'approvata';
$string['approvedtemplate'] = 'Notifica di approvazione (allo studente)';
$string['approvedtemplate_desc'] = 'Messaggio inviato allo studente quando la sua richiesta viene approvata.';
$string['autoissue'] = 'Emissione automatica al completamento del corso';
$string['autoissue_desc'] = 'Emetti automaticamente i certificati quando uno studente completa il corso. Richiede che il completamento del corso sia abilitato. Non si applica alle attivit\u00e0 con flusso di approvazione.';
$string['back'] = 'Indietro';
$string['backtoview'] = 'Indietro';
$string['batchdownload'] = 'Scarica tutto come ZIP';
$string['bgcolor'] = 'Colore di sfondo';
$string['bgimage'] = 'Immagine di sfondo';
$string['bgimageopacity'] = 'Opacità immagine di sfondo';
$string['bgimagesize'] = 'Dimensione immagine di sfondo';
$string['bgimagesizeactual'] = 'Dimensione reale';
$string['bgimagesizecontain'] = 'Contenere (adattare all\'interno)';
$string['bgimagesizecover'] = 'Coprire (riempire la pagina)';
$string['bgimagesizestretch'] = 'Stirare';
$string['bold'] = 'Grassetto';
$string['bordercolor'] = 'Colore bordo';
$string['borderstyle'] = 'Stile bordo';
$string['borderwidth'] = 'Larghezza bordo';
$string['builtin'] = 'Integrati';
$string['builtintemplates'] = 'Modelli integrati';
$string['bulkactions'] = 'Azioni in blocco';
$string['bulkdelete'] = 'Elimina selezionati';
$string['bulkemail'] = 'Invia email ai selezionati';
$string['bulkissue'] = 'Emissione in blocco';
$string['bulkissuealreadyissued'] = '{$a} studente/i ha/hanno gi\u00e0 un certificato (ignorato/i)';
$string['bulkissuecomplete'] = '{$a} certificato/i emesso/i con successo.';
$string['bulkissuedefaultmessage'] = 'Gentile {studentname},

Congratulazioni! Il tuo certificato per "{certname}" nel corso "{coursename}" \u00e8 stato emesso.

Puoi scaricarlo qui: {url}

Cordiali saluti';
$string['bulkissuedesc'] = 'Emetti certificati a tutti gli studenti iscritti idonei che non ne hanno ancora ricevuto uno.';
$string['bulkissuenoeligible'] = 'Tutti gli studenti iscritti hanno gi\u00e0 ricevuto un certificato.';
$string['bulkissuenoselection'] = 'Nessuno studente selezionato.';
$string['bulkissuenotified'] = '{$a} studente/i notificato/i.';
$string['bulkissuenotify'] = 'Notifica gli studenti';
$string['bulkissuenotifyemail'] = 'Invia notifica via email';
$string['bulkissuenotifymessage'] = 'Messaggio di notifica';
$string['bulkissuenotifymoodle'] = 'Invia notifica via Moodle';
$string['bulkissuenotifyplaceholders'] = 'Segnaposto disponibili: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = 'Il tuo certificato per {$a} \u00e8 stato emesso.';
$string['bulkissuenotifysubject'] = 'Il tuo certificato \u00e8 stato emesso: {$a}';
$string['bulkissuesubmit'] = 'Emetti certificati a {$a} studente/i';
$string['bulkoperationcomplete'] = '{$a->count} certificato/i elaborato/i: {$a->action}.';
$string['bulkreissue'] = 'Riemetti selezionati';
$string['bulkrevoke'] = 'Revoca selezionati';
$string['certificate'] = 'Certificato';
$string['certificateexpired'] = 'Questo certificato \u00e8 scaduto il {$a}.';
$string['certificateexpiredverify'] = 'Questo certificato \u00e8 scaduto';
$string['certificateexpires'] = 'Questo certificato scade il {$a}.';
$string['certificateinvalid'] = 'Questo certificato non \u00e8 valido';
$string['certificateissued'] = 'Il tuo certificato \u00e8 stato emesso il {$a}.';
$string['certificatenotfound'] = 'Nessun certificato trovato con questo codice di verifica.';
$string['certificaterevoked'] = 'Questo certificato \u00e8 stato revocato';
$string['certificaterevokedstudent'] = 'Il tuo certificato \u00e8 stato revocato. Contatta il tuo docente o amministratore per maggiori informazioni.';
$string['certificatevalid'] = 'Questo certificato \u00e8 valido';
$string['certificateversion'] = 'Questa \u00e8 la versione {$a} del tuo certificato (rinnovato).';
$string['certstudio:addinstance'] = 'Aggiungi un\'attivit\u00e0 Certificate Studio';
$string['certstudio:approvecertificate'] = 'Approva le richieste di certificato';
$string['certstudio:manage'] = 'Gestisci modelli di certificato';
$string['certstudio:manageemailstudents'] = 'Gestisci le impostazioni di notifica email';
$string['certstudio:manageprotection'] = 'Gestisci le impostazioni di protezione PDF';
$string['certstudio:managetemplates'] = 'Gestisci modelli di certificato';
$string['certstudio:receiveissue'] = 'Ricevi un certificato';
$string['certstudio:revokecertificate'] = 'Revoca certificati emessi';
$string['certstudio:verifycertificate'] = 'Verifica codici dei certificati';
$string['certstudio:view'] = 'Visualizza certificato';
$string['certstudio:viewallcertificates'] = 'Visualizza tutti i certificati emessi';
$string['certstudio:viewreport'] = 'Visualizza report e analisi dei certificati';
$string['city'] = 'Citt\u00e0';
$string['clearbg'] = 'Cancella sfondo';
$string['clicktorenametemplate'] = 'Clicca per rinominare il modello';
$string['codegenerationmethod'] = 'Metodo di generazione del codice';
$string['codegenerationmethod_desc'] = 'Scegli tra i due metodi per la generazione dei codici di verifica dei certificati.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Cifre con trattini)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Stringa casuale maiuscole/minuscole/cifre)';
$string['color'] = 'Colore';
$string['colorblue'] = 'Blu';
$string['colordark'] = 'Scuro';
$string['colorgold'] = 'Oro';
$string['colorgray'] = 'Grigio';
$string['colorgreen'] = 'Verde';
$string['colorpink'] = 'Rosa';
$string['colorpurple'] = 'Viola';
$string['colorred'] = 'Rosso';
$string['comment'] = 'Commento';
$string['confirmbulk'] = 'Sei sicuro di voler eseguire questa azione in blocco sui certificati selezionati?';
$string['confirmdelete'] = 'Sei sicuro di voler eliminare questo modello? Questa azione non pu\u00f2 essere annullata.';
$string['confirmdeleteissue'] = 'Sei sicuro di voler eliminare definitivamente questa registrazione del certificato?';
$string['confirmrevoke'] = 'Sei sicuro di voler revocare questo certificato? La pagina di verifica lo mostrer\u00e0 come revocato.';
$string['copy'] = 'Copia';
$string['course'] = 'Corso';
$string['createblank'] = 'Certificato vuoto';
$string['createblankdesc'] = 'Inizia con un\'area di lavoro vuota';
$string['created'] = 'Creato';
$string['createtemplate'] = '-- Crea nuovo modello --';
$string['current'] = 'Corrente';
$string['currenttemplate'] = 'Modello corrente';
$string['custom'] = 'Personalizzato';
$string['customsource'] = 'Personalizzati';
$string['customtemplates'] = 'Modelli personalizzati';
$string['dateformat'] = 'Formato data';
$string['dateissued'] = 'Data di emissione';
$string['daterequested'] = 'Data della richiesta';
$string['defaultfilename'] = 'Nome file PDF predefinito';
$string['defaultfilename_desc'] = 'Schema predefinito del nome file per i PDF scaricati. Segnaposto: {coursename}, {studentname}, {date}, {activityname}. Pu\u00f2 essere sovrascritto per ogni attivit\u00e0.';
$string['defaultprotection'] = 'Protezione PDF predefinita';
$string['defaultprotection_desc'] = 'Flag di protezione predefiniti per i PDF (separati da virgola): print, modify, copy. Possono essere sovrascritti per ogni attivit\u00e0.';
$string['defaultvalues'] = 'Valori predefiniti per le impostazioni dell\'attivit\u00e0';
$string['defaultvalues_desc'] = 'I valori predefiniti vengono utilizzati nel modulo di impostazioni quando si crea una nuova attivit\u00e0.';
$string['delete'] = 'Elimina';
$string['deleteissuedcertificates'] = 'Elimina certificati emessi';
$string['downloadcertificate'] = 'Scarica certificato';
$string['downloadfilename'] = 'Nome file PDF';
$string['downloadfilename_help'] = 'Nome file personalizzato per il certificato PDF scaricato. \u00c8 possibile utilizzare segnaposto: {coursename}, {studentname}, {date}. Lasciare vuoto per usare il nome dell\'attivit\u00e0. Esempio: Certificato_{coursename}_{studentname}';
$string['downloadsettings'] = 'Impostazioni di download';
$string['editcertstudio'] = 'Modifica certificato';
$string['edittemplate'] = 'Modifica modello';
$string['elementcount'] = '{$a} elementi';
$string['elementname'] = 'Nome elemento';
$string['elements'] = 'Elementi';
$string['elementtype_bgimage'] = 'Immagine di sfondo';
$string['elementtype_border'] = 'Bordo';
$string['elementtype_categoryname'] = 'Nome categoria';
$string['elementtype_certdate'] = 'Data greca';
$string['elementtype_certstatement'] = 'Dichiarazione greca';
$string['elementtype_code'] = 'Codice di verifica';
$string['elementtype_coursefield'] = 'Campo corso';
$string['elementtype_coursename'] = 'Nome corso';
$string['elementtype_date'] = 'Data';
$string['elementtype_daterange'] = 'Intervallo di date';
$string['elementtype_digitalsignature'] = 'Firma digitale';
$string['elementtype_expiry'] = 'Data di scadenza';
$string['elementtype_grade'] = 'Valutazione';
$string['elementtype_gradeitemname'] = 'Nome elemento di valutazione';
$string['elementtype_image'] = 'Immagine';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Nome studente';
$string['elementtype_teachername'] = 'Nome docente';
$string['elementtype_text'] = 'Testo';
$string['elementtype_userfield'] = 'Campo utente';
$string['elementtype_userpicture'] = 'Foto utente';
$string['emailcertbody'] = 'Gentile {$a->studentname},

Il tuo certificato per "{$a->certname}" nel corso "{$a->coursename}" \u00e8 allegato a questa email.

Codice di verifica: {$a->code}
Verifica online: {$a->verifyurl}

Cordiali saluti';
$string['emailcertificate'] = 'Invia certificato via email';
$string['emailcertificatebody'] = 'Gentile {$a->fullname},

Il tuo certificato per "{$a->certname}" nel corso "{$a->coursename}" \u00e8 stato emesso.

Puoi verificarlo utilizzando il codice: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = 'Il tuo certificato per {$a}';
$string['emailcertsubject'] = 'Il tuo certificato: {$a}';
$string['emailcerttemplate'] = 'Notifica email del certificato';
$string['emailcerttemplate_default'] = 'Gentile {studentname},

Il tuo certificato per "{certname}" nel corso "{coursename}" \u00e8 allegato a questa email.

Codice di verifica: {code}
Verifica online: {verifyurl}

Cordiali saluti';
$string['emailcerttemplate_desc'] = 'Corpo del messaggio per l\'invio del certificato PDF come allegato. Segnaposto: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Invia email ad altri';
$string['emailothers_desc'] = 'Indirizzi email separati da virgola che riceveranno una copia del certificato quando sar\u00e0 disponibile.';
$string['emailsent'] = 'Certificato inviato via email con successo.';
$string['emailsettings'] = 'Notifiche email';
$string['emailstudents'] = 'Invia email agli studenti';
$string['emailstudents_desc'] = 'Se abilitato, gli studenti riceveranno una copia del certificato via email quando sar\u00e0 disponibile.';
$string['emailteacherbody'] = 'Un certificato per "{$a->certname}" \u00e8 stato emesso a {$a->fullname} nel corso "{$a->coursename}".';
$string['emailteachers'] = 'Invia email ai docenti';
$string['emailteachers_desc'] = 'Se abilitato, i docenti riceveranno una copia del certificato via email quando sar\u00e0 disponibile.';
$string['emailteachersubject'] = 'Certificato emesso: {$a->certname}';
$string['entercode'] = 'Inserisci il codice di verifica';
$string['eventcertificateapproved'] = 'Certificato approvato';
$string['eventcertificateissued'] = 'Certificato emesso';
$string['eventcertificaterejected'] = 'Certificato rifiutato';
$string['eventcertificaterequested'] = 'Certificato richiesto';
$string['eventcertificaterevoked'] = 'Certificato revocato';
$string['eventpagecreated'] = 'Pagina creata';
$string['eventpagedeleted'] = 'Pagina eliminata';
$string['eventtemplatecreated'] = 'Modello creato';
$string['eventtemplatedeleted'] = 'Modello eliminato';
$string['eventtemplateupdated'] = 'Modello aggiornato';
$string['expired'] = 'Scaduto';
$string['expiredon'] = 'Scaduto il';
$string['expirydate'] = 'Data di scadenza';
$string['expirydays'] = 'Validit\u00e0 del certificato (giorni)';
$string['expirydays_help'] = 'Numero di giorni di validit\u00e0 del certificato dalla data di emissione. Impostare a 0 per nessuna scadenza.';
$string['expiryperiod'] = 'Periodo di scadenza (giorni)';
$string['expirysettings'] = 'Impostazioni di scadenza';
$string['exportcsv'] = 'Esporta CSV';
$string['exportods'] = 'Esporta ODS';
$string['exporttemplate'] = 'Esporta modello';
$string['exportxlsx'] = 'Esporta XLSX';
$string['fieldname'] = 'Nome campo';
$string['font'] = 'Font';
$string['fontsize'] = 'Dimensione font';
$string['gallerydescription'] = 'Scegli un modello da cui iniziare oppure creane uno da zero';
$string['generalsettings'] = 'Impostazioni generali';
$string['getcertificate'] = 'Ottieni certificato';
$string['gradeitem'] = 'Elemento di valutazione';
$string['height'] = 'Altezza';
$string['importtemplate'] = 'Importa modello';
$string['invalidaction'] = 'Azione non valida';
$string['invalidelementdata'] = 'Dati dell\'elemento non validi';
$string['invalidfilearea'] = 'Area file non valida';
$string['issuedcertificates'] = 'Certificati emessi';
$string['issuedcount'] = '{$a} certificato/i emesso/i';
$string['issuedtemplate'] = 'Notifica di emissione del certificato';
$string['issuedtemplate_default'] = 'Gentile {studentname},

Congratulazioni! Il tuo certificato per "{certname}" nel corso "{coursename}" \u00e8 stato emesso.

Puoi scaricarlo qui: {url}

Codice di verifica: {code}

Cordiali saluti';
$string['issuedtemplate_desc'] = 'Messaggio inviato allo studente quando un certificato viene emesso. Segnaposto: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Emissione del certificato non trovata';
$string['italic'] = 'Corsivo';
$string['landscape'] = 'Orizzontale';
$string['layers'] = 'Livelli';
$string['loading'] = 'Caricamento...';
$string['lock'] = 'Blocca';
$string['manageapprovals'] = 'Gestisci approvazioni';
$string['managetemplates'] = 'Gestisci modelli';
$string['managetemplates_desc'] = 'Visualizza, esporta, importa ed elimina modelli. Gestisci tutti i modelli predefiniti e personalizzati da un unico punto.';
$string['messageprovider:approval_request'] = 'Richiesta di approvazione del certificato';
$string['messageprovider:approval_result'] = 'Esito dell\'approvazione del certificato';
$string['messagetemplates'] = 'Modelli di messaggio';
$string['messagetemplates_desc'] = 'Personalizza i messaggi di notifica. Segnaposto: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Migra attivit\u00e0 (moduli del corso)';
$string['migrateissues'] = 'Migra certificati emessi';
$string['migratetemplates'] = 'Migra modelli (pagine ed elementi)';
$string['migrationcomplete'] = 'Migrazione completata: {$a->templates} modello/i, {$a->activities} attivit\u00e0, {$a->issues} emissione/i migrata/e.';
$string['migrationlog'] = 'Log di migrazione';
$string['migrationnodata'] = 'Nessun dato customcert trovato da migrare.';
$string['migrationnotavailable'] = 'Il plugin Custom Certificate (mod_customcert) non \u00e8 installato. Nulla da migrare.';
$string['migrationoptions'] = 'Opzioni di migrazione';
$string['migrationsummary'] = 'Dati Custom Certificate trovati';
$string['migrationtool'] = 'Migra da Custom Certificate';
$string['migrationwarning'] = 'Questa operazione creer\u00e0 nuovi record certstudio dai dati customcert. I dati customcert esistenti NON saranno modificati o eliminati. Gli elementi gi\u00e0 migrati saranno ignorati.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studio';
$string['multilang'] = 'Certificati multilingua';
$string['multilang_desc'] = 'Forza la lingua del certificato per attivit\u00e0, sovrascrivendo la preferenza dell\'utente.';
$string['mycertificates'] = 'I miei certificati';
$string['name'] = 'Nome';
$string['nelements'] = '{$a} elementi';
$string['nocertificates'] = 'Non hai ancora ricevuto nessun certificato.';
$string['nocertificatesissued'] = 'Nessun certificato \u00e8 stato ancora emesso. Completa le attivit\u00e0 richieste per ricevere il tuo certificato.';
$string['nodata'] = 'Nessun dato disponibile.';
$string['norequests'] = 'Nessuna richiesta di approvazione trovata.';
$string['notapproved'] = 'Il tuo certificato non \u00e8 stato ancora approvato.';
$string['notemplates'] = 'Nessun modello trovato.';
$string['notemplatesavailable'] = 'Nessun modello disponibile. Clicca su "Inizia da zero" per creare il tuo certificato.';
$string['notissued'] = 'Non emesso';
$string['opacity'] = 'Opacit\u00e0';
$string['optional'] = 'facoltativo';
$string['pages'] = 'Pagine';
$string['pagesettings'] = 'Impostazioni pagina';
$string['pagesize'] = 'Dimensione pagina';
$string['pdfsettings'] = 'Impostazioni PDF';
$string['platform'] = 'Piattaforma';
$string['pluginadministration'] = 'Amministrazione di Certificate Studio';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Verticale';
$string['positionandsize'] = 'Posizione e dimensione';
$string['previewpdf'] = 'Anteprima PDF';
$string['privacy:metadata:certstudio_approval_requests'] = 'Richieste di approvazione dei certificati.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'Il commento del revisore sulla richiesta.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'L\'utente che ha esaminato la richiesta.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'Lo stato dell\'approvazione.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Quando la richiesta \u00e8 stata effettuata.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Quando la richiesta \u00e8 stata aggiornata l\'ultima volta.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'L\'utente che ha richiesto il certificato.';
$string['privacy:metadata:certstudio_issues'] = 'Registrazioni dei certificati emessi.';
$string['privacy:metadata:certstudio_issues:code'] = 'Il codice di verifica univoco.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'Lo snapshot dei dati del modello del certificato.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Quando il certificato \u00e8 stato emesso.';
$string['privacy:metadata:certstudio_issues:userid'] = 'L\'utente che ha ricevuto il certificato.';
$string['privacy:path:approvalrequests'] = 'Richieste di approvazione';
$string['privacy:path:issues'] = 'Certificati emessi';
$string['properties'] = 'Propriet\u00e0';
$string['protection'] = 'Protezione PDF';
$string['protection_copy'] = 'Impedisci copia';
$string['protection_copy_desc'] = 'Abilita la protezione dall\'azione di copia.';
$string['protection_modify'] = 'Impedisci modifica';
$string['protection_modify_desc'] = 'Abilita la protezione dall\'azione di modifica.';
$string['protection_print'] = 'Impedisci stampa';
$string['protection_print_desc'] = 'Abilita la protezione dall\'azione di stampa.';
$string['protectionflags'] = 'Flag di protezione';
$string['protectionflags_help'] = 'Flag di protezione separati da virgola: print, modify, copy';
$string['publishtogallery'] = 'Pubblica nella galleria';
$string['publishtogallerytip'] = 'Pubblica una copia nella galleria dei modelli affinché tutti i corsi possano utilizzarla';
$string['reason'] = 'Motivo';
$string['receiveddate'] = 'Data di ricezione';
$string['redo'] = 'Ripeti';
$string['reissue'] = 'Riemetti';
$string['reissuedtemplate'] = 'Notifica di riemissione del certificato';
$string['reissuedtemplate_default'] = 'Gentile {studentname},

Una nuova versione del tuo certificato per "{certname}" nel corso "{coursename}" \u00e8 stata emessa.

Puoi scaricarlo qui: {url}

Codice di verifica: {code}

Cordiali saluti';
$string['reissuedtemplate_desc'] = 'Messaggio inviato allo studente quando viene emessa una nuova versione del suo certificato. Segnaposto: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Rifiuta';
$string['rejected'] = 'rifiutata';
$string['rejectedtemplate'] = 'Notifica di rifiuto (allo studente)';
$string['rejectedtemplate_desc'] = 'Messaggio inviato allo studente quando la sua richiesta viene rifiutata.';
$string['reportanalytics'] = 'Analisi dei certificati';
$string['reportmonthly'] = 'Andamento mensile (ultimi 12 mesi)';
$string['reportpercourse'] = 'Certificati per corso';
$string['reportrecent'] = 'Certificati recenti (ultimi 30 giorni)';
$string['reporttotalactivities'] = 'Totale attivit\u00e0';
$string['reporttotalissued'] = 'Totale emessi';
$string['reporttotaltemplates'] = 'Totale modelli';
$string['reportuniquerecipients'] = 'Destinatari unici';
$string['requestagain'] = 'Invia nuova richiesta';
$string['requestapproved'] = 'Richiesta approvata con successo.';
$string['requestcertificate'] = 'Richiedi certificato';
$string['requestpending'] = 'La tua richiesta di certificato \u00e8 in attesa di approvazione.';
$string['requestrejected'] = 'La tua richiesta di certificato \u00e8 stata rifiutata.';
$string['requestrejectedmsg'] = 'Richiesta rifiutata con successo.';
$string['requestsubmitted'] = 'La tua richiesta di certificato \u00e8 stata inviata.';
$string['requiredtime'] = 'Minuti richiesti nel corso';
$string['requiredtime_desc'] = 'Tempo minimo in minuti che uno studente deve trascorrere nel corso prima di poter ricevere il certificato. Impostare a 0 per disabilitare.';
$string['requiredtimenotmet'] = 'Devi trascorrere almeno {$a->required} minuti in questo corso prima di poter ricevere un certificato. Finora hai trascorso circa {$a->spent} minuti.';
$string['returncourse'] = 'Pulsante Torna al corso';
$string['returncourse_desc'] = 'Mostra un pulsante "Torna al corso" nella pagina di visualizzazione del certificato.';
$string['returntocourse'] = 'Torna al corso';
$string['reviewer'] = 'Revisore';
$string['revokecertificate'] = 'Revoca certificato';
$string['revoked'] = 'Revocato';
$string['revokeddate'] = 'Revocato il';
$string['revokedrenewal'] = 'Revocato per rinnovo (nuova versione emessa)';
$string['revokedtemplate'] = 'Notifica di revoca del certificato';
$string['revokedtemplate_default'] = 'Gentile {studentname},

Il tuo certificato per "{certname}" nel corso "{coursename}" \u00e8 stato revocato.

Motivo: {reason}

Per qualsiasi domanda, contatta il tuo docente.

Cordiali saluti';
$string['revokedtemplate_desc'] = 'Messaggio inviato allo studente quando il suo certificato viene revocato. Segnaposto: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Rotazione';
$string['save'] = 'Salva';
$string['savechangestip'] = 'Salva le modifiche solo per questa attività';
$string['saved'] = 'Modifiche salvate';
$string['saveerror'] = 'Errore nel salvataggio delle modifiche';
$string['savestatussaved'] = 'Salvato';
$string['searchbyname'] = 'Cerca per nome...';
$string['selectelement'] = 'Fai clic su un elemento per modificarne le propriet\u00e0.';
$string['selecttemplate'] = 'Seleziona modello';
$string['sharecertificate'] = 'Condividi';
$string['shareemailbody'] = 'Volevo condividere con te che ho ottenuto il certificato "{$a->certname}".

Puoi verificarlo qui: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Il mio certificato: {$a}';
$string['sharetext'] = 'Ho appena ottenuto il certificato "{$a}"!';
$string['showcasecourse'] = 'Corso';
$string['showcasedownloadpdf'] = 'Scarica PDF';
$string['showcaseissuedon'] = 'Emesso il';
$string['showcaserecipient'] = 'Conferito a';
$string['showcaseshare'] = 'Condividi questo certificato';
$string['showcasetitle'] = 'Certificato digitale';
$string['showcaseverified'] = 'Certificato verificato';
$string['showposxy'] = 'Mostra posizione X e Y';
$string['showposxy_desc'] = 'Mostra la posizione X e Y durante la modifica di un elemento, consentendo all\'utente di specificare con precisione la posizione.';
$string['startfromscratch'] = 'Inizia da zero';
$string['startmigration'] = 'Avvia migrazione';
$string['status'] = 'Stato';
$string['statusapproved'] = 'Approvato';
$string['statusexpired'] = 'Scaduto';
$string['statuspending'] = 'In attesa';
$string['statusrejected'] = 'Rifiutato';
$string['statusrevoked'] = 'Revocato';
$string['statusvalid'] = 'Valido';
$string['student'] = 'Studente';
$string['styleclassic'] = 'Classico';
$string['styledark'] = 'Scuro';
$string['styleelegant'] = 'Elegante';
$string['stylegradient'] = 'Sfumatura';
$string['styleminimal'] = 'Minimalista';
$string['stylemodern'] = 'Moderno';
$string['stylespecial'] = 'Speciale';
$string['subplugintype_certstudioselem'] = 'Tipo di elemento';
$string['subplugintype_certstudioselem_plural'] = 'Tipi di elemento';
$string['taskemailcertificate'] = 'Invia certificato via email';
$string['taskissuecertificate'] = 'Emetti certificati e invia email';
$string['template'] = 'Modello';
$string['templatedeleted'] = 'Il modello "{$a}" \u00e8 stato eliminato.';
$string['templatefile'] = 'File del modello (.json)';
$string['templatefilehelp'] = 'Carica un file .certstudio.json esportato da un\'altra installazione di Certificate Studio.';
$string['templategallery'] = 'Galleria modelli';
$string['templateimported'] = 'Modello "{$a->name}" importato con successo ({$a->pages} pagina/e, {$a->elements} elemento/i).';
$string['templateimportinvalid'] = 'File del modello non valido. Carica un file .certstudio.json valido.';
$string['templateinuse'] = 'Questo modello \u00e8 utilizzato da {$a} attivit\u00e0 e non pu\u00f2 essere eliminato.';
$string['templatenameplaceholder'] = 'Nome del modello...';
$string['templates'] = 'Modelli';
$string['templatesharing'] = 'Importa/Esporta modelli';
$string['textcontent'] = 'Contenuto testo';
$string['toggleelementspanel'] = 'Mostra/nascondi pannello elementi';
$string['togglegrid'] = 'Attiva/disattiva griglia';
$string['toggleguides'] = 'Attiva/disattiva guide';
$string['togglepropertiespanel'] = 'Mostra/nascondi pannello proprietà';
$string['typography'] = 'Tipografia';
$string['undo'] = 'Annulla';
$string['unknowncourse'] = 'Corso sconosciuto';
$string['unknownuser'] = 'Utente sconosciuto';
$string['unlock'] = 'Sblocca';
$string['uploadbgimage'] = 'Carica';
$string['uploadbgimagetip'] = 'Carica immagine di sfondo';
$string['usethisTemplate'] = 'Usa questo modello';
$string['usethistemplate'] = 'Usa questo modello';
$string['valid'] = 'Valido';
$string['verificationcode'] = 'Codice di verifica';
$string['verify'] = 'Verifica';
$string['verifyallcertificates'] = 'Consenti verifica pubblica';
$string['verifyallcertificates_desc'] = 'Consenti a chiunque di verificare i certificati senza effettuare l\'accesso.';
$string['verifyanother'] = 'Verifica un altro certificato';
$string['verifyany'] = 'Consenti a chiunque di verificare un certificato';
$string['verifyany_desc'] = 'Consenti a chiunque possieda il link di verifica del certificato (inclusi gli utenti non autenticati) di verificare un certificato.';
$string['verifycertificate'] = 'Verifica certificato';
$string['verifyintro'] = 'Inserisci un codice di verifica del certificato per verificarne l\'autenticit\u00e0 su {$a}.';
$string['verifylink_desc'] = 'Questo link ti porter\u00e0 a una pagina dove potrai verificare i certificati sul sito.';
$string['verifynotfound'] = 'Nessun certificato trovato con questo codice di verifica. Controlla e riprova.';
$string['verifyurl'] = 'URL di verifica personalizzato';
$string['verifyurl_desc'] = 'URL personalizzato per il link di verifica del QR Code. Lasciare vuoto per utilizzare la pagina di verifica predefinita di Moodle. Segnaposto: {code}';
$string['version'] = 'Versione';
$string['viewonline'] = 'Visualizza online';
$string['width'] = 'Larghezza';
$string['zoomin'] = 'Ingrandisci';
$string['zoomout'] = 'Riduci';
