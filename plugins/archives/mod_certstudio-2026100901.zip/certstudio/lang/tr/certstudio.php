<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Turkish language strings for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['a4landscape'] = 'A4 Yatay';
$string['actions'] = 'İşlemler';
$string['actionsheading'] = 'İşlemler';
$string['active'] = 'Aktif';
$string['activities'] = 'Etkinlikler';
$string['aiapikey'] = 'API anahtarı';
$string['aiapikey_desc'] = 'Seçilen AI sağlayıcı için API anahtarınız. OpenAI veya Anthropic\'ten edinin.';
$string['aierror'] = 'AI oluşturma hatası: {$a}';
$string['aigeneratebutton'] = 'Oluştur';
$string['aigeneratedesc'] = 'İstediğiniz sertifikayı tanımlayın, AI sizin için bir şablon oluşturacaktır.';
$string['aigenerateplaceholder'] = 'ör. altın kenarlıklı, mavi renkli resmi bir BT kursu sertifikası...';
$string['aigeneratesuccess'] = 'Şablon başarıyla oluşturuldu! Düzenleyiciye yönlendiriliyorsunuz...';
$string['aigeneratetitle'] = 'AI Şablon Oluşturucu';
$string['aigenerating'] = 'AI ile şablon oluşturuluyor...';
$string['aimodel'] = 'Model';
$string['aimodel_desc'] = 'Kullanılacak AI modeli. OpenAI için: gpt-4o-mini, gpt-4o. Anthropic için: claude-sonnet-4-20250514.';
$string['ainokey'] = 'AI API anahtarı yapılandırılmamış. Lütfen eklenti ayarlarından ayarlayın.';
$string['aiparseerror'] = 'AI yanıtı ayrıştırılamadı. Lütfen farklı bir açıklama ile tekrar deneyin.';
$string['aiprovider'] = 'AI sağlayıcı';
$string['aiprovider_desc'] = 'Şablon oluşturma için hangi AI hizmetinin kullanılacağını seçin.';
$string['aisettings'] = 'AI Şablon Oluşturucu';
$string['aisettings_desc'] = 'AI destekli otomatik şablon oluşturmayı yapılandırın. OpenAI veya Anthropic\'ten bir API anahtarı gerektirir.';
$string['aligncenter'] = 'Orta';
$string['alignleft'] = 'Sol';
$string['alignright'] = 'Sağ';
$string['all'] = 'Tümü';
$string['allcolors'] = 'Tüm renkler';
$string['allstyles'] = 'Tüm stiller';
$string['alltemplates'] = 'Tüm Şablonlar';
$string['appearance'] = 'Görünüm';
$string['apply'] = 'Uygula';
$string['approval'] = 'Onay iş akışı';
$string['approvalenabled'] = 'Onay iş akışını etkinleştir';
$string['approvalenabled_desc'] = 'Yeni etkinlikler için varsayılan olarak onay iş akışını etkinleştir.';
$string['approvalenabled_help'] = 'Etkinleştirildiğinde, öğrencilerin sertifikayı indirmeden önce bir öğretmenden onay istemesi gerekir.';
$string['approvalnotifystudent'] = 'Sonuç hakkında öğrenciyi bilgilendir';
$string['approvalnotifystudent_desc'] = 'Talepleri onaylandığında veya reddedildiğinde öğrencilere bildirim gönder.';
$string['approvalnotifyteacher'] = 'Talep üzerine öğretmeni bilgilendir';
$string['approvalnotifyteacher_desc'] = 'Bir öğrenci sertifika talep ettiğinde öğretmenlere bildirim gönder.';
$string['approvalrequestbody'] = '{$a->student}, "{$a->activity}" için sertifika talep etti.';
$string['approvalrequestbodyhtml'] = '<p><strong>{$a->student}</strong>, "<strong>{$a->activity}</strong>" için sertifika talep etti.</p><p><a href="{$a->url}">Onay taleplerini incele</a></p>';
$string['approvalrequestexists'] = 'Zaten bekleyen bir onay talebiniz var.';
$string['approvalrequestnotfound'] = 'Onay talebi bulunamadı.';
$string['approvalrequestnotpending'] = 'Bu onay talebi artık beklemede değil.';
$string['approvalrequests'] = 'Onay talepleri';
$string['approvalrequestsmall'] = '{$a} tarafından yeni sertifika talebi';
$string['approvalrequestsubject'] = 'Sertifika onay talebi: {$a}';
$string['approvalrequesttemplate'] = 'Talep bildirimi (öğretmene)';
$string['approvalrequesttemplate_desc'] = 'Bir öğrenci sertifika onayı istediğinde öğretmenlere gönderilen mesaj.';
$string['approvalresultbody'] = '"{$a->activity}" için sertifika talebiniz {$a->status}.';
$string['approvalresultbodyhtml'] = '<p>"<strong>{$a->activity}</strong>" için sertifika talebiniz <strong>{$a->status}</strong>.</p><p>İnceleyen: {$a->reviewer}</p>{$a->comment}<p><a href="{$a->url}">Sertifikayı görüntüle</a></p>';
$string['approvalresultsmall'] = 'Sertifika talebi {$a}';
$string['approvalresultsubject'] = 'Sertifika talebi {$a->status}: {$a->activity}';
$string['approvalsettings'] = 'Onay ayarları';
$string['approve'] = 'Onayla';
$string['approved'] = 'onaylandı';
$string['approvedtemplate'] = 'Onay bildirimi (öğrenciye)';
$string['approvedtemplate_desc'] = 'Talebi onaylandığında öğrenciye gönderilen mesaj.';
$string['autoissue'] = 'Kurs tamamlandığında otomatik ver';
$string['autoissue_desc'] = 'Öğrenci kursu tamamladığında sertifikaları otomatik olarak ver. Kurs tamamlama özelliğinin etkinleştirilmiş olması gerekir. Onay iş akışı olan etkinlikler için geçerli değildir.';
$string['back'] = 'Geri';
$string['backtoview'] = 'Geri';
$string['batchdownload'] = 'Tümünü ZIP olarak indir';
$string['bgcolor'] = 'Arka plan rengi';
$string['bgimage'] = 'Arka plan resmi';
$string['bgimageopacity'] = 'Arka plan resmi opaklığı';
$string['bgimagesize'] = 'Arka plan resim boyutu';
$string['bgimagesizeactual'] = 'Gerçek boyut';
$string['bgimagesizecontain'] = 'Sığdır (içine yerleştir)';
$string['bgimagesizecover'] = 'Kapla (sayfayı doldur)';
$string['bgimagesizestretch'] = 'Uzat';
$string['bold'] = 'Kalın';
$string['bordercolor'] = 'Kenarlık rengi';
$string['borderstyle'] = 'Kenarlık stili';
$string['borderwidth'] = 'Kenarlık genişliği';
$string['builtin'] = 'Yerleşik';
$string['builtintemplates'] = 'Yerleşik şablonlar';
$string['bulkactions'] = 'Toplu işlemler';
$string['bulkdelete'] = 'Seçilenleri sil';
$string['bulkemail'] = 'Seçilenlere e-posta gönder';
$string['bulkissue'] = 'Toplu Verme';
$string['bulkissuealreadyissued'] = '{$a} öğrenci zaten sertifikaya sahip (atlandı)';
$string['bulkissuecomplete'] = '{$a} sertifika başarıyla verildi.';
$string['bulkissuedefaultmessage'] = 'Sayın {studentname},

Tebrikler! "{coursename}" kursundaki "{certname}" sertifikanız düzenlenmiştir.

Buradan indirebilirsiniz: {url}

Saygılarımızla';
$string['bulkissuedesc'] = 'Henüz sertifika almamış tüm uygun kayıtlı öğrencilere sertifika ver.';
$string['bulkissuenoeligible'] = 'Tüm kayıtlı öğrenciler zaten sertifika almıştır.';
$string['bulkissuenoselection'] = 'Hiçbir öğrenci seçilmedi.';
$string['bulkissuenotified'] = '{$a} öğrenci bilgilendirildi.';
$string['bulkissuenotify'] = 'Öğrencileri bilgilendir';
$string['bulkissuenotifyemail'] = 'E-posta ile bildirim gönder';
$string['bulkissuenotifymessage'] = 'Bildirim mesajı';
$string['bulkissuenotifymoodle'] = 'Moodle üzerinden bildirim gönder';
$string['bulkissuenotifyplaceholders'] = 'Kullanılabilir yer tutucular: {studentname}, {coursename}, {certname}, {url}';
$string['bulkissuenotifysmall'] = '{$a} için sertifikanız verildi.';
$string['bulkissuenotifysubject'] = 'Sertifikanız verildi: {$a}';
$string['bulkissuesubmit'] = '{$a} öğrenciye sertifika ver';
$string['bulkoperationcomplete'] = '{$a->count} sertifika işlendi: {$a->action}.';
$string['bulkreissue'] = 'Seçilenleri yeniden ver';
$string['bulkrevoke'] = 'Seçilenleri iptal et';
$string['certificate'] = 'Sertifika';
$string['certificateexpired'] = 'Bu sertifikanın süresi {$a} tarihinde dolmuştur.';
$string['certificateexpiredverify'] = 'Bu sertifikanın süresi dolmuştur';
$string['certificateexpires'] = 'Bu sertifikanın süresi {$a} tarihinde dolacaktır.';
$string['certificateinvalid'] = 'Bu sertifika geçersizdir';
$string['certificateissued'] = 'Sertifikanız {$a} tarihinde verildi.';
$string['certificatenotfound'] = 'Bu doğrulama koduyla eşleşen sertifika bulunamadı.';
$string['certificaterevoked'] = 'Bu sertifika iptal edilmiştir';
$string['certificaterevokedstudent'] = 'Sertifikanız iptal edilmiştir. Daha fazla bilgi için lütfen öğretmeniniz veya yöneticinizle iletişime geçin.';
$string['certificatevalid'] = 'Bu sertifika geçerlidir';
$string['certificateversion'] = 'Bu, sertifikanızın {$a}. sürümüdür (yenilenmiş).';
$string['certstudio:addinstance'] = 'Yeni bir Certificate Studio etkinliği ekle';
$string['certstudio:approvecertificate'] = 'Sertifika taleplerini onayla';
$string['certstudio:manage'] = 'Sertifika şablonlarını yönet';
$string['certstudio:manageemailstudents'] = 'E-posta bildirim ayarlarını yönet';
$string['certstudio:manageprotection'] = 'PDF koruma ayarlarını yönet';
$string['certstudio:managetemplates'] = 'Sertifika şablonlarını yönet';
$string['certstudio:receiveissue'] = 'Sertifika al';
$string['certstudio:revokecertificate'] = 'Verilen sertifikaları iptal et';
$string['certstudio:verifycertificate'] = 'Sertifika kodlarını doğrula';
$string['certstudio:view'] = 'Sertifikayı görüntüle';
$string['certstudio:viewallcertificates'] = 'Verilen tüm sertifikaları görüntüle';
$string['certstudio:viewreport'] = 'Sertifika raporlarını ve analizlerini görüntüle';
$string['city'] = 'Şehir';
$string['clearbg'] = 'Arka planı temizle';
$string['clicktorenametemplate'] = 'Şablonu yeniden adlandırmak için tıklayın';
$string['codegenerationmethod'] = 'Kod oluşturma yöntemi';
$string['codegenerationmethod_desc'] = 'Sertifika doğrulama kodları oluşturmak için iki yöntem arasından seçim yapın.';
$string['codegenerationmethod_digitshyphens'] = '0123-4567-8901 (Tireli rakamlar)';
$string['codegenerationmethod_upperlowerdigits'] = '6aOdbLEuoC (Büyük/küçük harf/rakam rastgele dize)';
$string['color'] = 'Renk';
$string['colorblue'] = 'Mavi';
$string['colordark'] = 'Koyu';
$string['colorgold'] = 'Altın';
$string['colorgray'] = 'Gri';
$string['colorgreen'] = 'Yeşil';
$string['colorpink'] = 'Pembe';
$string['colorpurple'] = 'Mor';
$string['colorred'] = 'Kırmızı';
$string['comment'] = 'Yorum';
$string['confirmbulk'] = 'Seçilen sertifikalar üzerinde bu toplu işlemi gerçekleştirmek istediğinizden emin misiniz?';
$string['confirmdelete'] = 'Bu şablonu silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.';
$string['confirmdeleteissue'] = 'Bu sertifika kaydını kalıcı olarak silmek istediğinizden emin misiniz?';
$string['confirmrevoke'] = 'Bu sertifikayı iptal etmek istediğinizden emin misiniz? Doğrulama sayfası sertifikayı iptal edilmiş olarak gösterecektir.';
$string['copy'] = 'Kopyala';
$string['course'] = 'Kurs';
$string['createblank'] = 'Boş Sertifika';
$string['createblankdesc'] = 'Boş bir tuval ile başlayın';
$string['created'] = 'Oluşturulma tarihi';
$string['createtemplate'] = '-- Yeni şablon oluştur --';
$string['current'] = 'Mevcut';
$string['currenttemplate'] = 'Mevcut şablon';
$string['custom'] = 'Özel';
$string['customsource'] = 'Özel';
$string['customtemplates'] = 'Özel şablonlar';
$string['dateformat'] = 'Tarih biçimi';
$string['dateissued'] = 'Verilme tarihi';
$string['daterequested'] = 'Talep tarihi';
$string['defaultfilename'] = 'Varsayılan PDF dosya adı';
$string['defaultfilename_desc'] = 'İndirilen PDF\'ler için varsayılan dosya adı kalıbı. Yer tutucular: {coursename}, {studentname}, {date}, {activityname}. Etkinlik başına geçersiz kılınabilir.';
$string['defaultprotection'] = 'Varsayılan PDF koruma';
$string['defaultprotection_desc'] = 'PDF\'ler için varsayılan koruma bayrakları (virgülle ayrılmış): print, modify, copy. Etkinlik başına geçersiz kılınabilir.';
$string['defaultvalues'] = 'Etkinlik ayarları için varsayılan değerler';
$string['defaultvalues_desc'] = 'Varsayılan değerler, yeni bir etkinlik oluştururken ayarlar formunda kullanılır.';
$string['delete'] = 'Sil';
$string['deleteissuedcertificates'] = 'Verilmiş sertifikaları sil';
$string['downloadcertificate'] = 'Sertifikayı İndir';
$string['downloadfilename'] = 'PDF dosya adı';
$string['downloadfilename_help'] = 'İndirilen PDF sertifika için özel dosya adı. Yer tutucuları kullanabilirsiniz: {coursename}, {studentname}, {date}. Etkinlik adını kullanmak için boş bırakın. Örnek: Sertifika_{coursename}_{studentname}';
$string['downloadsettings'] = 'İndirme ayarları';
$string['editcertstudio'] = 'Sertifikayı düzenle';
$string['edittemplate'] = 'Şablonu Düzenle';
$string['elementcount'] = '{$a} öğe';
$string['elementname'] = 'Öğe adı';
$string['elements'] = 'Öğeler';
$string['elementtype_bgimage'] = 'Arka plan görseli';
$string['elementtype_border'] = 'Kenarlık';
$string['elementtype_categoryname'] = 'Kategori adı';
$string['elementtype_certdate'] = 'Yunanca tarih';
$string['elementtype_certstatement'] = 'Yunanca ifade';
$string['elementtype_code'] = 'Doğrulama kodu';
$string['elementtype_coursefield'] = 'Kurs alanı';
$string['elementtype_coursename'] = 'Kurs adı';
$string['elementtype_date'] = 'Tarih';
$string['elementtype_daterange'] = 'Tarih aralığı';
$string['elementtype_digitalsignature'] = 'Dijital imza';
$string['elementtype_expiry'] = 'Son geçerlilik tarihi';
$string['elementtype_grade'] = 'Not';
$string['elementtype_gradeitemname'] = 'Not öğesi adı';
$string['elementtype_image'] = 'Görsel';
$string['elementtype_qrcode'] = 'QR Code';
$string['elementtype_studentname'] = 'Öğrenci adı';
$string['elementtype_teachername'] = 'Öğretmen adı';
$string['elementtype_text'] = 'Metin';
$string['elementtype_userfield'] = 'Kullanıcı alanı';
$string['elementtype_userpicture'] = 'Kullanıcı fotoğrafı';
$string['emailcertbody'] = 'Sayın {$a->studentname},

"{$a->coursename}" kursundaki "{$a->certname}" sertifikanız bu e-postaya eklenmiştir.

Doğrulama kodu: {$a->code}
Çevrimiçi doğrulama: {$a->verifyurl}

Saygılarımızla';
$string['emailcertificate'] = 'Sertifikayı e-posta ile gönder';
$string['emailcertificatebody'] = 'Sayın {$a->fullname},

"{$a->coursename}" kursundaki "{$a->certname}" sertifikanız düzenlenmiştir.

Doğrulama kodu ile doğrulayabilirsiniz: {$a->code}

{$a->verifyurl}';
$string['emailcertificatesubject'] = '{$a} için sertifikanız';
$string['emailcertsubject'] = 'Sertifikanız: {$a}';
$string['emailcerttemplate'] = 'Sertifika e-posta bildirimi';
$string['emailcerttemplate_default'] = 'Sayın {studentname},

"{coursename}" kursundaki "{certname}" sertifikanız bu e-postaya eklenmiştir.

Doğrulama kodu: {code}
Çevrimiçi doğrulama: {verifyurl}

Saygılarımızla';
$string['emailcerttemplate_desc'] = 'Sertifika PDF\'i ek olarak e-postayla gönderildiğinde mesaj gövdesi. Yer tutucular: {studentname}, {coursename}, {certname}, {code}, {verifyurl}';
$string['emailothers'] = 'Diğerlerine e-posta gönder';
$string['emailothers_desc'] = 'Sertifika hazır olduğunda bir kopyasını alacak virgülle ayrılmış e-posta adresleri.';
$string['emailsent'] = 'Sertifika başarıyla e-posta ile gönderildi.';
$string['emailsettings'] = 'E-posta bildirimleri';
$string['emailstudents'] = 'Öğrencilere e-posta gönder';
$string['emailstudents_desc'] = 'Etkinleştirilirse, sertifika hazır olduğunda öğrencilere e-posta ile bir kopyası gönderilir.';
$string['emailteacherbody'] = '"{$a->coursename}" kursunda {$a->fullname} adına "{$a->certname}" sertifikası verildi.';
$string['emailteachers'] = 'Öğretmenlere e-posta gönder';
$string['emailteachers_desc'] = 'Etkinleştirilirse, sertifika hazır olduğunda öğretmenlere e-posta ile bir kopyası gönderilir.';
$string['emailteachersubject'] = 'Sertifika verildi: {$a->certname}';
$string['entercode'] = 'Doğrulama kodunu girin';
$string['eventcertificateapproved'] = 'Sertifika onaylandı';
$string['eventcertificateissued'] = 'Sertifika verildi';
$string['eventcertificaterejected'] = 'Sertifika reddedildi';
$string['eventcertificaterequested'] = 'Sertifika talep edildi';
$string['eventcertificaterevoked'] = 'Sertifika iptal edildi';
$string['eventpagecreated'] = 'Sayfa oluşturuldu';
$string['eventpagedeleted'] = 'Sayfa silindi';
$string['eventtemplatecreated'] = 'Şablon oluşturuldu';
$string['eventtemplatedeleted'] = 'Şablon silindi';
$string['eventtemplateupdated'] = 'Şablon güncellendi';
$string['expired'] = 'Süresi dolmuş';
$string['expiredon'] = 'Süresi dolma tarihi';
$string['expirydate'] = 'Son geçerlilik tarihi';
$string['expirydays'] = 'Sertifika geçerlilik süresi (gün)';
$string['expirydays_help'] = 'Sertifikanın verilme tarihinden itibaren geçerli olduğu gün sayısı. Süresiz için 0 olarak ayarlayın.';
$string['expiryperiod'] = 'Geçerlilik süresi (gün)';
$string['expirysettings'] = 'Geçerlilik ayarları';
$string['exportcsv'] = 'CSV Dışa Aktar';
$string['exportods'] = 'ODS Dışa Aktar';
$string['exporttemplate'] = 'Şablonu dışa aktar';
$string['exportxlsx'] = 'XLSX Dışa Aktar';
$string['fieldname'] = 'Alan adı';
$string['font'] = 'Yazı tipi';
$string['fontsize'] = 'Yazı tipi boyutu';
$string['gallerydescription'] = 'Başlamak için bir şablon seçin veya sıfırdan kendi şablonunuzu oluşturun';
$string['generalsettings'] = 'Genel ayarlar';
$string['getcertificate'] = 'Sertifika Al';
$string['gradeitem'] = 'Not öğesi';
$string['height'] = 'Yükseklik';
$string['importtemplate'] = 'Şablonu içe aktar';
$string['invalidaction'] = 'Geçersiz işlem';
$string['invalidelementdata'] = 'Geçersiz öğe verisi';
$string['invalidfilearea'] = 'Geçersiz dosya alanı';
$string['issuedcertificates'] = 'Verilmiş sertifikalar';
$string['issuedcount'] = '{$a} sertifika verildi';
$string['issuedtemplate'] = 'Sertifika verildi bildirimi';
$string['issuedtemplate_default'] = 'Sayın {studentname},

Tebrikler! "{coursename}" kursundaki "{certname}" sertifikanız düzenlenmiştir.

Buradan indirebilirsiniz: {url}

Doğrulama kodu: {code}

Saygılarımızla';
$string['issuedtemplate_desc'] = 'Sertifika verildiğinde öğrenciye gönderilen mesaj. Yer tutucular: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['issuenotfound'] = 'Sertifika kaydı bulunamadı';
$string['italic'] = 'İtalik';
$string['landscape'] = 'Yatay';
$string['layers'] = 'Katmanlar';
$string['loading'] = 'Yükleniyor...';
$string['lock'] = 'Kilitle';
$string['manageapprovals'] = 'Onayları yönet';
$string['managetemplates'] = 'Şablonları Yönet';
$string['managetemplates_desc'] = 'Şablonları görüntüleyin, dışa aktarın, içe aktarın ve silin. Tüm yerleşik ve özel şablonları tek bir yerden yönetin.';
$string['messageprovider:approval_request'] = 'Sertifika onay talebi';
$string['messageprovider:approval_result'] = 'Sertifika onay sonucu';
$string['messagetemplates'] = 'Mesaj şablonları';
$string['messagetemplates_desc'] = 'Bildirim mesajlarını özelleştirin. Yer tutucular: {studentname}, {coursename}, {certname}, {url}, {code}, {reason}';
$string['migrateactivities'] = 'Etkinlikleri taşı (kurs modülleri)';
$string['migrateissues'] = 'Verilmiş sertifikaları taşı';
$string['migratetemplates'] = 'Şablonları taşı (sayfalar ve öğeler)';
$string['migrationcomplete'] = 'Taşıma tamamlandı: {$a->templates} şablon, {$a->activities} etkinlik, {$a->issues} sertifika taşındı.';
$string['migrationlog'] = 'Taşıma günlüğü';
$string['migrationnodata'] = 'Taşınacak customcert verisi bulunamadı.';
$string['migrationnotavailable'] = 'Custom Certificate (mod_customcert) eklentisi yüklü değil. Taşınacak bir şey yok.';
$string['migrationoptions'] = 'Taşıma seçenekleri';
$string['migrationsummary'] = 'Custom Certificate verileri bulundu';
$string['migrationtool'] = 'Custom Certificate\'dan Taşıma';
$string['migrationwarning'] = 'Bu işlem, customcert verilerinizden yeni certstudio kayıtları oluşturacaktır. Mevcut customcert verileri değiştirilmeyecek veya silinmeyecektir. Daha önce taşınmış öğeler atlanacaktır.';
$string['modulename'] = 'Certificate Studio';
$string['modulenameplural'] = 'Certificate Studio\'lar';
$string['multilang'] = 'Çok dilli sertifikalar';
$string['multilang_desc'] = 'Kullanıcı tercihini geçersiz kılarak etkinlik başına sertifika dilini zorla.';
$string['mycertificates'] = 'Sertifikalarım';
$string['name'] = 'Ad';
$string['nelements'] = '{$a} öğe';
$string['nocertificates'] = 'Henüz hiç sertifika almadınız.';
$string['nocertificatesissued'] = 'Henüz sertifika verilmedi. Sertifikanızı almak için lütfen gerekli etkinlikleri tamamlayın.';
$string['nodata'] = 'Veri bulunamadı.';
$string['norequests'] = 'Onay talebi bulunamadı.';
$string['notapproved'] = 'Sertifikanız henüz onaylanmadı.';
$string['notemplates'] = 'Şablon bulunamadı.';
$string['notemplatesavailable'] = 'Kullanılabilir şablon yok. Kendi sertifikanızı oluşturmak için "Sıfırdan başla"ya tıklayın.';
$string['notissued'] = 'Verilmedi';
$string['opacity'] = 'Saydamlık';
$string['optional'] = 'isteğe bağlı';
$string['pages'] = 'Sayfalar';
$string['pagesettings'] = 'Sayfa ayarları';
$string['pagesize'] = 'Sayfa boyutu';
$string['pdfsettings'] = 'PDF ayarları';
$string['platform'] = 'Platform';
$string['pluginadministration'] = 'Certificate Studio yönetimi';
$string['pluginname'] = 'Certificate Studio';
$string['portrait'] = 'Dikey';
$string['positionandsize'] = 'Konum ve Boyut';
$string['previewpdf'] = 'PDF Önizleme';
$string['privacy:metadata:certstudio_approval_requests'] = 'Sertifika onay talepleri.';
$string['privacy:metadata:certstudio_approval_requests:reviewcomment'] = 'İnceleyenin talep hakkındaki yorumu.';
$string['privacy:metadata:certstudio_approval_requests:reviewerid'] = 'Talebi inceleyen kullanıcı.';
$string['privacy:metadata:certstudio_approval_requests:status'] = 'Onay durumu.';
$string['privacy:metadata:certstudio_approval_requests:timecreated'] = 'Talebin yapıldığı zaman.';
$string['privacy:metadata:certstudio_approval_requests:timemodified'] = 'Talebin son güncellendiği zaman.';
$string['privacy:metadata:certstudio_approval_requests:userid'] = 'Sertifika talep eden kullanıcı.';
$string['privacy:metadata:certstudio_issues'] = 'Verilmiş sertifika kayıtları.';
$string['privacy:metadata:certstudio_issues:code'] = 'Benzersiz doğrulama kodu.';
$string['privacy:metadata:certstudio_issues:templatedata'] = 'Sertifika şablon verisi anlık görüntüsü.';
$string['privacy:metadata:certstudio_issues:timecreated'] = 'Sertifikanın verildiği zaman.';
$string['privacy:metadata:certstudio_issues:userid'] = 'Sertifikayı alan kullanıcı.';
$string['privacy:path:approvalrequests'] = 'Onay talepleri';
$string['privacy:path:issues'] = 'Verilmiş sertifikalar';
$string['properties'] = 'Özellikler';
$string['protection'] = 'PDF koruma';
$string['protection_copy'] = 'Kopyalamayı engelle';
$string['protection_copy_desc'] = 'Kopyalama işlemine karşı korumayı etkinleştir.';
$string['protection_modify'] = 'Değiştirmeyi engelle';
$string['protection_modify_desc'] = 'Değiştirme işlemine karşı korumayı etkinleştir.';
$string['protection_print'] = 'Yazdırmayı engelle';
$string['protection_print_desc'] = 'Yazdırma işlemine karşı korumayı etkinleştir.';
$string['protectionflags'] = 'Koruma bayrakları';
$string['protectionflags_help'] = 'Virgülle ayrılmış koruma bayrakları: print, modify, copy';
$string['publishtogallery'] = 'Galeriye yayınla';
$string['publishtogallerytip'] = 'Tüm kursların kullanabilmesi için Şablon Galerisine bir kopya yayınla';
$string['reason'] = 'Gerekçe';
$string['receiveddate'] = 'Alınma tarihi';
$string['redo'] = 'Yinele';
$string['reissue'] = 'Yeniden ver';
$string['reissuedtemplate'] = 'Sertifika yeniden verildi bildirimi';
$string['reissuedtemplate_default'] = 'Sayın {studentname},

"{coursename}" kursundaki "{certname}" sertifikanızın yeni bir sürümü düzenlenmiştir.

Buradan indirebilirsiniz: {url}

Doğrulama kodu: {code}

Saygılarımızla';
$string['reissuedtemplate_desc'] = 'Sertifikanın yeni bir sürümü verildiğinde öğrenciye gönderilen mesaj. Yer tutucular: {studentname}, {coursename}, {certname}, {url}, {code}';
$string['reject'] = 'Reddet';
$string['rejected'] = 'reddedildi';
$string['rejectedtemplate'] = 'Red bildirimi (öğrenciye)';
$string['rejectedtemplate_desc'] = 'Talebi reddedildiğinde öğrenciye gönderilen mesaj.';
$string['reportanalytics'] = 'Sertifika Analizleri';
$string['reportmonthly'] = 'Aylık eğilim (son 12 ay)';
$string['reportpercourse'] = 'Kurs başına sertifikalar';
$string['reportrecent'] = 'Son sertifikalar (son 30 gün)';
$string['reporttotalactivities'] = 'Toplam etkinlikler';
$string['reporttotalissued'] = 'Toplam verilen';
$string['reporttotaltemplates'] = 'Toplam şablonlar';
$string['reportuniquerecipients'] = 'Benzersiz alıcılar';
$string['requestagain'] = 'Yeni talep gönder';
$string['requestapproved'] = 'Talep başarıyla onaylandı.';
$string['requestcertificate'] = 'Sertifika Talep Et';
$string['requestpending'] = 'Sertifika talebiniz onay bekliyor.';
$string['requestrejected'] = 'Sertifika talebiniz reddedildi.';
$string['requestrejectedmsg'] = 'Talep başarıyla reddedildi.';
$string['requestsubmitted'] = 'Sertifika talebiniz gönderildi.';
$string['requiredtime'] = 'Kursta gerekli süre (dakika)';
$string['requiredtime_desc'] = 'Öğrencinin sertifika alabilmesi için kursa giriş yapmış olması gereken minimum süre (dakika). Devre dışı bırakmak için 0 olarak ayarlayın.';
$string['requiredtimenotmet'] = 'Sertifika alabilmek için bu kursta en az {$a->required} dakika geçirmeniz gerekmektedir. Şu ana kadar yaklaşık {$a->spent} dakika geçirdiniz.';
$string['returncourse'] = 'Kursa dön düğmesi';
$string['returncourse_desc'] = 'Sertifika görüntüleme sayfasında "Kursa dön" düğmesini göster.';
$string['returntocourse'] = 'Kursa dön';
$string['reviewer'] = 'İnceleyen';
$string['revokecertificate'] = 'Sertifikayı iptal et';
$string['revoked'] = 'İptal edildi';
$string['revokeddate'] = 'İptal tarihi';
$string['revokedrenewal'] = 'Yenileme için iptal edildi (yeni sürüm verildi)';
$string['revokedtemplate'] = 'Sertifika iptal bildirimi';
$string['revokedtemplate_default'] = 'Sayın {studentname},

"{coursename}" kursundaki "{certname}" sertifikanız iptal edilmiştir.

Gerekçe: {reason}

Herhangi bir sorunuz varsa lütfen eğitmeninizle iletişime geçin.

Saygılarımızla';
$string['revokedtemplate_desc'] = 'Sertifikası iptal edildiğinde öğrenciye gönderilen mesaj. Yer tutucular: {studentname}, {coursename}, {certname}, {reason}';
$string['rotation'] = 'Döndürme';
$string['save'] = 'Kaydet';
$string['savechangestip'] = 'Değişiklikleri yalnızca bu etkinlik için kaydet';
$string['saved'] = 'Değişiklikler kaydedildi';
$string['saveerror'] = 'Değişiklikler kaydedilirken hata oluştu';
$string['savestatussaved'] = 'Kaydedildi';
$string['searchbyname'] = 'Ada göre ara...';
$string['selectelement'] = 'Özelliklerini düzenlemek için bir öğeye tıklayın.';
$string['selecttemplate'] = 'Şablon seçin';
$string['sharecertificate'] = 'Paylaş';
$string['shareemailbody'] = '"{$a->certname}" sertifikasını kazandığımı paylaşmak istedim.

Buradan doğrulayabilirsiniz: {$a->verifyurl}

- {$a->fullname}';
$string['shareemailsubject'] = 'Sertifikam: {$a}';
$string['sharetext'] = '"{$a}" sertifikasını kazandım!';
$string['showcasecourse'] = 'Kurs';
$string['showcasedownloadpdf'] = 'PDF İndir';
$string['showcaseissuedon'] = 'Verilme tarihi';
$string['showcaserecipient'] = 'Verilen kişi';
$string['showcaseshare'] = 'Bu sertifikayı paylaş';
$string['showcasetitle'] = 'Dijital Sertifika';
$string['showcaseverified'] = 'Doğrulanmış Sertifika';
$string['showposxy'] = 'X ve Y konumunu göster';
$string['showposxy_desc'] = 'Bir öğeyi düzenlerken X ve Y konumunu göstererek kullanıcının konumu doğru bir şekilde belirlemesini sağlar.';
$string['startfromscratch'] = 'Sıfırdan Başla';
$string['startmigration'] = 'Taşımayı başlat';
$string['status'] = 'Durum';
$string['statusapproved'] = 'Onaylandı';
$string['statusexpired'] = 'Süresi dolmuş';
$string['statuspending'] = 'Beklemede';
$string['statusrejected'] = 'Reddedildi';
$string['statusrevoked'] = 'İptal edildi';
$string['statusvalid'] = 'Geçerli';
$string['student'] = 'Öğrenci';
$string['styleclassic'] = 'Klasik';
$string['styledark'] = 'Koyu';
$string['styleelegant'] = 'Zarif';
$string['stylegradient'] = 'Gradyan';
$string['styleminimal'] = 'Minimalist';
$string['stylemodern'] = 'Modern';
$string['stylespecial'] = 'Özel';
$string['subplugintype_certstudioselem'] = 'Öğe türü';
$string['subplugintype_certstudioselem_plural'] = 'Öğe türleri';
$string['taskemailcertificate'] = 'Sertifikayı e-posta ile gönder';
$string['taskissuecertificate'] = 'Sertifika ver ve e-posta gönder';
$string['template'] = 'Şablon';
$string['templatedeleted'] = '"{$a}" şablonu silindi.';
$string['templatefile'] = 'Şablon dosyası (.json)';
$string['templatefilehelp'] = 'Başka bir Certificate Studio kurulumundan dışa aktarılmış bir .certstudio.json dosyası yükleyin.';
$string['templategallery'] = 'Şablon Galerisi';
$string['templateimported'] = '"{$a->name}" şablonu başarıyla içe aktarıldı ({$a->pages} sayfa, {$a->elements} öğe).';
$string['templateimportinvalid'] = 'Geçersiz şablon dosyası. Lütfen geçerli bir .certstudio.json dosyası yükleyin.';
$string['templateinuse'] = 'Bu şablon {$a} etkinlik tarafından kullanılmaktadır ve silinemez.';
$string['templatenameplaceholder'] = 'Şablon adı...';
$string['templates'] = 'Şablonlar';
$string['templatesharing'] = 'Şablon İçe/Dışa Aktarma';
$string['textcontent'] = 'Metin içeriği';
$string['toggleelementspanel'] = 'Öğeler panelini göster/gizle';
$string['togglegrid'] = 'Izgarayı aç/kapat';
$string['toggleguides'] = 'Kılavuzları aç/kapat';
$string['togglepropertiespanel'] = 'Özellikler panelini göster/gizle';
$string['typography'] = 'Tipografi';
$string['undo'] = 'Geri al';
$string['unknowncourse'] = 'Bilinmeyen kurs';
$string['unknownuser'] = 'Bilinmeyen kullanıcı';
$string['unlock'] = 'Kilidi aç';
$string['uploadbgimage'] = 'Yükle';
$string['uploadbgimagetip'] = 'Arka plan resmi yükle';
$string['usethisTemplate'] = 'Bu şablonu kullan';
$string['usethistemplate'] = 'Bu şablonu kullan';
$string['valid'] = 'Geçerli';
$string['verificationcode'] = 'Doğrulama kodu';
$string['verify'] = 'Doğrula';
$string['verifyallcertificates'] = 'Herkese açık doğrulamaya izin ver';
$string['verifyallcertificates_desc'] = 'Herhangi birinin giriş yapmadan sertifikaları doğrulamasına izin ver.';
$string['verifyanother'] = 'Başka bir sertifika doğrula';
$string['verifyany'] = 'Herkesin sertifika doğrulamasına izin ver';
$string['verifyany_desc'] = 'Sertifika doğrulama bağlantısına sahip herkesin (giriş yapmamış kullanıcılar dahil) sertifikayı doğrulamasına izin ver.';
$string['verifycertificate'] = 'Sertifika Doğrula';
$string['verifyintro'] = '{$a} üzerinde bir sertifikanın doğruluğunu kontrol etmek için doğrulama kodunu girin.';
$string['verifylink_desc'] = 'Bu bağlantı sizi sitedeki sertifikaları doğrulayabileceğiniz bir sayfaya yönlendirecektir.';
$string['verifynotfound'] = 'Bu doğrulama koduyla sertifika bulunamadı. Lütfen kontrol edip tekrar deneyin.';
$string['verifyurl'] = 'Özel doğrulama URL\'si';
$string['verifyurl_desc'] = 'QR Code doğrulama bağlantısı için özel URL. Varsayılan Moodle doğrulama sayfasını kullanmak için boş bırakın. Yer tutucular: {code}';
$string['version'] = 'Sürüm';
$string['viewonline'] = 'Çevrimiçi Görüntüle';
$string['width'] = 'Genişlik';
$string['zoomin'] = 'Yakınlaştır';
$string['zoomout'] = 'Uzaklaştır';
