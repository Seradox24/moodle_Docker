<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate Studio admin settings.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/certstudio/classes/admin_setting_apikey.php');

if ($ADMIN->fulltree) {
    // =====================================================================
    // General settings.
    // =====================================================================
    $settings->add(new admin_setting_heading(
        'mod_certstudio/generalhdr',
        get_string('generalsettings', 'mod_certstudio'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'mod_certstudio/verifyurl',
        get_string('verifyurl', 'mod_certstudio'),
        get_string('verifyurl_desc', 'mod_certstudio'),
        '',
        PARAM_URL
    ));

    $settings->add(new admin_setting_configselect(
        'mod_certstudio/codegenerationmethod',
        get_string('codegenerationmethod', 'mod_certstudio'),
        get_string('codegenerationmethod_desc', 'mod_certstudio'),
        0,
        [
            0 => get_string('codegenerationmethod_upperlowerdigits', 'mod_certstudio'),
            1 => get_string('codegenerationmethod_digitshyphens', 'mod_certstudio'),
        ]
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/returncourse',
        get_string('returncourse', 'mod_certstudio'),
        get_string('returncourse_desc', 'mod_certstudio'),
        0
    ));

    // Quick links.
    $migratepageurl = new moodle_url('/mod/certstudio/migrate.php');
    $settings->add(new admin_setting_description(
        'mod_certstudio/migratelink',
        get_string('migrationtool', 'mod_certstudio'),
        '<a href="' . $migratepageurl->out(false) . '" class="btn btn-sm btn-outline-warning">'
        . '<i class="fa fa-exchange"></i> ' . get_string('migrationtool', 'mod_certstudio') . '</a>'
        . '<br><span class="text-muted small">' . get_string('migrationwarning', 'mod_certstudio') . '</span>'
    ));

    $reporturl = new moodle_url('/mod/certstudio/report.php');
    $settings->add(new admin_setting_description(
        'mod_certstudio/reportlink',
        get_string('reportanalytics', 'mod_certstudio'),
        '<a href="' . $reporturl->out(false) . '" class="btn btn-sm btn-outline-success">'
        . '<i class="fa fa-bar-chart"></i> ' . get_string('reportanalytics', 'mod_certstudio') . '</a>'
    ));

    $templateshareurl = new moodle_url('/mod/certstudio/templateshare.php');
    $settings->add(new admin_setting_description(
        'mod_certstudio/templatesharelink',
        get_string('managetemplates', 'mod_certstudio'),
        '<a href="' . $templateshareurl->out(false) . '" class="btn btn-sm btn-info text-white">'
        . '<i class="fa fa-th-list"></i> ' . get_string('managetemplates', 'mod_certstudio') . '</a>'
        . '<br><span class="text-muted small">' . get_string('managetemplates_desc', 'mod_certstudio') . '</span>'
    ));

    $verifypageurl = new moodle_url('/mod/certstudio/showcase.php');
    $settings->add(new admin_setting_description(
        'mod_certstudio/verifylink',
        get_string('verifycertificate', 'mod_certstudio'),
        '<a href="' . $verifypageurl->out(false) . '" class="btn btn-sm btn-outline-primary">'
        . '<i class="fa fa-check-circle"></i> ' . get_string('verifycertificate', 'mod_certstudio') . '</a>'
        . '<br><span class="text-muted small">' . get_string('verifylink_desc', 'mod_certstudio') . '</span>'
    ));

    // =====================================================================
    // PDF settings.
    // =====================================================================
    $settings->add(new admin_setting_heading(
        'mod_certstudio/pdfhdr',
        get_string('pdfsettings', 'mod_certstudio'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'mod_certstudio/defaultfilename',
        get_string('defaultfilename', 'mod_certstudio'),
        get_string('defaultfilename_desc', 'mod_certstudio'),
        'Certificate_{coursename}_{studentname}',
        PARAM_TEXT
    ));

    // Protection flags as individual checkboxes.
    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/protection_print',
        get_string('protection_print', 'mod_certstudio'),
        get_string('protection_print_desc', 'mod_certstudio'),
        0
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/protection_modify',
        get_string('protection_modify', 'mod_certstudio'),
        get_string('protection_modify_desc', 'mod_certstudio'),
        0
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/protection_copy',
        get_string('protection_copy', 'mod_certstudio'),
        get_string('protection_copy_desc', 'mod_certstudio'),
        0
    ));

    // =====================================================================
    // Email notification settings.
    // =====================================================================
    $settings->add(new admin_setting_heading(
        'mod_certstudio/emailhdr',
        get_string('emailsettings', 'mod_certstudio'),
        ''
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/emailstudents',
        get_string('emailstudents', 'mod_certstudio'),
        get_string('emailstudents_desc', 'mod_certstudio'),
        0
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/emailteachers',
        get_string('emailteachers', 'mod_certstudio'),
        get_string('emailteachers_desc', 'mod_certstudio'),
        0
    ));

    $settings->add(new admin_setting_configtext(
        'mod_certstudio/emailothers',
        get_string('emailothers', 'mod_certstudio'),
        get_string('emailothers_desc', 'mod_certstudio'),
        '',
        PARAM_TEXT
    ));

    // =====================================================================
    // Default values for activity settings.
    // =====================================================================
    $settings->add(new admin_setting_heading(
        'mod_certstudio/defaultshdr',
        get_string('defaultvalues', 'mod_certstudio'),
        get_string('defaultvalues_desc', 'mod_certstudio')
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/verifyany',
        get_string('verifyany', 'mod_certstudio'),
        get_string('verifyany_desc', 'mod_certstudio'),
        0
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/autoissue',
        get_string('autoissue', 'mod_certstudio'),
        get_string('autoissue_desc', 'mod_certstudio'),
        0
    ));

    $settings->add(new admin_setting_configtext(
        'mod_certstudio/requiredtime',
        get_string('requiredtime', 'mod_certstudio'),
        get_string('requiredtime_desc', 'mod_certstudio'),
        '0',
        PARAM_INT
    ));

    // =====================================================================
    // Approval settings.
    // =====================================================================
    $settings->add(new admin_setting_heading(
        'mod_certstudio/approvalhdr',
        get_string('approvalsettings', 'mod_certstudio'),
        ''
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/approvalenabled',
        get_string('approvalenabled', 'mod_certstudio'),
        get_string('approvalenabled_desc', 'mod_certstudio'),
        0
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/approvalnotifyteacher',
        get_string('approvalnotifyteacher', 'mod_certstudio'),
        get_string('approvalnotifyteacher_desc', 'mod_certstudio'),
        1
    ));

    $settings->add(new admin_setting_configcheckbox(
        'mod_certstudio/approvalnotifystudent',
        get_string('approvalnotifystudent', 'mod_certstudio'),
        get_string('approvalnotifystudent_desc', 'mod_certstudio'),
        1
    ));

    // =====================================================================
    // Message templates.
    // =====================================================================
    $settings->add(new admin_setting_heading(
        'mod_certstudio/messagehdr',
        get_string('messagetemplates', 'mod_certstudio'),
        get_string('messagetemplates_desc', 'mod_certstudio')
    ));

    $settings->add(new admin_setting_configtextarea(
        'mod_certstudio/approvalrequesttemplate',
        get_string('approvalrequesttemplate', 'mod_certstudio'),
        get_string('approvalrequesttemplate_desc', 'mod_certstudio'),
        '{student} has requested a certificate for "{activity}".',
        PARAM_RAW,
        60,
        4
    ));

    $settings->add(new admin_setting_configtextarea(
        'mod_certstudio/approvedtemplate',
        get_string('approvedtemplate', 'mod_certstudio'),
        get_string('approvedtemplate_desc', 'mod_certstudio'),
        'Your certificate request for "{activity}" has been approved.',
        PARAM_RAW,
        60,
        4
    ));

    $settings->add(new admin_setting_configtextarea(
        'mod_certstudio/rejectedtemplate',
        get_string('rejectedtemplate', 'mod_certstudio'),
        get_string('rejectedtemplate_desc', 'mod_certstudio'),
        'Your certificate request for "{activity}" has been rejected.',
        PARAM_RAW,
        60,
        4
    ));

    $settings->add(new admin_setting_configtextarea(
        'mod_certstudio/issuedtemplate',
        get_string('issuedtemplate', 'mod_certstudio'),
        get_string('issuedtemplate_desc', 'mod_certstudio'),
        get_string('issuedtemplate_default', 'mod_certstudio'),
        PARAM_RAW,
        60,
        5
    ));

    $settings->add(new admin_setting_configtextarea(
        'mod_certstudio/revokedtemplate',
        get_string('revokedtemplate', 'mod_certstudio'),
        get_string('revokedtemplate_desc', 'mod_certstudio'),
        get_string('revokedtemplate_default', 'mod_certstudio'),
        PARAM_RAW,
        60,
        5
    ));

    $settings->add(new admin_setting_configtextarea(
        'mod_certstudio/reissuedtemplate',
        get_string('reissuedtemplate', 'mod_certstudio'),
        get_string('reissuedtemplate_desc', 'mod_certstudio'),
        get_string('reissuedtemplate_default', 'mod_certstudio'),
        PARAM_RAW,
        60,
        5
    ));

    $settings->add(new admin_setting_configtextarea(
        'mod_certstudio/emailcerttemplate',
        get_string('emailcerttemplate', 'mod_certstudio'),
        get_string('emailcerttemplate_desc', 'mod_certstudio'),
        get_string('emailcerttemplate_default', 'mod_certstudio'),
        PARAM_RAW,
        60,
        5
    ));

    // =====================================================================
    // AI Template Generator settings.
    // =====================================================================
    $settings->add(new admin_setting_heading(
        'mod_certstudio/aihdr',
        get_string('aisettings', 'mod_certstudio'),
        get_string('aisettings_desc', 'mod_certstudio')
    ));

    $settings->add(new admin_setting_configselect(
        'mod_certstudio/aiprovider',
        get_string('aiprovider', 'mod_certstudio'),
        get_string('aiprovider_desc', 'mod_certstudio'),
        'openai',
        [
            'openai' => 'OpenAI (GPT-4)',
            'anthropic' => 'Anthropic (Claude)',
        ]
    ));

    $settings->add(new mod_certstudio_admin_setting_apikey(
        'mod_certstudio/aiapikey',
        get_string('aiapikey', 'mod_certstudio'),
        get_string('aiapikey_desc', 'mod_certstudio'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'mod_certstudio/aimodel',
        get_string('aimodel', 'mod_certstudio'),
        get_string('aimodel_desc', 'mod_certstudio'),
        'gpt-4o-mini',
        PARAM_TEXT
    ));
}
