<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_certstudio;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/completionlib.php');

/**
 * Tests for the rules that decide when a certificate may be issued, and for the paths that apply them.
 *
 * @package    mod_certstudio
 * @category   test
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \mod_certstudio\certificate::can_issue
 */
class issue_rules_test extends \advanced_testcase {
    /**
     * Set up test fixtures.
     */
    public function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
    }

    /**
     * Helper to create a course with completion enabled, a certstudio activity and an enrolled student.
     *
     * @param array $settings Extra settings for the activity.
     * @return array [$course, $certstudio, $student]
     */
    private function create_activity(array $settings = []): array {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course(['enablecompletion' => 1]);
        $student = $generator->create_user();
        $generator->enrol_user($student->id, $course->id, 'student');

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $certstudio = $csg->create_instance(array_merge([
            'course' => $course->id,
            'templateid' => $csg->create_template(),
        ], $settings));

        return [$course, $certstudio, $student];
    }

    /**
     * Helper to enrol a user with the given role.
     *
     * @param \stdClass $course The course.
     * @param string $role The role shortname.
     * @return \stdClass The user.
     */
    private function enrol_user(\stdClass $course, string $role): \stdClass {
        $user = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($user->id, $course->id, $role);
        return $user;
    }

    /**
     * Helper to mark a course as completed by a user, which triggers the course_completed event.
     *
     * @param \stdClass $course The course.
     * @param \stdClass $user The user.
     */
    private function complete_course(\stdClass $course, \stdClass $user): void {
        $completion = new \completion_completion(['course' => $course->id, 'userid' => $user->id]);
        $completion->mark_complete();

        // Other plugins installed on the site observe course completion too; only our own observer must not fail.
        foreach ($this->getDebuggingMessages() as $debugging) {
            $this->assertStringNotContainsString('mod_certstudio', $debugging->message);
        }
        $this->resetDebugging();
    }

    /**
     * An enrolled student who meets every rule can be issued a certificate.
     */
    public function test_eligible_student(): void {
        [, $certstudio, $student] = $this->create_activity();

        $this->assertNull(certificate::can_issue($certstudio, $certstudio->cmid, $student->id));
    }

    /**
     * Users without an active enrolment are refused, including suspended students.
     */
    public function test_requires_active_enrolment(): void {
        [$course, $certstudio] = $this->create_activity();
        $generator = $this->getDataGenerator();
        $notenrolled = $generator->create_user();
        $suspended = $generator->create_user();
        $generator->enrol_user($suspended->id, $course->id, 'student', 'manual', 0, 0, ENROL_USER_SUSPENDED);

        $this->assertSame('notenrolled', certificate::can_issue($certstudio, $certstudio->cmid, $notenrolled->id));
        $this->assertSame('notenrolled', certificate::can_issue($certstudio, $certstudio->cmid, $suspended->id));
    }

    /**
     * A non-editing teacher can view the activity but cannot receive a certificate.
     */
    public function test_requires_receive_capability(): void {
        [$course, $certstudio] = $this->create_activity();
        $teacher = $this->enrol_user($course, 'teacher');

        $this->assertSame('nopermission', certificate::can_issue($certstudio, $certstudio->cmid, $teacher->id));
    }

    /**
     * A hidden activity is not available to students.
     */
    public function test_hidden_activity(): void {
        [, $certstudio, $student] = $this->create_activity(['visible' => 0]);

        $this->assertSame('notavailable', certificate::can_issue($certstudio, $certstudio->cmid, $student->id));
    }

    /**
     * An active certificate means nothing new is issued, and a revoked one blocks a new certificate.
     */
    public function test_existing_and_revoked_certificates(): void {
        $this->redirectMessages();
        $this->setAdminUser();
        [, $certstudio, $student] = $this->create_activity();

        $issueid = certificate::issue($certstudio->id, $student->id);
        $this->assertSame('alreadyissued', certificate::can_issue($certstudio, $certstudio->cmid, $student->id));

        certificate::revoke($issueid, 'Issued by mistake');
        $this->assertSame('revoked', certificate::can_issue($certstudio, $certstudio->cmid, $student->id));
    }

    /**
     * The site-wide required time in course must be spent.
     */
    public function test_required_time(): void {
        [, $certstudio, $student] = $this->create_activity();
        set_config('requiredtime', 10, 'mod_certstudio');

        $this->assertSame('requiredtime', certificate::can_issue($certstudio, $certstudio->cmid, $student->id));
    }

    /**
     * With the approval workflow, only an approved request allows a certificate, and approving issues it.
     *
     * @covers \mod_certstudio\approval::approve
     */
    public function test_approval_workflow(): void {
        $this->redirectMessages();
        [$course, $certstudio, $student] = $this->create_activity(['approvalenabled' => 1]);
        $teacher = $this->enrol_user($course, 'editingteacher');

        $this->assertSame('approval', certificate::can_issue($certstudio, $certstudio->cmid, $student->id));
        // The student may still ask for approval.
        $this->assertNull(certificate::can_issue($certstudio, $certstudio->cmid, $student->id, false));

        $requestid = approval::request($certstudio->id, $student->id);
        $this->assertSame('approval', certificate::can_issue($certstudio, $certstudio->cmid, $student->id));

        approval::approve($requestid, $teacher->id);
        $this->assertCount(1, certificate::get_issues_for_user($certstudio->id, $student->id));
        $this->assertSame('alreadyissued', certificate::can_issue($certstudio, $certstudio->cmid, $student->id));
    }

    /**
     * The web service used by the mobile app cannot bypass the approval workflow.
     *
     * @covers \mod_certstudio\external::issue_cert
     */
    public function test_web_service_requires_approval(): void {
        [, $certstudio, $student] = $this->create_activity(['approvalenabled' => 1]);
        $this->setUser($student);

        $this->expectException(\moodle_exception::class);
        $this->expectExceptionMessage(get_string('cannotissue_approval', 'mod_certstudio'));
        external::issue_cert($certstudio->cmid);
    }

    /**
     * The web service cannot issue a new certificate after the previous one was revoked.
     *
     * @covers \mod_certstudio\external::issue_cert
     */
    public function test_web_service_respects_revocation(): void {
        $this->redirectMessages();
        [, $certstudio, $student] = $this->create_activity();
        $this->setAdminUser();
        certificate::revoke(certificate::issue($certstudio->id, $student->id), 'Issued by mistake');
        $this->setUser($student);

        $this->expectException(\moodle_exception::class);
        $this->expectExceptionMessage(get_string('cannotissue_revoked', 'mod_certstudio'));
        external::issue_cert($certstudio->cmid);
    }

    /**
     * The web service issues a certificate to an eligible student and returns its code.
     *
     * @covers \mod_certstudio\external::issue_cert
     */
    public function test_web_service_issues_to_eligible_student(): void {
        [, $certstudio, $student] = $this->create_activity();
        $this->setUser($student);

        $result = external::issue_cert($certstudio->cmid);
        $result = \core_external\external_api::clean_returnvalue(external::issue_cert_returns(), $result);

        $issues = certificate::get_issues_for_user($certstudio->id, $student->id);
        $this->assertCount(1, $issues);
        $this->assertSame(reset($issues)->code, $result['code']);
    }

    /**
     * Course completion issues certificates when auto-issue is on, except for activities with approval.
     *
     * @covers \mod_certstudio\observer::course_completed
     */
    public function test_auto_issue_on_course_completion(): void {
        set_config('enablecompletion', 1);
        set_config('autoissue', 1, 'mod_certstudio');
        [$course, $certstudio, $student] = $this->create_activity();
        /** @var \mod_certstudio_generator $csg */
        $csg = $this->getDataGenerator()->get_plugin_generator('mod_certstudio');
        $withapproval = $csg->create_instance([
            'course' => $course->id,
            'templateid' => $csg->create_template(),
            'approvalenabled' => 1,
        ]);

        $this->complete_course($course, $student);

        $this->assertCount(1, certificate::get_issues_for_user($certstudio->id, $student->id));
        $this->assertCount(0, certificate::get_issues_for_user($withapproval->id, $student->id));
    }

    /**
     * Course completion issues nothing when auto-issue is off.
     *
     * @covers \mod_certstudio\observer::course_completed
     */
    public function test_no_auto_issue_when_disabled(): void {
        set_config('enablecompletion', 1);
        [$course, $certstudio, $student] = $this->create_activity();

        $this->complete_course($course, $student);

        $this->assertCount(0, certificate::get_issues_for_user($certstudio->id, $student->id));
    }

    /**
     * Turning on the email settings no longer issues certificates to anybody.
     */
    public function test_email_settings_do_not_issue_certificates(): void {
        global $DB;

        set_config('emailstudents', 1, 'mod_certstudio');
        set_config('emailteachers', 1, 'mod_certstudio');
        set_config('emailothers', 'registrar@example.com', 'mod_certstudio');
        [, $certstudio] = $this->create_activity();

        $this->assertFalse(class_exists('\mod_certstudio\task\issue_certificates_task'));
        $this->assertSame(0, $DB->count_records('certstudio_issues', ['certstudioid' => $certstudio->id]));
    }

    /**
     * The student is notified once when the certificate is issued, and teachers are emailed by the adhoc task.
     *
     * @covers \mod_certstudio\certificate::issue
     * @covers \mod_certstudio\task\email_certificate_task
     */
    public function test_student_notified_once_and_teacher_emailed(): void {
        global $DB;

        set_config('emailstudents', 1, 'mod_certstudio');
        set_config('emailteachers', 1, 'mod_certstudio');
        [$course, $certstudio, $student] = $this->create_activity();
        $teacher = $this->enrol_user($course, 'editingteacher');
        $messages = $this->redirectMessages();
        $emails = $this->redirectEmails();
        $this->setUser($student);

        $issueid = certificate::issue($certstudio->id, $student->id);
        $this->expectOutputRegex('/Sent certificate email to teacher ' . $teacher->id . '\./');
        $this->runAdhocTasks('\mod_certstudio\task\email_certificate_task');

        $this->assertSame(1, $messages->count());
        $this->assertEquals($student->id, $messages->get_messages()[0]->useridto);
        $this->assertSame(1, $emails->count());
        $this->assertSame($teacher->email, $emails->get_messages()[0]->to);
        $this->assertEquals(1, $DB->get_field('certstudio_issues', 'emailed', ['id' => $issueid]));
    }

    /**
     * A reissued certificate is marked as emailed once the student is notified about it.
     *
     * @covers \mod_certstudio\certificate::reissue
     */
    public function test_reissue_marks_emailed(): void {
        global $DB;

        $this->redirectMessages();
        $this->setAdminUser();
        [, $certstudio, $student] = $this->create_activity();

        $newid = certificate::reissue(certificate::issue($certstudio->id, $student->id));

        $this->assertEquals(1, $DB->get_field('certstudio_issues', 'emailed', ['id' => $newid]));
    }

    /**
     * No email goes out for a certificate revoked before the adhoc task ran.
     *
     * @covers \mod_certstudio\task\email_certificate_task
     */
    public function test_no_email_for_revoked_certificate(): void {
        set_config('emailteachers', 1, 'mod_certstudio');
        [$course, $certstudio, $student] = $this->create_activity();
        $this->enrol_user($course, 'editingteacher');
        $this->redirectMessages();
        $emails = $this->redirectEmails();
        $this->setAdminUser();

        $issueid = certificate::issue($certstudio->id, $student->id);
        certificate::revoke($issueid, 'Issued by mistake');
        $this->expectOutputRegex('/issue ' . $issueid . ' not found or no longer active/');
        $this->runAdhocTasks('\mod_certstudio\task\email_certificate_task');

        $this->assertSame(0, $emails->count());
    }
}
