<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_certstudio;

/**
 * Tests for the text that dynamic elements print on an issued certificate.
 *
 * @package    mod_certstudio
 * @category   test
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \mod_certstudio\certificate
 */
final class dynamic_elements_test extends \advanced_testcase {
    /** @var \stdClass The course. */
    private \stdClass $course;

    /** @var \stdClass The certstudio activity. */
    private \stdClass $certstudio;

    /** @var \stdClass The student. */
    private \stdClass $student;

    /** @var int The template page the elements go on. */
    private int $pageid;

    /**
     * Set up a course with a Certificate Studio activity and a student.
     */
    public function setUp(): void {
        global $DB;

        parent::setUp();
        $this->resetAfterTest(true);

        $generator = $this->getDataGenerator();
        $this->course = $generator->create_course([
            'startdate' => $this->athens('2026-03-02 09:00'),
            'enddate' => $this->athens('2026-06-30 18:00'),
        ]);
        $this->student = $generator->create_user(['timezone' => 'Europe/Athens']);
        $generator->enrol_user($this->student->id, $this->course->id, 'student');

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $templateid = $csg->create_template();
        $this->certstudio = $csg->create_instance(['course' => $this->course->id, 'templateid' => $templateid]);
        $this->pageid = (int) $DB->get_field('certstudio_pages', 'id', ['templateid' => $templateid], MUST_EXIST);
    }

    /**
     * Get a timestamp for a date and time in Athens.
     *
     * @param string $datetime Date and time, such as '2026-03-02 09:00'.
     * @return int Unix timestamp.
     */
    private function athens(string $datetime): int {
        return (new \DateTime($datetime, new \DateTimeZone('Europe/Athens')))->getTimestamp();
    }

    /**
     * Add an element to the activity's design.
     *
     * @param string $name Unique element name, to find it in the resolved data.
     * @param string $type Element type.
     * @param array $data Element settings.
     */
    private function add_element(string $name, string $type, array $data = []): void {
        global $DB;

        $DB->insert_record('certstudio_elements', (object) [
            'pageid' => $this->pageid,
            'name' => $name,
            'type' => $type,
            'data' => json_encode($data),
            'posx' => 10,
            'posy' => 10,
            'width' => 100,
            'height' => 10,
            'fontfamily' => 'Roboto',
            'fontsize' => 12,
            'fontweight' => 'normal',
            'fontstyle' => 'normal',
            'color' => '#000000',
            'alignment' => 'L',
            'opacity' => 1,
            'sequence' => 10,
            'timecreated' => time(),
            'timemodified' => time(),
        ]);
    }

    /**
     * Issue the certificate to the student at a given time.
     *
     * @param int $timecreated Issue time.
     * @return string The verification code.
     */
    private function issue_at(int $timecreated): string {
        global $DB;

        $issueid = certificate::issue($this->certstudio->id, $this->student->id, false);
        $issue = $DB->get_record('certstudio_issues', ['id' => $issueid], '*', MUST_EXIST);
        $DB->set_field('certstudio_issues', 'timecreated', $timecreated, ['id' => $issueid]);
        if (!empty($issue->expirydate)) {
            $expirydate = $timecreated + ($issue->expirydate - $issue->timecreated);
            $DB->set_field('certstudio_issues', 'expirydate', $expirydate, ['id' => $issueid]);
        }
        return $issue->code;
    }

    /**
     * Get the text resolved for each element when the certificate is downloaded.
     *
     * @param string $code The verification code, or '' for a certificate being issued now.
     * @return string[] Resolved text by element name.
     */
    private function resolve(string $code): array {
        $resolved = [];
        foreach (certificate::get_template_data($this->certstudio->id, $this->student->id, $code)->pages as $page) {
            foreach ($page->elements as $element) {
                $data = json_decode($element->data, true);
                if (is_array($data) && array_key_exists('resolvedtext', $data)) {
                    $resolved[$element->name] = $data['resolvedtext'];
                }
            }
        }
        return $resolved;
    }

    /**
     * Format a date as the certificate should, in the student's time zone.
     *
     * @param int $time Unix timestamp.
     * @param string $format Language config key of the format.
     * @return string The date.
     */
    private function date(int $time, string $format = 'strftimedate'): string {
        return userdate($time, get_string($format, 'langconfig'), 'Europe/Athens');
    }

    /**
     * Dates show when the certificate was issued, in the student's time zone and the chosen format,
     * whoever downloads it and whenever.
     */
    public function test_date_uses_issue_time_and_format(): void {
        global $USER;

        $this->add_element('default', 'date');
        $this->add_element('daydate', 'date', ['dateformat' => 'strftimedaydate']);
        $this->add_element('numeric', 'date', ['dateformat' => '%d/%m/%Y']);
        $this->add_element('oldeditor', 'date', ['dateformat' => 'F j, Y']);
        $this->add_element('customcert', 'date', ['dateformat' => '{"dateitem":"-1","dateformat":"strftimedatefullshort"}']);
        $this->add_element('certdate', 'certdate', ['city' => 'Θεσσαλονίκη']);

        // Just after midnight in Athens, still the previous day in São Paulo.
        $issued = $this->athens('2026-03-11 00:30');
        $code = $this->issue_at($issued);
        $this->setAdminUser();
        $USER->timezone = 'America/Sao_Paulo';

        $resolved = $this->resolve($code);
        $this->assertSame($this->date($issued), $resolved['default']);
        $this->assertStringContainsString('11', $resolved['default']);
        $this->assertSame($this->date($issued, 'strftimedaydate'), $resolved['daydate']);
        $this->assertSame('11/03/2026', $resolved['numeric']);
        $this->assertSame($this->date($issued), $resolved['oldeditor']);
        $this->assertSame($this->date($issued, 'strftimedatefullshort'), $resolved['customcert']);
        $this->assertSame('Θεσσαλονίκη, 11 Μαρτίου 2026', $resolved['certdate']);
    }

    /**
     * The date range shows the course start and end dates, or the start date alone without an end date.
     */
    public function test_date_range_shows_course_dates(): void {
        global $DB;

        $this->add_element('range', 'daterange', ['dateformat' => 'strftimedatefullshort']);
        $code = $this->issue_at(time());

        $this->assertSame('02/03/26 - 30/06/26', $this->resolve($code)['range']);

        $DB->set_field('course', 'enddate', 0, ['id' => $this->course->id]);
        $this->assertSame('02/03/26', $this->resolve($code)['range']);
    }

    /**
     * The expiry date is that of the issue, and empty for a certificate that does not expire.
     */
    public function test_expiry_date(): void {
        global $DB;

        $this->add_element('expiry', 'expiry');
        $this->assertSame('', $this->resolve('')['expiry']);

        $DB->set_field('certstudio', 'expirydays', 365, ['id' => $this->certstudio->id]);
        $issued = $this->athens('2026-03-11 12:00');
        $code = $this->issue_at($issued);
        $this->assertSame($this->date($issued + 365 * DAYSECS), $this->resolve($code)['expiry']);
    }

    /**
     * Grade and grade item name use the chosen grade item, and the course total by default or when the
     * grade item belongs to another course.
     */
    public function test_grade_item(): void {
        $generator = $this->getDataGenerator();
        $exam = new \grade_item($generator->create_grade_item([
            'courseid' => $this->course->id,
            'itemname' => 'Final exam',
        ]), false);
        $exam->update_final_grade($this->student->id, 85);
        $othercourse = $generator->create_course();
        $otheritem = $generator->create_grade_item(['courseid' => $othercourse->id, 'itemname' => 'Other']);

        $this->add_element('examname', 'gradeitemname', ['gradeitem' => 'gradeitem:' . $exam->id]);
        $this->add_element('examgrade', 'grade', ['gradeitem' => 'gradeitem:' . $exam->id]);
        $this->add_element('defaultname', 'gradeitemname');
        $this->add_element('othername', 'gradeitemname', ['gradeitem' => 'gradeitem:' . $otheritem->id]);
        $code = $this->issue_at(time());

        $resolved = $this->resolve($code);
        $this->assertSame('Final exam', $resolved['examname']);
        $this->assertSame(grade_format_gradevalue(85, $exam), $resolved['examgrade']);
        $this->assertSame(get_string('coursetotal', 'grades'), $resolved['defaultname']);
        $this->assertSame(get_string('coursetotal', 'grades'), $resolved['othername']);

        $options = array_column(certificate::get_grade_item_options($this->course->id), 'label', 'value');
        $this->assertSame('Final exam', $options['gradeitem:' . $exam->id]);
        $this->assertArrayNotHasKey('gradeitem:' . $otheritem->id, $options);
    }

    /**
     * The course field element prints standard fields, formatted course dates and custom fields that
     * everyone may see, and nothing else.
     */
    public function test_course_field(): void {
        global $DB;

        $DB->set_field('course', 'idnumber', 'CS-101', ['id' => $this->course->id]);
        /** @var \core_customfield_generator $cfgenerator */
        $cfgenerator = $this->getDataGenerator()->get_plugin_generator('core_customfield');
        $category = $cfgenerator->create_category(['component' => 'core_course', 'area' => 'course']);
        $hours = $cfgenerator->create_field([
            'categoryid' => $category->get('id'),
            'type' => 'text',
            'shortname' => 'hours',
            'configdata' => ['visibility' => \core_course\customfield\course_handler::VISIBLETOALL],
        ]);
        $secret = $cfgenerator->create_field([
            'categoryid' => $category->get('id'),
            'type' => 'text',
            'shortname' => 'secret',
            'configdata' => ['visibility' => \core_course\customfield\course_handler::NOTVISIBLE],
        ]);
        $cfgenerator->add_instance_data($hours, $this->course->id, '40');
        $cfgenerator->add_instance_data($secret, $this->course->id, 'hidden');

        $this->add_element('shortname', 'coursefield', ['fieldname' => 'shortname']);
        $this->add_element('startdate', 'coursefield', ['fieldname' => 'startdate']);
        $this->add_element('hours', 'coursefield', ['fieldname' => 'customfield_hours']);
        $this->add_element('secret', 'coursefield', ['fieldname' => 'customfield_secret']);
        $this->add_element('notallowed', 'coursefield', ['fieldname' => 'cacherev']);
        $this->add_element('migrated', 'coursefield', ['text' => '{idnumber}']);
        $code = $this->issue_at(time());

        $resolved = $this->resolve($code);
        $this->assertSame($this->course->shortname, $resolved['shortname']);
        $this->assertSame($this->date($this->course->startdate), $resolved['startdate']);
        $this->assertSame('40', $resolved['hours']);
        $this->assertSame('', $resolved['secret']);
        $this->assertSame('', $resolved['notallowed']);
        $this->assertSame('CS-101', $resolved['migrated']);

        $options = array_column(certificate::get_course_field_options(), 'value');
        $this->assertContains('customfield_hours', $options);
        $this->assertNotContains('customfield_secret', $options);
    }

    /**
     * User fields from designs migrated from Custom certificate by 1.0.0 are printed.
     */
    public function test_migrated_user_field(): void {
        $this->add_element('email', 'userfield', ['text' => '{email}']);
        $this->assertSame($this->student->email, $this->resolve($this->issue_at(time()))['email']);
    }

    /**
     * The migration stores the field of user field and course field elements where the editor expects it.
     */
    public function test_migration_converts_field_elements(): void {
        $method = new \ReflectionMethod(migration::class, 'convert_element_data');
        $migration = new migration();

        $userfield = json_decode($method->invoke($migration, (object) ['element' => 'userfield', 'data' => 'city']), true);
        $this->assertSame('city', $userfield['fieldname']);

        $coursefield = json_decode($method->invoke($migration, (object) ['element' => 'coursefield', 'data' => '']), true);
        $this->assertSame('fullname', $coursefield['fieldname']);
    }
}
