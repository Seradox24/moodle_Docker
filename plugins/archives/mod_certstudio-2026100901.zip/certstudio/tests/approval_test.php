<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_certstudio;

/**
 * Unit tests for the approval class.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \mod_certstudio\approval
 */
class approval_test extends \advanced_testcase {
    /**
     * Set up test fixtures.
     */
    public function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
    }

    /**
     * Helper to create a test activity with approval enabled.
     *
     * @return array [$course, $certstudio, $student, $teacher]
     */
    private function create_approval_activity(): array {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $student = $generator->create_user();
        $teacher = $generator->create_user();
        $generator->enrol_user($student->id, $course->id, 'student');
        $generator->enrol_user($teacher->id, $course->id, 'editingteacher');

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $templateid = $csg->create_template();

        $certstudio = $csg->create_instance([
            'course' => $course->id,
            'templateid' => $templateid,
            'approvalenabled' => 1,
            'approvalnotifyteacher' => 0,
            'approvalnotifystudent' => 0,
        ]);

        return [$course, $certstudio, $student, $teacher];
    }

    /**
     * Test creating an approval request.
     */
    public function test_request(): void {
        [$course, $certstudio, $student, $teacher] = $this->create_approval_activity();

        $requestid = approval::request($certstudio->id, $student->id);

        $this->assertGreaterThan(0, $requestid);

        $request = approval::get_request($requestid);
        $this->assertNotEmpty($request);
        $this->assertEquals(approval::STATUS_PENDING, (int) $request->status);
        $this->assertEquals($student->id, $request->userid);
    }

    /**
     * Test duplicate request returns existing ID.
     */
    public function test_duplicate_request_returns_existing(): void {
        [$course, $certstudio, $student, $teacher] = $this->create_approval_activity();

        $id1 = approval::request($certstudio->id, $student->id);
        $id2 = approval::request($certstudio->id, $student->id);

        $this->assertEquals($id1, $id2);
    }

    /**
     * Test approving a request.
     */
    public function test_approve(): void {
        [$course, $certstudio, $student, $teacher] = $this->create_approval_activity();

        $requestid = approval::request($certstudio->id, $student->id);
        $result = approval::approve($requestid, $teacher->id, 'Well done!');

        $this->assertTrue($result);

        $request = approval::get_request($requestid);
        $this->assertEquals(approval::STATUS_APPROVED, (int) $request->status);
        $this->assertEquals($teacher->id, $request->reviewerid);
        $this->assertEquals('Well done!', $request->reviewcomment);
    }

    /**
     * Test rejecting a request.
     */
    public function test_reject(): void {
        [$course, $certstudio, $student, $teacher] = $this->create_approval_activity();

        $requestid = approval::request($certstudio->id, $student->id);
        $result = approval::reject($requestid, $teacher->id, 'Not ready yet.');

        $this->assertTrue($result);

        $request = approval::get_request($requestid);
        $this->assertEquals(approval::STATUS_REJECTED, (int) $request->status);
        $this->assertEquals('Not ready yet.', $request->reviewcomment);
    }

    /**
     * Test approving already approved request throws exception.
     */
    public function test_approve_non_pending_throws(): void {
        [$course, $certstudio, $student, $teacher] = $this->create_approval_activity();

        $requestid = approval::request($certstudio->id, $student->id);
        approval::approve($requestid, $teacher->id);

        $this->expectException(\moodle_exception::class);
        approval::approve($requestid, $teacher->id);
    }

    /**
     * Test rejecting already rejected request throws exception.
     */
    public function test_reject_non_pending_throws(): void {
        [$course, $certstudio, $student, $teacher] = $this->create_approval_activity();

        $requestid = approval::request($certstudio->id, $student->id);
        approval::reject($requestid, $teacher->id);

        $this->expectException(\moodle_exception::class);
        approval::reject($requestid, $teacher->id);
    }

    /**
     * Test get_pending_requests.
     */
    public function test_get_pending_requests(): void {
        $generator = $this->getDataGenerator();
        [$course, $certstudio, $student1, $teacher] = $this->create_approval_activity();
        $student2 = $generator->create_user();
        $generator->enrol_user($student2->id, $course->id, 'student');

        approval::request($certstudio->id, $student1->id);
        approval::request($certstudio->id, $student2->id);

        $pending = approval::get_pending_requests($certstudio->id);
        $this->assertCount(2, $pending);
    }

    /**
     * Test get_user_request returns most recent.
     */
    public function test_get_user_request(): void {
        [$course, $certstudio, $student, $teacher] = $this->create_approval_activity();

        $this->assertFalse(approval::get_user_request($certstudio->id, $student->id));

        approval::request($certstudio->id, $student->id);
        $request = approval::get_user_request($certstudio->id, $student->id);

        $this->assertNotEmpty($request);
        $this->assertEquals(approval::STATUS_PENDING, (int) $request->status);
    }

    /**
     * Test approve with nonexistent request throws exception.
     */
    public function test_approve_nonexistent_throws(): void {
        $this->expectException(\moodle_exception::class);
        approval::approve(99999, 1);
    }

    /**
     * Test reject with nonexistent request throws exception.
     */
    public function test_reject_nonexistent_throws(): void {
        $this->expectException(\moodle_exception::class);
        approval::reject(99999, 1);
    }

    /**
     * Test approval constants.
     */
    public function test_status_constants(): void {
        $this->assertEquals(0, approval::STATUS_PENDING);
        $this->assertEquals(1, approval::STATUS_APPROVED);
        $this->assertEquals(2, approval::STATUS_REJECTED);
    }
}
