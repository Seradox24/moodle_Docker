<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_certstudio;

/**
 * Tests for the migration from mod_customcert.
 *
 * @package    mod_certstudio
 * @category   test
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \mod_certstudio\migration
 */
class migration_test extends \advanced_testcase {
    /**
     * Set up test fixtures.
     */
    public function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
        if (!\core_component::get_component_directory('mod_customcert')) {
            $this->markTestSkipped('mod_customcert is not installed.');
        }
    }

    /**
     * A migrated activity keeps the original's section, visibility, access restrictions and completion,
     * so it is not open to students the original was closed to.
     */
    public function test_migrated_activity_keeps_restrictions(): void {
        global $DB;

        $this->setAdminUser();
        $course = $this->getDataGenerator()->create_course(['numsections' => 3, 'enablecompletion' => 1]);
        $availability = json_encode(\core_availability\tree::get_root_json(
            [\availability_date\condition::get_json('>=', time() + DAYSECS)]
        ));
        $customcert = $this->getDataGenerator()->create_module('customcert', [
            'course' => $course->id,
            'section' => 2,
            'visible' => 0,
            'availability' => $availability,
            'completion' => COMPLETION_TRACKING_AUTOMATIC,
            'completionview' => 1,
        ]);

        (new migration())->run(true, true, false);

        $newid = $DB->get_field('certstudio', 'id', ['course' => $course->id, 'name' => '[Migrated] ' . $customcert->name]);
        $this->assertNotEmpty($newid);
        $oldcm = get_coursemodule_from_instance('customcert', $customcert->id, $course->id);
        $newcm = get_coursemodule_from_instance('certstudio', $newid, $course->id);

        $this->assertEquals($oldcm->section, $newcm->section);
        $this->assertEquals(0, $newcm->visible);
        $this->assertSame($availability, $newcm->availability);
        $this->assertEquals(COMPLETION_TRACKING_AUTOMATIC, $newcm->completion);
        $this->assertEquals(1, $newcm->completionview);

        // Placed right after the original activity.
        $sequence = explode(',', $DB->get_field('course_sections', 'sequence', ['id' => $oldcm->section]));
        $this->assertSame(array_search($oldcm->id, $sequence) + 1, array_search($newcm->id, $sequence));
    }
}
