<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_certstudio;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/gradelib.php');
require_once($CFG->dirroot . '/mod/certstudio/lib.php');

/**
 * Tests for access checks, data protection and template lifecycle.
 *
 * @package    mod_certstudio
 * @category   test
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \mod_certstudio\external
 */
class security_test extends \advanced_testcase {
    /**
     * Set up test fixtures.
     */
    public function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
    }

    /**
     * Helper to create a course with a certstudio activity, its editing teacher and a student.
     *
     * The activity gets a template of its own in its module context, as the gallery would give it.
     *
     * @return \stdClass With course, certstudio, context, teacher, student, pageid and elementid.
     */
    private function create_activity(): \stdClass {
        global $DB;

        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $teacher = $generator->create_user();
        $student = $generator->create_user(['institution' => 'Letstudy Academy']);
        $generator->enrol_user($teacher->id, $course->id, 'editingteacher');
        $generator->enrol_user($student->id, $course->id, 'student');

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $templateid = $csg->create_template();
        $certstudio = $csg->create_instance(['course' => $course->id, 'templateid' => $templateid]);
        $context = \context_module::instance($certstudio->cmid);
        $DB->set_field('certstudio_templates', 'contextid', $context->id, ['id' => $templateid]);

        $pageid = (int) $DB->get_field('certstudio_pages', 'id', ['templateid' => $templateid], MUST_EXIST);
        $elementid = (int) $DB->get_field('certstudio_elements', 'id', ['pageid' => $pageid], IGNORE_MULTIPLE);
        $certstudio->templateid = $templateid;

        return (object) compact('course', 'certstudio', 'context', 'teacher', 'student', 'pageid', 'elementid');
    }

    /**
     * Assert that a call is refused with the given error code.
     *
     * @param callable $call The call that must fail.
     * @param string $errorcode The expected moodle_exception error code.
     */
    private function assert_refused(callable $call, string $errorcode): void {
        try {
            $call();
            $this->fail("Expected the call to be refused with '{$errorcode}'.");
        } catch (\moodle_exception $e) {
            $this->assertSame($errorcode, $e->errorcode);
        }
    }

    /**
     * Element JSON for the web services.
     *
     * @param int $pageid The page.
     * @param array $extra Extra fields, e.g. the element id.
     * @return string
     */
    private function element_json(int $pageid, array $extra = []): string {
        return json_encode(array_merge([
            'pageid' => $pageid, 'name' => 'Hacked', 'type' => 'text', 'data' => ['text' => 'Hacked'],
            'posx' => 1, 'posy' => 1, 'width' => 10, 'height' => 10,
        ], $extra));
    }

    /**
     * A teacher cannot add, change or delete elements in another course's template.
     */
    public function test_element_services_require_own_template(): void {
        global $DB;

        $mine = $this->create_activity();
        $theirs = $this->create_activity();
        $before = $DB->get_record('certstudio_elements', ['id' => $theirs->elementid]);
        $this->setUser($mine->teacher);
        $cmid = $mine->certstudio->cmid;

        $this->assert_refused(fn() => external::save_element($cmid, $this->element_json($theirs->pageid)), 'invalidpagedata');
        $this->assert_refused(
            fn() => external::save_element($cmid, $this->element_json($mine->pageid, ['id' => $theirs->elementid])),
            'invalidpagedata'
        );
        $this->assert_refused(fn() => external::delete_element($cmid, $theirs->elementid), 'invalidpagedata');
        $foreignpage = json_encode(['id' => $theirs->pageid, 'width' => 1, 'height' => 1]);
        $this->assert_refused(fn() => external::save_page($cmid, $foreignpage), 'invalidpagedata');

        // A batch with one foreign element is refused as a whole, before anything is written.
        $batch = '[' . $this->element_json($mine->pageid, ['id' => $mine->elementid, 'name' => 'Changed']) . ','
            . $this->element_json($theirs->pageid, ['id' => $theirs->elementid]) . ']';
        $this->assert_refused(fn() => external::save_elements($cmid, $batch), 'invalidpagedata');

        $this->assertEquals($before, $DB->get_record('certstudio_elements', ['id' => $theirs->elementid]));
        $this->assertNotSame('Changed', $DB->get_field('certstudio_elements', 'name', ['id' => $mine->elementid]));
        $this->assertSame(0, $DB->count_records('certstudio_elements', ['name' => 'Hacked']));

        // The teacher's own template still works, and empty element data is stored as an object.
        $result = external::save_element($cmid, $this->element_json($mine->pageid, ['data' => []]));
        $this->assertSame('{}', $DB->get_field('certstudio_elements', 'data', ['id' => $result['id']]));
    }

    /**
     * use_template copies gallery templates, but not another course's private template.
     */
    public function test_use_template_source(): void {
        global $DB;

        $mine = $this->create_activity();
        $theirs = $this->create_activity();
        /** @var \mod_certstudio_generator $csg */
        $csg = $this->getDataGenerator()->get_plugin_generator('mod_certstudio');
        $gallerytemplate = $csg->create_template();
        $this->setUser($mine->teacher);

        $this->assert_refused(
            fn() => external::use_template($mine->certstudio->cmid, $theirs->certstudio->templateid),
            'templatenotfound'
        );
        $result = external::use_template($mine->certstudio->cmid, $gallerytemplate);
        $this->assertEquals($result['templateid'], $DB->get_field('certstudio', 'templateid', ['id' => $mine->certstudio->id]));
    }

    /**
     * Replacing a design deletes only the activity's own, unused template, never a shared or gallery one.
     *
     * @covers \mod_certstudio\template::delete_if_unused
     */
    public function test_replacing_template_keeps_shared_ones(): void {
        global $DB;

        $one = $this->create_activity();
        $two = $this->create_activity();
        $this->setUser($one->teacher);

        // Activity one's own template is deleted when it starts from scratch.
        external::create_blank($one->certstudio->cmid);
        $this->assertFalse($DB->record_exists('certstudio_templates', ['id' => $one->certstudio->templateid]));

        // A template another activity still uses survives.
        $DB->set_field('certstudio', 'templateid', $two->certstudio->templateid, ['id' => $one->certstudio->id]);
        external::create_blank($one->certstudio->cmid);
        $this->assertTrue($DB->record_exists('certstudio_templates', ['id' => $two->certstudio->templateid]));

        // So does a gallery template an activity was pointed at directly.
        $systemtemplate = template::create('Gallery', \context_system::instance()->id);
        $DB->set_field('certstudio', 'templateid', $systemtemplate, ['id' => $one->certstudio->id]);
        external::create_blank($one->certstudio->cmid);
        $this->assertTrue($DB->record_exists('certstudio_templates', ['id' => $systemtemplate]));
    }

    /**
     * The settings form never changes the template, and deleting an activity twice succeeds.
     */
    public function test_instance_update_and_delete(): void {
        global $DB;

        $one = $this->create_activity();
        $data = (object) ['instance' => $one->certstudio->id, 'name' => 'Renamed', 'templateid' => 999999,
            'intro' => '', 'introformat' => FORMAT_HTML];
        certstudio_update_instance($data);
        $stored = $DB->get_field('certstudio', 'templateid', ['id' => $one->certstudio->id]);
        $this->assertEquals($one->certstudio->templateid, $stored);

        $this->assertTrue(certstudio_delete_instance($one->certstudio->id));
        $this->assertFalse($DB->record_exists('certstudio_templates', ['id' => $one->certstudio->templateid]));
        $this->assertTrue(certstudio_delete_instance($one->certstudio->id));
    }

    /**
     * The user field element prints identity fields, never the password hash or other internals.
     *
     * @covers \mod_certstudio\certificate
     */
    public function test_user_field_allow_list(): void {
        global $DB;

        $one = $this->create_activity();
        $user = $DB->get_record('user', ['id' => $one->student->id]);
        $field = new \ReflectionMethod(certificate::class, 'get_user_field');
        $resolve = fn(string $name) => $field->invoke(null, $user, (object) ['data' => json_encode(['fieldname' => $name])]);

        foreach (['password', 'secret', 'lastip', 'auth', 'username'] as $hidden) {
            $this->assertSame('', $resolve($hidden), $hidden);
        }
        $this->assertSame('Letstudy Academy', $resolve('institution'));

        // Custom profile fields: only those teachers may already see.
        $generator = $this->getDataGenerator();
        $generator->create_custom_profile_field(['datatype' => 'text', 'shortname' => 'regno', 'name' => 'Reg no',
            'visible' => PROFILE_VISIBLE_ALL]);
        $generator->create_custom_profile_field(['datatype' => 'text', 'shortname' => 'nationalid', 'name' => 'National ID',
            'visible' => PROFILE_VISIBLE_NONE]);
        profile_save_custom_fields($user->id, ['regno' => 'R-42', 'nationalid' => 'AB123456']);
        $this->assertSame('R-42', $resolve('regno'));
        $this->assertSame('R-42', $resolve('profile_field_regno'));
        $this->assertSame('', $resolve('nationalid'));
    }

    /**
     * A grade hidden from the student is not printed on their certificate.
     *
     * @covers \mod_certstudio\certificate
     */
    public function test_hidden_grade_is_not_printed(): void {
        $one = $this->create_activity();
        $gradeitem = \grade_item::fetch_course_item($one->course->id);
        $gradeitem->update_final_grade($one->student->id, 80, 'test');
        $grade = new \ReflectionMethod(certificate::class, 'get_user_grade');

        $this->assertNotSame('', $grade->invoke(null, (int) $one->course->id, (int) $one->student->id));
        $gradeitem->set_hidden(1);
        $this->assertSame('', $grade->invoke(null, (int) $one->course->id, (int) $one->student->id));
    }

    /**
     * Server-side PDFs only use the plugin's own images.
     *
     * @covers \mod_certstudio\pdfgenerator
     */
    public function test_pdf_image_sources(): void {
        global $CFG;

        $resolve = new \ReflectionMethod(pdfgenerator::class, 'resolve_image_src');
        $this->assertStringEndsWith(
            '/mod/certstudio/pix/backgrounds/classic-gold.svg',
            $resolve->invoke(null, '/mod/certstudio/pix/backgrounds/classic-gold.svg')
        );
        $this->assertSame('', $resolve->invoke(null, '/mod/certstudio/../../config.php'));

        // Real files: a user's private image must be refused, the activity's own design image accepted.
        $one = $this->create_activity();
        $png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==');
        $fs = get_file_storage();
        $usercontext = \context_user::instance($one->student->id);
        $private = $fs->create_file_from_string(['contextid' => $usercontext->id, 'component' => 'user', 'filearea' => 'private',
            'itemid' => 0, 'filepath' => '/', 'filename' => 'secret.png'], $png);
        $design = $fs->create_file_from_string(['contextid' => $one->context->id, 'component' => 'mod_certstudio',
            'filearea' => 'elementimage', 'itemid' => $one->elementid, 'filepath' => '/', 'filename' => 'logo.png'], $png);
        $url = fn(\stored_file $f) => \moodle_url::make_pluginfile_url(
            $f->get_contextid(),
            $f->get_component(),
            $f->get_filearea(),
            $f->get_itemid(),
            $f->get_filepath(),
            $f->get_filename()
        )->out(false);

        $this->assertSame('', $resolve->invoke(null, $url($private)));
        $this->assertFileExists($resolve->invoke(null, $url($design)));
        $this->assertSame($png, file_get_contents($resolve->invoke(null, $url($design))));
    }

    /**
     * Reissuing from an older version leaves exactly one active certificate and a linear version chain.
     *
     * @covers \mod_certstudio\certificate::reissue
     */
    public function test_reissue_from_old_version(): void {
        global $DB;

        $this->redirectMessages();
        $this->setAdminUser();
        $one = $this->create_activity();
        $first = certificate::issue($one->certstudio->id, $one->student->id);
        $second = certificate::reissue($first);
        $third = certificate::reissue($first);

        $issues = $DB->get_records('certstudio_issues', ['certstudioid' => $one->certstudio->id], 'id ASC');
        $this->assertCount(1, array_filter($issues, fn($i) => (int) $i->status === certificate::STATUS_ACTIVE));
        $this->assertEquals([1, 2, 3], array_values(array_map(fn($i) => (int) $i->version, $issues)));
        $this->assertEquals($second, $issues[$third]->parentid);
    }

    /**
     * Course reset removes approval requests along with the certificates.
     */
    public function test_reset_removes_approval_requests(): void {
        global $DB;

        $this->redirectMessages();
        $one = $this->create_activity();
        approval::request($one->certstudio->id, $one->student->id);

        certstudio_reset_userdata((object) ['courseid' => $one->course->id, 'reset_certstudio' => 1]);

        $this->assertSame(0, $DB->count_records('certstudio_approval_requests', ['certstudioid' => $one->certstudio->id]));
    }

    /**
     * The page background colour is stored.
     */
    public function test_page_background_colour_is_saved(): void {
        global $DB;

        $one = $this->create_activity();
        $this->setUser($one->teacher);
        external::save_page($one->certstudio->cmid, json_encode([
            'id' => $one->pageid, 'width' => 297, 'height' => 210, 'bgcolor' => '#1a1a2e',
        ]));
        $this->assertSame('#1a1a2e', $DB->get_field('certstudio_pages', 'bgcolor', ['id' => $one->pageid]));
    }
}
