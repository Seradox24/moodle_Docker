<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * mod_certstudio data generator.
 *
 * @package    mod_certstudio
 * @copyright  2017 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Certificate Studio module data generator class.
 *
 * @package    mod_certstudio
 * @copyright  2017 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_certstudio_generator extends testing_module_generator {
    /**
     * Creates a certstudio activity instance.
     *
     * @param array|stdClass $record Data for the module.
     * @param array|null $options Options.
     * @return stdClass The created activity record.
     */
    public function create_instance($record = null, ?array $options = null) {
        $record = (object) (array) ($record ?? []);

        $defaults = [
            'name' => 'Test Certificate',
            'intro' => 'Test certificate intro',
            'introformat' => FORMAT_HTML,
            'templateid' => 0,
            'approvalenabled' => 0,
            'approvalnotifyteacher' => 0,
            'approvalnotifystudent' => 0,
            'protection' => '',
            'downloadfilename' => '',
        ];

        foreach ($defaults as $key => $value) {
            if (!isset($record->$key)) {
                $record->$key = $value;
            }
        }

        return parent::create_instance($record, (array) $options);
    }

    /**
     * Creates a template with a page and basic elements for testing.
     *
     * @return int The template ID.
     */
    public function create_template(): int {
        global $DB;

        $now = time();
        $systemctx = \context_system::instance();

        $template = new \stdClass();
        $template->name = 'Test Template';
        $template->contextid = $systemctx->id;
        $template->timecreated = $now;
        $template->timemodified = $now;
        $template->id = $DB->insert_record('certstudio_templates', $template);

        $page = new \stdClass();
        $page->templateid = $template->id;
        $page->width = 297;
        $page->height = 210;
        $page->leftmargin = 0;
        $page->rightmargin = 0;
        $page->bgcolor = '#ffffff';
        $page->sequence = 1;
        $page->timecreated = $now;
        $page->timemodified = $now;
        $page->id = $DB->insert_record('certstudio_pages', $page);

        // Add a student name element.
        $el = new \stdClass();
        $el->pageid = $page->id;
        $el->name = 'Student Name';
        $el->type = 'studentname';
        $el->data = '{}';
        $el->posx = 50;
        $el->posy = 80;
        $el->width = 200;
        $el->height = 20;
        $el->fontfamily = 'Roboto';
        $el->fontsize = 24;
        $el->fontweight = 'bold';
        $el->fontstyle = 'normal';
        $el->color = '#000000';
        $el->alignment = 'C';
        $el->opacity = 1;
        $el->rotation = 0;
        $el->locked = 0;
        $el->sequence = 1;
        $el->timecreated = $now;
        $el->timemodified = $now;
        $DB->insert_record('certstudio_elements', $el);

        return $template->id;
    }
}
