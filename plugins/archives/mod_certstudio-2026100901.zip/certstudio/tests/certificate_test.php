<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_certstudio;

/**
 * Unit tests for the certificate class.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \mod_certstudio\certificate
 */
class certificate_test extends \advanced_testcase {
    /**
     * Set up test fixtures.
     */
    public function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
    }

    /**
     * Helper to create a certstudio activity with a template.
     *
     * @return array [$course, $certstudio, $student]
     */
    private function create_test_activity(): array {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $student = $generator->create_user();
        $generator->enrol_user($student->id, $course->id, 'student');

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $templateid = $csg->create_template();

        $certstudio = $csg->create_instance([
            'course' => $course->id,
            'templateid' => $templateid,
        ]);

        return [$course, $certstudio, $student];
    }

    /**
     * Test issuing a certificate to a user.
     */
    public function test_issue_certificate(): void {
        global $DB;

        [$course, $certstudio, $student] = $this->create_test_activity();

        $issueid = certificate::issue($certstudio->id, $student->id);

        $this->assertGreaterThan(0, $issueid);

        $issue = $DB->get_record('certstudio_issues', ['id' => $issueid]);
        $this->assertNotEmpty($issue);
        $this->assertEquals($certstudio->id, $issue->certstudioid);
        $this->assertEquals($student->id, $issue->userid);
        $this->assertNotEmpty($issue->code);
        $this->assertNotEmpty($issue->templatedata);
    }

    /**
     * Test duplicate issue prevention returns existing ID.
     */
    public function test_issue_duplicate_returns_existing(): void {
        [$course, $certstudio, $student] = $this->create_test_activity();

        $id1 = certificate::issue($certstudio->id, $student->id);
        $id2 = certificate::issue($certstudio->id, $student->id);

        $this->assertEquals($id1, $id2);
    }

    /**
     * Test getting issues for a user.
     */
    public function test_get_issues_for_user(): void {
        [$course, $certstudio, $student] = $this->create_test_activity();

        $issues = certificate::get_issues_for_user($certstudio->id, $student->id);
        $this->assertEmpty($issues);

        certificate::issue($certstudio->id, $student->id);

        $issues = certificate::get_issues_for_user($certstudio->id, $student->id);
        $this->assertCount(1, $issues);
    }

    /**
     * Test getting a single issue by ID.
     */
    public function test_get_issue(): void {
        [$course, $certstudio, $student] = $this->create_test_activity();

        $issueid = certificate::issue($certstudio->id, $student->id);
        $issue = certificate::get_issue($issueid);

        $this->assertNotEmpty($issue);
        $this->assertEquals($student->id, $issue->userid);
    }

    /**
     * Test revoking a certificate.
     */
    public function test_revoke_certificate(): void {
        global $DB;

        [$course, $certstudio, $student] = $this->create_test_activity();

        $issueid = certificate::issue($certstudio->id, $student->id);
        $result = certificate::revoke($issueid);

        $this->assertTrue($result);
        // Revocation is soft: the record stays, marked as revoked.
        $this->assertEquals(certificate::STATUS_REVOKED, $DB->get_field('certstudio_issues', 'status', ['id' => $issueid]));
    }

    /**
     * Test revoking non-existent issue throws exception.
     */
    public function test_revoke_nonexistent_throws(): void {
        $this->expectException(\moodle_exception::class);
        certificate::revoke(99999);
    }

    /**
     * Test revoking also cleans up approval requests.
     */
    public function test_revoke_cleans_approval_requests(): void {
        global $DB;

        [$course, $certstudio, $student] = $this->create_test_activity();

        // Create an approval request manually.
        $req = new \stdClass();
        $req->certstudioid = $certstudio->id;
        $req->userid = $student->id;
        $req->status = approval::STATUS_APPROVED;
        $req->timecreated = time();
        $req->timemodified = time();
        $DB->insert_record('certstudio_approval_requests', $req);

        $issueid = certificate::issue($certstudio->id, $student->id);
        certificate::revoke($issueid);

        $remaining = $DB->count_records('certstudio_approval_requests', [
            'certstudioid' => $certstudio->id,
            'userid' => $student->id,
        ]);
        $this->assertEquals(0, $remaining);
    }

    /**
     * Test get_all_issues returns all issues for an activity.
     */
    public function test_get_all_issues(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $student1 = $generator->create_user();
        $student2 = $generator->create_user();
        $generator->enrol_user($student1->id, $course->id, 'student');
        $generator->enrol_user($student2->id, $course->id, 'student');

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $templateid = $csg->create_template();
        $certstudio = $csg->create_instance([
            'course' => $course->id,
            'templateid' => $templateid,
        ]);

        certificate::issue($certstudio->id, $student1->id);
        certificate::issue($certstudio->id, $student2->id);

        $issues = certificate::get_all_issues($certstudio->id);
        $this->assertCount(2, $issues);
    }

    /**
     * Test verification code uniqueness.
     */
    public function test_verification_codes_unique(): void {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $templateid = $csg->create_template();
        $certstudio = $csg->create_instance([
            'course' => $course->id,
            'templateid' => $templateid,
        ]);

        $codes = [];
        for ($i = 0; $i < 10; $i++) {
            $user = $generator->create_user();
            $generator->enrol_user($user->id, $course->id, 'student');
            $issueid = certificate::issue($certstudio->id, $user->id);
            $issue = certificate::get_issue($issueid);
            $codes[] = $issue->code;
        }

        // All codes should be unique.
        $this->assertCount(10, array_unique($codes));
    }

    /**
     * Test get_template_data resolves student name.
     */
    public function test_get_template_data_resolves_placeholders(): void {
        [$course, $certstudio, $student] = $this->create_test_activity();

        $data = certificate::get_template_data($certstudio->id, $student->id, 'TEST-CODE');

        $this->assertNotEmpty($data->pages);
        $this->assertNotEmpty($data->pages[0]->elements);

        // Find the studentname element and check it has resolvedtext.
        $found = false;
        foreach ($data->pages[0]->elements as $el) {
            if ($el->type === 'studentname') {
                $eldata = json_decode($el->data, true);
                $this->assertEquals(fullname($student), $eldata['resolvedtext']);
                $found = true;
            }
        }
        $this->assertTrue($found, 'studentname element should have resolvedtext');
    }
}
