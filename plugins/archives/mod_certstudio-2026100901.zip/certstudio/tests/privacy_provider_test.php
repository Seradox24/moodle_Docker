<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_certstudio;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use core_privacy\tests\provider_testcase;
use mod_certstudio\privacy\provider;

/**
 * Unit tests for the privacy provider.
 *
 * @package    mod_certstudio
 * @copyright  2018 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @covers     \mod_certstudio\privacy\provider
 */
class privacy_provider_test extends provider_testcase {
    /**
     * Set up test fixtures.
     */
    public function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);
    }

    /**
     * Helper: create activity, student, issue.
     *
     * @return array [$course, $certstudio, $student, $cm, $context]
     */
    private function create_test_data(): array {
        $generator = $this->getDataGenerator();
        $course = $generator->create_course();
        $student = $generator->create_user();
        $generator->enrol_user($student->id, $course->id, 'student');

        /** @var \mod_certstudio_generator $csg */
        $csg = $generator->get_plugin_generator('mod_certstudio');
        $templateid = $csg->create_template();
        $certstudio = $csg->create_instance([
            'course' => $course->id,
            'templateid' => $templateid,
        ]);

        $cm = get_coursemodule_from_instance('certstudio', $certstudio->id);
        $context = \context_module::instance($cm->id);

        return [$course, $certstudio, $student, $cm, $context];
    }

    /**
     * Test metadata collection.
     */
    public function test_get_metadata(): void {
        $collection = new collection('mod_certstudio');
        $result = provider::get_metadata($collection);
        $this->assertNotEmpty($result);

        $items = $result->get_collection();
        $this->assertGreaterThanOrEqual(2, count($items));
    }

    /**
     * Test get_contexts_for_userid with issued certificate.
     */
    public function test_get_contexts_for_userid(): void {
        global $DB;

        [$course, $certstudio, $student, $cm, $context] = $this->create_test_data();

        // No context before issue.
        $contextlist = provider::get_contexts_for_userid($student->id);
        $this->assertEmpty($contextlist->get_contextids());

        // Insert issue record directly to avoid event side effects.
        $issue = new \stdClass();
        $issue->certstudioid = $certstudio->id;
        $issue->userid = $student->id;
        $issue->code = 'TEST-' . random_string(8);
        $issue->templatedata = '{}';
        $issue->timecreated = time();
        $DB->insert_record('certstudio_issues', $issue);

        $contextlist = provider::get_contexts_for_userid($student->id);
        $contextids = $contextlist->get_contextids();
        $this->assertNotEmpty($contextids, 'Context list should not be empty after inserting issue');
        $this->assertContains((int) $context->id, array_map('intval', $contextids));
    }

    /**
     * Test get_contexts_for_userid with approval request.
     */
    public function test_get_contexts_for_userid_approval(): void {
        global $DB;

        [$course, $certstudio, $student, $cm, $context] = $this->create_test_data();

        // Create approval request directly (notifications disabled).
        $req = new \stdClass();
        $req->certstudioid = $certstudio->id;
        $req->userid = $student->id;
        $req->status = 0;
        $req->timecreated = time();
        $req->timemodified = time();
        $DB->insert_record('certstudio_approval_requests', $req);

        $contextlist = provider::get_contexts_for_userid($student->id);
        $contextids = $contextlist->get_contextids();
        $this->assertNotEmpty($contextids, 'Context list should not be empty after inserting approval request');
        $this->assertContains((int) $context->id, array_map('intval', $contextids));
    }

    /**
     * Test get_users_in_context.
     */
    public function test_get_users_in_context(): void {
        global $DB;

        [$course, $certstudio, $student, $cm, $context] = $this->create_test_data();

        // Insert issue record directly.
        $issue = new \stdClass();
        $issue->certstudioid = $certstudio->id;
        $issue->userid = $student->id;
        $issue->code = 'TEST-' . random_string(8);
        $issue->templatedata = '{}';
        $issue->timecreated = time();
        $DB->insert_record('certstudio_issues', $issue);

        $userlist = new userlist($context, 'mod_certstudio');
        provider::get_users_in_context($userlist);

        $this->assertContains((int) $student->id, array_map('intval', $userlist->get_userids()));
    }

    /**
     * Test export_user_data.
     */
    public function test_export_user_data(): void {
        [$course, $certstudio, $student, $cm, $context] = $this->create_test_data();

        certificate::issue($certstudio->id, $student->id);

        $contextlist = new approved_contextlist($student, 'mod_certstudio', [$context->id]);
        provider::export_user_data($contextlist);

        $writer = writer::with_context($context);
        $data = $writer->get_data([get_string('privacy:path:issues', 'mod_certstudio')]);
        $this->assertNotEmpty($data);
        $this->assertEquals($student->id, $data->userid);
    }

    /**
     * Test delete_data_for_all_users_in_context.
     */
    public function test_delete_data_for_all_users_in_context(): void {
        global $DB;

        [$course, $certstudio, $student, $cm, $context] = $this->create_test_data();

        certificate::issue($certstudio->id, $student->id);
        $this->assertTrue($DB->record_exists('certstudio_issues', ['certstudioid' => $certstudio->id]));

        provider::delete_data_for_all_users_in_context($context);

        $this->assertFalse($DB->record_exists('certstudio_issues', ['certstudioid' => $certstudio->id]));
    }

    /**
     * Test delete_data_for_user.
     */
    public function test_delete_data_for_user(): void {
        global $DB;

        [$course, $certstudio, $student, $cm, $context] = $this->create_test_data();

        certificate::issue($certstudio->id, $student->id);

        $contextlist = new approved_contextlist($student, 'mod_certstudio', [$context->id]);
        provider::delete_data_for_user($contextlist);

        $this->assertFalse($DB->record_exists('certstudio_issues', [
            'certstudioid' => $certstudio->id,
            'userid' => $student->id,
        ]));
    }

    /**
     * Test delete_data_for_users.
     */
    public function test_delete_data_for_users(): void {
        global $DB;

        [$course, $certstudio, $student, $cm, $context] = $this->create_test_data();

        certificate::issue($certstudio->id, $student->id);

        $userlist = new approved_userlist($context, 'mod_certstudio', [$student->id]);
        provider::delete_data_for_users($userlist);

        $this->assertFalse($DB->record_exists('certstudio_issues', [
            'certstudioid' => $certstudio->id,
            'userid' => $student->id,
        ]));
    }
}
