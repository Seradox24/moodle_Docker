<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Post-install script for mod_certstudio.
 *
 * Creates 40 background-only templates using SVG backgrounds.
 * Users add their own text elements after selecting a template.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Create default background-only templates on install.
 *
 * @return bool
 */
function xmldb_certstudio_install() {
    global $CFG, $DB;

    require_once($CFG->dirroot . '/mod/certstudio/classes/svg_backgrounds.php');

    $now = time();
    $systemctx = \context_system::instance();
    $pw = 297;
    $ph = 210;

    // Generate all SVG background files.
    $backgrounds = \mod_certstudio\svg_backgrounds::generate_all();

    foreach ($backgrounds as $bg) {
        $bgcolor = (strpos($bg['tags'], 'dark') !== false) ? '#1a1a2e' : '#ffffff';

        $t = new \stdClass();
        $t->name = $bg['name'];
        $t->contextid = $systemctx->id;
        $t->tags = $bg['tags'];
        $t->timecreated = $now;
        $t->timemodified = $now;
        $t->id = $DB->insert_record('certstudio_templates', $t);

        $p = new \stdClass();
        $p->templateid = $t->id;
        $p->width = $pw;
        $p->height = $ph;
        $p->leftmargin = 0;
        $p->rightmargin = 0;
        $p->bgcolor = $bgcolor;
        $p->sequence = 1;
        $p->timecreated = $now;
        $p->timemodified = $now;
        $p->id = $DB->insert_record('certstudio_pages', $p);

        $bgel = new \stdClass();
        $bgel->pageid = $p->id;
        $bgel->name = 'Background';
        $bgel->type = 'bgimage';
        $bgel->data = json_encode(['src' => '/mod/certstudio/pix/backgrounds/' . $bg['filename'], 'sizemode' => 'stretch']);
        $bgel->posx = 0;
        $bgel->posy = 0;
        $bgel->width = $pw;
        $bgel->height = $ph;
        $bgel->fontfamily = 'Roboto';
        $bgel->fontsize = 12;
        $bgel->fontweight = 'normal';
        $bgel->fontstyle = 'normal';
        $bgel->color = '#000000';
        $bgel->alignment = 'C';
        $bgel->opacity = 1;
        $bgel->rotation = 0;
        $bgel->locked = 1;
        $bgel->sequence = 0;
        $bgel->timecreated = $now;
        $bgel->timemodified = $now;
        $DB->insert_record('certstudio_elements', $bgel);
    }

    return true;
}
