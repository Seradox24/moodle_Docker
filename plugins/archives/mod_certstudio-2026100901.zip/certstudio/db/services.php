<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Web services definition for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'mod_certstudio_save_element' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'save_element',
        'description' => 'Save or update a single certificate element',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_delete_element' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'delete_element',
        'description' => 'Delete a certificate element',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_save_elements' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'save_elements',
        'description' => 'Save or update multiple certificate elements in batch',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_save_page' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'save_page',
        'description' => 'Save page settings for a certificate template',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_use_template' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'use_template',
        'description' => 'Duplicate a gallery template for use in an activity',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_create_blank' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'create_blank',
        'description' => 'Create a blank certificate template',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_rename_template' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'rename_template',
        'description' => 'Rename a certificate template',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_publish_to_gallery' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'publish_to_gallery',
        'description' => 'Publish a template copy to the site-wide gallery',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_delete_issue' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'delete_issue',
        'description' => 'Delete an issued certificate',
        'type'        => 'write',
        'ajax'        => true,
        'services'    => [MOODLE_OFFICIAL_MOBILE_SERVICE],
    ],
    'mod_certstudio_revoke_issue' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'revoke_issue',
        'description' => 'Revoke an issued certificate',
        'type'        => 'write',
        'ajax'        => true,
    ],
    'mod_certstudio_issue_cert' => [
        'classname'   => 'mod_certstudio\external',
        'methodname'  => 'issue_cert',
        'description' => 'Issue a certificate for the current user',
        'type'        => 'write',
        'ajax'        => true,
        'services'    => [MOODLE_OFFICIAL_MOBILE_SERVICE],
    ],
    'mod_certstudio_list_issues' => [
        'classname'    => 'mod_certstudio\external',
        'methodname'   => 'list_issues',
        'description'  => 'List issued certificates',
        'capabilities' => 'mod/certstudio:viewallcertificates',
        'type'         => 'read',
        'ajax'         => true,
    ],
];
