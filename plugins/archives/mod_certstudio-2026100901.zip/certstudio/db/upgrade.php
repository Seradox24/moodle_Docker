<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2016 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Execute mod_certstudio upgrade from the given old version.
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_certstudio_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2025041401) {
        $table = new xmldb_table('certstudio');
        $field = new xmldb_field(
            'downloadfilename',
            XMLDB_TYPE_CHAR,
            '255',
            null,
            null,
            null,
            null,
            'protection'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_mod_savepoint(true, 2025041401, 'certstudio');
    }

    if ($oldversion < 2025041403) {
        // Add expirydays to certstudio activity table.
        $table = new xmldb_table('certstudio');
        $field = new xmldb_field(
            'expirydays',
            XMLDB_TYPE_INTEGER,
            '10',
            null,
            XMLDB_NOTNULL,
            null,
            '0',
            'downloadfilename'
        );
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add expirydate to certstudio_issues table.
        $table = new xmldb_table('certstudio_issues');
        $field = new xmldb_field(
            'expirydate',
            XMLDB_TYPE_INTEGER,
            '10',
            null,
            null,
            null,
            null,
            'timecreated'
        );
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_mod_savepoint(true, 2025041403, 'certstudio');
    }

    if ($oldversion < 2025041404) {
        // Add language field to certstudio activity table.
        $table = new xmldb_table('certstudio');
        $field = new xmldb_field(
            'language',
            XMLDB_TYPE_CHAR,
            '20',
            null,
            null,
            null,
            null,
            'expirydays'
        );
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_mod_savepoint(true, 2025041404, 'certstudio');
    }

    if ($oldversion < 2025041405) {
        $table = new xmldb_table('certstudio_issues');

        // Status: 0=active, 1=revoked.
        $field = new xmldb_field('status', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'expirydate');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('revokedby', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'status');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('revokedat', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'revokedby');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('revokereason', XMLDB_TYPE_TEXT, null, null, null, null, null, 'revokedat');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('version', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '1', 'revokereason');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('parentid', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'version');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('emailed', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'parentid');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add status index.
        $index = new xmldb_index('status', XMLDB_INDEX_NOTUNIQUE, ['status']);
        if (!$dbman->index_exists($table, $index)) {
            $dbman->add_index($table, $index);
        }

        upgrade_mod_savepoint(true, 2025041405, 'certstudio');
    }

    if ($oldversion < 2025041409) {
        // Replace old built-in templates with 10 new templates that have background images.
        $systemctx = \context_system::instance();
        $now = time();
        $pw = 297;
        $ph = 210;

        // Delete old system-level (built-in) templates not used by any activity.
        $systemtemplates = $DB->get_records('certstudio_templates', ['contextid' => $systemctx->id]);
        foreach ($systemtemplates as $tmpl) {
            // Check if any activity uses this template.
            $inuse = $DB->record_exists('certstudio', ['templateid' => $tmpl->id]);
            if (!$inuse) {
                // Delete elements, pages, then template.
                $pages = $DB->get_records('certstudio_pages', ['templateid' => $tmpl->id]);
                foreach ($pages as $page) {
                    $DB->delete_records('certstudio_elements', ['pageid' => $page->id]);
                }
                $DB->delete_records('certstudio_pages', ['templateid' => $tmpl->id]);
                $DB->delete_records('certstudio_templates', ['id' => $tmpl->id]);
            }
        }

        // Helper: create template + page with bgimage, return page ID.
        $makepage = function ($name, $bgsvg = '', $bgcolor = '#ffffff') use ($DB, $now, $systemctx, $pw, $ph) {
            $t = new \stdClass();
            $t->name = $name;
            $t->contextid = $systemctx->id;
            $t->timecreated = $now;
            $t->timemodified = $now;
            $t->id = $DB->insert_record('certstudio_templates', $t);
            $p = new \stdClass();
            $p->templateid = $t->id;
            $p->width = $pw;
            $p->height = $ph;
            $p->leftmargin = 0;
            $p->rightmargin = 0;
            $p->bgcolor = $bgcolor;
            $p->sequence = 1;
            $p->timecreated = $now;
            $p->timemodified = $now;
            $p->id = $DB->insert_record('certstudio_pages', $p);

            // Add background image element if provided.
            if (!empty($bgsvg)) {
                $bgel = new \stdClass();
                $bgel->pageid = $p->id;
                $bgel->name = 'Background';
                $bgel->type = 'bgimage';
                $bgel->data = json_encode(['src' => '/mod/certstudio/pix/backgrounds/' . $bgsvg, 'sizemode' => 'stretch']);
                $bgel->posx = 0;
                $bgel->posy = 0;
                $bgel->width = $pw;
                $bgel->height = $ph;
                $bgel->fontfamily = 'Roboto';
                $bgel->fontsize = 12;
                $bgel->fontweight = 'normal';
                $bgel->fontstyle = 'normal';
                $bgel->color = '#000000';
                $bgel->alignment = 'C';
                $bgel->opacity = 1;
                $bgel->rotation = 0;
                $bgel->locked = 1;
                $bgel->sequence = 0;
                $bgel->timecreated = $now;
                $bgel->timemodified = $now;
                $DB->insert_record('certstudio_elements', $bgel);
            }

            return $p->id;
        };

        // Helper: add element.
        $addel = function (
            $pageid,
            $seq,
            $name,
            $type,
            $x,
            $y,
            $w,
            $h,
            $font,
            $size,
            $weight,
            $style,
            $color,
            $align,
            $data = [],
            $opacity = 1
        ) use (
            $DB,
            $now
) {
            $el = new \stdClass();
            $el->pageid = $pageid;
            $el->name = $name;
            $el->type = $type;
            $el->data = json_encode($data);
            $el->posx = $x;
            $el->posy = $y;
            $el->width = $w;
            $el->height = $h;
            $el->fontfamily = $font;
            $el->fontsize = $size;
            $el->fontweight = $weight;
            $el->fontstyle = $style;
            $el->color = $color;
            $el->alignment = $align;
            $el->opacity = $opacity;
            $el->rotation = 0;
            $el->locked = 0;
            $el->sequence = $seq;
            $el->timecreated = $now;
            $el->timemodified = $now;
            $DB->insert_record('certstudio_elements', $el);
        };

        $cx = function ($ew) use ($pw) {
            return round(($pw - $ew) / 2, 1);
        };

        // 1. GOLDEN LUXURY.
        $pid = $makepage('Golden Luxury', 'golden-luxury.svg');
        $addel(
            $pid,
            1,
            'Ornamental Header',
            'text',
            $cx(200),
            46,
            200,
            6,
            'Montserrat',
            10,
            'normal',
            'normal',
            '#8b7355',
            'C',
            ['text' => 'PROUDLY PRESENTED TO'],
            0.7
        );
        $addel(
            $pid,
            2,
            'Title',
            'text',
            $cx(220),
            55,
            220,
            22,
            'Playfair Display',
            38,
            'bold',
            'normal',
            '#5c4033',
            'C',
            ['text' => 'Certificate of Achievement']
        );
        $addel(
            $pid,
            3,
            'Subtitle',
            'text',
            $cx(200),
            80,
            200,
            7,
            'Montserrat',
            12,
            'normal',
            'italic',
            '#8b7355',
            'C',
            ['text' => 'This is to certify that']
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            $cx(230),
            92,
            230,
            18,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#3e2723',
            'C'
        );
        $addel(
            $pid,
            5,
            'Completion',
            'text',
            $cx(200),
            115,
            200,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#666666',
            'C',
            ['text' => 'has successfully completed the course']
        );
        $addel(
            $pid,
            6,
            'Course Name',
            'coursename',
            $cx(230),
            126,
            230,
            14,
            'Playfair Display',
            22,
            'bold',
            'normal',
            '#5c4033',
            'C'
        );
        $addel(
            $pid,
            7,
            'Date Label',
            'text',
            30,
            150,
            80,
            6,
            'Lato',
            9,
            'normal',
            'normal',
            '#999999',
            'C',
            ['text' => 'Awarded on']
        );
        $addel(
            $pid,
            8,
            'Date',
            'certdate',
            30,
            158,
            80,
            8,
            'Lato',
            12,
            'normal',
            'normal',
            '#555555',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            9,
            'Instructor Label',
            'text',
            187,
            150,
            80,
            6,
            'Lato',
            9,
            'normal',
            'normal',
            '#999999',
            'C',
            ['text' => 'Instructor']
        );
        $addel(
            $pid,
            10,
            'Teacher',
            'teachername',
            187,
            158,
            80,
            8,
            'Lato',
            12,
            'normal',
            'normal',
            '#555555',
            'C'
        );
        $addel(
            $pid,
            11,
            'Code',
            'code',
            $cx(80),
            178,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#bcaaa4',
            'C'
        );

        // 2. ROYAL BLUE.
        $pid = $makepage('Royal Blue', 'royal-blue.svg');
        $addel(
            $pid,
            1,
            'Title',
            'text',
            $cx(240),
            42,
            240,
            22,
            'Playfair Display',
            40,
            'bold',
            'normal',
            '#1a237e',
            'C',
            ['text' => 'Certificate of Completion']
        );
        $addel(
            $pid,
            2,
            'Separator',
            'text',
            $cx(160),
            66,
            160,
            5,
            'Roboto',
            10,
            'normal',
            'normal',
            '#c9a84c',
            'C',
            ['text' => str_repeat("\xe2\x94\x81", 20)],
            0.4
        );
        $addel(
            $pid,
            3,
            'Presented To',
            'text',
            $cx(200),
            74,
            200,
            7,
            'Montserrat',
            12,
            'normal',
            'normal',
            '#5c6bc0',
            'C',
            ['text' => 'This certificate is presented to']
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            $cx(240),
            86,
            240,
            20,
            'Playfair Display',
            32,
            'bold',
            'normal',
            '#1a237e',
            'C'
        );
        $addel(
            $pid,
            5,
            'Description',
            'text',
            $cx(220),
            112,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#757575',
            'C',
            ['text' => 'for successfully completing the course']
        );
        $addel(
            $pid,
            6,
            'Course Name',
            'coursename',
            $cx(240),
            124,
            240,
            14,
            'Playfair Display',
            22,
            'bold',
            'normal',
            '#283593',
            'C'
        );
        $addel(
            $pid,
            7,
            'Date',
            'certdate',
            30,
            155,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#616161',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            8,
            'Teacher',
            'teachername',
            177,
            155,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#616161',
            'C'
        );
        $addel(
            $pid,
            9,
            'QR Code',
            'qrcode',
            258,
            158,
            22,
            22,
            'Roboto',
            10,
            'normal',
            'normal',
            '#1a237e',
            'C'
        );
        $addel(
            $pid,
            10,
            'Code',
            'code',
            $cx(80),
            184,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#9e9e9e',
            'C'
        );

        // 3. MODERN TEAL.
        $pid = $makepage('Modern Teal', 'modern-teal.svg');
        $addel(
            $pid,
            1,
            'Small Label',
            'text',
            95,
            25,
            190,
            8,
            'Montserrat',
            10,
            'bold',
            'normal',
            '#00897b',
            'L',
            ['text' => 'CERTIFICATE OF COMPLETION']
        );
        $addel(
            $pid,
            2,
            'Title',
            'text',
            95,
            38,
            190,
            24,
            'Playfair Display',
            36,
            'bold',
            'normal',
            '#212121',
            'L',
            ['text' => 'Certificate']
        );
        $addel(
            $pid,
            3,
            'Presented To',
            'text',
            95,
            72,
            190,
            7,
            'Lato',
            11,
            'normal',
            'normal',
            '#78909c',
            'L',
            ['text' => 'This certificate is awarded to']
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            95,
            84,
            190,
            18,
            'Playfair Display',
            28,
            'bold',
            'normal',
            '#00695c',
            'L'
        );
        $addel(
            $pid,
            5,
            'Description',
            'text',
            95,
            108,
            190,
            7,
            'Lato',
            11,
            'normal',
            'normal',
            '#78909c',
            'L',
            ['text' => 'for successfully completing']
        );
        $addel(
            $pid,
            6,
            'Course Name',
            'coursename',
            95,
            118,
            190,
            14,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#00897b',
            'L'
        );
        $addel(
            $pid,
            7,
            'Date Label',
            'text',
            95,
            148,
            80,
            6,
            'Montserrat',
            8,
            'bold',
            'normal',
            '#90a4ae',
            'L',
            ['text' => 'DATE']
        );
        $addel(
            $pid,
            8,
            'Date',
            'certdate',
            95,
            156,
            80,
            8,
            'Lato',
            12,
            'normal',
            'normal',
            '#37474f',
            'L',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            9,
            'Instructor Label',
            'text',
            195,
            148,
            80,
            6,
            'Montserrat',
            8,
            'bold',
            'normal',
            '#90a4ae',
            'L',
            ['text' => 'INSTRUCTOR']
        );
        $addel(
            $pid,
            10,
            'Teacher',
            'teachername',
            195,
            156,
            80,
            8,
            'Lato',
            12,
            'normal',
            'normal',
            '#37474f',
            'L'
        );
        $addel(
            $pid,
            11,
            'Code',
            'code',
            95,
            180,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#b0bec5',
            'L'
        );

        // 4. EMERALD CLASSIC.
        $pid = $makepage('Emerald Classic', 'emerald-classic.svg');
        $addel(
            $pid,
            1,
            'Header',
            'text',
            $cx(200),
            22,
            200,
            6,
            'Montserrat',
            10,
            'bold',
            'normal',
            '#2e7d32',
            'C',
            ['text' => 'CERTIFICATE OF EXCELLENCE']
        );
        $addel(
            $pid,
            2,
            'Title',
            'text',
            $cx(230),
            34,
            230,
            22,
            'Playfair Display',
            38,
            'bold',
            'normal',
            '#1b5e20',
            'C',
            ['text' => 'Certificate']
        );
        $addel(
            $pid,
            3,
            'Subtitle',
            'text',
            $cx(200),
            58,
            200,
            10,
            'Merriweather',
            14,
            'normal',
            'italic',
            '#4e342e',
            'C',
            ['text' => 'of Excellence']
        );
        $addel(
            $pid,
            4,
            'Presented To',
            'text',
            $cx(200),
            86,
            200,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#757575',
            'C',
            ['text' => 'Proudly presented to']
        );
        $addel(
            $pid,
            5,
            'Student Name',
            'studentname',
            $cx(240),
            98,
            240,
            18,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#1b5e20',
            'C'
        );
        $addel(
            $pid,
            6,
            'Description',
            'text',
            $cx(220),
            122,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#757575',
            'C',
            ['text' => 'for outstanding achievement in']
        );
        $addel(
            $pid,
            7,
            'Course Name',
            'coursename',
            $cx(230),
            134,
            230,
            12,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#2e7d32',
            'C'
        );
        $addel(
            $pid,
            8,
            'Date',
            'certdate',
            30,
            160,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#616161',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            9,
            'Teacher',
            'teachername',
            177,
            160,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#616161',
            'C'
        );
        $addel(
            $pid,
            10,
            'Code',
            'code',
            $cx(80),
            185,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#a5d6a7',
            'C'
        );

        // 5. BURGUNDY ELEGANT.
        $pid = $makepage('Burgundy Elegant', 'burgundy-elegant.svg');
        $addel(
            $pid,
            1,
            'Top Title',
            'text',
            $cx(200),
            12,
            200,
            10,
            'Playfair Display',
            16,
            'bold',
            'normal',
            '#ffffff',
            'C',
            ['text' => 'CERTIFICATE OF ACHIEVEMENT']
        );
        $addel(
            $pid,
            2,
            'Main Title',
            'text',
            $cx(240),
            52,
            240,
            22,
            'Playfair Display',
            36,
            'bold',
            'normal',
            '#6d1a36',
            'C',
            ['text' => 'Certificate']
        );
        $addel(
            $pid,
            3,
            'Subtitle',
            'text',
            $cx(200),
            76,
            200,
            8,
            'Montserrat',
            13,
            'normal',
            'italic',
            '#8b6914',
            'C',
            ['text' => 'This certifies that']
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            $cx(240),
            90,
            240,
            18,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#6d1a36',
            'C'
        );
        $addel(
            $pid,
            5,
            'Description',
            'text',
            $cx(220),
            114,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#666666',
            'C',
            ['text' => 'has successfully completed the course']
        );
        $addel(
            $pid,
            6,
            'Course Name',
            'coursename',
            $cx(230),
            126,
            230,
            12,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#8b2252',
            'C'
        );
        $addel(
            $pid,
            7,
            'Date',
            'certdate',
            40,
            148,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#757575',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            8,
            'Teacher',
            'teachername',
            167,
            148,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#757575',
            'C'
        );
        $addel(
            $pid,
            9,
            'Bottom Title',
            'text',
            $cx(200),
            190,
            200,
            8,
            'Montserrat',
            9,
            'normal',
            'normal',
            '#ffffff',
            'C',
            ['text' => 'Excellence in Education'],
            0.8
        );
        $addel(
            $pid,
            10,
            'Code',
            'code',
            $cx(80),
            165,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#bcaaa4',
            'C'
        );

        // 6. OCEAN GRADIENT.
        $pid = $makepage('Ocean Gradient', 'ocean-gradient.svg');
        $addel(
            $pid,
            1,
            'Header',
            'text',
            $cx(200),
            40,
            200,
            6,
            'Montserrat',
            10,
            'bold',
            'normal',
            '#1565c0',
            'C',
            ['text' => 'CERTIFICATE OF COMPLETION']
        );
        $addel(
            $pid,
            2,
            'Title',
            'text',
            $cx(240),
            50,
            240,
            22,
            'Playfair Display',
            38,
            'bold',
            'normal',
            '#0d47a1',
            'C',
            ['text' => 'Certificate']
        );
        $addel(
            $pid,
            3,
            'Presented To',
            'text',
            $cx(200),
            80,
            200,
            7,
            'Lato',
            12,
            'normal',
            'italic',
            '#5c6bc0',
            'C',
            ['text' => 'This certificate is presented to']
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            $cx(240),
            92,
            240,
            18,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#0d47a1',
            'C'
        );
        $addel(
            $pid,
            5,
            'Description',
            'text',
            $cx(220),
            116,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#78909c',
            'C',
            ['text' => 'for successfully completing']
        );
        $addel(
            $pid,
            6,
            'Course Name',
            'coursename',
            $cx(240),
            128,
            240,
            12,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#1565c0',
            'C'
        );
        $addel(
            $pid,
            7,
            'Date',
            'certdate',
            40,
            150,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#546e7a',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            8,
            'Teacher',
            'teachername',
            167,
            150,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#546e7a',
            'C'
        );
        $addel(
            $pid,
            9,
            'QR Code',
            'qrcode',
            255,
            150,
            22,
            22,
            'Roboto',
            10,
            'normal',
            'normal',
            '#0d47a1',
            'C'
        );
        $addel(
            $pid,
            10,
            'Code',
            'code',
            $cx(80),
            175,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#90a4ae',
            'C'
        );

        // 7. MINIMAL GRAY.
        $pid = $makepage('Minimal Gray', 'minimal-gray.svg');
        $addel(
            $pid,
            1,
            'Title',
            'text',
            $cx(240),
            30,
            240,
            24,
            'Montserrat',
            42,
            'bold',
            'normal',
            '#424242',
            'C',
            ['text' => 'CERTIFICATE']
        );
        $addel(
            $pid,
            2,
            'Subtitle',
            'text',
            $cx(200),
            56,
            200,
            8,
            'Lato',
            14,
            'normal',
            'normal',
            '#9e9e9e',
            'C',
            ['text' => 'OF COMPLETION']
        );
        $addel(
            $pid,
            3,
            'Student Name',
            'studentname',
            $cx(250),
            80,
            250,
            20,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#212121',
            'C'
        );
        $addel(
            $pid,
            4,
            'Description',
            'text',
            $cx(220),
            108,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#9e9e9e',
            'C',
            ['text' => 'has successfully completed the course']
        );
        $addel(
            $pid,
            5,
            'Course Name',
            'coursename',
            $cx(240),
            120,
            240,
            14,
            'Montserrat',
            20,
            'bold',
            'normal',
            '#424242',
            'C'
        );
        $addel(
            $pid,
            6,
            'Date',
            'certdate',
            $cx(120),
            150,
            120,
            8,
            'Lato',
            12,
            'normal',
            'normal',
            '#bdbdbd',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            7,
            'QR Code',
            'qrcode',
            258,
            168,
            22,
            22,
            'Roboto',
            10,
            'normal',
            'normal',
            '#424242',
            'C'
        );
        $addel(
            $pid,
            8,
            'Code',
            'code',
            $cx(80),
            185,
            80,
            5,
            'Lato',
            8,
            'normal',
            'normal',
            '#e0e0e0',
            'C'
        );

        // 8. PURPLE ELEGANCE.
        $pid = $makepage('Purple Elegance', 'purple-elegance.svg');
        $addel(
            $pid,
            1,
            'Header',
            'text',
            $cx(200),
            22,
            200,
            6,
            'Montserrat',
            10,
            'bold',
            'normal',
            '#7b1fa2',
            'C',
            ['text' => 'CERTIFICATE OF ACHIEVEMENT']
        );
        $addel(
            $pid,
            2,
            'Title',
            'text',
            $cx(230),
            34,
            230,
            22,
            'Playfair Display',
            38,
            'bold',
            'normal',
            '#4a148c',
            'C',
            ['text' => 'Certificate']
        );
        $addel(
            $pid,
            3,
            'Presented To',
            'text',
            $cx(200),
            60,
            200,
            7,
            'Lato',
            12,
            'normal',
            'italic',
            '#9c27b0',
            'C',
            ['text' => 'This is to certify that']
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            $cx(240),
            72,
            240,
            18,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#4a148c',
            'C'
        );
        $addel(
            $pid,
            5,
            'Description',
            'text',
            $cx(220),
            96,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#666666',
            'C',
            ['text' => 'has demonstrated excellence in']
        );
        $addel(
            $pid,
            6,
            'Course Name',
            'coursename',
            $cx(230),
            108,
            230,
            12,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#6a1b9a',
            'C'
        );
        $addel(
            $pid,
            7,
            'Grade Label',
            'text',
            $cx(60),
            130,
            60,
            6,
            'Montserrat',
            8,
            'normal',
            'normal',
            '#9e9e9e',
            'C',
            ['text' => 'GRADE']
        );
        $addel(
            $pid,
            8,
            'Grade',
            'grade',
            $cx(60),
            138,
            60,
            12,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#4a148c',
            'C'
        );
        $addel(
            $pid,
            9,
            'Date',
            'certdate',
            30,
            158,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#757575',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            10,
            'Teacher',
            'teachername',
            177,
            158,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#757575',
            'C'
        );
        $addel(
            $pid,
            11,
            'Code',
            'code',
            $cx(80),
            178,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#ce93d8',
            'C'
        );

        // 9. SUNSET WARM.
        $pid = $makepage('Sunset Warm', 'sunset-warm.svg');
        $addel(
            $pid,
            1,
            'Title',
            'text',
            $cx(240),
            35,
            240,
            22,
            'Playfair Display',
            38,
            'bold',
            'normal',
            '#bf360c',
            'C',
            ['text' => 'Certificate of Completion']
        );
        $addel(
            $pid,
            2,
            'Ornament',
            'text',
            $cx(160),
            58,
            160,
            5,
            'Roboto',
            10,
            'normal',
            'normal',
            '#ff8f00',
            'C',
            ['text' => "\xe2\x9c\xa6 " . str_repeat("\xe2\x80\x94", 8)
                . " \xe2\x9c\xa6 " . str_repeat("\xe2\x80\x94", 8) . " \xe2\x9c\xa6"],
            0.5
        );
        $addel(
            $pid,
            3,
            'Presented To',
            'text',
            $cx(200),
            76,
            200,
            7,
            'Lato',
            12,
            'normal',
            'italic',
            '#8d6e63',
            'C',
            ['text' => 'This certificate is awarded to']
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            $cx(240),
            88,
            240,
            18,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#bf360c',
            'C'
        );
        $addel(
            $pid,
            5,
            'Description',
            'text',
            $cx(220),
            112,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#8d6e63',
            'C',
            ['text' => 'for successfully completing the course']
        );
        $addel(
            $pid,
            6,
            'Course Name',
            'coursename',
            $cx(230),
            124,
            230,
            12,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#e65100',
            'C'
        );
        $addel(
            $pid,
            7,
            'Date',
            'certdate',
            30,
            150,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#795548',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            8,
            'Teacher',
            'teachername',
            177,
            150,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#795548',
            'C'
        );
        $addel(
            $pid,
            9,
            'Code',
            'code',
            $cx(80),
            178,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#d7ccc8',
            'C'
        );

        // 10. DARK PROFESSIONAL.
        $pid = $makepage('Dark Professional', 'dark-professional.svg', '#1a1a2e');
        $addel(
            $pid,
            1,
            'Header',
            'text',
            $cx(200),
            20,
            200,
            6,
            'Montserrat',
            10,
            'bold',
            'normal',
            '#daa520',
            'C',
            ['text' => 'CERTIFICATE OF PROFESSIONAL DEVELOPMENT']
        );
        $addel(
            $pid,
            2,
            'Title',
            'text',
            $cx(240),
            34,
            240,
            22,
            'Playfair Display',
            38,
            'bold',
            'normal',
            '#ffffff',
            'C',
            ['text' => 'Certificate']
        );
        $addel(
            $pid,
            3,
            'Subtitle',
            'text',
            $cx(200),
            58,
            200,
            8,
            'Lato',
            14,
            'normal',
            'italic',
            '#daa520',
            'C',
            ['text' => 'of Professional Development']
        );
        $addel(
            $pid,
            4,
            'Presented To',
            'text',
            $cx(200),
            84,
            200,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#90a4ae',
            'C',
            ['text' => 'Awarded to']
        );
        $addel(
            $pid,
            5,
            'Student Name',
            'studentname',
            $cx(240),
            96,
            240,
            18,
            'Playfair Display',
            30,
            'bold',
            'normal',
            '#ffffff',
            'C'
        );
        $addel(
            $pid,
            6,
            'Description',
            'text',
            $cx(220),
            120,
            220,
            7,
            'Lato',
            12,
            'normal',
            'normal',
            '#78909c',
            'C',
            ['text' => 'for completing the course']
        );
        $addel(
            $pid,
            7,
            'Course Name',
            'coursename',
            $cx(240),
            132,
            240,
            12,
            'Playfair Display',
            20,
            'bold',
            'normal',
            '#daa520',
            'C'
        );
        $addel(
            $pid,
            8,
            'Date',
            'certdate',
            30,
            158,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#78909c',
            'C',
            ['dateformat' => 'F j, Y']
        );
        $addel(
            $pid,
            9,
            'Teacher',
            'teachername',
            177,
            158,
            90,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#78909c',
            'C'
        );
        $addel(
            $pid,
            10,
            'QR Code',
            'qrcode',
            258,
            158,
            22,
            22,
            'Roboto',
            10,
            'normal',
            'normal',
            '#daa520',
            'C'
        );
        $addel(
            $pid,
            11,
            'Code',
            'code',
            $cx(80),
            185,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#546e7a',
            'C'
        );

        // BONUS: Greek Formal (with background).
        $pid = $makepage('Greek Formal', 'greek-formal.svg');
        $addel(
            $pid,
            1,
            'Title',
            'text',
            $cx(220),
            44,
            220,
            22,
            'Playfair Display',
            36,
            'bold',
            'normal',
            '#1a237e',
            'C',
            ['text' => "\xce\x92\xce\x95\xce\x92\xce\x91\xce\x99\xce\xa9\xce\xa3\xce\x97"]
        );
        $addel(
            $pid,
            2,
            'Subtitle',
            'text',
            $cx(200),
            68,
            200,
            7,
            'Lato',
            12,
            'normal',
            'italic',
            '#5c6bc0',
            'C',
            ['text' => "\xce\xa0\xce\xb9\xcf\x83\xcf\x84\xce\xbf\xcf\x80\xce\xbf\xce\xb9\xce\xb7\xcf\x84\xce\xb9\xce\xba\xcf\x8c"
                . " \xce\x95\xcf\x80\xce\xb9\xce\xbc\xcf\x8c\xcf\x81\xcf\x86\xcf\x89\xcf\x83\xce\xb7\xcf\x82"]
        );
        $addel(
            $pid,
            3,
            'Statement',
            'certstatement',
            $cx(240),
            82,
            240,
            20,
            'Lato',
            13,
            'normal',
            'normal',
            '#424242',
            'C'
        );
        $addel(
            $pid,
            4,
            'Student Name',
            'studentname',
            $cx(240),
            106,
            240,
            18,
            'Playfair Display',
            28,
            'bold',
            'normal',
            '#1a237e',
            'C'
        );
        $addel(
            $pid,
            5,
            'Course Name',
            'coursename',
            $cx(230),
            130,
            230,
            12,
            'Playfair Display',
            18,
            'bold',
            'normal',
            '#283593',
            'C'
        );
        $addel(
            $pid,
            6,
            'Date',
            'certdate',
            30,
            155,
            100,
            8,
            'Lato',
            11,
            'normal',
            'normal',
            '#616161',
            'C',
            ['city' => "\xce\x91\xce\xb8\xce\xae\xce\xbd\xce\xb1"]
        );
        $addel(
            $pid,
            7,
            'Teacher Label',
            'text',
            180,
            150,
            90,
            6,
            'Lato',
            9,
            'normal',
            'normal',
            '#9e9e9e',
            'C',
            ['text' => "\xce\x9f/\xce\x97 \xce\x95\xce\xba\xcf\x80\xce\xb1"
                . "\xce\xb9\xce\xb4\xce\xb5\xcf\x85\xcf\x84\xce\xae"
                . "\xcf\x82/\xcf\x84\xcf\x81\xce\xb9\xce\xb1"]
        );
        $addel(
            $pid,
            8,
            'Teacher',
            'teachername',
            180,
            158,
            90,
            8,
            'Lato',
            12,
            'normal',
            'normal',
            '#424242',
            'C'
        );
        $addel(
            $pid,
            9,
            'Code',
            'code',
            $cx(80),
            180,
            80,
            5,
            'Roboto',
            7,
            'normal',
            'normal',
            '#9e9e9e',
            'C'
        );

        upgrade_mod_savepoint(true, 2025041409, 'certstudio');
    }

    if ($oldversion < 2025041410) {
        // Add tags field to certstudio_templates.
        $table = new xmldb_table('certstudio_templates');
        $field = new xmldb_field('tags', XMLDB_TYPE_TEXT, null, null, null, null, null, 'contextid');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Delete ALL system templates not in use by any activity.
        $systemctx = \context_system::instance();
        $systemtemplates = $DB->get_records('certstudio_templates', ['contextid' => $systemctx->id]);
        foreach ($systemtemplates as $tmpl) {
            $inuse = $DB->record_exists('certstudio', ['templateid' => $tmpl->id]);
            if (!$inuse) {
                $pages = $DB->get_records('certstudio_pages', ['templateid' => $tmpl->id]);
                foreach ($pages as $page) {
                    $DB->delete_records('certstudio_elements', ['pageid' => $page->id]);
                }
                $DB->delete_records('certstudio_pages', ['templateid' => $tmpl->id]);
                $DB->delete_records('certstudio_templates', ['id' => $tmpl->id]);
            }
        }

        // Generate all SVG backgrounds.
        global $CFG;
        require_once($CFG->dirroot . '/mod/certstudio/classes/svg_backgrounds.php');
        $backgrounds = \mod_certstudio\svg_backgrounds::generate_all();

        $now = time();
        $pw = 297;
        $ph = 210;

        foreach ($backgrounds as $bg) {
            $bgcolor = (strpos($bg['tags'], 'dark') !== false) ? '#1a1a2e' : '#ffffff';

            $t = new \stdClass();
            $t->name = $bg['name'];
            $t->contextid = $systemctx->id;
            $t->tags = $bg['tags'];
            $t->timecreated = $now;
            $t->timemodified = $now;
            $t->id = $DB->insert_record('certstudio_templates', $t);

            $p = new \stdClass();
            $p->templateid = $t->id;
            $p->width = $pw;
            $p->height = $ph;
            $p->leftmargin = 0;
            $p->rightmargin = 0;
            $p->bgcolor = $bgcolor;
            $p->sequence = 1;
            $p->timecreated = $now;
            $p->timemodified = $now;
            $p->id = $DB->insert_record('certstudio_pages', $p);

            $bgel = new \stdClass();
            $bgel->pageid = $p->id;
            $bgel->name = 'Background';
            $bgel->type = 'bgimage';
            $bgel->data = json_encode(['src' => '/mod/certstudio/pix/backgrounds/' . $bg['filename'], 'sizemode' => 'stretch']);
            $bgel->posx = 0;
            $bgel->posy = 0;
            $bgel->width = $pw;
            $bgel->height = $ph;
            $bgel->fontfamily = 'Roboto';
            $bgel->fontsize = 12;
            $bgel->fontweight = 'normal';
            $bgel->fontstyle = 'normal';
            $bgel->color = '#000000';
            $bgel->alignment = 'C';
            $bgel->opacity = 1;
            $bgel->rotation = 0;
            $bgel->locked = 1;
            $bgel->sequence = 0;
            $bgel->timecreated = $now;
            $bgel->timemodified = $now;
            $DB->insert_record('certstudio_elements', $bgel);
        }

        upgrade_mod_savepoint(true, 2025041410, 'certstudio');
    }

    if ($oldversion < 2026100901) {
        // The page background colour is used by the editor and both PDF renderers, but was missing from
        // install.xml, so fresh installs never stored it.
        $table = new xmldb_table('certstudio_pages');
        $field = new xmldb_field('bgcolor', XMLDB_TYPE_CHAR, '20', null, null, null, '#ffffff', 'backgroundimage');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Empty element data was saved as a JSON array, which the editor could not add settings to.
        $DB->set_field_select('certstudio_elements', 'data', '{}', $DB->sql_compare_text('data') . ' = ?', ['[]']);

        upgrade_mod_savepoint(true, 2026100901, 'certstudio');
    }

    return true;
}
