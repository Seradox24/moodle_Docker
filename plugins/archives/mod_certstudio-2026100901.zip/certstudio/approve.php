<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate approval management page.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT); // Course module id.
$action = optional_param('action', '', PARAM_ALPHA);
$requestid = optional_param('requestid', 0, PARAM_INT);
$comment = optional_param('comment', '', PARAM_TEXT);

$cm = get_coursemodule_from_id('certstudio', $id, 0, false, MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
$certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:approvecertificate', $context);

$PAGE->set_url('/mod/certstudio/approve.php', ['id' => $cm->id]);
$PAGE->set_title(get_string('manageapprovals', 'mod_certstudio'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);

$approval = new \mod_certstudio\approval();

// Helper: run a callable suppressing all output and PHP errors so redirect() works cleanly.
$runsilent = function (callable $fn) {
    global $CFG;
    $olddebug = $CFG->debug ?? null;
    $olddisplay = $CFG->debugdisplay ?? null;
    $CFG->debug = 0;
    $CFG->debugdisplay = 0;
    ob_start();
    $fn();
    ob_end_clean();
    $CFG->debug = $olddebug;
    $CFG->debugdisplay = $olddisplay;
    @trigger_error('', E_USER_NOTICE);
};

// Handle actions.
if ($action && $requestid && confirm_sesskey()) {
    // The capability check above only covers this activity, so the request must belong to it.
    $request = $approval->get_request($requestid);
    if (!$request || (int) $request->certstudioid !== (int) $certstudio->id) {
        throw new moodle_exception('approvalrequestnotfound', 'mod_certstudio');
    }
    switch ($action) {
        case 'approve':
            $runsilent(function () use ($approval, $requestid, $USER, $comment) {
                $approval->approve($requestid, $USER->id, $comment);
            });
            redirect(
                new moodle_url('/mod/certstudio/approve.php', ['id' => $cm->id]),
                get_string('requestapproved', 'mod_certstudio'),
                null,
                \core\output\notification::NOTIFY_SUCCESS
            );
            break;
        case 'reject':
            $runsilent(function () use ($approval, $requestid, $USER, $comment) {
                $approval->reject($requestid, $USER->id, $comment);
            });
            redirect(
                new moodle_url('/mod/certstudio/approve.php', ['id' => $cm->id]),
                get_string('requestrejectedmsg', 'mod_certstudio'),
                null,
                \core\output\notification::NOTIFY_SUCCESS
            );
            break;
    }
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('manageapprovals', 'mod_certstudio'));

// Filtering and pagination params.
$asearch = optional_param('asearch', '', PARAM_TEXT);
$astatus = optional_param('astatus', '', PARAM_ALPHA);
$apage = optional_param('apage', 0, PARAM_INT);
$aperpage = 20;

// Build query with optional filters.
$wheresql = "WHERE ar.certstudioid = ?";
$params = [$certstudio->id];
if (!empty($asearch)) {
    $wheresql .= " AND (CONCAT(u.firstname, ' ', u.lastname) LIKE ?)";
    $params[] = '%' . $DB->sql_like_escape($asearch) . '%';
}
if ($astatus === 'pending') {
    $wheresql .= " AND ar.status = ?";
    $params[] = \mod_certstudio\approval::STATUS_PENDING;
} else if ($astatus === 'approved') {
    $wheresql .= " AND ar.status = ?";
    $params[] = \mod_certstudio\approval::STATUS_APPROVED;
} else if ($astatus === 'rejected') {
    $wheresql .= " AND ar.status = ?";
    $params[] = \mod_certstudio\approval::STATUS_REJECTED;
}

$totalcount = $DB->count_records_sql(
    "SELECT COUNT(ar.id) FROM {certstudio_approval_requests} ar
     JOIN {user} u ON u.id = ar.userid
     $wheresql",
    $params
);

$allrequests = $DB->get_records_sql(
    "SELECT ar.* FROM {certstudio_approval_requests} ar
     JOIN {user} u ON u.id = ar.userid
     $wheresql
     ORDER BY CASE WHEN ar.status = 0 THEN 0 ELSE 1 END, ar.timecreated DESC",
    $params,
    $apage * $aperpage,
    $aperpage
);

// Filter form.
$filterurl = new moodle_url('/mod/certstudio/approve.php', ['id' => $cm->id]);
echo '<form method="get" action="' . $filterurl->out(false) . '" class="mb-3">';
echo '<input type="hidden" name="id" value="' . $cm->id . '">';
echo '<div class="d-flex flex-wrap gap-2 align-items-center" style="gap:8px;">';
echo '<div class="input-group" style="max-width:300px;">';
echo '<input type="text" name="asearch" class="form-control form-control-sm" '
    . 'placeholder="' . get_string('search') . ' ' . get_string('student', 'mod_certstudio') . '..." '
    . 'value="' . s($asearch) . '">';
echo '</div>';
echo '<select name="astatus" class="form-control form-control-sm" style="max-width:150px;">';
echo '<option value="">' . get_string('all') . '</option>';
echo '<option value="pending"' . ($astatus === 'pending' ? ' selected' : '') . '>'
    . get_string('statuspending', 'mod_certstudio') . '</option>';
echo '<option value="approved"' . ($astatus === 'approved' ? ' selected' : '') . '>'
    . get_string('statusapproved', 'mod_certstudio') . '</option>';
echo '<option value="rejected"' . ($astatus === 'rejected' ? ' selected' : '') . '>'
    . get_string('statusrejected', 'mod_certstudio') . '</option>';
echo '</select>';
echo '<button type="submit" class="btn btn-sm btn-outline-secondary">'
    . '<i class="fa fa-search"></i> ' . get_string('search') . '</button>';
if (!empty($asearch) || !empty($astatus)) {
    echo '<a href="' . $filterurl->out(false) . '" class="btn btn-sm btn-outline-danger" title="' . get_string('clearfilters', 'mod_certstudio') . '"><i class="fa fa-times"></i></a>';
}
echo '</div></form>';

$approvedata = [
    'cmid' => $cm->id,
    'sesskey' => sesskey(),
    'requests' => [],
    'hasrequests' => !empty($allrequests),
];

foreach ($allrequests as $req) {
    $user = $DB->get_record('user', ['id' => $req->userid]);
    $reviewer = $req->reviewerid ? $DB->get_record('user', ['id' => $req->reviewerid]) : null;

    $statustext = '';
    $statusclass = '';
    switch ($req->status) {
        case \mod_certstudio\approval::STATUS_PENDING:
            $statustext = get_string('statuspending', 'mod_certstudio');
            $statusclass = 'badge-warning';
            break;
        case \mod_certstudio\approval::STATUS_APPROVED:
            $statustext = get_string('statusapproved', 'mod_certstudio');
            $statusclass = 'badge-success';
            break;
        case \mod_certstudio\approval::STATUS_REJECTED:
            $statustext = get_string('statusrejected', 'mod_certstudio');
            $statusclass = 'badge-danger';
            break;
    }

    $approvedata['requests'][] = [
        'id' => $req->id,
        'username' => $user ? fullname($user) : '?',
        'datecreated' => userdate($req->timecreated),
        'status' => $statustext,
        'statusclass' => $statusclass,
        'ispending' => $req->status == \mod_certstudio\approval::STATUS_PENDING,
        'reviewername' => $reviewer ? fullname($reviewer) : '',
        'reviewcomment' => $req->reviewcomment ?? '',
    ];
}

echo $OUTPUT->render_from_template('mod_certstudio/approve', $approvedata);

// Pagination.
if ($totalcount > $aperpage) {
    $pagingurl = new moodle_url('/mod/certstudio/approve.php', [
        'id' => $cm->id, 'asearch' => $asearch, 'astatus' => $astatus,
    ]);
    echo $OUTPUT->paging_bar($totalcount, $apage, $aperpage, $pagingurl, 'apage');
}

// Back button.
echo html_writer::div(
    $OUTPUT->single_button(
        new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]),
        get_string('back'),
        'get'
    ),
    'mt-3'
);

echo $OUTPUT->footer();
