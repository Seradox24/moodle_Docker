<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Image upload handler for the certificate editor.
 *
 * This endpoint handles file uploads which cannot be processed
 * through the External Services API.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);

require_once(__DIR__ . '/../../config.php');

$cmid = required_param('cmid', PARAM_INT);
$imagetype = optional_param('imagetype', '', PARAM_ALPHA);
$pageid = optional_param('pageid', 0, PARAM_INT);
$elementid = optional_param('elementid', '', PARAM_ALPHANUMEXT);
$filearea = optional_param('filearea', '', PARAM_ALPHA);

$cm = get_coursemodule_from_id('certstudio', $cmid, 0, false, MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);

require_login($course, true, $cm);
require_sesskey();
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:manage', $context);

header('Content-Type: application/json');

try {
    // Determine file area from imagetype or filearea param.
    if (empty($filearea)) {
        if ($imagetype === 'background') {
            $filearea = 'background';
        } else {
            $filearea = 'elementimage';
        }
    }

    // Only the plugin's design image areas, the same ones certstudio_pluginfile() serves.
    $designareas = ['image', 'bgimage', 'digitalsignature', 'userpicture', 'background', 'elementimage'];
    if (!in_array($filearea, $designareas, true)) {
        throw new moodle_exception('invalidimage', 'mod_certstudio');
    }

    // Use pageid for backgrounds, elementid for element images.
    $itemid = ($imagetype === 'background') ? $pageid : (int) $elementid;
    if (!$itemid) {
        $itemid = $pageid ?: 0;
    }

    $result = [];
    if (isset($_FILES['file'])) {
        // Raster images within the upload limit only. An SVG can carry scripts and reference other URLs
        // when the PDF is generated on the server.
        $upload = $_FILES['file'];
        $maxbytes = get_user_max_upload_file_size($context, $CFG->maxbytes, $course->maxbytes);
        $imageinfo = ($upload['error'] === UPLOAD_ERR_OK && is_uploaded_file($upload['tmp_name']))
            ? getimagesize($upload['tmp_name']) : false;
        $allowedtypes = [IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF, IMAGETYPE_WEBP];
        if (!$imageinfo || !in_array($imageinfo[2], $allowedtypes, true) || $upload['size'] > $maxbytes) {
            throw new moodle_exception('invalidimage', 'mod_certstudio');
        }
        // Name the file after its real type, so it is stored and served with the right MIME type.
        $basename = pathinfo(clean_param($upload['name'], PARAM_FILE), PATHINFO_FILENAME) ?: 'image';

        $fs = get_file_storage();
        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'mod_certstudio',
            'filearea'  => $filearea,
            'itemid'    => $itemid,
            'filepath'  => '/',
            'filename'  => $basename . image_type_to_extension($imageinfo[2]),
        ];

        // Delete existing file in same area/item.
        $fs->delete_area_files($context->id, 'mod_certstudio', $filearea, $itemid);

        $file = $fs->create_file_from_pathname($fileinfo, $_FILES['file']['tmp_name']);
        $url = moodle_url::make_pluginfile_url(
            $context->id,
            'mod_certstudio',
            $filearea,
            $itemid,
            $file->get_filepath(),
            $file->get_filename()
        );
        $result = ['success' => true, 'url' => $url->out(false), 'filename' => $file->get_filename()];
    } else {
        $result = ['success' => false, 'error' => 'No file uploaded'];
    }

    echo json_encode($result);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
