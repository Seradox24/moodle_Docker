<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Migration tool: import data from mod_customcert to mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url('/mod/certstudio/migrate.php');
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('migrationtool', 'mod_certstudio'));
$PAGE->set_heading(get_string('migrationtool', 'mod_certstudio'));

$action = optional_param('action', '', PARAM_ALPHA);
$confirm = optional_param('confirm', 0, PARAM_INT);

$summary = \mod_certstudio\migration::get_migration_summary();

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('migrationtool', 'mod_certstudio'));

if (!$summary['available']) {
    echo $OUTPUT->notification(get_string('migrationnotavailable', 'mod_certstudio'), 'warning');
    echo $OUTPUT->footer();
    die;
}

if ($action === 'run' && $confirm && confirm_sesskey()) {
    $migratetemplates = optional_param('templates', 0, PARAM_INT);
    $migrateactivities = optional_param('activities', 0, PARAM_INT);
    $migrateissues = optional_param('issues', 0, PARAM_INT);

    $migration = new \mod_certstudio\migration();
    $results = $migration->run(
        (bool) $migratetemplates,
        (bool) $migrateactivities,
        (bool) $migrateissues
    );

    echo $OUTPUT->notification(get_string('migrationcomplete', 'mod_certstudio', (object) $results), 'success');

    if (!empty($results['log'])) {
        echo '<div class="card mt-3"><div class="card-body">';
        echo '<h5>' . get_string('migrationlog', 'mod_certstudio') . '</h5>';
        echo '<pre class="small" style="max-height:400px;overflow:auto">';
        foreach ($results['log'] as $line) {
            echo s($line) . "\n";
        }
        echo '</pre></div></div>';
    }

    echo $OUTPUT->continue_button(new moodle_url('/mod/certstudio/migrate.php'));
    echo $OUTPUT->footer();
    die;
}

// Show summary and migration form.
echo '<div class="card mb-3"><div class="card-body">';
echo '<h5>' . get_string('migrationsummary', 'mod_certstudio') . '</h5>';
echo '<table class="table table-sm">';
echo '<tr><td>' . get_string('templates', 'mod_certstudio') . '</td><td><strong>' . $summary['templates'] . '</strong></td></tr>';
echo '<tr><td>' . get_string('activities', 'mod_certstudio') . '</td><td><strong>' . $summary['activities'] . '</strong></td></tr>';
echo '<tr><td>' . get_string('issuedcertificates', 'mod_certstudio') . '</td><td><strong>' . $summary['issues'] . '</strong></td></tr>';
echo '<tr><td>' . get_string('pages', 'mod_certstudio') . '</td><td><strong>' . $summary['pages'] . '</strong></td></tr>';
echo '<tr><td>' . get_string('elements', 'mod_certstudio') . '</td><td><strong>' . $summary['elements'] . '</strong></td></tr>';
echo '</table>';
echo '</div></div>';

if ($summary['templates'] == 0 && $summary['activities'] == 0) {
    echo $OUTPUT->notification(get_string('migrationnodata', 'mod_certstudio'), 'info');
    echo $OUTPUT->footer();
    die;
}

echo '<form method="post" action="' . (new moodle_url('/mod/certstudio/migrate.php'))->out(false) . '">';
echo '<input type="hidden" name="action" value="run">';
echo '<input type="hidden" name="confirm" value="1">';
echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';

echo '<div class="card mb-3"><div class="card-body">';
echo '<h5>' . get_string('migrationoptions', 'mod_certstudio') . '</h5>';

echo '<div class="form-check mb-2">';
echo '<input type="checkbox" class="form-check-input" name="templates" value="1" id="mig-templates" checked>';
echo '<label class="form-check-label" for="mig-templates">' . get_string('migratetemplates', 'mod_certstudio') . '</label>';
echo '</div>';

echo '<div class="form-check mb-2">';
echo '<input type="checkbox" class="form-check-input" name="activities" value="1" id="mig-activities" checked>';
echo '<label class="form-check-label" for="mig-activities">' . get_string('migrateactivities', 'mod_certstudio') . '</label>';
echo '</div>';

echo '<div class="form-check mb-2">';
echo '<input type="checkbox" class="form-check-input" name="issues" value="1" id="mig-issues" checked>';
echo '<label class="form-check-label" for="mig-issues">' . get_string('migrateissues', 'mod_certstudio') . '</label>';
echo '</div>';

echo '</div></div>';

echo $OUTPUT->notification(get_string('migrationwarning', 'mod_certstudio'), 'warning');

echo '<button type="submit" class="btn btn-primary"><i class="fa fa-exchange"></i> '
    . get_string('startmigration', 'mod_certstudio') . '</button>';
echo ' <a href="' . (new moodle_url('/admin/settings.php', ['section' => 'modsettingcertstudio']))->out(false)
    . '" class="btn btn-secondary">' . get_string('cancel') . '</a>';

echo '</form>';

echo $OUTPUT->footer();
