# Third-party libraries

This directory contains third-party libraries used by the certstudio plugin.

## Libraries

### interact.js
- **Version:** 1.10.27
- **License:** MIT
- **Source:** https://github.com/taye/interact.js
- **Description:** JavaScript drag and drop, resizing, and multi-touch gestures for modern browsers.

### jsPDF
- **Version:** 2.5.2
- **License:** MIT
- **Source:** https://github.com/MrRio/jsPDF
- **Description:** PDF document creation from JavaScript.

### JSZip
- **Version:** 3.10.1
- **License:** MIT / GPLv3 (dual licensed)
- **Source:** https://github.com/Stuk/jszip
- **Description:** A JavaScript class for generating and reading zip files.

### qrcode.js
- **Version:** 1.0.0
- **License:** MIT
- **Source:** https://github.com/davidshimjs/qrcodejs
- **Description:** Cross-browser QR code generator for JavaScript.

## Updating libraries

When updating any library, remember to:
1. Update the minified file in the corresponding subdirectory.
2. Update the version number in `/mod/certstudio/thirdpartylibs.xml`.
3. Update the version number in this README.
4. Run `grunt ignorefiles` from the Moodle root to regenerate the ignore list.
