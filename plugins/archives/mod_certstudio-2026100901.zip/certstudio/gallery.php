<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate Studio template gallery page.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT); // Course module id.

$cm = get_coursemodule_from_id('certstudio', $id, 0, false, MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
$certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:manage', $context);

$PAGE->set_url('/mod/certstudio/gallery.php', ['id' => $cm->id]);
$PAGE->set_title(get_string('pluginname', 'mod_certstudio') . ': ' . get_string('templategallery', 'mod_certstudio'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');

// Get all system-level templates (the default ones + user-published ones).
$systemctx = \context_system::instance();
$systemtemplates = \mod_certstudio\template::get_by_context($systemctx->id);

// Get the current activity's template (if any) - skip it in the gallery since it's a working copy.
$currenttemplateid = !empty($certstudio->templateid) ? $certstudio->templateid : 0;

// Text-type element types for determining preview rendering.
$texttypes = [
    'text', 'studentname', 'coursename', 'categoryname', 'date', 'grade',
    'gradeitemname', 'code', 'teachername', 'userfield', 'coursefield',
    'daterange', 'expiry', 'certdate', 'certstatement',
];

// Helper to build template data for one template record.
// Colours and image URLs from template data end up inside style attributes: let only plain values through.
$safecolor = function ($value, string $fallback): string {
    $value = trim((string) $value);
    return preg_match('/^(#[0-9a-fA-F]{3,8}|[a-zA-Z]+|rgba?\([\d\s.,%]+\))$/', $value) ? $value : $fallback;
};
$safecssurl = function ($value): string {
    $value = (string) $value;
    return preg_match('#^(https?://|/)[^\s()\'";\\\\]+$#', $value) ? $value : '';
};

$buildtemplatedata = function ($tmpl, $iscustom = false) use ($DB, $CFG, $texttypes, $currenttemplateid, $safecolor, $safecssurl) {
    $pages = \mod_certstudio\template::get_pages($tmpl->id);
    $firstpage = reset($pages);

    $elementcount = 0;
    $previewelements = [];

    if ($firstpage) {
        $elements = $DB->get_records('certstudio_elements', ['pageid' => $firstpage->id], 'sequence ASC');
        $elementcount = count($elements);

        foreach ($elements as $el) {
            // Skip bgimage from counted preview elements; handle separately.
            if ($el->type === 'bgimage') {
                $data = json_decode($el->data ?? '', true);
                if (!empty($data['src'])) {
                    $src = $data['src'];
                    // Prefix relative plugin paths with wwwroot for subfolder installs.
                    if (strpos($src, '/mod/certstudio/') === 0) {
                        $src = $CFG->wwwroot . $src;
                    }
                    $bgimagesrc = $safecssurl($src);
                }
                continue;
            }
            $previewelements[] = [
                'type' => $el->type,
                'name' => $el->name,
                'posx' => round($el->posx / $firstpage->width * 100, 1),
                'posy' => round($el->posy / $firstpage->height * 100, 1),
                'width' => round($el->width / $firstpage->width * 100, 1),
                'height' => round($el->height / $firstpage->height * 100, 1),
                'color' => $safecolor($el->color, '#333'),
                'fontsize' => $el->fontsize,
                'istext' => in_array($el->type, $texttypes),
            ];
        }
    }

    // Parse tags for filtering.
    $tags = !empty($tmpl->tags) ? $tmpl->tags : '';
    $taglist = array_filter(array_map('trim', explode(',', $tags)));
    $style = '';
    $color = '';
    $stylevalues = ['classic', 'modern', 'elegant', 'gradient', 'minimal', 'dark', 'special'];
    foreach ($taglist as $tag) {
        if (in_array($tag, $stylevalues)) {
            $style = $tag;
        } else {
            $color = $tag;
        }
    }

    return [
        'id' => $tmpl->id,
        'name' => $tmpl->name,
        'elementcount' => $elementcount,
        'pagewidth' => $firstpage ? (int)$firstpage->width : 297,
        'pageheight' => $firstpage ? (int)$firstpage->height : 210,
        'previewelements' => $previewelements,
        'bgimagesrc' => $bgimagesrc ?? '',
        'hasbgimage' => !empty($bgimagesrc),
        'bgcolor' => $firstpage ? $safecolor($firstpage->bgcolor ?? '', '#ffffff') : '#ffffff',
        'iscurrent' => ($tmpl->id == $currenttemplateid),
        'iscustom' => $iscustom,
        'tags' => $tags,
        'style' => $style,
        'color' => $color,
    ];
};

// Separate built-in templates (with tags) from user-published ones (no tags).
$alltemplates = array_values($systemtemplates);
$builtintemplates = [];
$customtemplates = [];

if (!empty($alltemplates)) {
    foreach ($alltemplates as $tmpl) {
        if (!empty($tmpl->tags)) {
            $builtintemplates[] = $buildtemplatedata($tmpl, false);
        } else {
            $customtemplates[] = $buildtemplatedata($tmpl, true);
        }
    }
}

$gallerydata = [
    'cmid' => $cm->id,
    'aienabled' => !empty(get_config('mod_certstudio', 'aiapikey')),
    'builtintemplates' => $builtintemplates,
    'hasbuiltintemplates' => !empty($builtintemplates),
    'customtemplates' => $customtemplates,
    'hascustomtemplates' => !empty($customtemplates),
    'templates' => array_merge($builtintemplates, $customtemplates),
    'hastemplates' => !empty($builtintemplates) || !empty($customtemplates),
    'currenttemplateid' => $currenttemplateid,
    'viewurl' => (new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]))->out(false),
];

// Pre-load JS strings needed by the gallery AMD module.
$PAGE->requires->strings_for_js([
    'aigenerating',
    'aigeneratesuccess',
    'aierror',
], 'mod_certstudio');

// Load the gallery AMD module.
$PAGE->requires->js_call_amd('mod_certstudio/gallery', 'init', [$cm->id, !empty($certstudio->templateid)]);

echo $OUTPUT->header();
echo $OUTPUT->render_from_template('mod_certstudio/gallery', $gallerydata);
echo $OUTPUT->footer();
