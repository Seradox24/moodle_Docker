<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library of functions for mod_certstudio.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Add certstudio instance.
 *
 * @param stdClass $data Form data
 * @param mod_certstudio_mod_form $mform The form
 * @return int New instance id
 */
function certstudio_add_instance($data, $mform = null) {
    global $DB;

    $data->timecreated = time();
    $data->timemodified = $data->timecreated;

    $data->id = $DB->insert_record('certstudio', $data);

    return $data->id;
}

/**
 * Update certstudio instance.
 *
 * @param stdClass $data Form data
 * @param mod_certstudio_mod_form $mform The form
 * @return bool Success
 */
function certstudio_update_instance($data, $mform = null) {
    global $DB;

    $data->timemodified = time();
    $data->id = $data->instance;

    // The template is chosen in the gallery and edited in the editor, never in this form. The hidden value it
    // carries was read when the form opened, so writing it back could restore a template that has since been replaced.
    unset($data->templateid);

    return $DB->update_record('certstudio', $data);
}

/**
 * Delete certstudio instance.
 *
 * @param int $id Instance id
 * @return bool Success
 */
function certstudio_delete_instance($id) {
    global $DB;

    $certstudio = $DB->get_record('certstudio', ['id' => $id]);
    if (!$certstudio) {
        // Already gone, e.g. a retried deletion: report success so the course module can be removed.
        return true;
    }
    $cm = get_coursemodule_from_instance('certstudio', $id, 0, false, IGNORE_MISSING);
    $context = $cm ? context_module::instance($cm->id, IGNORE_MISSING) : false;

    // Delete approval requests.
    $DB->delete_records('certstudio_approval_requests', ['certstudioid' => $id]);

    // Delete issues.
    $DB->delete_records('certstudio_issues', ['certstudioid' => $id]);

    // Delete the instance.
    $DB->delete_records('certstudio', ['id' => $id]);

    // Delete the activity's own template, unless something else still uses it.
    if ($context && !empty($certstudio->templateid)) {
        \mod_certstudio\template::delete_if_unused((int) $certstudio->templateid, $context->id);
    }

    return true;
}

/**
 * Returns the features supported by this module.
 *
 * @param string $feature FEATURE_xx constant
 * @return mixed True if supported, null if unknown
 */
function certstudio_supports($feature) {
    switch ($feature) {
        case FEATURE_MOD_INTRO:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        case FEATURE_BACKUP_MOODLE2:
            return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return true;
        case FEATURE_MOD_PURPOSE:
            return MOD_PURPOSE_ASSESSMENT;
        default:
            return null;
    }
}

/**
 * Serve the files from the certstudio file areas.
 *
 * @param stdClass $course The course object
 * @param stdClass $cm The course module object
 * @param context $context The context
 * @param string $filearea The file area
 * @param array $args Extra arguments
 * @param bool $forcedownload Force download
 * @param array $options Additional options
 * @return bool False if file not found
 */
function certstudio_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    if ($context->contextlevel != CONTEXT_MODULE) {
        return false;
    }

    require_login($course, true, $cm);
    require_capability('mod/certstudio:view', $context);

    $validareas = ['image', 'bgimage', 'digitalsignature', 'userpicture', 'background', 'elementimage'];
    if (!in_array($filearea, $validareas)) {
        return false;
    }

    $itemid = array_shift($args);
    $filename = array_pop($args);
    $filepath = $args ? '/' . implode('/', $args) . '/' : '/';

    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'mod_certstudio', $filearea, $itemid, $filepath, $filename);
    if (!$file) {
        return false;
    }

    send_stored_file($file, 0, 0, $forcedownload, $options);
}

/**
 * Get font files available in the plugin.
 *
 * @return array Font definitions
 */
function certstudio_get_fonts() {
    global $CFG;

    $fontdir = $CFG->dirroot . '/mod/certstudio/fonts/';
    $fonts = [];

    $fontfiles = [
        'Roboto' => [
            'regular' => 'Roboto-Regular.ttf',
            'bold' => 'Roboto-Bold.ttf',
            'italic' => 'Roboto-Italic.ttf',
            'bolditalic' => 'Roboto-BoldItalic.ttf',
        ],
        'Open Sans' => [
            'regular' => 'OpenSans-Regular.ttf',
            'bold' => 'OpenSans-Bold.ttf',
        ],
        'Lato' => [
            'regular' => 'Lato-Regular.ttf',
            'bold' => 'Lato-Bold.ttf',
            'italic' => 'Lato-Italic.ttf',
        ],
        'Poppins' => [
            'regular' => 'Poppins-Regular.ttf',
            'bold' => 'Poppins-Bold.ttf',
        ],
        'Montserrat' => [
            'regular' => 'Montserrat-Regular.ttf',
        ],
        'Raleway' => [
            'regular' => 'Raleway-Regular.ttf',
        ],
        'Merriweather' => [
            'regular' => 'Merriweather-Regular.ttf',
            'bold' => 'Merriweather-Bold.ttf',
        ],
        'Playfair Display' => [
            'regular' => 'PlayfairDisplay-Regular.ttf',
        ],
        'Noto Sans' => [
            'regular' => 'NotoSans-Regular.ttf',
        ],
        'Noto Serif' => [
            'regular' => 'NotoSerif-Regular.ttf',
        ],
        'GFS Didot' => [
            'regular' => 'GFSDidot-Regular.ttf',
        ],
    ];

    foreach ($fontfiles as $family => $variants) {
        foreach ($variants as $style => $file) {
            $fullpath = $fontdir . $file;
            if (file_exists($fullpath)) {
                $fonts[] = [
                    'family' => $family,
                    'style' => $style,
                    'file' => $file,
                    'path' => $fullpath,
                ];
            }
        }
    }

    return $fonts;
}

/**
 * Generate a unique verification code.
 *
 * The method is determined by the plugin setting 'codegenerationmethod':
 *   0 = Upper/lower/digits random string (e.g. 6aOdbLEuoC)
 *   1 = Digits with hyphens (e.g. 0123-4567-8901)
 *
 * @return string Unique verification code.
 */
function certstudio_generate_code() {
    global $DB;

    $method = get_config('mod_certstudio', 'codegenerationmethod');

    do {
        if ($method === '1') {
            $code = sprintf('%04d-%04d-%04d', random_int(0, 9999), random_int(0, 9999), random_int(0, 9999));
        } else {
            $code = random_string(10);
        }
    } while ($DB->record_exists('certstudio_issues', ['code' => $code]));

    return $code;
}

/**
 * Reset user data for a course reset.
 *
 * @param stdClass $data The reset data
 * @return array Status array
 */
function certstudio_reset_userdata($data) {
    global $DB;
    $componentstr = get_string('modulenameplural', 'mod_certstudio');
    $status = [];
    if (!empty($data->reset_certstudio)) {
        $sql = "SELECT cert.id FROM {certstudio} cert WHERE cert.course = :courseid";
        $DB->delete_records_select('certstudio_issues', "certstudioid IN ($sql)", ['courseid' => $data->courseid]);
        // Approvals belong to the issued certificates: a request approved before the reset must not issue one afterwards.
        $DB->delete_records_select('certstudio_approval_requests', "certstudioid IN ($sql)", ['courseid' => $data->courseid]);
        $status[] = ['component' => $componentstr, 'item' => get_string('deleteissuedcertificates', 'mod_certstudio'), 'error' => false];
    }
    return $status;
}

/**
 * Add elements to the course reset form.
 *
 * @param MoodleQuickForm $mform The form
 */
function certstudio_reset_course_form_definition(&$mform) {
    $mform->addElement('header', 'certstudioheader', get_string('modulenameplural', 'mod_certstudio'));
    $mform->addElement('advcheckbox', 'reset_certstudio', get_string('deleteissuedcertificates', 'mod_certstudio'));
}

/**
 * Default values for course reset form.
 *
 * @param stdClass $course The course
 * @return array Defaults
 */
function certstudio_reset_course_form_defaults($course) {
    return ['reset_certstudio' => 1];
}

/**
 * Get view actions for participation reports.
 *
 * @return array
 */
function certstudio_get_view_actions() {
    return ['view', 'view all', 'view report'];
}

/**
 * Get post actions for participation reports.
 *
 * @return array
 */
function certstudio_get_post_actions() {
    return ['received'];
}

/**
 * Return a small object with summary information about what a user has done.
 *
 * @param stdClass $course The course
 * @param stdClass $user The user
 * @param stdClass $mod The course module
 * @param stdClass $certstudio The certstudio instance
 * @return stdClass
 */
function certstudio_user_outline($course, $user, $mod, $certstudio) {
    global $DB;
    $result = new stdClass();
    // The latest active certificate: revoked and reissued versions of it can exist too.
    $issues = $DB->get_records(
        'certstudio_issues',
        ['certstudioid' => $certstudio->id, 'userid' => $user->id, 'status' => 0],
        'timecreated DESC',
        '*',
        0,
        1
    );
    if ($issue = reset($issues)) {
        $result->info = get_string('receiveddate', 'mod_certstudio');
        $result->time = $issue->timecreated;
    } else {
        $result->info = get_string('notissued', 'mod_certstudio');
    }
    return $result;
}

/**
 * Print a detailed representation of what a user has done.
 *
 * @param stdClass $course The course
 * @param stdClass $user The user
 * @param stdClass $mod The course module
 * @param stdClass $certstudio The certstudio instance
 */
function certstudio_user_complete($course, $user, $mod, $certstudio) {
    global $DB, $OUTPUT;
    // The latest active certificate: revoked and reissued versions of it can exist too.
    $issues = $DB->get_records(
        'certstudio_issues',
        ['certstudioid' => $certstudio->id, 'userid' => $user->id, 'status' => 0],
        'timecreated DESC',
        '*',
        0,
        1
    );
    if ($issue = reset($issues)) {
        echo $OUTPUT->box_start();
        echo get_string('receiveddate', 'mod_certstudio') . ": ";
        echo userdate($issue->timecreated);
        echo $OUTPUT->box_end();
    } else {
        print_string('notissued', 'mod_certstudio');
    }
}

/**
 * Extend the settings navigation with certstudio nodes.
 *
 * @param settings_navigation $settings The settings navigation
 * @param navigation_node $certstudionode The certstudio navigation node
 */
function certstudio_extend_settings_navigation(settings_navigation $settings, navigation_node $certstudionode) {
    // No additional navigation nodes needed — editing and verification
    // are accessible from the activity's main view page.
    return $certstudionode->trim_if_empty();
}

/**
 * Add "My Certificates" node to the user profile navigation tree.
 *
 * @param core_user\output\myprofile\tree $tree The myprofile tree
 * @param stdClass $user The user
 * @param bool $iscurrentuser Whether this is the current user
 * @param stdClass $course The course
 */
function mod_certstudio_myprofile_navigation(core_user\output\myprofile\tree $tree, $user, $iscurrentuser, $course) {
    global $USER;
    if (($user->id != $USER->id) && !has_capability('mod/certstudio:viewallcertificates', context_system::instance())) {
        return;
    }
    $params = ['userid' => $user->id];
    if ($course) {
        $params['course'] = $course->id;
    }
    $url = new moodle_url('/mod/certstudio/my_certificates.php', $params);
    $node = new core_user\output\myprofile\node(
        'miscellaneous',
        'mycertstudio',
        get_string('mycertificates', 'mod_certstudio'),
        null,
        $url
    );
    $tree->add_node($node);
}
