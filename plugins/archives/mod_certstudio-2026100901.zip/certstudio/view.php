<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate Studio view page.
 *
 * @package    mod_certstudio
 * @copyright  2013 Mark Nelson <markn@moodle.com>
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

$id = optional_param('id', 0, PARAM_INT); // Course module id.
$c = optional_param('c', 0, PARAM_INT);   // Instance id.
$action = optional_param('action', '', PARAM_ALPHA);

if ($id) {
    $cm = get_coursemodule_from_id('certstudio', $id, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
    $certstudio = $DB->get_record('certstudio', ['id' => $cm->instance], '*', MUST_EXIST);
} else {
    $certstudio = $DB->get_record('certstudio', ['id' => $c], '*', MUST_EXIST);
    $course = $DB->get_record('course', ['id' => $certstudio->course], '*', MUST_EXIST);
    $cm = get_coursemodule_from_instance('certstudio', $certstudio->id, $course->id, false, MUST_EXIST);
}

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/certstudio:view', $context);

$PAGE->set_url('/mod/certstudio/view.php', ['id' => $cm->id]);
$PAGE->set_title(format_string($certstudio->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);

// Trigger course module viewed event.
$event = \mod_certstudio\event\course_module_viewed::create([
    'objectid' => $certstudio->id,
    'context' => $context,
]);
$event->add_record_snapshot('course', $course);
$event->add_record_snapshot('certstudio', $certstudio);
$event->trigger();

// Mark the activity as viewed for the "view" completion condition.
require_once($CFG->libdir . '/completionlib.php');
$completion = new completion_info($course);
$completion->set_module_viewed($cm);

// Build download filename helper - resolves placeholders in the custom filename pattern.
$resolvefilename = function ($pattern, $username = '', $coursename = '') use ($certstudio, $course) {
    if (empty($pattern)) {
        $pattern = $certstudio->name;
    }
    $replacements = [
        '{coursename}' => $course->fullname,
        '{courseshortname}' => $course->shortname,
        '{studentname}' => $username,
        '{date}' => userdate(time(), '%Y-%m-%d'),
        '{activityname}' => $certstudio->name,
    ];
    $result = str_replace(array_keys($replacements), array_values($replacements), $pattern);
    return preg_replace('/[^a-zA-Z0-9_\-\p{L}\p{N}]/u', '_', $result);
};
$downloadpattern = !empty($certstudio->downloadfilename)
    ? $certstudio->downloadfilename
    : (get_config('mod_certstudio', 'defaultfilename') ?: '');

// Helper: run a callable suppressing all output and PHP errors so redirect() works cleanly.
// Moodle's redirect() checks DEBUGGING_PRINTED, error_get_last(), and ob buffers.
// The debugging() function defines DEBUGGING_PRINTED when $CFG->debugdisplay is on,
// and once defined, a PHP constant cannot be undefined - so we must prevent it from
// being defined in the first place by temporarily disabling $CFG->debugdisplay.
$runsilent = function (callable $fn) {
    global $CFG;
    $olddebug = $CFG->debug ?? null;
    $olddisplay = $CFG->debugdisplay ?? null;
    $CFG->debug = 0;
    $CFG->debugdisplay = 0;
    ob_start();
    $fn();
    ob_end_clean();
    $CFG->debug = $olddebug;
    $CFG->debugdisplay = $olddisplay;
    // Clear error_get_last() so redirect() won't see stale errors.
    @trigger_error('', E_USER_NOTICE);
};

// Handle certificate request action (approval flow).
if ($action === 'request' && confirm_sesskey() && $certstudio->approvalenabled) {
    // Same eligibility rules as issuing, except the approval itself.
    $reason = \mod_certstudio\certificate::can_issue($certstudio, $cm->id, $USER->id, false);
    if ($reason !== null) {
        redirect(
            new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]),
            get_string('cannotissue_' . $reason, 'mod_certstudio'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }
    $approval = new \mod_certstudio\approval();
    $runsilent(function () use ($approval, $certstudio, $USER) {
        $approval->request($certstudio->id, $USER->id);
    });
    redirect(new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]));
}

// Handle direct certificate issuance (no-approval flow).
if ($action === 'getcert' && confirm_sesskey() && !has_capability('mod/certstudio:manage', context_module::instance($cm->id))) {
    $certificate = new \mod_certstudio\certificate();
    $existing = $certificate->get_issues_for_user($certstudio->id, $USER->id);
    if (empty($existing)) {
        // The page hides the button when the user is not eligible; enforce the same rules here.
        $reason = \mod_certstudio\certificate::can_issue($certstudio, $cm->id, $USER->id);
        if ($reason !== null) {
            redirect(
                new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]),
                get_string('cannotissue_' . $reason, 'mod_certstudio'),
                null,
                \core\output\notification::NOTIFY_ERROR
            );
        }
        $runsilent(function () use ($certificate, $certstudio, $USER) {
            $certificate->issue($certstudio->id, $USER->id);
        });
    }
    redirect(new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]));
}

// Handle CSV export.
if ($action === 'exportcsv' && has_capability('mod/certstudio:viewallcertificates', $context)) {
    $issues = $DB->get_records_sql(
        "SELECT ci.id, ci.code, ci.timecreated, ci.status, u.firstname, u.lastname, u.email
         FROM {certstudio_issues} ci
         JOIN {user} u ON u.id = ci.userid
         WHERE ci.certstudioid = ? AND ci.status = 0
         ORDER BY ci.timecreated DESC",
        [$certstudio->id]
    );
    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $certstudio->name) . '_certificates.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    // BOM for Excel UTF-8.
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, [
        get_string('student', 'mod_certstudio'),
        get_string('email'),
        get_string('verificationcode', 'mod_certstudio'),
        get_string('dateissued', 'mod_certstudio'),
    ], ',', '"', '\\');
    foreach ($issues as $issue) {
        fputcsv($out, [
            $issue->firstname . ' ' . $issue->lastname,
            $issue->email,
            $issue->code,
            userdate($issue->timecreated, '%Y-%m-%d %H:%M'),
        ], ',', '"', '\\');
    }
    fclose($out);
    exit;
}

// Handle XLSX export.
if ($action === 'exportxlsx' && has_capability('mod/certstudio:viewallcertificates', $context)) {
    require_once($CFG->libdir . '/excellib.class.php');
    $issues = $DB->get_records_sql(
        "SELECT ci.id, ci.code, ci.timecreated, ci.status, u.firstname, u.lastname, u.email
         FROM {certstudio_issues} ci
         JOIN {user} u ON u.id = ci.userid
         WHERE ci.certstudioid = ? AND ci.status = 0
         ORDER BY ci.timecreated DESC",
        [$certstudio->id]
    );
    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $certstudio->name) . '_certificates';
    $workbook = new MoodleExcelWorkbook('-');
    $workbook->send($filename . '.xlsx');
    $sheet = $workbook->add_worksheet(get_string('issuedcertificates', 'mod_certstudio'));

    // Header row with bold.
    $boldformat = $workbook->add_format(['bold' => 1]);
    $headers = [
        get_string('student', 'mod_certstudio'),
        get_string('email'),
        get_string('verificationcode', 'mod_certstudio'),
        get_string('dateissued', 'mod_certstudio'),
    ];
    foreach ($headers as $col => $header) {
        $sheet->write_string(0, $col, $header, $boldformat);
    }

    $row = 1;
    foreach ($issues as $issue) {
        $sheet->write_string($row, 0, $issue->firstname . ' ' . $issue->lastname);
        $sheet->write_string($row, 1, $issue->email);
        $sheet->write_string($row, 2, $issue->code);
        $sheet->write_string($row, 3, userdate($issue->timecreated, '%Y-%m-%d %H:%M'));
        $row++;
    }
    $workbook->close();
    exit;
}

// Handle batch ZIP download (server-side PDF generation).
if ($action === 'exportzip' && has_capability('mod/certstudio:viewallcertificates', $context)) {
    $issues = $DB->get_records_sql(
        "SELECT ci.id, ci.userid, ci.code, ci.timecreated, u.firstname, u.lastname
         FROM {certstudio_issues} ci
         JOIN {user} u ON u.id = ci.userid
         WHERE ci.certstudioid = ? AND ci.status = 0
         ORDER BY ci.timecreated DESC",
        [$certstudio->id]
    );

    if (!empty($issues)) {
        $certificate = new \mod_certstudio\certificate();
        $zipname = preg_replace('/[^a-zA-Z0-9_-]/', '_', $certstudio->name) . '_certificates.zip';
        $tempdir = make_temp_directory('certstudio_zip');
        $zippath = $tempdir . '/' . uniqid('zip_') . '.zip';

        $zip = new ZipArchive();
        if ($zip->open($zippath, ZipArchive::CREATE) === true) {
            foreach ($issues as $issue) {
                $fullname = $issue->firstname . ' ' . $issue->lastname;
                $fname = $resolvefilename($downloadpattern, $fullname) ?: ($certstudio->name . '_' . $issue->firstname . '_' . $issue->lastname);
                $fname = preg_replace('/[^a-zA-Z0-9_\-\p{L}\p{N}]/u', '_', $fname);

                try {
                    $templatedata = $certificate->get_template_data($certstudio->id, $issue->userid, $issue->code);
                    $pdfcontent = \mod_certstudio\pdfgenerator::generate($templatedata);
                    $zip->addFromString($fname . '.pdf', $pdfcontent);
                } catch (\Exception $e) {
                    debugging('PDF generation failed for user ' . $issue->userid . ': ' . $e->getMessage());
                }
            }
            $zip->close();

            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $zipname . '"');
            header('Content-Length: ' . filesize($zippath));
            readfile($zippath);
            unlink($zippath);
            exit;
        }
    }
}

// Handle single revoke action.
if ($action === 'revoke' && confirm_sesskey() && has_capability('mod/certstudio:manage', $context)) {
    $issueid = required_param('issueid', PARAM_INT);
    $reason = optional_param('reason', '', PARAM_TEXT);
    $issue = $DB->get_record('certstudio_issues', ['id' => $issueid, 'certstudioid' => $certstudio->id]);
    if ($issue) {
        \mod_certstudio\certificate::revoke($issueid, $reason);
    }
    redirect(new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]));
}

// Handle single reissue action.
if ($action === 'reissue' && confirm_sesskey() && has_capability('mod/certstudio:manage', $context)) {
    $issueid = required_param('issueid', PARAM_INT);
    $issue = $DB->get_record('certstudio_issues', ['id' => $issueid, 'certstudioid' => $certstudio->id]);
    if ($issue) {
        \mod_certstudio\certificate::reissue($issueid);
    }
    redirect(new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]));
}

// Handle single email action.
if ($action === 'emailcert' && confirm_sesskey() && has_capability('mod/certstudio:manage', $context)) {
    $issueid = required_param('issueid', PARAM_INT);
    $issue = $DB->get_record('certstudio_issues', ['id' => $issueid, 'certstudioid' => $certstudio->id]);
    if ($issue) {
        $runsilent(function () use ($issueid) {
            \mod_certstudio\certificate::email_certificate($issueid);
        });
    }
    redirect(
        new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]),
        get_string('emailsent', 'mod_certstudio'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

// Handle single hard-delete action.
if ($action === 'deleteissue' && confirm_sesskey() && has_capability('mod/certstudio:manage', $context)) {
    $issueid = required_param('issueid', PARAM_INT);
    $issue = $DB->get_record('certstudio_issues', ['id' => $issueid, 'certstudioid' => $certstudio->id]);
    if ($issue) {
        \mod_certstudio\certificate::delete_issue($issueid);
    }
    redirect(new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]));
}

// Handle bulk operations.
if ($action === 'bulk' && confirm_sesskey() && has_capability('mod/certstudio:manage', $context)) {
    $bulkaction = required_param('bulkaction', PARAM_ALPHA);
    $issueids = optional_param_array('issueids', [], PARAM_INT);
    $bulkreason = optional_param('bulkreason', '', PARAM_TEXT);

    if (!empty($issueids)) {
        $count = 0;
        foreach ($issueids as $iid) {
            $issue = $DB->get_record('certstudio_issues', ['id' => $iid, 'certstudioid' => $certstudio->id]);
            if (!$issue) {
                continue;
            }
            switch ($bulkaction) {
                case 'revoke':
                    if ((int) ($issue->status ?? 0) === \mod_certstudio\certificate::STATUS_ACTIVE) {
                        \mod_certstudio\certificate::revoke($iid, $bulkreason);
                        $count++;
                    }
                    break;
                case 'reissue':
                    \mod_certstudio\certificate::reissue($iid);
                    $count++;
                    break;
                case 'email':
                    $runsilent(function () use ($iid) {
                        \mod_certstudio\certificate::email_certificate($iid);
                    });
                    $count++;
                    break;
                case 'delete':
                    \mod_certstudio\certificate::delete_issue($iid);
                    $count++;
                    break;
            }
        }
        $msg = get_string('bulkoperationcomplete', 'mod_certstudio', (object) [
            'count' => $count,
            'action' => get_string('bulk' . $bulkaction, 'mod_certstudio'),
        ]);
        redirect(
            new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]),
            $msg,
            null,
            \core\output\notification::NOTIFY_SUCCESS
        );
    }
    redirect(new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]));
}

// Determine capabilities early.
$canmanage = has_capability('mod/certstudio:manage', $context);
$canapprove = has_capability('mod/certstudio:approvecertificate', $context);
$canviewall = has_capability('mod/certstudio:viewallcertificates', $context);

// Pre-load jsPDF and QRCode BEFORE header output so they go into <head>.
$PAGE->requires->js(new moodle_url('/mod/certstudio/thirdparty/jspdf/jspdf.umd.min.js'), true);
$PAGE->requires->js(new moodle_url('/mod/certstudio/thirdparty/qrcode/qrcode.min.js'), true);

// Check if we need viewpage JS (admin with issues).
if ($canviewall) {
    $issuecount = $DB->count_records('certstudio_issues', ['certstudioid' => $certstudio->id]);
    if ($issuecount > 0) {
        $PAGE->requires->js_call_amd('mod_certstudio/viewpage', 'init', [
            $cm->id,
        ]);
    }
}

// Check if student needs download button.
if (!$canmanage) {
    $PAGE->requires->js_call_amd('mod_certstudio/renderer', 'initDownloadButton', ['#certstudio-download-btn']);
}

echo $OUTPUT->header();

// Show intro.
if ($certstudio->intro) {
    echo $OUTPUT->box(format_module_intro('certstudio', $certstudio, $cm->id), 'generalbox', 'intro');
}

// Show current template info with change button (managers only).
if ($canmanage && !empty($certstudio->templateid)) {
    $templaterecord = $DB->get_record('certstudio_templates', ['id' => $certstudio->templateid]);
    if ($templaterecord) {
        echo '<div class="certstudio-template-badge mb-3">';
        echo '<i class="fa fa-file-text-o"></i> Template: <strong>' . format_string($templaterecord->name) . '</strong>';
        if ($canmanage) {
            $galleryurl = new moodle_url('/mod/certstudio/gallery.php', ['id' => $cm->id]);
            echo ' <a href="' . $galleryurl->out(false) . '" class="btn btn-sm btn-outline-primary ml-2" style="font-size:12px;padding:2px 10px;border-radius:6px;">'
                . '<i class="fa fa-exchange"></i> Change</a>';
        }
        echo '</div>';
    }
}

// Teacher/manager view.
if ($canmanage) {
    echo '<div class="certstudio-manager-actions d-flex gap-2 mb-3 flex-wrap align-items-center">';
    $editurl = new moodle_url('/mod/certstudio/edit.php', ['id' => $cm->id]);
    echo '<a href="' . $editurl->out(false) . '" class="btn btn-primary"><i class="fa fa-pencil"></i> '
        . get_string('edittemplate', 'mod_certstudio') . '</a>';
    $galleryurl = new moodle_url('/mod/certstudio/gallery.php', ['id' => $cm->id]);
    echo '<a href="' . $galleryurl->out(false) . '" class="btn btn-outline-secondary"><i class="fa fa-th"></i> '
        . get_string('templategallery', 'mod_certstudio') . '</a>';
    $bulkurl = new moodle_url('/mod/certstudio/bulkissue.php', ['id' => $cm->id]);
    echo '<a href="' . $bulkurl->out(false) . '" class="btn btn-outline-success"><i class="fa fa-users"></i> '
        . get_string('bulkissue', 'mod_certstudio') . '</a>';
    echo '</div>';
}

if ($canapprove && $certstudio->approvalenabled) {
    $approveurl = new moodle_url('/mod/certstudio/approve.php', ['id' => $cm->id]);
    echo html_writer::div(
        $OUTPUT->single_button($approveurl, get_string('manageapprovals', 'mod_certstudio'), 'get'),
        'mb-3'
    );
}

// Show issued certificates list for managers.
if ($canviewall) {
    // Filtering and pagination params.
    $isearch = optional_param('isearch', '', PARAM_TEXT);
    $istatus = optional_param('istatus', '', PARAM_ALPHA);
    $ipage = optional_param('ipage', 0, PARAM_INT);
    $iperpage = 20;

    // Build query with optional search and status filter.
    $searchsql = '';
    $searchparams = [$certstudio->id];
    if (!empty($isearch)) {
        $searchsql .= " AND (CONCAT(u.firstname, ' ', u.lastname) LIKE ? OR u.email LIKE ? OR ci.code LIKE ?)";
        $like = '%' . $DB->sql_like_escape($isearch) . '%';
        $searchparams[] = $like;
        $searchparams[] = $like;
        $searchparams[] = $like;
    }
    if ($istatus === 'active') {
        $searchsql .= " AND ci.status = 0";
    } else if ($istatus === 'revoked') {
        $searchsql .= " AND ci.status = 1";
    }

    $filteredcount = $DB->count_records_sql(
        "SELECT COUNT(ci.id) FROM {certstudio_issues} ci
         JOIN {user} u ON u.id = ci.userid
         WHERE ci.certstudioid = ?" . $searchsql,
        $searchparams
    );

    $activecount = $DB->count_records('certstudio_issues', ['certstudioid' => $certstudio->id, 'status' => 0]);
    $revokedcount = $DB->count_records('certstudio_issues', ['certstudioid' => $certstudio->id, 'status' => 1]);

    echo '<div class="certstudio-issues-section mt-4">';
    echo '<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap">';
    echo '<h4 class="mb-0"><i class="fa fa-certificate text-primary mr-2"></i> '
        . get_string('issuedcertificates', 'mod_certstudio')
        . ' <span class="badge badge-secondary ml-1">' . $issuecount . '</span>';
    if ($revokedcount > 0) {
        echo ' <span class="badge badge-danger ml-1" title="' . get_string('revoked', 'mod_certstudio') . '">' . $revokedcount . ' ' . get_string('revoked', 'mod_certstudio') . '</span>';
    }
    echo '</h4>';
    if ($issuecount > 0) {
        echo '<div class="d-flex gap-1">';
        $zipurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'action' => 'exportzip']);
        echo '<a href="' . $zipurl->out(false) . '" class="btn btn-sm btn-outline-info" title="'
            . get_string('batchdownload', 'mod_certstudio') . '">'
            . '<i class="fa fa-file-archive-o"></i> ZIP</a>';
        $csvurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'action' => 'exportcsv']);
        echo '<a href="' . $csvurl->out(false) . '" class="btn btn-sm btn-outline-success" title="' . get_string('exportcsv', 'mod_certstudio') . '">'
            . '<i class="fa fa-file-text-o"></i> CSV</a>';
        $xlsxurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'action' => 'exportxlsx']);
        echo '<a href="' . $xlsxurl->out(false) . '" class="btn btn-sm btn-outline-success" title="' . get_string('exportxlsx', 'mod_certstudio') . '">'
            . '<i class="fa fa-file-excel-o"></i> XLSX</a>';
        echo '</div>';
    }
    echo '</div>';

    if ($issuecount > 0) {
        // Search and status filter form.
        $searchurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id]);
        echo '<form method="get" action="' . $searchurl->out(false) . '" class="mb-3">';
        echo '<input type="hidden" name="id" value="' . $cm->id . '">';
        echo '<div class="d-flex gap-2 flex-wrap align-items-center">';
        echo '<div class="input-group" style="max-width:400px;">';
        echo '<input type="text" name="isearch" class="form-control form-control-sm" '
            . 'placeholder="' . get_string('search') . ' (' . get_string('student', 'mod_certstudio')
            . ', email, code)..." value="' . s($isearch) . '">';
        echo '<div class="input-group-append">';
        echo '<button type="submit" class="btn btn-sm btn-outline-secondary"><i class="fa fa-search"></i></button>';
        echo '</div></div>';
        // Status filter buttons.
        echo '<div class="btn-group btn-group-sm">';
        $allclass = empty($istatus) ? 'btn-secondary' : 'btn-outline-secondary';
        $activeclass = $istatus === 'active' ? 'btn-success' : 'btn-outline-success';
        $revokedclass = $istatus === 'revoked' ? 'btn-danger' : 'btn-outline-danger';
        echo '<a href="' . (new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'isearch' => $isearch]))->out(false)
            . '" class="btn ' . $allclass . '">' . get_string('all') . ' (' . $issuecount . ')</a>';
        echo '<a href="' . (new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'isearch' => $isearch, 'istatus' => 'active']))->out(false)
            . '" class="btn ' . $activeclass . '"><i class="fa fa-check"></i> ' . $activecount . '</a>';
        if ($revokedcount > 0) {
            echo '<a href="' . (new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'isearch' => $isearch, 'istatus' => 'revoked']))->out(false)
                . '" class="btn ' . $revokedclass . '"><i class="fa fa-ban"></i> ' . $revokedcount . '</a>';
        }
        echo '</div>';
        if (!empty($isearch) || !empty($istatus)) {
            echo '<a href="' . $searchurl->out(false) . '" class="btn btn-sm btn-outline-danger" title="' . get_string('clearfilters', 'mod_certstudio') . '"><i class="fa fa-times"></i> ' . get_string('clearfilters', 'mod_certstudio') . '</a>';
        }
        echo '</div></form>';

        $issues = $DB->get_records_sql(
            "SELECT ci.id, ci.userid, ci.code, ci.timecreated, ci.status, ci.version, ci.emailed,
                    ci.revokedat, ci.revokereason, ci.expirydate,
                    u.firstname, u.lastname, u.email
             FROM {certstudio_issues} ci
             JOIN {user} u ON u.id = ci.userid
             WHERE ci.certstudioid = ?" . $searchsql . "
             ORDER BY ci.status ASC, ci.timecreated DESC",
            $searchparams,
            $ipage * $iperpage,
            $iperpage
        );

        // Prepare template data for admin download buttons.
        $certificate = new \mod_certstudio\certificate();

        // Bulk operations form wrapper.
        $bulkurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'action' => 'bulk']);
        echo '<form method="post" action="' . $bulkurl->out(false) . '" id="certstudio-bulk-form">';
        echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';

        echo '<div class="table-responsive">';
        echo '<table class="certstudio-issues-table" id="certstudio-issues-table">';
        echo '<thead><tr>';
        echo '<th style="width:30px;"><input type="checkbox" id="certstudio-selectall" title="' . get_string('selectall', 'mod_certstudio') . '"></th>';
        echo '<th class="certstudio-sortable" data-col="1"><i class="fa fa-user"></i> '
            . get_string('student', 'mod_certstudio') . ' <i class="fa fa-sort text-muted"></i></th>';
        echo '<th class="certstudio-sortable" data-col="2"><i class="fa fa-key"></i> ' . get_string('verificationcode', 'mod_certstudio')
            . ' <i class="fa fa-sort text-muted"></i></th>';
        echo '<th class="certstudio-sortable" data-col="3"><i class="fa fa-info-circle"></i> '
            . get_string('status') . ' <i class="fa fa-sort text-muted"></i></th>';
        echo '<th class="certstudio-sortable" data-col="4"><i class="fa fa-calendar"></i> '
            . get_string('dateissued', 'mod_certstudio') . ' <i class="fa fa-sort text-muted"></i></th>';
        echo '<th class="text-center">' . get_string('actions', 'mod_certstudio') . '</th>';
        echo '</tr></thead><tbody>';
        foreach ($issues as $issue) {
            $fullname = $issue->firstname . ' ' . $issue->lastname;
            $isrevoked = ((int) ($issue->status ?? 0) === \mod_certstudio\certificate::STATUS_REVOKED);
            $isexpired = (!empty($issue->expirydate) && $issue->expirydate < time());
            $rowclass = $isrevoked ? ' class="table-danger"' : ($isexpired ? ' class="table-warning"' : '');

            echo '<tr' . $rowclass . '>';
            echo '<td><input type="checkbox" name="issueids[]" value="' . $issue->id . '" class="certstudio-bulk-cb"></td>';
            echo '<td><strong>' . s($fullname) . '</strong><br><small class="text-muted">' . s($issue->email) . '</small></td>';
            echo '<td><code class="certstudio-code">' . s($issue->code) . '</code>';
            if ((int) ($issue->version ?? 1) > 1) {
                echo ' <span class="badge badge-info">v' . (int) $issue->version . '</span>';
            }
            echo '</td>';

            // Status column.
            echo '<td>';
            if ($isrevoked) {
                echo '<span class="badge badge-danger"><i class="fa fa-ban"></i> ' . get_string('revoked', 'mod_certstudio') . '</span>';
                if (!empty($issue->revokedat)) {
                    echo '<br><small class="text-muted">' . userdate($issue->revokedat, get_string('strftimedatetimeshort', 'langconfig')) . '</small>';
                }
            } else if ($isexpired) {
                echo '<span class="badge badge-warning"><i class="fa fa-clock-o"></i> '
                    . get_string('expired', 'mod_certstudio') . '</span>';
            } else {
                echo '<span class="badge badge-success"><i class="fa fa-check"></i> ' . get_string('active', 'mod_certstudio') . '</span>';
            }
            if (!empty($issue->emailed) && (int) $issue->emailed === 1) {
                echo ' <span class="badge badge-light" title="' . get_string('emailed', 'mod_certstudio') . '"><i class="fa fa-envelope-o"></i></span>';
            }
            echo '</td>';

            echo '<td data-sort="' . $issue->timecreated . '">'
                . userdate($issue->timecreated, get_string('strftimedatetimeshort', 'langconfig')) . '</td>';

            // Actions column.
            echo '<td class="text-center text-nowrap certstudio-issue-actions">';
            if (!$isrevoked) {
                // Download button.
                try {
                    $usertemplatedata = $certificate->get_template_data($certstudio->id, $issue->userid, $issue->code);
                    $userjson = json_encode($usertemplatedata, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
                    $userfname = $resolvefilename($downloadpattern, $fullname) ?: ($certstudio->name . '_certificate_' . $issue->firstname . '_' . $issue->lastname);
                    echo '<button class="btn btn-sm btn-outline-primary certstudio-admin-download mr-1" '
                        . 'data-templatedata="' . s($userjson) . '" '
                        . 'data-code="' . s($issue->code) . '" '
                        . 'data-filename="' . s($userfname) . '" '
                        . 'title="' . get_string('downloadpdf', 'mod_certstudio') . '"><i class="fa fa-download"></i></button>';
                } catch (\Exception $e) {
                    // Skip download button if template data fails.
                    unset($e);
                }

                // Email button.
                $emailurl = new moodle_url('/mod/certstudio/view.php', [
                    'id' => $cm->id, 'action' => 'emailcert', 'issueid' => $issue->id, 'sesskey' => sesskey(),
                ]);
                echo '<a href="' . $emailurl->out(false) . '" class="btn btn-sm btn-outline-info mr-1" '
                    . 'title="' . get_string('emailcertificate', 'mod_certstudio') . '">'
                    . '<i class="fa fa-envelope"></i></a>';

                // Revoke button.
                $revokeurl = new moodle_url('/mod/certstudio/view.php', [
                    'id' => $cm->id, 'action' => 'revoke', 'issueid' => $issue->id, 'sesskey' => sesskey(),
                ]);
                echo '<a href="' . $revokeurl->out(false) . '" class="btn btn-sm btn-outline-warning mr-1" '
                    . 'onclick="return confirm(\'' . get_string('confirmrevoke', 'mod_certstudio') . '\');" '
                    . 'title="' . get_string('revokecertificate', 'mod_certstudio') . '">'
                    . '<i class="fa fa-ban"></i></a>';
            } else {
                // Reissue button for revoked certs.
                $reissueurl = new moodle_url('/mod/certstudio/view.php', [
                    'id' => $cm->id, 'action' => 'reissue', 'issueid' => $issue->id, 'sesskey' => sesskey(),
                ]);
                echo '<a href="' . $reissueurl->out(false) . '" class="btn btn-sm btn-outline-success mr-1" '
                    . 'title="' . get_string('reissue', 'mod_certstudio') . '">'
                    . '<i class="fa fa-refresh"></i></a>';
            }

            // Delete button (always available).
            $deleteurl = new moodle_url('/mod/certstudio/view.php', [
                'id' => $cm->id, 'action' => 'deleteissue', 'issueid' => $issue->id, 'sesskey' => sesskey(),
            ]);
            echo '<a href="' . $deleteurl->out(false) . '" class="btn btn-sm btn-outline-danger" '
                . 'onclick="return confirm(\'' . get_string('confirmdeleteissue', 'mod_certstudio') . '\');" '
                . 'title="' . get_string('delete') . '">'
                . '<i class="fa fa-trash"></i></a>';

            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '</div>';

        // Bulk operations bar.
        echo '<div class="certstudio-bulk-bar mt-2 mb-3 p-2 bg-light rounded d-flex align-items-center gap-2 flex-wrap">';
        echo '<strong><i class="fa fa-check-square-o"></i> ' . get_string('bulkactions', 'mod_certstudio') . ':</strong>';
        echo '<select name="bulkaction" class="form-control form-control-sm" style="width:auto;">';
        echo '<option value="revoke">' . get_string('bulkrevoke', 'mod_certstudio') . '</option>';
        echo '<option value="reissue">' . get_string('bulkreissue', 'mod_certstudio') . '</option>';
        echo '<option value="email">' . get_string('bulkemail', 'mod_certstudio') . '</option>';
        echo '<option value="delete">' . get_string('bulkdelete', 'mod_certstudio') . '</option>';
        echo '</select>';
        echo '<input type="text" name="bulkreason" class="form-control form-control-sm" style="width:200px;" '
            . 'placeholder="' . get_string('reason', 'mod_certstudio') . ' (' . get_string('optional', 'mod_certstudio') . ')">';
        echo '<button type="submit" class="btn btn-sm btn-primary" '
            . 'onclick="return confirm(\'' . get_string('confirmbulk', 'mod_certstudio') . '\');">'
            . '<i class="fa fa-cog"></i> ' . get_string('apply', 'mod_certstudio') . '</button>';
        echo '</div>';
        echo '</form>';

        // Pagination.
        if ($filteredcount > $iperpage) {
            $pagingurl = new moodle_url('/mod/certstudio/view.php', ['id' => $cm->id, 'isearch' => $isearch, 'istatus' => $istatus]);
            echo $OUTPUT->paging_bar($filteredcount, $ipage, $iperpage, $pagingurl, 'ipage');
        }

        // Select all + column sorting JS.
        echo '<script>
        document.getElementById("certstudio-selectall").addEventListener("change", function() {
            document.querySelectorAll(".certstudio-bulk-cb").forEach(function(cb) { cb.checked = this.checked; }.bind(this));
        });
        (function() {
            var table = document.getElementById("certstudio-issues-table");
            if (!table) return;
            var sortState = {};
            table.querySelectorAll(".certstudio-sortable").forEach(function(th) {
                th.style.cursor = "pointer";
                th.addEventListener("click", function() {
                    var col = parseInt(th.getAttribute("data-col"));
                    var asc = sortState[col] !== "asc";
                    sortState[col] = asc ? "asc" : "desc";
                    // Reset all sort icons.
                    table.querySelectorAll(".certstudio-sortable .fa-sort, .certstudio-sortable .fa-sort-asc, .certstudio-sortable .fa-sort-desc").forEach(function(icon) {
                        icon.className = "fa fa-sort text-muted";
                    });
                    // Set active icon.
                    var icon = th.querySelector(".fa-sort, .fa-sort-asc, .fa-sort-desc");
                    if (icon) icon.className = "fa fa-sort-" + (asc ? "asc" : "desc");
                    // Sort rows.
                    var tbody = table.querySelector("tbody");
                    var rows = Array.from(tbody.querySelectorAll("tr"));
                    rows.sort(function(a, b) {
                        var cellA = a.cells[col], cellB = b.cells[col];
                        var vA, vB;
                        if (cellA.hasAttribute("data-sort")) {
                            vA = parseFloat(cellA.getAttribute("data-sort"));
                            vB = parseFloat(cellB.getAttribute("data-sort"));
                        } else {
                            vA = (cellA.textContent || "").trim().toLowerCase();
                            vB = (cellB.textContent || "").trim().toLowerCase();
                        }
                        if (vA < vB) return asc ? -1 : 1;
                        if (vA > vB) return asc ? 1 : -1;
                        return 0;
                    });
                    rows.forEach(function(row) { tbody.appendChild(row); });
                });
            });
        })();
        </script>';
    } else {
        echo '<div class="alert alert-light text-center"><i class="fa fa-info-circle"></i> No certificates have been issued yet.</div>';
    }
    echo '</div>';
}

// Student view.
if (!$canmanage) {
    $certificate = new \mod_certstudio\certificate();
    $existingissue = $certificate->get_issues_for_user($certstudio->id, $USER->id);

    // Check required time in course (lifetime total).
    $requiredtime = (int) get_config('mod_certstudio', 'requiredtime');
    $hasmetrequiredtime = true;
    if ($requiredtime > 0 && empty($existingissue)) {
        $minutesspent = \mod_certstudio\certificate::get_minutes_spent($course->id, $USER->id);
        if ($minutesspent < $requiredtime) {
            $hasmetrequiredtime = false;
            echo $OUTPUT->notification(
                get_string('requiredtimenotmet', 'mod_certstudio', [
                    'required' => $requiredtime,
                    'spent' => $minutesspent,
                ]),
                'warning'
            );
        }
    }

    // Helper: render download button with proper data.
    $renderdownload = function ($issue) use ($certificate, $certstudio, $USER, $PAGE, $cm, $resolvefilename, $downloadpattern) {
        $templatedata = $certificate->get_template_data($certstudio->id, $USER->id, $issue->code);
        $templatejson = json_encode($templatedata);
        $fullname = fullname($USER);
        $filename = $resolvefilename($downloadpattern, $fullname) ?: ($certstudio->name . '_certificate');

        echo html_writer::div(
            html_writer::tag(
                'button',
                '<i class="fa fa-download"></i> ' . get_string('downloadcertificate', 'mod_certstudio'),
                [
                    'class' => 'btn btn-primary',
                    'id' => 'certstudio-download-btn',
                    'data-templatedata' => $templatejson,
                    'data-code' => $issue->code,
                    'data-filename' => $filename,
                ]
            ),
            'mb-3'
        );
    };

    // Also check for revoked certificates to show appropriate message.
    $revokedissues = $certificate->get_issues_for_user($certstudio->id, $USER->id, false);
    $hasrevokedonly = empty($existingissue) && !empty($revokedissues);

    if (!empty($existingissue)) {
        $issue = reset($existingissue);

        // Show version info if renewed.
        if (!empty($issue->version) && (int) $issue->version > 1) {
            echo html_writer::tag(
                'p',
                '<i class="fa fa-refresh"></i> ' . get_string('certificateversion', 'mod_certstudio', (int) $issue->version),
                ['class' => 'text-info small']
            );
        }

        echo html_writer::tag('p', get_string(
            'certificateissued',
            'mod_certstudio',
            userdate($issue->timecreated)
        ));

        // Show expiry info.
        if (!empty($issue->expirydate)) {
            $isexpired = ($issue->expirydate < time());
            if ($isexpired) {
                echo $OUTPUT->notification(
                    get_string('certificateexpired', 'mod_certstudio', userdate($issue->expirydate)),
                    'warning'
                );
            } else {
                echo html_writer::tag(
                    'p',
                    '<i class="fa fa-clock-o"></i> ' . get_string('certificateexpires', 'mod_certstudio', userdate($issue->expirydate)),
                    ['class' => 'text-info small']
                );
            }
        }

        $renderdownload($issue);

        // Verify certificate link.
        $showcaseurl = new moodle_url('/mod/certstudio/showcase.php', ['code' => $issue->code]);
        echo '<a href="' . $showcaseurl->out(false) . '" target="_blank" class="btn btn-outline-info mb-2 mr-2">'
            . '<i class="fa fa-shield"></i> ' . get_string('verifycertificate', 'mod_certstudio') . '</a>';

        echo html_writer::tag('p', get_string('verificationcode', 'mod_certstudio') . ': ' .
            html_writer::tag('code', $issue->code), ['class' => 'text-muted small']);

        // LinkedIn "Add to Profile" + Social sharing buttons.
        $verifyurl = (new moodle_url('/mod/certstudio/showcase.php', ['code' => $issue->code]))->out(false);
        $certname = format_string($certstudio->name);
        $orgname = format_string($SITE->fullname);
        $issuedate = date('Y-m', $issue->timecreated);
        $issueyear = date('Y', $issue->timecreated);
        $issuemonth = date('m', $issue->timecreated);

        echo '<div class="certstudio-sharing mt-2 mb-3">';
        echo '<span class="text-muted small mr-2">' . get_string('sharecertificate', 'mod_certstudio') . ':</span>';

        // LinkedIn Add to Profile.
        $linkedinurl = 'https://www.linkedin.com/profile/add?startTask=CERTIFICATION_NAME'
            . '&name=' . urlencode($certname)
            . '&organizationName=' . urlencode($orgname)
            . '&issueYear=' . $issueyear
            . '&issueMonth=' . $issuemonth
            . '&certUrl=' . urlencode($verifyurl)
            . '&certId=' . urlencode($issue->code);
        echo '<a href="' . s($linkedinurl) . '" target="_blank" class="btn btn-sm btn-outline-primary mr-1" title="' . get_string('sharelinkedin', 'mod_certstudio') . '">'
            . '<i class="fa fa-linkedin"></i> ' . get_string('sharelinkedin', 'mod_certstudio') . '</a>';

        // Facebook share.
        $fburl = 'https://www.facebook.com/sharer/sharer.php?u=' . urlencode($verifyurl);
        echo '<a href="' . s($fburl) . '" target="_blank" class="btn btn-sm btn-outline-secondary mr-1" title="' . get_string('sharefacebook', 'mod_certstudio') . '">'
            . '<i class="fa fa-facebook"></i></a>';

        // Twitter/X share.
        $tweettext = get_string('sharetext', 'mod_certstudio', $certname);
        $twitterurl = 'https://twitter.com/intent/tweet?text=' . urlencode($tweettext) . '&url=' . urlencode($verifyurl);
        echo '<a href="' . s($twitterurl) . '" target="_blank" class="btn btn-sm btn-outline-secondary mr-1" title="' . get_string('sharetwitter', 'mod_certstudio') . '">'
            . '<i class="fa fa-twitter"></i></a>';

        // Email share.
        $emailsubject = get_string('shareemailsubject', 'mod_certstudio', $certname);
        $emailbody = get_string('shareemailbody', 'mod_certstudio', (object)[
            'certname' => $certname,
            'verifyurl' => $verifyurl,
            'fullname' => fullname($USER),
        ]);
        $mailtourl = 'mailto:?subject=' . rawurlencode($emailsubject) . '&body=' . rawurlencode($emailbody);
        echo '<a href="' . s($mailtourl) . '" class="btn btn-sm btn-outline-secondary" title="' . get_string('shareemail', 'mod_certstudio') . '">'
            . '<i class="fa fa-envelope"></i></a>';

        echo '</div>';
    } else if ($hasrevokedonly) {
        // Student only has revoked certificates - show message.
        echo $OUTPUT->notification(get_string('certificaterevokedstudent', 'mod_certstudio'), 'warning');
    } else if (!$hasmetrequiredtime) {
        // Required time not met - message already shown above, don't show buttons.
        null;
    } else if ($certstudio->approvalenabled) {
        $approval = new \mod_certstudio\approval();
        $request = $approval->get_user_request($certstudio->id, $USER->id);

        if (!$request) {
            $requesturl = new moodle_url('/mod/certstudio/view.php', [
                'id' => $cm->id, 'action' => 'request', 'sesskey' => sesskey(),
            ]);
            echo html_writer::div(
                $OUTPUT->single_button($requesturl, get_string('requestcertificate', 'mod_certstudio'), 'post'),
                'mb-3'
            );
        } else if ($request->status == \mod_certstudio\approval::STATUS_PENDING) {
            echo $OUTPUT->notification(get_string('requestpending', 'mod_certstudio'), 'info');
        } else if ($request->status == \mod_certstudio\approval::STATUS_REJECTED) {
            echo $OUTPUT->notification(
                get_string('requestrejected', 'mod_certstudio') .
                ($request->reviewcomment ? '<br>' . format_text($request->reviewcomment) : ''),
                'warning'
            );
            $requesturl = new moodle_url('/mod/certstudio/view.php', [
                'id' => $cm->id, 'action' => 'request', 'sesskey' => sesskey(),
            ]);
            echo html_writer::div(
                $OUTPUT->single_button($requesturl, get_string('requestagain', 'mod_certstudio'), 'post'),
                'mb-3'
            );
        } else if ($request->status == \mod_certstudio\approval::STATUS_APPROVED) {
            // Approving now issues straight away, so this only covers requests approved by older versions.
            if (\mod_certstudio\certificate::can_issue($certstudio, $cm->id, $USER->id) === null) {
                $certificate->issue($certstudio->id, $USER->id);
            }
            $issues = $certificate->get_issues_for_user($certstudio->id, $USER->id);
            $issue = reset($issues);
            if ($issue) {
                $renderdownload($issue);
            }
        }
    } else {
        // No approval needed - show "Get Certificate" button.
        $getcerturl = new moodle_url('/mod/certstudio/view.php', [
            'id' => $cm->id, 'action' => 'getcert', 'sesskey' => sesskey(),
        ]);
        echo html_writer::div(
            $OUTPUT->single_button($getcerturl, get_string('getcertificate', 'mod_certstudio'), 'post'),
            'mb-3'
        );
    }
}

// Show "Return to course" button if enabled in settings.
if (get_config('mod_certstudio', 'returncourse')) {
    $courseurl = new moodle_url('/course/view.php', ['id' => $course->id]);
    echo html_writer::div(
        html_writer::link(
            $courseurl,
            '<i class="fa fa-arrow-left"></i> ' . get_string('returntocourse', 'mod_certstudio'),
            ['class' => 'btn btn-secondary']
        ),
        'mt-3 mb-3'
    );
}

echo $OUTPUT->footer();
