<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate wallet - personal page showing all user certificates.
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

require_login();

$userid = optional_param('userid', $USER->id, PARAM_INT);
$context = context_system::instance();

// Only allow viewing own certificates unless has site-wide capability.
if ($userid != $USER->id) {
    require_capability('moodle/site:config', $context);
}

$PAGE->set_url('/mod/certstudio/mycertificates.php', ['userid' => $userid]);
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_title(get_string('mycertificates', 'mod_certstudio'));
$PAGE->set_heading(get_string('mycertificates', 'mod_certstudio'));

// Load jsPDF for download functionality.
$PAGE->requires->js(new moodle_url('/mod/certstudio/thirdparty/jspdf/jspdf.umd.min.js'), true);
$PAGE->requires->js(new moodle_url('/mod/certstudio/thirdparty/qrcode/qrcode.min.js'), true);
$PAGE->requires->js_call_amd('mod_certstudio/renderer', 'initDownloadButton', ['.certstudio-wallet-download']);

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('mycertificates', 'mod_certstudio'));

// Get all certificates for this user.
$issues = $DB->get_records_sql(
    "SELECT ci.id, ci.certstudioid, ci.code, ci.timecreated, ci.expirydate, ci.templatedata,
            cs.name AS certname, cs.course AS courseid,
            c.fullname AS coursename, c.shortname AS courseshortname
     FROM {certstudio_issues} ci
     JOIN {certstudio} cs ON cs.id = ci.certstudioid
     JOIN {course} c ON c.id = cs.course
     WHERE ci.userid = ? AND ci.status = 0
     ORDER BY ci.timecreated DESC",
    [$userid]
);

if (empty($issues)) {
    echo $OUTPUT->notification(get_string('nocertificates', 'mod_certstudio'), 'info');
    echo $OUTPUT->footer();
    die;
}

echo '<div class="certstudio-wallet">';
foreach ($issues as $issue) {
    $isexpired = !empty($issue->expirydate) && ($issue->expirydate < time());
    $statusclass = $isexpired ? 'border-warning' : 'border-success';
    $statusbadge = $isexpired
        ? '<span class="badge badge-warning">' . get_string('expired', 'mod_certstudio') . '</span>'
        : '<span class="badge badge-success">' . get_string('valid', 'mod_certstudio') . '</span>';

    $verifyurl = (new moodle_url('/mod/certstudio/verify.php', ['code' => $issue->code]))->out(false);
    $courseurl = (new moodle_url('/course/view.php', ['id' => $issue->courseid]))->out(false);

    // Get template data for download.
    $certificate = new \mod_certstudio\certificate();
    $templatedata = $certificate->get_template_data($issue->certstudioid, $userid, $issue->code);
    $templatejson = json_encode($templatedata, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    echo '<div class="card mb-3 ' . $statusclass . '">';
    echo '<div class="card-body">';
    echo '<div class="d-flex justify-content-between align-items-start flex-wrap">';
    echo '<div>';
    echo '<h5 class="card-title mb-1">' . s($issue->certname) . ' ' . $statusbadge . '</h5>';
    echo '<p class="text-muted mb-1"><i class="fa fa-graduation-cap"></i> <a href="' . $courseurl . '">' . s($issue->coursename) . '</a></p>';
    echo '<p class="small text-muted mb-1"><i class="fa fa-calendar"></i> ' . get_string('dateissued', 'mod_certstudio') . ': ' . userdate($issue->timecreated) . '</p>';
    if (!empty($issue->expirydate)) {
        echo '<p class="small ' . ($isexpired ? 'text-warning' : 'text-info') . ' mb-1"><i class="fa fa-clock-o"></i> ';
        echo ($isexpired ? get_string('certificateexpired', 'mod_certstudio', userdate($issue->expirydate))
                         : get_string('certificateexpires', 'mod_certstudio', userdate($issue->expirydate)));
        echo '</p>';
    }
    echo '<p class="small text-muted mb-0"><i class="fa fa-key"></i> ' . get_string('verificationcode', 'mod_certstudio') . ': <code>' . s($issue->code) . '</code></p>';
    echo '</div>';
    echo '<div class="d-flex gap-1 mt-2">';
    echo '<button class="btn btn-sm btn-primary certstudio-wallet-download" '
        . 'data-templatedata="' . s($templatejson) . '" '
        . 'data-code="' . s($issue->code) . '" '
        . 'data-filename="' . s($issue->certname) . '">'
        . '<i class="fa fa-download"></i></button>';
    echo '<a href="' . s($verifyurl) . '" class="btn btn-sm btn-outline-secondary" title="' . get_string('verify', 'mod_certstudio') . '"><i class="fa fa-check-circle"></i></a>';

    // LinkedIn share.
    $linkedinurl = 'https://www.linkedin.com/profile/add?startTask=CERTIFICATION_NAME'
        . '&name=' . urlencode($issue->certname)
        . '&organizationName=' . urlencode(format_string($SITE->fullname))
        . '&issueYear=' . date('Y', $issue->timecreated)
        . '&issueMonth=' . date('m', $issue->timecreated)
        . '&certUrl=' . urlencode($verifyurl)
        . '&certId=' . urlencode($issue->code);
    echo '<a href="' . s($linkedinurl) . '" target="_blank" class="btn btn-sm btn-outline-primary" title="' . get_string('sharelinkedin', 'mod_certstudio') . '"><i class="fa fa-linkedin"></i></a>';

    echo '</div></div>';
    echo '</div></div>';
}
echo '</div>';

echo $OUTPUT->footer();
