// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Certificate Studio template gallery module.
 *
 * Handles template selection, blank template creation,
 * card entrance animations, and hover effects.
 *
 * @module     mod_certstudio/gallery
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['core/ajax', 'core/notification', 'core/str'], function(Ajax, Notification, Str) {
    'use strict';

    /** @var {number} cmid The course module ID. */
    var cmid = 0;

    /** @var {boolean} hasTemplate Whether the activity already has a design that a gallery action would replace. */
    var hasTemplate = false;

    /**
     * Ask before replacing the activity's current design, which also changes how issued certificates look.
     *
     * @return {Promise} Resolved when there is nothing to replace or the user confirms; rejected when they cancel.
     */
    function confirmReplace() {
        if (!hasTemplate) {
            return Promise.resolve();
        }
        return Notification.saveCancelPromise(
            Str.get_string('replacetemplate', 'mod_certstudio'),
            Str.get_string('replacetemplateconfirm', 'mod_certstudio'),
            Str.get_string('replacetemplatebutton', 'mod_certstudio')
        );
    }

    /**
     * Animate gallery cards with a staggered fade-in on page load.
     *
     * Each card starts invisible and translated down by 20px, then
     * transitions to full opacity and its natural position. Each
     * successive card is delayed by 100ms.
     */
    function animateCards() {
        var cards = document.querySelectorAll('.certstudio-gallery-card');

        // Stagger the entrance animation with 120ms delay per card.
        // Cards start with opacity:0 and transform:translateY(20px) via CSS,
        // then get the 'visible' class added to trigger the CSS transition.
        cards.forEach(function(card, index) {
            setTimeout(function() {
                card.classList.add('visible');
            }, 80 + index * 120);
        });
    }

    /**
     * Set up hover effect listeners on gallery cards.
     *
     * Adds the 'hover' class on mouseenter and removes it on mouseleave,
     * allowing CSS to handle the visual scale and shadow enhancement.
     */
    function setupHoverEffects() {
        var cards = document.querySelectorAll('.certstudio-gallery-card');

        cards.forEach(function(card) {
            card.addEventListener('mouseenter', function() {
                card.classList.add('hover');
            });
            card.addEventListener('mouseleave', function() {
                card.classList.remove('hover');
            });
        });
    }

    /**
     * Handle clicking the "Use this template" button.
     *
     * Duplicates the selected template via the external service and redirects
     * the user to the editor on success.
     *
     * @param {Event} e The click event.
     */
    function handleUseTemplate(e) {
        e.preventDefault();
        var button = e.currentTarget;
        confirmReplace().then(function() {
            useTemplate(button);
            return null;
        }).catch(function() {
            // Cancelled: keep the current design.
        });
    }

    /**
     * Copy a gallery template into the activity and open the editor.
     *
     * @param {HTMLElement} button The "Use this template" button.
     */
    function useTemplate(button) {
        var templateid = button.getAttribute('data-template-id');

        // Show loading state.
        button.disabled = true;
        var originalText = button.textContent;
        button.textContent = 'Loading...';

        Ajax.call([{
            methodname: 'mod_certstudio_use_template',
            args: {cmid: cmid, templateid: Number(templateid)}
        }])[0].then(function() {
            window.location.href = M.cfg.wwwroot + '/mod/certstudio/edit.php?id=' + cmid;
        }).catch(function(err) {
            window.console.error('usetemplate error:', err);
            button.disabled = false;
            button.textContent = originalText;
        });
    }

    /**
     * Handle clicking the "Start from Scratch" button.
     *
     * Creates a new blank template via the external service and redirects
     * the user to the editor on success.
     *
     * @param {Event} e The click event.
     */
    function handleCreateBlank(e) {
        e.preventDefault();
        var button = e.currentTarget;
        confirmReplace().then(function() {
            createBlank(button);
            return null;
        }).catch(function() {
            // Cancelled: keep the current design.
        });
    }

    /**
     * Give the activity a new blank template and open the editor.
     *
     * @param {HTMLElement} button The "Start from Scratch" button.
     */
    function createBlank(button) {
        // Show loading state.
        button.disabled = true;
        var originalText = button.textContent;
        button.textContent = 'Loading...';

        Ajax.call([{
            methodname: 'mod_certstudio_create_blank',
            args: {cmid: cmid}
        }])[0].then(function() {
            window.location.href = M.cfg.wwwroot + '/mod/certstudio/edit.php?id=' + cmid;
        }).catch(function(err) {
            window.console.error('createblank error:', err);
            button.disabled = false;
            button.textContent = originalText;
        });
    }

    /**
     * Handle AI template generation.
     *
     * Sends the description to the AI endpoint, then creates a blank
     * template (if needed), saves the AI-generated elements, and
     * redirects to the editor.
     */
    function handleAIGenerate() {
        var promptInput = document.getElementById('certstudio-ai-prompt');
        var statusDiv = document.getElementById('certstudio-ai-status');
        var generateBtn = document.getElementById('certstudio-ai-generate');

        if (!promptInput || !statusDiv || !generateBtn) {
            return;
        }

        var description = promptInput.value.trim();
        if (!description) {
            promptInput.focus();
            return;
        }

        // Confirm before calling the AI, so a cancelled replacement does not spend AI credits.
        confirmReplace().then(function() {
            generateFromDescription(description, promptInput, statusDiv, generateBtn);
            return null;
        }).catch(function() {
            // Cancelled: keep the current design.
        });
    }

    /**
     * Generate a design from a description with AI, save it as the activity's template and open the editor.
     *
     * @param {String} description What the certificate should look like.
     * @param {HTMLElement} promptInput The description input.
     * @param {HTMLElement} statusDiv Where progress and errors are shown.
     * @param {HTMLElement} generateBtn The generate button.
     */
    function generateFromDescription(description, promptInput, statusDiv, generateBtn) {
        // Show loading state.
        generateBtn.disabled = true;
        promptInput.disabled = true;
        statusDiv.style.display = 'block';
        statusDiv.className = 'mt-2 text-info';
        statusDiv.innerHTML = '<i class="fa fa-spinner fa-spin"></i> ' +
            M.util.get_string('aigenerating', 'mod_certstudio');

        // Step 1: Call AI endpoint to generate elements (kept as fetch — separate PHP endpoint).
        var aiUrl = M.cfg.wwwroot + '/mod/certstudio/aigenerate.php' +
            '?cmid=' + cmid +
            '&description=' + encodeURIComponent(description) +
            '&sesskey=' + M.cfg.sesskey;

        fetch(aiUrl)
        .then(function(response) {
            return response.json();
        })
        .then(function(aiData) {
            if (!aiData.success) {
                throw new Error(aiData.error || 'AI generation failed');
            }

            // Step 2: Create a blank template via external service.
            return Ajax.call([{
                methodname: 'mod_certstudio_create_blank',
                args: {cmid: cmid}
            }])[0].then(function(blankData) {
                return {
                    elements: aiData.elements,
                    templateid: blankData.templateid,
                    pageid: blankData.pageid
                };
            });
        })
        .then(function(result) {
            // Step 3: Save AI-generated elements to the template page.
            var elementsWithPage = result.elements.map(function(el, idx) {
                el.pageid = result.pageid;
                el.sequence = idx;
                el.rotation = 0;
                el.locked = 0;
                if (typeof el.data !== 'object') {
                    el.data = {};
                }
                return el;
            });

            return Ajax.call([{
                methodname: 'mod_certstudio_save_elements',
                args: {cmid: cmid, elements: JSON.stringify(elementsWithPage)}
            }])[0].then(function() {
                // Success! Redirect to editor.
                statusDiv.className = 'mt-2 text-success';
                statusDiv.innerHTML = '<i class="fa fa-check"></i> ' +
                    M.util.get_string('aigeneratesuccess', 'mod_certstudio');
                setTimeout(function() {
                    window.location.href = M.cfg.wwwroot + '/mod/certstudio/edit.php?id=' + cmid;
                }, 500);
            });
        })
        .catch(function(err) {
            window.console.error('AI generate error:', err);
            statusDiv.className = 'mt-2 text-danger';
            // The message can come from the AI provider, so add it as text, not HTML.
            statusDiv.innerHTML = '<i class="fa fa-exclamation-triangle"></i> ';
            statusDiv.appendChild(document.createTextNode(err.message || ''));
            generateBtn.disabled = false;
            promptInput.disabled = false;
        });
    }

    /**
     * Set up the AI generation button and input handlers.
     */
    function setupAIGenerate() {
        var generateBtn = document.getElementById('certstudio-ai-generate');
        var promptInput = document.getElementById('certstudio-ai-prompt');

        if (generateBtn) {
            generateBtn.addEventListener('click', handleAIGenerate);
        }

        if (promptInput) {
            promptInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAIGenerate();
                }
            });
        }
    }

    /**
     * Bind click handlers for template actions.
     */
    function setupClickHandlers() {
        // "Use this template" buttons.
        var useButtons = document.querySelectorAll('[data-action="use-template"]');
        useButtons.forEach(function(button) {
            button.addEventListener('click', handleUseTemplate);
        });

        // "Start from Scratch" buttons.
        var blankButtons = document.querySelectorAll('[data-action="create-blank"]');
        blankButtons.forEach(function(button) {
            button.addEventListener('click', handleCreateBlank);
        });
    }

    /** Current filter state. */
    var currentSearch = '';
    var currentSource = 'all';
    var currentStyle = 'all';
    var currentColor = 'all';

    /**
     * Apply filters to gallery cards and sections.
     */
    function applyFilters() {
        var cards = document.querySelectorAll('.certstudio-gallery-card[data-template-id]');
        var builtinVisible = 0;
        var customVisible = 0;

        cards.forEach(function(card) {
            var name = (card.getAttribute('data-name') || '').toLowerCase();
            var source = card.getAttribute('data-source') || 'builtin';
            var style = card.getAttribute('data-style') || '';
            var color = card.getAttribute('data-color') || '';

            var matchSearch = !currentSearch || name.indexOf(currentSearch.toLowerCase()) !== -1;
            var matchSource = currentSource === 'all' || currentSource === source;
            var matchStyle = currentStyle === 'all' || style === currentStyle;
            var matchColor = currentColor === 'all' || color === currentColor;

            var visible = matchSearch && matchSource && matchStyle && matchColor;
            card.style.display = visible ? '' : 'none';

            if (visible) {
                if (source === 'builtin') {
                    builtinVisible++;
                } else {
                    customVisible++;
                }
            }
        });

        // Show/hide sections based on visible cards.
        var builtinSection = document.querySelector('[data-section="builtin"]');
        var customSection = document.querySelector('[data-section="custom"]');
        if (builtinSection) {
            builtinSection.style.display = (currentSource === 'custom' || builtinVisible === 0) ? 'none' : '';
        }
        if (customSection) {
            customSection.style.display = (currentSource === 'builtin' || customVisible === 0) ? 'none' : '';
        }
    }

    /**
     * Helper to set up a button group filter.
     *
     * @param {string} selector CSS selector for the buttons.
     * @param {string} attr Data attribute name to read.
     * @param {Function} setter Function to call with the new value.
     */
    function setupButtonGroup(selector, attr, setter) {
        var buttons = document.querySelectorAll(selector);
        buttons.forEach(function(btn) {
            btn.addEventListener('click', function() {
                buttons.forEach(function(b) { b.classList.remove('active'); });
                btn.classList.add('active');
                setter(btn.getAttribute(attr));
                applyFilters();
            });
        });
    }

    /**
     * Set up search and filter controls.
     */
    function setupFilters() {
        var searchInput = document.getElementById('certstudio-gallery-search');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                currentSearch = searchInput.value.trim();
                applyFilters();
            });
        }

        setupButtonGroup('.certstudio-source-filter', 'data-source', function(v) { currentSource = v; });
        setupButtonGroup('.certstudio-style-filter', 'data-style', function(v) { currentStyle = v; });
        setupButtonGroup('.certstudio-color-filter', 'data-color', function(v) { currentColor = v; });
    }

    return {
        /**
         * Initialise the gallery module.
         *
         * @param {number} coursemoduleid The course module ID.
         * @param {boolean} hascurrenttemplate Whether the activity already has a design.
         */
        init: function(coursemoduleid, hascurrenttemplate) {
            cmid = coursemoduleid;
            hasTemplate = !!hascurrenttemplate;

            animateCards();
            setupHoverEffects();
            setupClickHandlers();
            setupFilters();
            setupAIGenerate();
        }
    };
});
