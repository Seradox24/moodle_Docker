// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Layers panel management for mod_certstudio.
 *
 * @module     mod_certstudio/layers
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_certstudio/elements'], function(Elements) {
    'use strict';

    /** @type {HTMLElement|null} The layers panel container. */
    var panelEl = null;

    /** @type {Function|null} Callback when an element is selected via the layers panel. */
    var onSelectCallback = null;

    /** @type {Function|null} Callback when layer order changes. */
    var onReorderCallback = null;

    /** @type {Function|null} Callback when visibility toggles. */
    var onVisibilityCallback = null;

    /** @type {Function|null} Callback when lock toggles. */
    var onLockCallback = null;

    /**
     * Create a single layer item DOM element.
     *
     * @param {Object} element The element data.
     * @return {HTMLElement}
     */
    function createLayerItem(element) {
        var typeConfig = Elements.getTypeConfig(element.type);
        var icon = typeConfig ? typeConfig.icon : 'fa-question';
        var label = element.name || (typeConfig ? typeConfig.label : element.type);

        var item = document.createElement('div');
        item.className = 'certstudio-layer-item';
        item.setAttribute('data-element-id', element.id);
        item.setAttribute('draggable', 'true');

        if (element.selected) {
            item.classList.add('selected');
        }

        // Drag handle.
        var handle = document.createElement('span');
        handle.className = 'certstudio-layer-handle';
        handle.innerHTML = '<i class="fa fa-bars"></i>';
        item.appendChild(handle);

        // Type icon.
        var iconSpan = document.createElement('span');
        iconSpan.className = 'certstudio-layer-icon';
        iconSpan.innerHTML = '<i class="fa ' + icon + '"></i>';
        item.appendChild(iconSpan);

        // Label.
        var nameSpan = document.createElement('span');
        nameSpan.className = 'certstudio-layer-name';
        nameSpan.textContent = label;
        item.appendChild(nameSpan);

        // Visibility toggle.
        var visBtn = document.createElement('button');
        visBtn.className = 'certstudio-layer-btn certstudio-layer-visibility';
        visBtn.type = 'button';
        visBtn.title = 'Toggle visibility';
        visBtn.innerHTML = element.visible === false
            ? '<i class="fa fa-eye-slash"></i>'
            : '<i class="fa fa-eye"></i>';
        visBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            var newState = !(element.visible !== false);
            if (typeof onVisibilityCallback === 'function') {
                onVisibilityCallback(element.id, newState);
            }
        });
        item.appendChild(visBtn);

        // Lock toggle.
        var lockBtn = document.createElement('button');
        lockBtn.className = 'certstudio-layer-btn certstudio-layer-lock';
        lockBtn.type = 'button';
        lockBtn.title = 'Toggle lock';
        lockBtn.innerHTML = element.locked
            ? '<i class="fa fa-lock"></i>'
            : '<i class="fa fa-unlock"></i>';
        lockBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            var newState = !element.locked;
            if (typeof onLockCallback === 'function') {
                onLockCallback(element.id, newState);
            }
        });
        item.appendChild(lockBtn);

        // Click to select.
        item.addEventListener('click', function() {
            if (typeof onSelectCallback === 'function') {
                onSelectCallback(element.id);
            }
        });

        return item;
    }

    /**
     * Attach drag-and-drop reorder handlers to layer items.
     */
    function attachDragReorder() {
        if (!panelEl) {
            return;
        }

        var dragSrcEl = null;

        var items = panelEl.querySelectorAll('.certstudio-layer-item');
        items.forEach(function(item) {
            item.addEventListener('dragstart', function(e) {
                dragSrcEl = this;
                this.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', this.getAttribute('data-element-id'));
            });

            item.addEventListener('dragover', function(e) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                this.classList.add('drag-over');
            });

            item.addEventListener('dragleave', function() {
                this.classList.remove('drag-over');
            });

            item.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('drag-over');
                if (dragSrcEl !== this) {
                    // Reorder DOM.
                    panelEl.insertBefore(dragSrcEl, this);
                    // Collect new order.
                    var newOrder = [];
                    panelEl.querySelectorAll('.certstudio-layer-item').forEach(function(el) {
                        newOrder.push(el.getAttribute('data-element-id'));
                    });
                    if (typeof onReorderCallback === 'function') {
                        onReorderCallback(newOrder);
                    }
                }
            });

            item.addEventListener('dragend', function() {
                this.classList.remove('dragging');
                panelEl.querySelectorAll('.certstudio-layer-item').forEach(function(el) {
                    el.classList.remove('drag-over');
                });
            });
        });
    }

    return {

        /**
         * Initialise the layers panel.
         *
         * @param {string|HTMLElement} container Selector or element for the layers panel.
         * @param {Object} callbacks Object with onSelect, onReorder, onVisibility, onLock callbacks.
         */
        init: function(container, callbacks) {
            if (typeof container === 'string') {
                panelEl = document.querySelector(container);
            } else {
                panelEl = container;
            }

            callbacks = callbacks || {};
            onSelectCallback = callbacks.onSelect || null;
            onReorderCallback = callbacks.onReorder || null;
            onVisibilityCallback = callbacks.onVisibility || null;
            onLockCallback = callbacks.onLock || null;
        },

        /**
         * Render the layers panel from the given elements array.
         * Elements are displayed in reverse sequence order (highest on top).
         *
         * @param {Array} elements Array of element data objects with at least {id, type, sequence}.
         */
        render: function(elements) {
            if (!panelEl) {
                return;
            }

            // Clear existing content.
            panelEl.innerHTML = '';

            // Sort by sequence descending (top layer first).
            var sorted = elements.slice().sort(function(a, b) {
                return (b.sequence || 0) - (a.sequence || 0);
            });

            sorted.forEach(function(element) {
                var item = createLayerItem(element);
                panelEl.appendChild(item);
            });

            attachDragReorder();
        },

        /**
         * Highlight a specific layer item as selected.
         *
         * @param {string} elementId
         */
        highlightLayer: function(elementId) {
            if (!panelEl) {
                return;
            }
            panelEl.querySelectorAll('.certstudio-layer-item').forEach(function(item) {
                item.classList.remove('selected');
                if (item.getAttribute('data-element-id') === String(elementId)) {
                    item.classList.add('selected');
                }
            });
        },

        /**
         * Save updated z-order from an array of element IDs (top-to-bottom).
         *
         * @param {Array} elementIds Ordered array of element IDs.
         */
        updateOrder: function(elementIds) {
            if (typeof onReorderCallback === 'function') {
                onReorderCallback(elementIds);
            }
        }
    };
});
