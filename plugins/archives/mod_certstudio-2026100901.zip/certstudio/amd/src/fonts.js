// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Font loader for jsPDF and CSS @font-face in mod_certstudio.
 *
 * @module     mod_certstudio/fonts
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    /** @type {HTMLStyleElement|null} Style element for injected @font-face rules. */
    var styleEl = null;

    /**
     * Normalise a font descriptor from PHP format to internal format.
     * PHP sends {family, style, url} where style is 'regular','bold','italic','bolditalic'.
     * Internal format expects {name, url, weight, style}.
     *
     * @param {Object} font Raw font descriptor.
     * @return {Object} Normalised font descriptor with name, url, weight, style.
     */
    function normaliseFont(font) {
        var name = font.name || font.family || 'Unknown';
        var url = font.url || '';
        var rawStyle = font.style || 'regular';

        // If weight is already set explicitly, use it directly.
        if (font.weight) {
            return {name: name, url: url, weight: font.weight, style: font.style || 'normal'};
        }

        // Map PHP style values (regular/bold/italic/bolditalic) to CSS weight/style.
        var weight = 'normal';
        var style = 'normal';
        if (rawStyle === 'bold' || rawStyle === 'bolditalic') {
            weight = 'bold';
        }
        if (rawStyle === 'italic' || rawStyle === 'bolditalic') {
            style = 'italic';
        }

        return {name: name, url: url, weight: weight, style: style};
    }

    /**
     * Fetch a font file and return it as a base64 string.
     *
     * @param {string} url URL to the TTF font file.
     * @return {Promise<string>} Base64-encoded font data.
     */
    function fetchFontAsBase64(url) {
        return fetch(url)
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('Failed to fetch font: ' + url + ' (' + response.status + ')');
                }
                return response.arrayBuffer();
            })
            .then(function(buffer) {
                var binary = '';
                var bytes = new Uint8Array(buffer);
                for (var i = 0; i < bytes.length; i++) {
                    binary += String.fromCharCode(bytes[i]);
                }
                return btoa(binary);
            });
    }

    /**
     * Derive jsPDF font style string from weight and style.
     *
     * @param {string} fontweight 'normal' or 'bold'.
     * @param {string} fontstyle 'normal' or 'italic'.
     * @return {string} One of 'normal', 'bold', 'italic', 'bolditalic'.
     */
    function deriveFontStyle(fontweight, fontstyle) {
        var isBold = fontweight === 'bold';
        var isItalic = fontstyle === 'italic';

        if (isBold && isItalic) {
            return 'bolditalic';
        } else if (isBold) {
            return 'bold';
        } else if (isItalic) {
            return 'italic';
        }
        return 'normal';
    }

    return {

        /**
         * Load TTF fonts into a jsPDF instance.
         *
         * Accepts font descriptors in either format:
         *   PHP format: {family, style ('regular'/'bold'/'italic'/'bolditalic'), url}
         *   Internal format: {name, weight, style, url}
         *
         * @param {Object} jspdfInstance The jsPDF document instance.
         * @param {Array}  fontUrls Array of font descriptor objects.
         * @return {Promise} Resolves when all fonts are loaded.
         */
        loadFonts: function(jspdfInstance, fontUrls) {
            if (!fontUrls || !fontUrls.length) {
                return Promise.resolve();
            }

            // Sort fonts so that Noto Sans and Roboto (good Unicode coverage) load first.
            var sorted = fontUrls.slice().sort(function(a, b) {
                var nameA = (a.name || a.family || '').toLowerCase();
                var nameB = (b.name || b.family || '').toLowerCase();
                var priority = {'noto sans': 0, 'noto serif': 1, 'roboto': 2};
                var pa = priority[nameA] !== undefined ? priority[nameA] : 10;
                var pb = priority[nameB] !== undefined ? priority[nameB] : 10;
                return pa - pb;
            });

            /** @type {Array<string>} Names of successfully loaded fonts. */
            var loaded = [];

            // Load fonts sequentially so the first success sets the fallback.
            var chain = Promise.resolve();
            sorted.forEach(function(rawFont) {
                chain = chain.then(function() {
                    var font = normaliseFont(rawFont);
                    var jsPdfStyle = deriveFontStyle(font.weight, font.style);
                    var vfsName = font.name + '-' + jsPdfStyle + '.ttf';

                    return fetchFontAsBase64(font.url).then(function(base64) {
                        try {
                            jspdfInstance.addFileToVFS(vfsName, base64);
                            jspdfInstance.addFont(vfsName, font.name, jsPdfStyle);
                            loaded.push(font.name);
                        } catch (addErr) {
                            window.console.warn('Failed to add font ' + font.name + ' to jsPDF:', addErr);
                        }
                    }).catch(function(err) {
                        window.console.warn('Failed to load font ' + font.name + ':', err);
                    });
                });
            });

            return chain.then(function() {
                return loaded;
            });
        },

        /**
         * Get the jsPDF font style string from weight and style values.
         *
         * @param {string} fontweight 'normal' or 'bold'.
         * @param {string} fontstyle 'normal' or 'italic'.
         * @return {string} 'normal', 'bold', 'italic', or 'bolditalic'.
         */
        getFontStyle: function(fontweight, fontstyle) {
            return deriveFontStyle(fontweight || 'normal', fontstyle || 'normal');
        },

        /**
         * Create CSS @font-face rules so custom fonts render in the editor canvas.
         *
         * Accepts font descriptors in either format:
         *   PHP format: {family, style ('regular'/'bold'/'italic'/'bolditalic'), url}
         *   Internal format: {name, weight, style, url}
         *
         * @param {Array} fontUrls Array of font descriptor objects.
         */
        loadCssFonts: function(fontUrls) {
            if (!fontUrls || !fontUrls.length) {
                return;
            }

            // Remove any previously injected style element.
            if (styleEl && styleEl.parentNode) {
                styleEl.parentNode.removeChild(styleEl);
            }

            styleEl = document.createElement('style');
            styleEl.setAttribute('data-certstudio-fonts', '1');

            var css = '';
            fontUrls.forEach(function(rawFont) {
                var font = normaliseFont(rawFont);

                css += '@font-face {\n';
                css += "  font-family: '" + font.name + "';\n";
                css += "  src: url('" + font.url + "') format('truetype');\n";
                css += '  font-weight: ' + font.weight + ';\n';
                css += '  font-style: ' + font.style + ';\n';
                css += '  font-display: swap;\n';
                css += '}\n\n';
            });

            styleEl.textContent = css;
            document.head.appendChild(styleEl);
        }
    };
});
