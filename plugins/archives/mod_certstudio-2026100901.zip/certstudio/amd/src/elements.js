// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Element types registry for mod_certstudio.
 *
 * @module     mod_certstudio/elements
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    /** @type {Object} Default text font settings. */
    var textDefaults = {
        fontfamily: 'Roboto',
        fontsize: 14,
        color: '#000000',
        alignment: 'L'
    };

    /**
     * Build a text-type element configuration.
     *
     * @param {string} label Display label.
     * @param {string} icon Font Awesome icon class.
     * @param {string} category Element category ID.
     * @param {Object} defaults Default property overrides.
     * @return {Object} Element type configuration.
     */
    function textType(label, icon, category, defaults) {
        var merged = {};
        var k;
        for (k in textDefaults) {
            if (textDefaults.hasOwnProperty(k)) {
                merged[k] = textDefaults[k];
            }
        }
        for (k in defaults) {
            if (defaults.hasOwnProperty(k)) {
                merged[k] = defaults[k];
            }
        }
        return {
            label: label,
            icon: icon,
            isText: true,
            category: category,
            defaults: merged
        };
    }

    /**
     * Build a non-text element configuration.
     *
     * @param {string} label Display label.
     * @param {string} icon Font Awesome icon class.
     * @param {string} category Element category ID.
     * @param {Object} defaults Default property values.
     * @return {Object} Element type configuration.
     */
    function mediaType(label, icon, category, defaults) {
        return {
            label: label,
            icon: icon,
            isText: false,
            category: category,
            defaults: defaults
        };
    }

    var typeRegistry = {
        // Text fields.
        text: textType(
            'Text', 'fa-font', 'text',
            {width: 60, height: 10}
        ),
        studentname: textType(
            'Student Name', 'fa-user', 'data',
            {width: 100, height: 12, fontsize: 20,
                fontweight: 'bold', color: '#333333',
                alignment: 'C'}
        ),
        coursename: textType(
            'Course Name', 'fa-book', 'data',
            {width: 100, height: 10, fontsize: 16,
                color: '#555555', alignment: 'C'}
        ),
        categoryname: textType(
            'Category Name', 'fa-folder', 'data',
            {width: 80, height: 10, fontsize: 12,
                color: '#666666', alignment: 'C'}
        ),
        teachername: textType(
            'Teacher Name', 'fa-graduation-cap', 'data',
            {width: 80, height: 10,
                color: '#333333', alignment: 'C'}
        ),
        // Date & grade.
        date: textType(
            'Date', 'fa-calendar', 'data',
            {width: 60, height: 8, fontsize: 12,
                color: '#666666', alignment: 'C'}
        ),
        daterange: textType(
            'Date Range', 'fa-calendar-o', 'data',
            {width: 80, height: 8, fontsize: 12,
                color: '#666666', alignment: 'C'}
        ),
        expiry: textType(
            'Expiry Date', 'fa-clock-o', 'data',
            {width: 60, height: 8, fontsize: 12,
                color: '#999999', alignment: 'C'}
        ),
        certdate: textType(
            'Localized Date', 'fa-map-marker', 'data',
            {width: 80, height: 10,
                fontfamily: 'GFS Didot',
                color: '#333333', alignment: 'C'}
        ),
        grade: textType(
            'Grade', 'fa-star', 'data',
            {width: 40, height: 8,
                fontweight: 'bold', color: '#333333',
                alignment: 'C'}
        ),
        gradeitemname: textType(
            'Grade Item Name', 'fa-list', 'data',
            {width: 80, height: 8, fontsize: 12,
                color: '#666666', alignment: 'C'}
        ),
        // Custom fields.
        userfield: textType(
            'User Field', 'fa-id-card', 'data',
            {width: 60, height: 8, fontsize: 12,
                color: '#333333'}
        ),
        coursefield: textType(
            'Course Field', 'fa-info-circle', 'data',
            {width: 60, height: 8, fontsize: 12,
                color: '#333333'}
        ),
        certstatement: textType(
            'Statement', 'fa-file-text', 'text',
            {width: 200, height: 25, fontsize: 16,
                color: '#333333', alignment: 'C'}
        ),
        // Media.
        image: mediaType(
            'Image', 'fa-image', 'media',
            {width: 40, height: 40}
        ),
        bgimage: mediaType(
            'Background Image', 'fa-picture-o', 'media',
            {width: 297, height: 210}
        ),
        userpicture: mediaType(
            'User Picture', 'fa-camera', 'media',
            {width: 25, height: 25}
        ),
        digitalsignature: mediaType(
            'Digital Signature', 'fa-pencil', 'media',
            {width: 40, height: 20}
        ),
        // Layout & verification.
        border: mediaType(
            'Border', 'fa-square-o', 'layout',
            {width: 280, height: 195}
        ),
        qrcode: mediaType(
            'QR Code', 'fa-qrcode', 'verify',
            {width: 25, height: 25}
        ),
        code: textType(
            'Verification Code', 'fa-barcode', 'verify',
            {width: 60, height: 6, fontsize: 8,
                color: '#999999', alignment: 'C'}
        )
    };

    /** @type {Array} Element type categories for the palette panel. */
    var categories = [
        {
            id: 'text',
            label: 'Text',
            icon: 'fa-font',
            types: ['text', 'certstatement']
        },
        {
            id: 'data',
            label: 'Data Fields',
            icon: 'fa-database',
            types: [
                'studentname', 'coursename',
                'categoryname', 'teachername',
                'date', 'daterange', 'expiry',
                'certdate', 'grade', 'gradeitemname',
                'userfield', 'coursefield'
            ]
        },
        {
            id: 'media',
            label: 'Media',
            icon: 'fa-image',
            types: ['image', 'userpicture', 'digitalsignature']
        },
        {
            id: 'layout',
            label: 'Layout',
            icon: 'fa-object-group',
            types: ['border']
        },
        {
            id: 'verify',
            label: 'Verification',
            icon: 'fa-shield',
            types: ['qrcode', 'code']
        }
    ];

    /** @type {Object} Placeholder text for each element type preview. */
    var placeholders = {
        text: 'Sample Text',
        studentname: '{Student Name}',
        coursename: '{Course Name}',
        categoryname: '{Category Name}',
        date: '{Date}',
        grade: '{Grade}',
        gradeitemname: '{Grade Item}',
        code: '{XXXX-XXXX}',
        teachername: '{Teacher Name}',
        userfield: '{User Field}',
        coursefield: '{Course Field}',
        daterange: '{Start - End}',
        expiry: '{Expiry Date}',
        certdate: 'City, January 1, 2026',
        certstatement: 'This is to certify that\n{Student Name}'
    };

    /**
     * Escape a value for HTML text or a double-quoted attribute.
     *
     * Element data comes from teachers and is shared through the gallery, so it must not be able to inject markup.
     *
     * @param {*} value The value to escape.
     * @return {String} The escaped value.
     */
    var escapeHtml = function(value) {
        return String(value === undefined || value === null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    };

    /**
     * Reduce a value to a safe CSS keyword or font name: letters, digits, spaces, hyphens and underscores.
     *
     * HTML escaping is not enough inside a style attribute, because entities are decoded before the CSS is parsed.
     *
     * @param {*} value The value to clean.
     * @return {String} The cleaned value.
     */
    var cssToken = function(value) {
        return String(value === undefined || value === null ? '' : value).replace(/[^\w\s-]/g, '');
    };

    /**
     * Return the value if it is a plain CSS colour (hex, rgb()/rgba() or a colour name), otherwise the fallback.
     *
     * @param {*} value The colour to check.
     * @param {String} fallback The colour to use when the value is not a plain colour.
     * @return {String} A safe colour.
     */
    var cssColor = function(value, fallback) {
        var colour = String(value === undefined || value === null ? '' : value).trim();
        return /^(#[0-9a-fA-F]{3,8}|[a-zA-Z]+|rgba?\([\d\s.,%]+\))$/.test(colour) ? colour : fallback;
    };

    return {
        /**
         * Get the configuration for an element type.
         *
         * @param {string} type The element type identifier.
         * @return {Object|null} Type configuration or null.
         */
        getTypeConfig: function(type) {
            return typeRegistry[type] || null;
        },

        /**
         * Get the list of element type categories.
         *
         * @return {Array} Array of category objects.
         */
        getCategories: function() {
            return categories;
        },

        /**
         * Get default property values for an element type.
         *
         * @param {string} type The element type identifier.
         * @return {Object} Default properties.
         */
        getDefaultProperties: function(type) {
            var cfg = typeRegistry[type];
            if (!cfg) { return {width: 50, height: 20}; }
            var defaults = {};
            for (var key in cfg.defaults) {
                if (cfg.defaults.hasOwnProperty(key)) {
                    defaults[key] = cfg.defaults[key];
                }
            }
            if (!defaults.fontweight) {
                defaults.fontweight = 'normal';
            }
            if (!defaults.fontstyle) {
                defaults.fontstyle = 'normal';
            }
            if (defaults.opacity === undefined) {
                defaults.opacity = 1;
            }
            if (defaults.rotation === undefined) {
                defaults.rotation = 0;
            }
            return defaults;
        },

        /**
         * Check whether the given type is a text-based element.
         *
         * @param {string} type The element type identifier.
         * @return {boolean} True if the type renders text.
         */
        isTextType: function(type) {
            return typeRegistry[type]
                ? typeRegistry[type].isText : false;
        },

        /**
         * Render an HTML preview string for the given element.
         *
         * @param {string} type The element type identifier.
         * @param {Object} el The element data object.
         * @return {string} HTML string for the element preview.
         */
        renderPreview: function(type, el) {
            var cfg = typeRegistry[type];
            if (!cfg) {
                return '<div style="display:flex;' +
                    'align-items:center;' +
                    'justify-content:center;' +
                    'width:100%;height:100%;' +
                    'background:#f5f5f5;' +
                    'font-size:11px;color:#999;">' +
                    escapeHtml(type) + '</div>';
            }

            if (cfg.isText) {
                var text = '';
                if (type === 'text' && el.data && el.data.text) {
                    text = el.data.text;
                } else {
                    text = placeholders[type] ||
                        '{' + cfg.label + '}';
                }
                var style = 'width:100%;height:100%;' +
                    'overflow:hidden;line-height:1.3;' +
                    'white-space:pre-wrap;';
                var family = cssToken(el.fontfamily ||
                    cfg.defaults.fontfamily || 'Roboto');
                style += "font-family:'" + family +
                    "',sans-serif;";
                style += 'font-size:' +
                    (parseFloat(el.fontsize || cfg.defaults.fontsize) ||
                    14) + 'pt;';
                style += 'font-weight:' +
                    cssToken(el.fontweight || 'normal') + ';';
                style += 'font-style:' +
                    cssToken(el.fontstyle || 'normal') + ';';
                style += 'color:' +
                    cssColor(el.color, '#000000') + ';';
                var align = el.alignment ||
                    cfg.defaults.alignment || 'L';
                if (align === 'C') {
                    style += 'text-align:center;';
                } else if (align === 'R') {
                    style += 'text-align:right;';
                } else {
                    style += 'text-align:left;';
                }
                return '<div class="certstudio-element-text"' +
                    ' style="' + style + '">' +
                    escapeHtml(text) + '</div>';
            }

            if (type === 'image' || type === 'bgimage' ||
                type === 'digitalsignature' ||
                type === 'userpicture') {
                var src = (el.data && el.data.src)
                    ? el.data.src : '';
                if (src) {
                    // Prefix relative plugin paths with wwwroot for subfolder installs.
                    if (src.charAt(0) === '/' && src.indexOf('/mod/certstudio/') === 0 &&
                            typeof M !== 'undefined' && M.cfg && M.cfg.wwwroot) {
                        src = M.cfg.wwwroot + src;
                    }
                    var fitMap = {
                        cover: 'cover',
                        contain: 'contain',
                        stretch: 'fill',
                        actual: 'none'
                    };
                    var sizemode = (el.data && el.data.sizemode)
                        ? el.data.sizemode : '';
                    var fit = (type === 'bgimage' && sizemode)
                        ? (fitMap[sizemode] || 'cover')
                        : 'contain';
                    return '<div class=' +
                        '"certstudio-element-image">' +
                        '<img src="' + escapeHtml(src) +
                        '" style="object-fit:' +
                        fit + ';" /></div>';
                }
                return '<div style="display:flex;' +
                    'align-items:center;' +
                    'justify-content:center;' +
                    'width:100%;height:100%;' +
                    'background:#f0f0f0;' +
                    'border:1px dashed #ccc;' +
                    'color:#aaa;">' +
                    '<i class="fa ' + cfg.icon +
                    '" style="font-size:20px;"></i></div>';
            }

            if (type === 'border') {
                var bdata = el.data || {};
                var bw = parseFloat(bdata.borderwidth) || 2;
                var styles = ['solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'inset', 'outset'];
                var bs = styles.indexOf(bdata.borderstyle) !== -1 ? bdata.borderstyle : 'solid';
                var bc = cssColor(bdata.bordercolor, '#1a237e');
                return '<div style="width:100%;' +
                    'height:100%;border:' + bw + 'px ' +
                    bs + ' ' + bc +
                    ';box-sizing:border-box;"></div>';
            }

            if (type === 'qrcode') {
                var qrId = 'qr-preview-' +
                    (cssToken(el.id).replace(/\s/g, '') ||
                    Math.random().toString(36).substr(2, 8));
                setTimeout(function() {
                    var container =
                        document.getElementById(qrId);
                    if (container &&
                        typeof window.QRCode !== 'undefined') {
                        container.innerHTML = '';
                        try {
                            var qrSize = Math.min(
                                container.offsetWidth,
                                container.offsetHeight
                            ) || 80;
                            var correctLvl =
                                window.QRCode.CorrectLevel
                                ? window.QRCode.CorrectLevel.M
                                : 1;
                            /* eslint-disable no-new */
                            new window.QRCode(container, {
                                text: 'https://verify.example.com',
                                width: qrSize,
                                height: qrSize,
                                correctLevel: correctLvl
                            });
                            /* eslint-enable no-new */
                        } catch (e) {
                            // Fallback to icon.
                        }
                    }
                }, 50);
                return '<div id="' + qrId + '" style=' +
                    '"display:flex;align-items:center;' +
                    'justify-content:center;width:100%;' +
                    'height:100%;background:#fff;">' +
                    '<i class="fa fa-qrcode" style=' +
                    '"font-size:24px;color:#333;">' +
                    '</i></div>';
            }

            return '<div style="display:flex;' +
                'align-items:center;' +
                'justify-content:center;' +
                'width:100%;height:100%;' +
                'background:#f9f9f9;color:#999;' +
                'font-size:11px;">' +
                '<i class="fa ' + cfg.icon +
                '"></i>&nbsp;' + cfg.label + '</div>';
        }
    };
});
