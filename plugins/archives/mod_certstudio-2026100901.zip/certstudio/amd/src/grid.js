// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Snap-to-grid and alignment guides for mod_certstudio.
 *
 * @module     mod_certstudio/grid
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    /** @type {number} Grid size in mm. */
    var gridSize = 5;

    /** @type {boolean} Whether snapping is enabled. */
    var enabled = true;

    /** @type {number} Snap threshold in mm for alignment guides. */
    var snapThreshold = 2;

    /**
     * Round a value to the nearest grid increment.
     *
     * @param {number} value
     * @return {number}
     */
    function snapValue(value) {
        return Math.round(value / gridSize) * gridSize;
    }

    return {

        /**
         * Set the grid size in mm.
         *
         * @param {number} mm Grid spacing in millimetres.
         */
        setGridSize: function(mm) {
            if (mm > 0) {
                gridSize = mm;
            }
        },

        /**
         * Get the current grid size.
         *
         * @return {number}
         */
        getGridSize: function() {
            return gridSize;
        },

        /**
         * Snap coordinates to the nearest grid point.
         *
         * @param {number} x X coordinate in mm.
         * @param {number} y Y coordinate in mm.
         * @return {{x: number, y: number}} Snapped coordinates.
         */
        snapToGrid: function(x, y) {
            if (!enabled) {
                return {x: x, y: y};
            }
            return {
                x: snapValue(x),
                y: snapValue(y)
            };
        },

        /**
         * Enable or disable grid snapping.
         *
         * @param {boolean} state
         */
        setEnabled: function(state) {
            enabled = !!state;
        },

        /**
         * Whether grid snapping is currently enabled.
         *
         * @return {boolean}
         */
        isEnabled: function() {
            return enabled;
        },

        /**
         * Set the snap threshold for alignment guides.
         *
         * @param {number} mm Threshold in mm.
         */
        setSnapThreshold: function(mm) {
            if (mm > 0) {
                snapThreshold = mm;
            }
        },

        /**
         * Calculate alignment guide lines for a given element relative to all other elements.
         *
         * Returns an object with arrays of vertical and horizontal guide positions (in mm)
         * and optional snapped x/y values when the element is within threshold of an alignment.
         *
         * @param {Object} element The element being moved with {x, y, width, height}.
         * @param {Array}  allElements All elements on the canvas.
         * @return {Object} { vertical: [], horizontal: [], snapX: number|null, snapY: number|null }
         */
        getAlignmentGuides: function(element, allElements) {
            var vertical = [];
            var horizontal = [];
            var snapX = null;
            var snapY = null;

            var elCenterX = element.x + element.width / 2;
            var elCenterY = element.y + element.height / 2;
            var elRight = element.x + element.width;
            var elBottom = element.y + element.height;

            for (var i = 0; i < allElements.length; i++) {
                var other = allElements[i];

                // Skip the element itself.
                if (other.id === element.id) {
                    continue;
                }

                var otherCenterX = other.x + other.width / 2;
                var otherCenterY = other.y + other.height / 2;
                var otherRight = other.x + other.width;
                var otherBottom = other.y + other.height;

                // Vertical guides (x-axis alignment).
                // Left edge to left edge.
                if (Math.abs(element.x - other.x) <= snapThreshold) {
                    vertical.push(other.x);
                    snapX = other.x;
                }
                // Right edge to right edge.
                if (Math.abs(elRight - otherRight) <= snapThreshold) {
                    vertical.push(otherRight);
                    snapX = otherRight - element.width;
                }
                // Center-x to center-x.
                if (Math.abs(elCenterX - otherCenterX) <= snapThreshold) {
                    vertical.push(otherCenterX);
                    snapX = otherCenterX - element.width / 2;
                }
                // Left edge to right edge.
                if (Math.abs(element.x - otherRight) <= snapThreshold) {
                    vertical.push(otherRight);
                    snapX = otherRight;
                }
                // Right edge to left edge.
                if (Math.abs(elRight - other.x) <= snapThreshold) {
                    vertical.push(other.x);
                    snapX = other.x - element.width;
                }

                // Horizontal guides (y-axis alignment).
                // Top edge to top edge.
                if (Math.abs(element.y - other.y) <= snapThreshold) {
                    horizontal.push(other.y);
                    snapY = other.y;
                }
                // Bottom edge to bottom edge.
                if (Math.abs(elBottom - otherBottom) <= snapThreshold) {
                    horizontal.push(otherBottom);
                    snapY = otherBottom - element.height;
                }
                // Center-y to center-y.
                if (Math.abs(elCenterY - otherCenterY) <= snapThreshold) {
                    horizontal.push(otherCenterY);
                    snapY = otherCenterY - element.height / 2;
                }
                // Top edge to bottom edge.
                if (Math.abs(element.y - otherBottom) <= snapThreshold) {
                    horizontal.push(otherBottom);
                    snapY = otherBottom;
                }
                // Bottom edge to top edge.
                if (Math.abs(elBottom - other.y) <= snapThreshold) {
                    horizontal.push(other.y);
                    snapY = other.y - element.height;
                }
            }

            return {
                vertical: vertical,
                horizontal: horizontal,
                snapX: snapX,
                snapY: snapY
            };
        }
    };
});
