// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main drag & drop certificate editor for mod_certstudio.
 *
 * @module     mod_certstudio/editor
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([
    'core/ajax',
    'core/templates',
    'mod_certstudio/elements',
    'mod_certstudio/history',
    'mod_certstudio/grid'
], function(Ajax, Templates, Elements, History, Grid) {
    'use strict';

    var config = {};
    var elements = [];
    var selectedId = null;
    var nextTempId = 1;
    var PX_PER_MM = 3.7795275591;
    var zoom = 1.0;
    var canvasEl = null;
    var clipboard = null;
    var isDragging = false;
    var isDirty = false;
    var autosaveTimer = null;
    var autosaveCountdown = null;
    var autosaveSecondsLeft = 0;
    var lastSavedTime = null;
    var AUTOSAVE_INTERVAL = 60000; // 60 seconds.

    /**
     * Convert millimetres to pixels at the current zoom level.
     *
     * @param {number} mm Value in millimetres.
     * @return {number} Value in pixels.
     */
    function mmToPx(mm) { return mm * PX_PER_MM * zoom; }

    /**
     * Convert pixels to millimetres at the current zoom level.
     *
     * @param {number} px Value in pixels.
     * @return {number} Value in millimetres.
     */
    function pxToMm(px) { return px / (PX_PER_MM * zoom); }

    /**
     * Find an element by its ID.
     *
     * @param {string|number} id The element ID.
     * @return {Object|null} The element or null if not found.
     */
    function findElement(id) {
        id = String(id);
        for (var i = 0; i < elements.length; i++) {
            if (String(elements[i].id) === id) { return elements[i]; }
        }
        return null;
    }

    /**
     * Get the next available sequence number for element z-ordering.
     *
     * @return {number} The next sequence number.
     */
    function nextSequence() {
        var max = 0;
        elements.forEach(function(el) { if ((el.sequence || 0) > max) { max = el.sequence; } });
        return max + 1;
    }

    /**
     * Format a date as a human-readable relative time string.
     *
     * @param {Date} date The date to format.
     * @return {string} Relative time string such as 'just now' or '5m ago'.
     */
    function formatTimeAgo(date) {
        if (!date) { return ''; }
        var now = new Date();
        var diff = Math.floor((now - date) / 1000);
        if (diff < 5) { return 'just now'; }
        if (diff < 60) { return diff + 's ago'; }
        if (diff < 3600) { return Math.floor(diff / 60) + 'm ago'; }
        return date.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    }

    /**
     * Update the save status indicator in the toolbar.
     *
     * @param {string} state One of 'dirty', 'saving', or 'saved'.
     */
    function updateSaveStatus(state) {
        var statusEl = document.getElementById('certstudio-save-status');
        if (!statusEl) { return; }
        var iconEl = statusEl.querySelector('.fa');
        var textEl = statusEl.querySelector('.certstudio-save-status-text');
        statusEl.classList.remove('is-dirty', 'is-saving');

        if (state === 'dirty') {
            statusEl.classList.add('is-dirty');
            if (iconEl) { iconEl.className = 'fa fa-circle-o'; }
            if (textEl) {
                var countdownStr = autosaveSecondsLeft > 0 ? ' \u00B7 autosave in ' + autosaveSecondsLeft + 's' : '';
                var ago = lastSavedTime
                    ? 'Last saved ' + formatTimeAgo(lastSavedTime) + countdownStr
                    : 'Unsaved changes' + countdownStr;
                textEl.textContent = ago;
            }
        } else if (state === 'saving') {
            statusEl.classList.add('is-saving');
            if (iconEl) { iconEl.className = 'fa fa-spinner fa-spin'; }
            if (textEl) { textEl.textContent = 'Saving...'; }
        } else if (state === 'saved') {
            if (iconEl) { iconEl.className = 'fa fa-check-circle'; }
            if (textEl) { textEl.textContent = 'Saved just now'; }
        }
    }

    /**
     * Start the autosave countdown timer and update the status display.
     */
    function startAutosaveCountdown() {
        if (autosaveCountdown) { clearInterval(autosaveCountdown); }
        autosaveSecondsLeft = Math.round(AUTOSAVE_INTERVAL / 1000);
        updateSaveStatus('dirty');
        autosaveCountdown = setInterval(function() {
            autosaveSecondsLeft--;
            if (autosaveSecondsLeft <= 0) {
                clearInterval(autosaveCountdown);
                autosaveCountdown = null;
                autosaveSecondsLeft = 0;
            }
            if (isDirty) { updateSaveStatus('dirty'); }
        }, 1000);
    }

    /**
     * Stop the autosave countdown timer and reset seconds remaining.
     */
    function stopAutosaveCountdown() {
        if (autosaveCountdown) { clearInterval(autosaveCountdown); autosaveCountdown = null; }
        autosaveSecondsLeft = 0;
    }

    /**
     * Mark the editor state as having unsaved changes and reset the autosave timer.
     */
    function markDirty() {
        isDirty = true;
        // Reset autosave timer.
        if (autosaveTimer) { clearTimeout(autosaveTimer); }
        autosaveTimer = setTimeout(function() {
            if (isDirty) {
                save(null, true); // silent autosave
            }
        }, AUTOSAVE_INTERVAL);
        startAutosaveCountdown();
    }

    /**
     * Push the current elements state to the undo history and mark as dirty.
     */
    function pushHistory() { History.push(elements); markDirty(); }

    /**
     * Display a temporary toast notification message.
     *
     * @param {string} message The message to display.
     * @param {string} type Notification type: 'success', 'error', or 'info'.
     */
    function showToast(message, type) {
        var existing = document.getElementById('certstudio-toast');
        if (existing) { existing.remove(); }
        var iconClass = 'fa-info-circle';
        if (type === 'success') {
            iconClass = 'fa-check-circle';
        } else if (type === 'error') {
            iconClass = 'fa-exclamation-circle';
        }
        Templates.render('mod_certstudio/toast', {iconclass: iconClass, message: message})
        .then(function(html) {
            var toast = document.createElement('div');
            toast.id = 'certstudio-toast';
            toast.className = 'certstudio-toast certstudio-toast-' + (type || 'info');
            toast.innerHTML = html;
            var editor = document.getElementById('certstudio-editor');
            if (editor) { editor.appendChild(toast); } else { document.body.appendChild(toast); }
            requestAnimationFrame(function() { toast.classList.add('show'); });
            setTimeout(function() {
                toast.classList.remove('show');
                setTimeout(function() { toast.remove(); }, 300);
            }, 2500);
            return;
        }).catch(function() { /* silent */ });
    }

    // --- DOM Rendering ---

    /**
     * Update only position and size CSS without touching innerHTML.
     * Used during drag for performance.
     *
     * @param {Object} el The element data object.
     */
    function updateElementPosition(el) {
        var domEl = document.getElementById('certstudio-el-' + el.id);
        if (!domEl) { return; }
        domEl.style.left = mmToPx(el.posx) + 'px';
        domEl.style.top = mmToPx(el.posy) + 'px';
        domEl.style.width = mmToPx(el.width) + 'px';
        domEl.style.height = mmToPx(el.height) + 'px';
    }

    /**
     * Render or update a single element on the editor canvas.
     *
     * @param {Object} el The element data object to render.
     */
    function renderElementOnCanvas(el) {
        var domId = 'certstudio-el-' + el.id;
        var domEl = document.getElementById(domId);

        if (!domEl) {
            domEl = document.createElement('div');
            domEl.id = domId;
            domEl.className = 'certstudio-element';
            domEl.setAttribute('data-element-id', el.id);
            domEl.setAttribute('data-type', el.type);
            canvasEl.appendChild(domEl);
        }

        domEl.style.left = mmToPx(el.posx) + 'px';
        domEl.style.top = mmToPx(el.posy) + 'px';
        domEl.style.width = mmToPx(el.width) + 'px';
        domEl.style.height = mmToPx(el.height) + 'px';
        domEl.style.opacity = el.opacity !== undefined ? el.opacity : 1;
        domEl.style.zIndex = el.sequence || 0;
        domEl.style.transform = el.rotation ? 'rotate(' + el.rotation + 'deg)' : '';

        if (el.locked) { domEl.classList.add('locked'); } else { domEl.classList.remove('locked'); }

        domEl.innerHTML = Elements.renderPreview(el.type, el);

        if (String(el.id) === String(selectedId)) {
            domEl.classList.add('selected');
            if (!domEl.querySelector('.certstudio-handle')) {
                ['nw','ne','sw','se'].forEach(function(pos) {
                    var h = document.createElement('div');
                    h.className = 'certstudio-handle certstudio-handle-' + pos;
                    domEl.appendChild(h);
                });
            }
        } else {
            domEl.classList.remove('selected');
            domEl.querySelectorAll('.certstudio-handle').forEach(function(h) { h.remove(); });
        }
    }

    /**
     * Re-render all elements on the canvas and update the layers panel.
     */
    function renderAll() {
        canvasEl.querySelectorAll('.certstudio-element').forEach(function(domEl) {
            if (!findElement(domEl.getAttribute('data-element-id'))) { domEl.remove(); }
        });
        elements.forEach(renderElementOnCanvas);
        updateLayersPanel();
    }

    /**
     * Update the page dimensions display in the toolbar.
     */
    function updatePageInfoDisplay() {
        var pageInfo = document.getElementById('certstudio-page-info');
        if (pageInfo) {
            var page = config.page || {};
            pageInfo.textContent = (page.width || 297) + 'mm \u00D7 ' + (page.height || 210) + 'mm';
        }
    }

    /**
     * Update the canvas element dimensions based on page config and zoom level.
     */
    function updateCanvasSize() {
        if (!canvasEl) { return; }
        var page = config.page || {};
        canvasEl.style.width = mmToPx(page.width || 297) + 'px';
        canvasEl.style.height = mmToPx(page.height || 210) + 'px';
        var display = document.getElementById('certstudio-zoom-display');
        if (display) { display.textContent = Math.round(zoom * 100) + '%'; }
        updatePageInfoDisplay();
    }

    /**
     * Automatically adjust the zoom level so the canvas fits within the wrapper.
     */
    function zoomToFit() {
        var wrapper = document.getElementById('certstudio-canvas-wrapper');
        if (!wrapper) { return; }
        var page = config.page || {};
        var pw = (page.width || 297) * PX_PER_MM;
        var ph = (page.height || 210) * PX_PER_MM;
        var ww = wrapper.clientWidth - 60;
        var wh = wrapper.clientHeight - 60;
        var fitZoom = Math.min(ww / pw, wh / ph, 1.0);
        zoom = Math.round(fitZoom * 20) / 20; // Round to nearest 5%.
        if (zoom < 0.3) { zoom = 0.3; }
        updateCanvasSize();
        renderAll();
    }

    /** @type {number} Counter to discard stale layer renders. */
    var layersRenderCount = 0;

    /**
     * Rebuild the layers panel listing all elements sorted by z-order.
     */
    function updateLayersPanel() {
        var listEl = document.getElementById('certstudio-layers-list');
        if (!listEl) { return; }
        var sorted = elements.slice().sort(function(a, b) { return (b.sequence || 0) - (a.sequence || 0); });
        var context = {layers: sorted.map(function(el) {
            var cfg = Elements.getTypeConfig(el.type);
            return {
                elementid: el.id,
                icon: cfg ? cfg.icon : 'fa-question',
                name: el.name || el.type,
                isactive: String(el.id) === String(selectedId),
                islocked: !!el.locked,
                lockicon: el.locked ? 'fa-lock' : 'fa-unlock'
            };
        })};

        var renderCount = ++layersRenderCount;
        Templates.render('mod_certstudio/layers_list', context)
        .then(function(html) {
            if (renderCount !== layersRenderCount) { return; }
            listEl.innerHTML = html;
            listEl.querySelectorAll('.certstudio-layer-item').forEach(function(item) {
                item.addEventListener('click', function(e) {
                    var elId = item.getAttribute('data-element-id');
                    var el = findElement(elId);
                    if (!el) { return; }
                    if (e.target.closest('.certstudio-layer-delete')) {
                        deleteElement(elId);
                        return;
                    }
                    if (e.target.closest('.certstudio-layer-lock')) {
                        el.locked = el.locked ? 0 : 1;
                        renderAll();
                        return;
                    }
                    if (e.target.closest('.certstudio-layer-up')) {
                        var curSeq = el.sequence || 0;
                        var swapEl = null;
                        elements.forEach(function(other) {
                            if ((other.sequence || 0) > curSeq) {
                                if (!swapEl || (other.sequence || 0) < (swapEl.sequence || 0)) {
                                    swapEl = other;
                                }
                            }
                        });
                        if (swapEl) {
                            var tmp = el.sequence; el.sequence = swapEl.sequence; swapEl.sequence = tmp;
                            renderAll();
                        }
                        return;
                    }
                    if (e.target.closest('.certstudio-layer-down')) {
                        var curSeq2 = el.sequence || 0;
                        var swapEl2 = null;
                        elements.forEach(function(other) {
                            if ((other.sequence || 0) < curSeq2) {
                                if (!swapEl2 || (other.sequence || 0) > (swapEl2.sequence || 0)) {
                                    swapEl2 = other;
                                }
                            }
                        });
                        if (swapEl2) {
                            var tmp2 = el.sequence; el.sequence = swapEl2.sequence; swapEl2.sequence = tmp2;
                            renderAll();
                        }
                        return;
                    }
                    selectElement(elId);
                });
            });
            return;
        }).catch(function() { /* silent */ });
    }

    // --- Properties Panel ---

    /**
     * Build a select field for the element settings panel.
     *
     * A value that is not among the choices shows the first choice, which is what the server uses for it.
     *
     * @param {string} label Field label.
     * @param {string} name Data field name.
     * @param {Array} choices List of {value, label} from the editor config.
     * @param {string} current Current value.
     * @return {Object} The field for the element_panel template.
     */
    function selectField(label, name, choices, current) {
        var known = (choices || []).some(function(c) { return c.value === current; });
        return {label: label, name: name, isselect: true, options: (choices || []).map(function(c, i) {
            return {value: c.value, label: c.label, selected: known ? c.value === current : i === 0};
        })};
    }

    /**
     * Update the properties panel to reflect the currently selected element.
     */
    function updatePropertiesPanel() {
        var noSel = document.querySelector('.certstudio-no-selection');
        var fields = document.querySelector('.certstudio-property-fields');
        if (!noSel || !fields) { return; }

        if (selectedId === null) { noSel.style.display = ''; fields.style.display = 'none'; return; }
        var el = findElement(selectedId);
        if (!el) { noSel.style.display = ''; fields.style.display = 'none'; return; }

        noSel.style.display = 'none';
        fields.style.display = '';

        var setVal = function(id, val) {
            var input = document.getElementById(id);
            if (input) { input.value = val !== undefined && val !== null ? val : ''; }
        };
        setVal('certstudio-prop-name', el.name || el.type);
        setVal('certstudio-prop-x', parseFloat(el.posx).toFixed(1));
        setVal('certstudio-prop-y', parseFloat(el.posy).toFixed(1));
        setVal('certstudio-prop-width', parseFloat(el.width).toFixed(1));
        setVal('certstudio-prop-height', parseFloat(el.height).toFixed(1));
        setVal('certstudio-prop-rotation', el.rotation || 0);
        setVal('certstudio-prop-font', el.fontfamily || 'Roboto');
        setVal('certstudio-prop-fontsize', el.fontsize || 14);
        setVal('certstudio-prop-color', el.color || '#000000');
        setVal('certstudio-prop-opacity', el.opacity !== undefined ? el.opacity : 1);

        var boldBtn = document.getElementById('certstudio-prop-bold');
        var italicBtn = document.getElementById('certstudio-prop-italic');
        if (boldBtn) { boldBtn.classList.toggle('active', el.fontweight === 'bold'); }
        if (italicBtn) { italicBtn.classList.toggle('active', el.fontstyle === 'italic'); }

        ['L', 'C', 'R'].forEach(function(a) {
            var btn = document.getElementById('certstudio-prop-align-' + a.toLowerCase());
            if (btn) { btn.classList.toggle('active', el.alignment === a); }
        });

        var textProps = document.querySelector('.certstudio-text-props');
        if (textProps) { textProps.style.display = Elements.isTextType(el.type) ? '' : 'none'; }

        // Element-specific data via Mustache template.
        var dataDiv = document.getElementById('certstudio-element-data');
        if (dataDiv) {
            var fields = [];
            if (el.type === 'text') {
                fields.push({label: 'Text content', name: 'text', istextarea: true,
                    value: (el.data && el.data.text) || ''});
            } else if (el.type === 'date' || el.type === 'daterange' || el.type === 'expiry') {
                fields.push(selectField('Date format', 'dateformat', config.dateformats,
                    (el.data && el.data.dateformat) || ''));
                if (el.type === 'daterange') {
                    fields.push({label: '', name: '', isinfo: true, value: 'Course start date - Course end date'});
                } else if (el.type === 'expiry') {
                    fields.push({label: '', name: '', isinfo: true,
                        value: 'Set "Certificate validity (days)" in the activity settings. ' +
                            'Empty if the certificate does not expire.'});
                }
            } else if (el.type === 'grade' || el.type === 'gradeitemname') {
                fields.push(selectField('Grade item', 'gradeitem', config.gradeitems,
                    (el.data && el.data.gradeitem) || ''));
            } else if (el.type === 'coursefield') {
                // Designs migrated from Custom certificate by 1.0.0 hold the field as {name} in the text.
                var legacyField = ((el.data && el.data.text) || '').match(/^\{(\w+)\}$/);
                fields.push(selectField('Course field', 'fieldname', config.coursefields,
                    (el.data && el.data.fieldname) || (legacyField ? legacyField[1] : '')));
            } else if (el.type === 'certdate') {
                fields.push({label: 'City', name: 'city', istext: true,
                    value: (el.data && el.data.city) || 'Αθήνα'});
            } else if (el.type === 'userfield') {
                fields.push({label: 'Field name', name: 'fieldname', istext: true,
                    value: (el.data && el.data.fieldname) || ''});
            } else if (el.type === 'bgimage') {
                var bgd = el.data || {};
                var sm = bgd.sizemode || 'cover';
                fields.push({label: 'Size Mode', name: 'sizemode', isselect: true, options: [
                    {value: 'cover', label: 'Cover (fill page)', selected: sm === 'cover'},
                    {value: 'contain', label: 'Contain (fit inside)', selected: sm === 'contain'},
                    {value: 'stretch', label: 'Stretch', selected: sm === 'stretch'},
                    {value: 'actual', label: 'Actual Size', selected: sm === 'actual'}
                ]});
                fields.push({label: 'Image source', name: '', isinfo: true,
                    value: 'Double-click element to upload'});
            } else if (el.type === 'border') {
                var bd = el.data || {};
                fields.push({label: 'Border width (px)', name: 'borderwidth', isnumber: true,
                    value: bd.borderwidth || 2});
                fields.push({label: 'Border color', name: 'bordercolor', iscolor: true,
                    value: bd.bordercolor || '#1a237e'});
            }
            Templates.render('mod_certstudio/element_panel', {type: el.type, fields: fields})
            .then(function(html) {
                dataDiv.innerHTML = html;
                dataDiv.querySelectorAll('.certstudio-data-input').forEach(function(input) {
                    input.addEventListener('input', function() {
                        var el2 = findElement(selectedId);
                        if (!el2) { return; }
                        if (!el2.data) { el2.data = {}; }
                        el2.data[input.getAttribute('data-field')] = input.value;
                        renderElementOnCanvas(el2);
                    });
                    input.addEventListener('change', function() {
                        var el2 = findElement(selectedId);
                        if (!el2) { return; }
                        if (!el2.data) { el2.data = {}; }
                        el2.data[input.getAttribute('data-field')] = input.value;
                        renderElementOnCanvas(el2);
                        pushHistory();
                    });
                });
                return;
            }).catch(function() { /* silent */ });
        }
    }

    /**
     * Update only x/y/w/h fields in the properties panel without a full rebuild.
     *
     * @param {Object} el The element data object.
     */
    function updatePositionFields(el) {
        var setVal = function(id, val) {
            var input = document.getElementById(id);
            if (input) { input.value = val; }
        };
        setVal('certstudio-prop-x', parseFloat(el.posx).toFixed(1));
        setVal('certstudio-prop-y', parseFloat(el.posy).toFixed(1));
        setVal('certstudio-prop-width', parseFloat(el.width).toFixed(1));
        setVal('certstudio-prop-height', parseFloat(el.height).toFixed(1));
    }

    /**
     * Select an element by ID and update the UI.
     *
     * @param {string|null} id The element ID to select, or null to deselect.
     */
    function selectElement(id) {
        selectedId = id !== null && id !== undefined ? String(id) : null;
        renderAll();
        updatePropertiesPanel();
    }

    /**
     * Deselect all elements.
     */
    function deselectAll() { selectElement(null); }

    /**
     * Add a new element of the given type to the canvas.
     *
     * @param {string} type The element type identifier.
     * @param {number} x Initial X position in mm.
     * @param {number} y Initial Y position in mm.
     * @return {Object} The newly created element object.
     */
    function addElement(type, x, y) {
        var defaults = Elements.getDefaultProperties(type);
        var cfg = Elements.getTypeConfig(type);
        var el = {
            id: 'temp-' + (nextTempId++),
            pageid: config.page.id,
            type: type,
            name: cfg ? cfg.label : type,
            data: {},
            posx: x || 20,
            posy: y || 20,
            width: defaults.width || 50,
            height: defaults.height || 20,
            rotation: 0,
            fontfamily: defaults.fontfamily || 'Roboto',
            fontsize: defaults.fontsize || 14,
            fontweight: defaults.fontweight || 'normal',
            fontstyle: defaults.fontstyle || 'normal',
            color: defaults.color || '#000000',
            alignment: defaults.alignment || 'L',
            opacity: 1,
            locked: 0,
            sequence: nextSequence()
        };
        if (type === 'text') { el.data = {text: 'Sample Text'}; }
        if (type === 'certdate') { el.data = {city: 'Αθήνα'}; }
        elements.push(el);
        pushHistory();
        selectElement(el.id);
        renderAll();
        return el;
    }

    /**
     * Delete an element by ID from the canvas and optionally from the server.
     *
     * @param {string|number} id The element ID to delete.
     */
    function deleteElement(id) {
        elements = elements.filter(function(el) { return String(el.id) !== String(id); });
        var domEl = document.getElementById('certstudio-el-' + id);
        if (domEl) { domEl.remove(); }
        if (String(selectedId) === String(id)) { selectedId = null; }
        // Also delete from server if it has a real (non-temp) ID.
        if (String(id).indexOf('temp-') !== 0) {
            Ajax.call([{
                methodname: 'mod_certstudio_delete_element',
                args: {cmid: config.cmid, elementid: Number(id)}
            }]);
        }
        pushHistory(); renderAll(); updatePropertiesPanel();
    }

    /**
     * Save all elements and page settings to the server via AJAX.
     *
     * @param {Function|null} callback Optional callback to invoke on success.
     * @param {boolean} silent If true, suppress visual feedback.
     */
    function save(callback, silent) {
        var saveData = elements.map(function(el) {
            return {
                id: String(el.id).indexOf('temp-') === 0 ? null : el.id,
                pageid: el.pageid || config.page.id,
                name: el.name || el.type,
                type: el.type,
                data: el.data || {},
                posx: el.posx, posy: el.posy,
                width: el.width, height: el.height,
                rotation: el.rotation || 0,
                fontfamily: el.fontfamily || 'Roboto',
                fontsize: el.fontsize || 14,
                fontweight: el.fontweight || 'normal',
                fontstyle: el.fontstyle || 'normal',
                color: el.color || '#000000',
                alignment: el.alignment || 'L',
                opacity: el.opacity !== undefined ? el.opacity : 1,
                locked: el.locked ? 1 : 0,
                sequence: el.sequence || 0
            };
        });

        // Save page settings too.
        Ajax.call([{
            methodname: 'mod_certstudio_save_page',
            args: {
                cmid: config.cmid,
                page: JSON.stringify({
                    id: config.page.id,
                    width: config.page.width,
                    height: config.page.height,
                    leftmargin: config.page.leftmargin || 0,
                    rightmargin: config.page.rightmargin || 0,
                    bgcolor: config.page.bgcolor || '#ffffff',
                    backgroundimage: config.page.backgroundimage || ''
                })
            }
        }]);

        var saveBtn = document.getElementById('certstudio-save');
        if (!silent && saveBtn) { saveBtn.disabled = true; saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving...'; }
        updateSaveStatus('saving');

        Ajax.call([{
            methodname: 'mod_certstudio_save_elements',
            args: {cmid: config.cmid, elements: JSON.stringify(saveData)}
        }])[0].then(function(data) {
            if (!silent && saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = '<i class="fa fa-save"></i> Save'; }
            if (data.ids) {
                for (var i = 0; i < elements.length; i++) {
                    var oldId = elements[i].id;
                    elements[i].id = data.ids[i];
                    var d = document.getElementById('certstudio-el-' + oldId);
                    if (d) { d.id = 'certstudio-el-' + data.ids[i]; d.setAttribute('data-element-id', data.ids[i]); }
                }
                isDirty = false;
                lastSavedTime = new Date();
                if (autosaveTimer) { clearTimeout(autosaveTimer); autosaveTimer = null; }
                stopAutosaveCountdown();
                updateSaveStatus('saved');
                selectedId = null; renderAll(); updatePropertiesPanel();
                if (!silent) {
                    showToast('Saved!', 'success');
                }
                if (typeof callback === 'function') { callback(); }
            }
        })
        .catch(function(err) {
            if (!silent && saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = '<i class="fa fa-save"></i> Save'; }
            updateSaveStatus('dirty');
            window.console.error(err);
        });
    }

    /** @type {number} Snap threshold in mm for alignment guides. */
    var SNAP_THRESHOLD = 2;

    /**
     * Show alignment guides on the canvas and snap the element to page centre.
     *
     * @param {Object} el The element being dragged.
     */
    function showAlignmentGuides(el) {
        clearAlignmentGuides();
        var page = config.page || {};
        var pw = page.width || 297;
        var ph = page.height || 210;
        var cx = el.posx + el.width / 2;
        var cy = el.posy + el.height / 2;
        var pageCx = pw / 2;
        var pageCy = ph / 2;

        // Snap to page center X.
        if (Math.abs(cx - pageCx) < SNAP_THRESHOLD) {
            el.posx = pageCx - el.width / 2;
            addGuide('v', pageCx, 0, ph);
        }
        // Snap to page center Y.
        if (Math.abs(cy - pageCy) < SNAP_THRESHOLD) {
            el.posy = pageCy - el.height / 2;
            addGuide('h', pageCy, 0, pw);
        }
        // Snap left edge to center.
        if (Math.abs(el.posx - pageCx) < SNAP_THRESHOLD) {
            el.posx = pageCx;
            addGuide('v', pageCx, 0, ph);
        }
        // Snap right edge to center.
        if (Math.abs(el.posx + el.width - pageCx) < SNAP_THRESHOLD) {
            el.posx = pageCx - el.width;
            addGuide('v', pageCx, 0, ph);
        }
    }

    /**
     * Add a single alignment guide line to the canvas.
     *
     * @param {string} dir Direction: 'v' for vertical, 'h' for horizontal.
     * @param {number} pos Position in mm along the perpendicular axis.
     * @param {number} start Start position in mm along the guide axis.
     * @param {number} end End position in mm along the guide axis.
     */
    function addGuide(dir, pos, start, end) {
        var g = document.createElement('div');
        g.className = 'certstudio-align-guide';
        if (dir === 'v') {
            g.style.left = mmToPx(pos) + 'px';
            g.style.top = mmToPx(start) + 'px';
            g.style.width = '1px';
            g.style.height = mmToPx(end - start) + 'px';
        } else {
            g.style.left = mmToPx(start) + 'px';
            g.style.top = mmToPx(pos) + 'px';
            g.style.width = mmToPx(end - start) + 'px';
            g.style.height = '1px';
        }
        canvasEl.appendChild(g);
    }

    /**
     * Remove all alignment guide lines from the canvas.
     */
    function clearAlignmentGuides() {
        canvasEl.querySelectorAll('.certstudio-align-guide').forEach(function(g) { g.remove(); });
    }

    /**
     * Set up pointer-based drag and resize interaction on canvas elements.
     */
    function setupInteract() {
        // Native pointer-based drag & resize (replaces interact.js for reliability).
        var dragState = null; // {el, domEl, startX, startY, startPosx, startPosy, mode, handle}

        /**
         * Determine the resize handle direction from the target element.
         *
         * @param {HTMLElement} target The event target element.
         * @return {string|null} Handle direction or null.
         */
        function getHandleDir(target) {
            if (!target) { return null; }
            if (target.classList.contains('certstudio-handle-nw')) { return 'nw'; }
            if (target.classList.contains('certstudio-handle-ne')) { return 'ne'; }
            if (target.classList.contains('certstudio-handle-sw')) { return 'sw'; }
            if (target.classList.contains('certstudio-handle-se')) { return 'se'; }
            return null;
        }

        /**
         * Clamp an element's position to stay within page boundaries.
         *
         * @param {Object} el The element to clamp.
         */
        function clampToPage(el) {
            var page = config.page || {};
            var pw = page.width || 297;
            var ph = page.height || 210;
            if (el.posx < 0) { el.posx = 0; }
            if (el.posy < 0) { el.posy = 0; }
            if (el.posx + el.width > pw) { el.posx = pw - el.width; }
            if (el.posy + el.height > ph) { el.posy = ph - el.height; }
        }

        canvasEl.addEventListener('pointerdown', function(e) {
            // Find if we hit a handle or an element.
            var handleDir = getHandleDir(e.target);
            var domEl = e.target.closest('.certstudio-element');
            if (!domEl) { return; }

            var id = domEl.getAttribute('data-element-id');
            var el = findElement(id);
            if (!el || el.locked) { return; }

            e.preventDefault();

            // Select element if not already selected.
            if (String(selectedId) !== String(id)) {
                var prev = selectedId ? document.getElementById('certstudio-el-' + selectedId) : null;
                if (prev) {
                    prev.classList.remove('selected');
                    prev.querySelectorAll('.certstudio-handle').forEach(function(h) {
                        h.remove();
                    });
                }
                selectedId = String(id);
                domEl.classList.add('selected');
                ['nw','ne','sw','se'].forEach(function(pos) {
                    var h = document.createElement('div');
                    h.className = 'certstudio-handle certstudio-handle-' + pos;
                    domEl.appendChild(h);
                });
                updatePropertiesPanel();
                updateLayersPanel();
            }

            var mode = handleDir ? 'resize' : 'drag';
            dragState = {
                el: el,
                domEl: domEl,
                startX: e.clientX,
                startY: e.clientY,
                startPosx: el.posx,
                startPosy: el.posy,
                startW: el.width,
                startH: el.height,
                mode: mode,
                handle: handleDir,
                moved: false
            };

            isDragging = true;
            if (mode === 'drag') { domEl.classList.add('dragging'); }
            canvasEl.setPointerCapture(e.pointerId);
        });

        canvasEl.addEventListener('pointermove', function(e) {
            if (!dragState) { return; }
            e.preventDefault();
            dragState.moved = true;

            var dx = pxToMm(e.clientX - dragState.startX);
            var dy = pxToMm(e.clientY - dragState.startY);
            var el = dragState.el;

            if (dragState.mode === 'drag') {
                el.posx = dragState.startPosx + dx;
                el.posy = dragState.startPosy + dy;
                if (Grid.isEnabled()) {
                    var s = Grid.snapToGrid(el.posx, el.posy);
                    el.posx = s.x; el.posy = s.y;
                }
                clampToPage(el);
                showAlignmentGuides(el);
                updateElementPosition(el);
                updatePositionFields(el);
            } else {
                // Resize from corner handle.
                var h = dragState.handle;
                var newW = dragState.startW;
                var newH = dragState.startH;
                var newX = dragState.startPosx;
                var newY = dragState.startPosy;
                var minW = 5; var minH = 3;

                if (h === 'se') {
                    newW = Math.max(minW, dragState.startW + dx);
                    newH = Math.max(minH, dragState.startH + dy);
                } else if (h === 'sw') {
                    newW = Math.max(minW, dragState.startW - dx);
                    newH = Math.max(minH, dragState.startH + dy);
                    newX = dragState.startPosx + dragState.startW - newW;
                } else if (h === 'ne') {
                    newW = Math.max(minW, dragState.startW + dx);
                    newH = Math.max(minH, dragState.startH - dy);
                    newY = dragState.startPosy + dragState.startH - newH;
                } else if (h === 'nw') {
                    newW = Math.max(minW, dragState.startW - dx);
                    newH = Math.max(minH, dragState.startH - dy);
                    newX = dragState.startPosx + dragState.startW - newW;
                    newY = dragState.startPosy + dragState.startH - newH;
                }
                el.width = newW; el.height = newH;
                el.posx = newX; el.posy = newY;

                // Clamp.
                var page = config.page || {};
                var pw = page.width || 297;
                var ph = page.height || 210;
                if (el.posx < 0) { el.width += el.posx; el.posx = 0; }
                if (el.posy < 0) { el.height += el.posy; el.posy = 0; }
                if (el.posx + el.width > pw) { el.width = pw - el.posx; }
                if (el.posy + el.height > ph) { el.height = ph - el.posy; }

                updateElementPosition(el);
                updatePositionFields(el);
            }
        });

        canvasEl.addEventListener('pointerup', function() {
            if (!dragState) { return; }
            var el = dragState.el;
            var domEl = dragState.domEl;
            var moved = dragState.moved;
            domEl.classList.remove('dragging');
            clearAlignmentGuides();

            if (moved) {
                renderElementOnCanvas(el);
                pushHistory();
            }

            dragState = null;
            // Defer isDragging = false so the click handler doesn't fire selectElement.
            setTimeout(function() { isDragging = false; }, 0);
            updatePropertiesPanel();
        });
    }

    /**
     * Set up the canvas as a drop zone for element palette items.
     */
    function setupDropZone() {
        if (!canvasEl) { return; }
        canvasEl.addEventListener('dragover', function(e) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
        canvasEl.addEventListener('drop', function(e) {
            e.preventDefault();
            var type = e.dataTransfer.getData('text/plain');
            if (!type || !Elements.getTypeConfig(type)) { return; }
            var rect = canvasEl.getBoundingClientRect();
            addElement(type, pxToMm(e.clientX - rect.left), pxToMm(e.clientY - rect.top));
        });
    }

    /**
     * Build the element type palette in the left panel.
     */
    function buildElementPalette() {
        var container = document.getElementById('certstudio-element-types');
        if (!container) { return; }
        var categories = Elements.getCategories();
        var context = {categories: categories.map(function(cat) {
            return {
                icon: cat.icon,
                label: cat.label,
                types: cat.types.map(function(type) {
                    var cfg = Elements.getTypeConfig(type);
                    return cfg ? {type: type, icon: cfg.icon, label: cfg.label} : null;
                }).filter(Boolean)
            };
        })};
        Templates.render('mod_certstudio/element_palette', context)
        .then(function(html) {
            container.innerHTML = html;
            // Set up category collapse toggles.
            container.querySelectorAll('.certstudio-category-header').forEach(function(header) {
                header.addEventListener('click', function() {
                    var grid = header.nextElementSibling;
                    if (grid) { grid.classList.toggle('collapsed'); }
                    header.classList.toggle('collapsed');
                });
            });
            setupElementTypesDrag();
            return;
        }).catch(function() { /* silent */ });
    }

    /**
     * Set up tab switching in the left panel.
     */
    function setupLeftPanelTabs() {
        document.querySelectorAll('.certstudio-left-tab').forEach(function(tab) {
            tab.addEventListener('click', function() {
                var target = tab.getAttribute('data-tab');
                document.querySelectorAll('.certstudio-left-tab').forEach(function(t) { t.classList.remove('active'); });
                document.querySelectorAll('.certstudio-left-tab-content').forEach(function(c) { c.classList.remove('active'); });
                tab.classList.add('active');
                var content = document.querySelector('.certstudio-left-tab-content[data-tab="' + target + '"]');
                if (content) { content.classList.add('active'); }
            });
        });
    }

    /**
     * Set up drag and double-click handlers on element type palette items.
     */
    function setupElementTypesDrag() {
        document.querySelectorAll('.certstudio-element-type').forEach(function(item) {
            item.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', item.getAttribute('data-type'));
                e.dataTransfer.effectAllowed = 'copy';
            });
            item.addEventListener('dblclick', function() {
                var type = item.getAttribute('data-type');
                var page = config.page || {};
                addElement(type, (page.width || 297) / 2 - 30, (page.height || 210) / 2 - 10);
            });
        });
    }

    /**
     * Set up keyboard shortcuts for delete, undo, redo, copy, and paste.
     */
    function setupKeyboard() {
        document.addEventListener('keydown', function(e) {
            var tag = (e.target.tagName || '').toLowerCase();
            if (tag === 'input' || tag === 'textarea' || tag === 'select') { return; }
            if ((e.key === 'Delete' || e.key === 'Backspace') && selectedId !== null) {
                e.preventDefault(); deleteElement(selectedId); return;
            }
            if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key === 'z') {
                e.preventDefault(); var s = History.undo(); if (s) { elements = s; renderAll(); } return;
            }
            if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.shiftKey && (e.key === 'z' || e.key === 'Z')))) {
                e.preventDefault(); var r = History.redo(); if (r) { elements = r; renderAll(); } return;
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'c' && selectedId) {
                clipboard = JSON.parse(JSON.stringify(findElement(selectedId))); return;
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'v' && clipboard) {
                e.preventDefault();
                var p = JSON.parse(JSON.stringify(clipboard));
                p.id = 'temp-' + (nextTempId++); p.posx += 5; p.posy += 5;
                p.sequence = nextSequence(); p.name = (p.name || p.type) + ' (copy)';
                elements.push(p); pushHistory(); selectElement(p.id); renderAll();
            }
        });
    }

    /**
     * Set up change handlers for the properties panel inputs.
     */
    function setupPropertyHandlers() {
        var map = {
            'certstudio-prop-name': function(el, v) { el.name = v; },
            'certstudio-prop-x': function(el, v) { el.posx = parseFloat(v) || 0; },
            'certstudio-prop-y': function(el, v) { el.posy = parseFloat(v) || 0; },
            'certstudio-prop-width': function(el, v) { el.width = parseFloat(v) || 10; },
            'certstudio-prop-height': function(el, v) { el.height = parseFloat(v) || 10; },
            'certstudio-prop-rotation': function(el, v) { el.rotation = parseInt(v) || 0; },
            'certstudio-prop-font': function(el, v) { el.fontfamily = v; },
            'certstudio-prop-fontsize': function(el, v) { el.fontsize = parseInt(v) || 14; },
            'certstudio-prop-color': function(el, v) { el.color = v; },
            'certstudio-prop-opacity': function(el, v) { el.opacity = parseFloat(v); }
        };
        Object.keys(map).forEach(function(id) {
            var input = document.getElementById(id);
            if (!input) { return; }
            var liveUpdate = function() {
                if (!selectedId) { return; }
                var el = findElement(selectedId);
                if (!el) { return; }
                map[id](el, input.value);
                renderElementOnCanvas(el); updateLayersPanel();
            };
            var commitChange = function() {
                if (!selectedId) { return; }
                liveUpdate();
                pushHistory();
            };
            input.addEventListener('input', liveUpdate);
            input.addEventListener('change', commitChange);
        });

        // Bold/Italic.
        var bBtn = document.getElementById('certstudio-prop-bold');
        if (bBtn) { bBtn.addEventListener('click', function() {
            var el = findElement(selectedId); if (!el) { return; }
            el.fontweight = el.fontweight === 'bold' ? 'normal' : 'bold';
            renderElementOnCanvas(el); updatePropertiesPanel(); pushHistory();
        }); }
        var iBtn = document.getElementById('certstudio-prop-italic');
        if (iBtn) { iBtn.addEventListener('click', function() {
            var el = findElement(selectedId); if (!el) { return; }
            el.fontstyle = el.fontstyle === 'italic' ? 'normal' : 'italic';
            renderElementOnCanvas(el); updatePropertiesPanel(); pushHistory();
        }); }

        // Alignment.
        ['l', 'c', 'r'].forEach(function(a) {
            var btn = document.getElementById('certstudio-prop-align-' + a);
            if (btn) { btn.addEventListener('click', function() {
                var el = findElement(selectedId); if (!el) { return; }
                el.alignment = a.toUpperCase();
                renderElementOnCanvas(el); updatePropertiesPanel(); pushHistory();
            }); }
        });

        // Lock.
        var lockBtn = document.getElementById('certstudio-prop-lock');
        if (lockBtn) { lockBtn.addEventListener('click', function() {
            var el = findElement(selectedId); if (!el) { return; }
            el.locked = el.locked ? 0 : 1; renderAll(); updatePropertiesPanel();
        }); }

        // Copy.
        var copyBtn = document.getElementById('certstudio-prop-copy');
        if (copyBtn) { copyBtn.addEventListener('click', function() {
            var el = findElement(selectedId); if (!el) { return; }
            var p = JSON.parse(JSON.stringify(el));
            p.id = 'temp-' + (nextTempId++); p.posx += 5; p.posy += 5;
            p.sequence = nextSequence(); p.name = (p.name || p.type) + ' (copy)';
            elements.push(p); pushHistory(); selectElement(p.id); renderAll();
        }); }

        // Delete.
        var delBtn = document.getElementById('certstudio-prop-delete');
        if (delBtn) { delBtn.addEventListener('click', function() { if (selectedId) { deleteElement(selectedId); } }); }
    }

    return {
        /**
         * Initialise the certificate editor.
         */
        init: function() {
            var configEl = document.getElementById('certstudio-config');
            if (configEl) {
                try { config = JSON.parse(configEl.getAttribute('data-config')); }
                catch (e) { window.console.error('certstudio: config parse error', e); config = {}; }
            }

            canvasEl = document.getElementById('certstudio-canvas');
            if (!canvasEl) { window.console.error('certstudio: canvas not found'); return; }

            elements = config.elements || [];
            // Settings are stored as named properties on data, so it must be an object, also for older saves stored as [].
            elements.forEach(function(el) {
                if (!el.data || Array.isArray(el.data)) {
                    el.data = {};
                }
            });
            nextTempId = elements.length + 100;

            if (config.fonts && config.fonts.length) {
                require(['mod_certstudio/fonts'], function(Fonts) { Fonts.loadCssFonts(config.fonts); });
            }

            // Auto-fit canvas to available space.
            zoomToFit();
            History.reset();
            History.push(elements); // Initial state, don't mark dirty.
            renderAll();

            buildElementPalette();
            setupLeftPanelTabs();
            setupInteract();
            setupDropZone();
            setupElementTypesDrag();
            setupKeyboard();
            setupPropertyHandlers();

            canvasEl.addEventListener('click', function(e) {
                if (isDragging) { return; } // Don't interfere with drag.
                if (e.target === canvasEl) { deselectAll(); }
                var target = e.target.closest('.certstudio-element');
                if (target) { selectElement(target.getAttribute('data-element-id')); }
            });

            // Save button.
            var saveBtn = document.getElementById('certstudio-save');
            if (saveBtn) { saveBtn.addEventListener('click', function(e) { e.preventDefault(); save(); }); }

            // Template name rename (on blur or Enter key).
            var templateNameInput = document.getElementById('certstudio-template-name');
            if (templateNameInput) {
                var renameTemplate = function() {
                    var newName = templateNameInput.value.trim();
                    if (!newName) { return; }
                    Ajax.call([{
                        methodname: 'mod_certstudio_rename_template',
                        args: {cmid: config.cmid, name: newName}
                    }])[0].then(function() {
                        showToast('Template renamed', 'success');
                    }).catch(function() { /* silent */ });
                };
                templateNameInput.addEventListener('blur', renameTemplate);
                templateNameInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') { e.preventDefault(); templateNameInput.blur(); }
                });
            }

            // Publish to Gallery button.
            var publishBtn = document.getElementById('certstudio-save-gallery');
            if (publishBtn) {
                publishBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var confirmMsg = 'Publish a copy of this template to the Gallery?' +
                        '\n\nThis will make it available as a built-in template ' +
                        'for ALL courses on this site.' +
                        '\nYour current template will not be affected.';
                    if (!window.confirm(confirmMsg)) {
                        return;
                    }
                    // First save current state, then publish.
                    save(function() {
                        publishBtn.disabled = true;
                        publishBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Publishing...';
                        Ajax.call([{
                            methodname: 'mod_certstudio_publish_to_gallery',
                            args: {cmid: config.cmid}
                        }])[0].then(function() {
                            publishBtn.disabled = false;
                            publishBtn.innerHTML = '<i class="fa fa-cloud-upload"></i> Save to Gallery';
                            showToast('Template published to Gallery!', 'success');
                        }).catch(function(err) {
                            publishBtn.disabled = false;
                            publishBtn.innerHTML = '<i class="fa fa-cloud-upload"></i> Save to Gallery';
                            showToast('Error: ' + (err.message || 'Unknown'), 'error');
                        });
                    });
                });
            }

            // Preview PDF.
            var previewBtn = document.getElementById('certstudio-preview-pdf');
            if (previewBtn) { previewBtn.addEventListener('click', function(e) {
                e.preventDefault();
                require(['mod_certstudio/renderer'], function(Renderer) {
                    Renderer.generatePdf(elements, config.page || {}, config.fonts || [], 'PREVIEW')
                    .then(function(blob) { window.open(URL.createObjectURL(blob), '_blank'); })
                    .catch(function(err) { window.console.error('PDF error:', err); });
                });
            }); }

            // Undo / Redo buttons.
            var undoBtn = document.getElementById('certstudio-undo');
            var redoBtn = document.getElementById('certstudio-redo');
            if (undoBtn) { undoBtn.addEventListener('click', function() {
                var s = History.undo(); if (s) { elements = s; renderAll(); }
            }); }
            if (redoBtn) { redoBtn.addEventListener('click', function() {
                var r = History.redo(); if (r) { elements = r; renderAll(); }
            }); }

            // Unsaved changes warning.
            window.addEventListener('beforeunload', function(e) {
                if (isDirty) {
                    e.preventDefault();
                    e.returnValue = '';
                }
            });

            // Zoom controls.
            var zi = document.getElementById('certstudio-zoom-in');
            var zo = document.getElementById('certstudio-zoom-out');
            if (zi) {
                zi.addEventListener('click', function() {
                    zoom = Math.min(2.0, zoom + 0.1);
                    updateCanvasSize();
                    renderAll();
                });
            }
            if (zo) {
                zo.addEventListener('click', function() {
                    zoom = Math.max(0.3, zoom - 0.1);
                    updateCanvasSize();
                    renderAll();
                });
            }

            // Grid toggle.
            var gridBtn = document.getElementById('certstudio-toggle-grid');
            if (gridBtn) {
                gridBtn.addEventListener('click', function() {
                    canvasEl.classList.toggle('show-grid');
                    gridBtn.classList.toggle('active');
                });
            }

            // Guides/Rulers toggle.
            var guidesBtn = document.getElementById('certstudio-toggle-guides');
            if (guidesBtn) {
                guidesBtn.addEventListener('click', function() {
                    var wrapper = document.getElementById('certstudio-canvas-wrapper');
                    if (!wrapper) { return; }
                    var existing = wrapper.querySelector('.certstudio-ruler-h');
                    if (existing) {
                        // Remove rulers.
                        wrapper.querySelectorAll('.certstudio-ruler-h, .certstudio-ruler-v').forEach(function(r) { r.remove(); });
                        canvasEl.classList.remove('show-guides');
                        guidesBtn.classList.remove('active');
                        return;
                    }
                    // Create horizontal ruler.
                    var hRuler = document.createElement('div');
                    hRuler.className = 'certstudio-ruler-h';
                    var pageW = config.page.width || 297;
                    var pageH = config.page.height || 210;
                    for (var i = 0; i <= pageW; i += 10) {
                        var tick = document.createElement('div');
                        tick.className = 'certstudio-ruler-tick' + (i % 50 === 0 ? ' major' : '');
                        tick.style.left = (i / pageW * 100) + '%';
                        if (i % 50 === 0) {
                            var label = document.createElement('span');
                            label.textContent = i;
                            tick.appendChild(label);
                        }
                        hRuler.appendChild(tick);
                    }
                    // Create vertical ruler.
                    var vRuler = document.createElement('div');
                    vRuler.className = 'certstudio-ruler-v';
                    for (var j = 0; j <= pageH; j += 10) {
                        var vtick = document.createElement('div');
                        vtick.className = 'certstudio-ruler-tick' + (j % 50 === 0 ? ' major' : '');
                        vtick.style.top = (j / pageH * 100) + '%';
                        if (j % 50 === 0) {
                            var vlabel = document.createElement('span');
                            vlabel.textContent = j;
                            vtick.appendChild(vlabel);
                        }
                        vRuler.appendChild(vtick);
                    }
                    wrapper.appendChild(hRuler);
                    wrapper.appendChild(vRuler);
                    canvasEl.classList.add('show-guides');
                    guidesBtn.classList.add('active');
                });
            }

            // Panel toggles.
            var toggleLeft = document.getElementById('certstudio-toggle-left');
            var toggleRight = document.getElementById('certstudio-toggle-right');
            var panelLeft = document.querySelector('.certstudio-panel-left');
            var panelRight = document.querySelector('.certstudio-panel-right');
            if (toggleLeft && panelLeft) {
                toggleLeft.addEventListener('click', function() {
                    panelLeft.classList.toggle('collapsed');
                    toggleLeft.classList.toggle('active');
                });
            }
            if (toggleRight && panelRight) {
                toggleRight.addEventListener('click', function() {
                    panelRight.classList.toggle('collapsed');
                    toggleRight.classList.toggle('active');
                });
            }

            // Page background color.
            var bgColorInput = document.getElementById('certstudio-page-bgcolor');
            if (bgColorInput) {
                bgColorInput.value = config.page.bgcolor || '#ffffff';
                canvasEl.style.backgroundColor = config.page.bgcolor || '#ffffff';
                bgColorInput.addEventListener('input', function() {
                    config.page.bgcolor = bgColorInput.value;
                    canvasEl.style.backgroundColor = bgColorInput.value;
                    markDirty();
                });
            }

            // Page background image upload - creates/updates a bgimage element.
            var bgImageBtn = document.getElementById('certstudio-page-bgimage-btn');
            var bgImageInput = document.getElementById('certstudio-page-bgimage-input');
            var bgImageClear = document.getElementById('certstudio-page-bgimage-clear');

            /**
             * Find the background image element in the elements array.
             *
             * @return {Object|null} The bgimage element or null.
             */
            function findBgImageElement() {
                for (var i = 0; i < elements.length; i++) {
                    if (elements[i].type === 'bgimage') { return elements[i]; }
                }
                return null;
            }

            if (bgImageBtn && bgImageInput) {
                bgImageBtn.addEventListener('click', function() { bgImageInput.click(); });
                bgImageInput.addEventListener('change', function() {
                    var file = bgImageInput.files[0];
                    if (!file) { return; }
                    var formData = new FormData();
                    formData.append('cmid', config.cmid);
                    formData.append('sesskey', M.cfg.sesskey);
                    formData.append('pageid', config.page.id);
                    formData.append('imagetype', 'background');
                    formData.append('file', file);
                    bgImageBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Uploading...';
                    fetch(M.cfg.wwwroot + '/mod/certstudio/upload.php', { method: 'POST', body: formData })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        bgImageBtn.innerHTML = '<i class="fa fa-upload"></i> Upload';
                        if (data.success && data.url) {
                            var bgEl = findBgImageElement();
                            if (bgEl) {
                                // Update existing bgimage element.
                                if (!bgEl.data) { bgEl.data = {}; }
                                bgEl.data.src = data.url;
                                renderElementOnCanvas(bgEl);
                                pushHistory();
                            } else {
                                // Create a new bgimage element covering full page.
                                var page = config.page || {};
                                var newEl = {
                                    id: 'temp-' + (nextTempId++),
                                    pageid: config.page.id,
                                    type: 'bgimage',
                                    name: 'Background Image',
                                    data: {src: data.url, sizemode: 'cover'},
                                    posx: 0, posy: 0,
                                    width: page.width || 297,
                                    height: page.height || 210,
                                    rotation: 0,
                                    fontfamily: 'Roboto', fontsize: 14,
                                    fontweight: 'normal', fontstyle: 'normal',
                                    color: '#000000', alignment: 'L',
                                    opacity: 1, locked: 0,
                                    sequence: 0 // Lowest layer.
                                };
                                elements.unshift(newEl);
                                pushHistory();
                            }
                            renderAll();
                            updateBgImageSettings();
                        }
                    });
                });
            }
            if (bgImageClear) {
                bgImageClear.addEventListener('click', function() {
                    var bgEl = findBgImageElement();
                    if (bgEl) {
                        deleteElement(bgEl.id);
                    }
                    updateBgImageSettings();
                });
            }

            // Background image page-settings controls (size mode, opacity).
            document.getElementById('certstudio-bgimage-settings');
            document.getElementById('certstudio-bgimage-opacity-group');
            var bgSizeSelect = document.getElementById('certstudio-bgimage-sizemode');
            var bgOpacityInput = document.getElementById('certstudio-bgimage-opacity');

            var bgOpacityVal = document.getElementById('certstudio-bgimage-opacity-val');

            /**
             * Update the background image settings controls in the page panel.
             */
            function updateBgImageSettings() {
                var bgEl = findBgImageElement();
                var hasBg = !!bgEl;
                if (bgSizeSelect) { bgSizeSelect.disabled = !hasBg; }
                if (bgOpacityInput) { bgOpacityInput.disabled = !hasBg; }
                if (hasBg) {
                    if (bgSizeSelect) { bgSizeSelect.value = (bgEl.data && bgEl.data.sizemode) || 'cover'; }
                    if (bgOpacityInput) {
                        var opVal = bgEl.opacity !== undefined ? bgEl.opacity : 1;
                        bgOpacityInput.value = opVal;
                        if (bgOpacityVal) { bgOpacityVal.textContent = Math.round(opVal * 100) + '%'; }
                    }
                } else {
                    if (bgOpacityVal) { bgOpacityVal.textContent = '100%'; }
                }
            }

            if (bgSizeSelect) {
                bgSizeSelect.addEventListener('change', function() {
                    var bgEl = findBgImageElement();
                    if (bgEl) {
                        if (!bgEl.data) { bgEl.data = {}; }
                        bgEl.data.sizemode = bgSizeSelect.value;
                        renderElementOnCanvas(bgEl);
                        pushHistory();
                    }
                });
            }
            if (bgOpacityInput) {
                bgOpacityInput.addEventListener('input', function() {
                    var bgEl = findBgImageElement();
                    var val = parseFloat(bgOpacityInput.value);
                    if (bgOpacityVal) { bgOpacityVal.textContent = Math.round(val * 100) + '%'; }
                    if (bgEl) {
                        bgEl.opacity = val;
                        renderElementOnCanvas(bgEl);
                        pushHistory();
                    }
                });
            }

            // Show/hide bgimage settings on init.
            updateBgImageSettings();

            // Image upload for image elements.
            canvasEl.addEventListener('dblclick', function(e) {
                var target = e.target.closest('.certstudio-element');
                // If dblclick didn't land on an element, try the currently selected one.
                if (!target && selectedId) {
                    target = document.getElementById('certstudio-el-' + selectedId);
                }
                if (!target) { return; }
                var el = findElement(target.getAttribute('data-element-id'));
                if (!el) { return; }
                if (el.type === 'image' || el.type === 'bgimage' || el.type === 'digitalsignature' || el.type === 'userpicture') {
                    var fileInput = document.createElement('input');
                    fileInput.type = 'file';
                    fileInput.accept = 'image/*';
                    fileInput.addEventListener('change', function() {
                        var file = fileInput.files[0];
                        if (!file) { return; }

                        /**
                         * Upload the image file using the given element ID.
                         * @param {number|string} realId The saved element ID.
                         */
                        var doUpload = function(realId) {
                            var formData = new FormData();
                            formData.append('cmid', config.cmid);
                            formData.append('sesskey', M.cfg.sesskey);
                            formData.append('elementid', realId);
                            formData.append('imagetype', 'element');
                            formData.append('file', file);
                            fetch(M.cfg.wwwroot + '/mod/certstudio/upload.php', {
                                method: 'POST', body: formData
                            })
                            .then(function(r) { return r.json(); })
                            .then(function(data) {
                                if (data.success && data.url) {
                                    if (!el.data) { el.data = {}; }
                                    el.data.src = data.url;
                                    // Auto-resize element to match image aspect ratio.
                                    var img = new Image();
                                    img.onload = function() {
                                        var ratio = img.naturalWidth / img.naturalHeight;
                                        // Keep roughly the same area but fix proportions.
                                        var area = el.width * el.height;
                                        el.height = Math.round(Math.sqrt(area / ratio));
                                        el.width = Math.round(el.height * ratio);
                                        renderElementOnCanvas(el);
                                        updatePropertiesPanel();
                                        markDirty();
                                    };
                                    img.onerror = function() {
                                        renderElementOnCanvas(el);
                                    };
                                    img.src = data.url;
                                }
                            })
                            .catch(function() {
                                // eslint-disable-next-line no-alert
                                window.alert('Image upload failed. Please try again.');
                            });
                        };

                        // If element has a temp ID, save it first to get a real DB ID.
                        if (String(el.id).indexOf('temp-') === 0) {
                            Ajax.call([{
                                methodname: 'mod_certstudio_save_element',
                                args: {cmid: config.cmid, element: JSON.stringify(el)}
                            }])[0].then(function(data) {
                                if (data.id) {
                                    el.id = data.id;
                                    target.id = 'certstudio-el-' + data.id;
                                    target.setAttribute('data-element-id', data.id);
                                    doUpload(data.id);
                                }
                            }).catch(function() {
                                // eslint-disable-next-line no-alert
                                window.alert('Failed to save element. Please try again.');
                            });
                        } else {
                            doUpload(el.id);
                        }
                    });
                    fileInput.click();
                }
            });

            // Page size preset.
            var preset = document.getElementById('certstudio-page-preset');
            if (preset) { preset.addEventListener('change', function() {
                if (preset.value === 'custom') { return; }
                var parts = preset.value.split('x');
                config.page.width = parseInt(parts[0]); config.page.height = parseInt(parts[1]);
                var wi = document.getElementById('certstudio-page-width');
                var hi = document.getElementById('certstudio-page-height');
                if (wi) { wi.value = config.page.width; }
                if (hi) { hi.value = config.page.height; }
                updateCanvasSize(); renderAll(); markDirty();
            }); }

            // Manual page width/height inputs.
            var pageWidthInput = document.getElementById('certstudio-page-width');
            var pageHeightInput = document.getElementById('certstudio-page-height');
            if (pageWidthInput) { pageWidthInput.addEventListener('change', function() {
                config.page.width = parseInt(pageWidthInput.value) || 297;
                updateCanvasSize(); renderAll(); markDirty();
            }); }
            if (pageHeightInput) { pageHeightInput.addEventListener('change', function() {
                config.page.height = parseInt(pageHeightInput.value) || 210;
                updateCanvasSize(); renderAll(); markDirty();
            }); }

            // Periodically update the "X ago" text in save status.
            setInterval(function() {
                if (!isDirty && lastSavedTime) {
                    var textEl = document.querySelector('.certstudio-save-status-text');
                    if (textEl) { textEl.textContent = 'Saved ' + formatTimeAgo(lastSavedTime); }
                } else if (isDirty && lastSavedTime) {
                    var textEl2 = document.querySelector('.certstudio-save-status-text');
                    if (textEl2) { textEl2.textContent = 'Last saved ' + formatTimeAgo(lastSavedTime); }
                }
            }, 30000);
        }
    };
});
