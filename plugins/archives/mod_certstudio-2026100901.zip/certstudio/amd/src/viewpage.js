// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * View page JS for mod_certstudio.
 *
 * Handles admin download buttons and delete buttons for issued certificates.
 *
 * @module     mod_certstudio/viewpage
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['core/ajax', 'mod_certstudio/renderer'], function(Ajax, Renderer) {
    'use strict';

    return {
        /**
         * Initialise view page handlers.
         *
         * @param {number} cmid Course module ID.
         */
        init: function(cmid) {
            // Admin download buttons.
            document.querySelectorAll('.certstudio-admin-download').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var dataAttr = btn.getAttribute('data-templatedata');
                    var code = btn.getAttribute('data-code') || '';
                    var filename = btn.getAttribute('data-filename') || 'certificate';
                    if (!dataAttr) {
                        return;
                    }
                    btn.disabled = true;
                    var origHtml = btn.innerHTML;
                    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
                    try {
                        var templatedata = JSON.parse(dataAttr);
                        Renderer.downloadPdf(templatedata, code, filename).then(function() {
                            btn.disabled = false;
                            btn.innerHTML = origHtml;
                        }).catch(function(err) {
                            window.console.error('PDF error:', err);
                            btn.disabled = false;
                            btn.innerHTML = origHtml;
                        });
                    } catch (err) {
                        window.console.error('Parse error:', err);
                        btn.disabled = false;
                        btn.innerHTML = origHtml;
                    }
                });
            });

            // Batch download ZIP button.
            var batchBtn = document.getElementById('certstudio-batchdownload');
            if (batchBtn) {
                batchBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var downloadBtns = document.querySelectorAll('.certstudio-admin-download');
                    if (downloadBtns.length === 0) { return; }
                    batchBtn.disabled = true;
                    var origHtml = batchBtn.innerHTML;
                    batchBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> 0/' + downloadBtns.length;

                    /**
                     * Generate a PDF blob with a timeout.
                     * @param {Object} templatedata Template data.
                     * @param {string} code Verification code.
                     * @param {number} timeoutMs Timeout in ms.
                     * @return {Promise<Blob|null>}
                     */
                    var getPdfWithTimeout = function(templatedata, code, timeoutMs) {
                        return new Promise(function(resolve) {
                            var timer = setTimeout(function() {
                                window.console.warn('PDF generation timed out for code:', code);
                                resolve(null);
                            }, timeoutMs);
                            Renderer.getPdfBlob(templatedata, code).then(function(blob) {
                                clearTimeout(timer);
                                resolve(blob);
                            }).catch(function(err) {
                                clearTimeout(timer);
                                window.console.warn('PDF generation failed for code:', code, err);
                                resolve(null);
                            });
                        });
                    };

                    /**
                     * Run the batch download after JSZip is available.
                     */
                    var runBatch = function() {
                        var zip = new JSZip(); // eslint-disable-line no-undef
                        var done = 0;
                        var chain = Promise.resolve();
                        downloadBtns.forEach(function(btn) {
                            chain = chain.then(function() {
                                var dataAttr = btn.getAttribute('data-templatedata');
                                var code = btn.getAttribute('data-code') || '';
                                var fname = btn.getAttribute('data-filename') || 'certificate';
                                if (!dataAttr) {
                                    done++;
                                    return;
                                }
                                var templatedata;
                                try {
                                    templatedata = JSON.parse(dataAttr);
                                } catch (parseErr) {
                                    window.console.warn('JSON parse error for:', fname, parseErr);
                                    done++;
                                    batchBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> '
                                        + done + '/' + downloadBtns.length;
                                    return;
                                }
                                return getPdfWithTimeout(templatedata, code, 15000).then(function(blob) {
                                    if (blob) {
                                        zip.file(fname + '.pdf', blob);
                                    }
                                    done++;
                                    batchBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> '
                                        + done + '/' + downloadBtns.length;
                                });
                            });
                        });
                        chain.then(function() {
                            return zip.generateAsync({type: 'blob'});
                        }).then(function(content) {
                            var url = URL.createObjectURL(content);
                            var a = document.createElement('a');
                            a.href = url;
                            a.download = 'certificates.zip';
                            document.body.appendChild(a);
                            a.click();
                            document.body.removeChild(a);
                            setTimeout(function() { URL.revokeObjectURL(url); }, 1000);
                            batchBtn.disabled = false;
                            batchBtn.innerHTML = origHtml;
                        }).catch(function(err) {
                            window.console.error('Batch download error:', err);
                            batchBtn.disabled = false;
                            batchBtn.innerHTML = origHtml;
                        });
                    };

                    // Load JSZip if not already available.
                    if (typeof JSZip !== 'undefined') { // eslint-disable-line no-undef
                        runBatch();
                    } else {
                        var script = document.createElement('script');
                        script.src = M.cfg.wwwroot + '/mod/certstudio/thirdparty/jszip/jszip.min.js';
                        script.onload = runBatch;
                        script.onerror = function() {
                            window.console.error('Failed to load JSZip library');
                            batchBtn.disabled = false;
                            batchBtn.innerHTML = origHtml;
                        };
                        document.head.appendChild(script);
                    }
                });
            }

            // Admin delete buttons.
            document.querySelectorAll('.certstudio-admin-delete').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var issueid = btn.getAttribute('data-issueid');
                    var username = btn.getAttribute('data-username') || '';
                    if (!window.confirm('Delete certificate for ' + username + '? This cannot be undone.')) {
                        return;
                    }
                    btn.disabled = true;
                    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';

                    Ajax.call([{
                        methodname: 'mod_certstudio_delete_issue',
                        args: {cmid: Number(cmid), issueid: Number(issueid)}
                    }])[0].then(function() {
                        // Remove the table row.
                        var row = btn.closest('tr');
                        if (row) {
                            row.style.transition = 'opacity 0.3s';
                            row.style.opacity = '0';
                            setTimeout(function() { row.remove(); }, 300);
                        }
                        // Update badge count.
                        var badge = document.querySelector('.certstudio-issues-section .badge');
                        if (badge) {
                            var count = parseInt(badge.textContent, 10) - 1;
                            badge.textContent = count;
                        }
                    }).catch(function(err) {
                        window.console.error('Delete error:', err);
                        require(['core/notification'], function(Notification) {
                            Notification.addNotification({
                                message: 'Error: ' + (err.message || 'Unknown error'),
                                type: 'error'
                            });
                        });
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fa fa-trash"></i>';
                    });
                });
            });
        }
    };
});
