// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * PDF generation with jsPDF for mod_certstudio.
 *
 * Expects window.jspdf (jsPDF UMD bundle) and window.QRCode (qrcode.js) to be loaded.
 *
 * @module     mod_certstudio/renderer
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_certstudio/fonts', 'mod_certstudio/elements'], function(Fonts, Elements) {
    'use strict';

    /**
     * Get the jsPDF constructor from the global scope.
     *
     * @return {Function} jsPDF constructor.
     */
    function getJsPDF() {
        if (window.jspdf && window.jspdf.jsPDF) {
            return window.jspdf.jsPDF;
        }
        if (window.jsPDF) {
            return window.jsPDF;
        }
        throw new Error('jsPDF is not loaded. Ensure the jsPDF UMD bundle is included.');
    }

    /**
     * Generate a QR code as a data URL image.
     *
     * @param {string} data The data to encode.
     * @param {number} size Size in pixels.
     * @return {Promise<string>} Data URL of the QR code image.
     */
    function generateQrDataUrl(data, size) {
        return new Promise(function(resolve, reject) {
            if (typeof window.QRCode === 'undefined') {
                reject(new Error('QRCode library is not loaded.'));
                return;
            }

            var container = document.createElement('div');
            container.style.display = 'none';
            document.body.appendChild(container);

            try {
                /* eslint-disable no-new */
                new window.QRCode(container, {
                    text: data || ' ',
                    width: size || 128,
                    height: size || 128,
                    correctLevel: window.QRCode.CorrectLevel
                        ? window.QRCode.CorrectLevel.M
                        : 1
                });
                /* eslint-enable no-new */

                // QRCode renders asynchronously via canvas; wait briefly.
                setTimeout(function() {
                    var canvas = container.querySelector('canvas');
                    if (canvas) {
                        resolve(canvas.toDataURL('image/png'));
                    } else {
                        var img = container.querySelector('img');
                        if (img && img.src) {
                            resolve(img.src);
                        } else {
                            reject(new Error('QR code generation failed.'));
                        }
                    }
                    document.body.removeChild(container);
                }, 100);
            } catch (e) {
                document.body.removeChild(container);
                reject(e);
            }
        });
    }

    /**
     * Parse a hex colour string to RGB components (0-255).
     *
     * @param {string} hex Colour in #RRGGBB or #RGB format.
     * @return {{r: number, g: number, b: number}}
     */
    function hexToRgb(hex) {
        hex = hex.replace('#', '');
        if (hex.length === 3) {
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        return {
            r: parseInt(hex.substring(0, 2), 16),
            g: parseInt(hex.substring(2, 4), 16),
            b: parseInt(hex.substring(4, 6), 16)
        };
    }

    /**
     * Apply rotation transforms around an element's centre.
     *
     * @param {Object} pdf jsPDF instance.
     * @param {number} cx Centre X in mm.
     * @param {number} cy Centre Y in mm.
     * @param {number} angle Rotation angle in degrees.
     * @param {Function} drawFn Function that performs the actual drawing.
     */
    function withRotation(pdf, cx, cy, angle, drawFn) {
        if (!angle) {
            drawFn();
            return;
        }
        pdf.saveGraphicsState();
        var rad = (angle * Math.PI) / 180;
        // Translate to centre, rotate, translate back.
        var cos = Math.cos(rad);
        var sin = Math.sin(rad);
        // jsPDF uses a transformation matrix: [a, b, c, d, e, f]
        // We translate origin to (cx, cy), rotate, then translate back.
        pdf.setCurrentTransformationMatrix(
            pdf.Matrix(cos, sin, -sin, cos, cx - cx * cos + cy * sin, cy - cx * sin - cy * cos)
        );
        drawFn();
        pdf.restoreGraphicsState();
    }

    /**
     * Normalise an element from editor format to renderer format.
     * Editor uses posx/posy and alignment L/C/R; renderer uses x/y and left/center/right.
     *
     * @param {Object} raw Element data from editor.
     * @return {Object} Normalised element.
     */
    function normaliseElement(raw) {
        var el = {};
        for (var k in raw) {
            if (raw.hasOwnProperty(k)) { el[k] = raw[k]; }
        }
        // Map posx/posy to x/y.
        if (el.posx !== undefined) { el.x = el.posx; }
        if (el.posy !== undefined) { el.y = el.posy; }
        // Map alignment L/C/R to left/center/right.
        if (el.alignment === 'L') { el.alignment = 'left'; }
        else if (el.alignment === 'C') { el.alignment = 'center'; }
        else if (el.alignment === 'R') { el.alignment = 'right'; }
        // Extract content from data object.
        var data = el.data || {};
        if (typeof data === 'string') {
            try { data = JSON.parse(data); } catch (e) { data = {}; }
        }
        el.data = data;
        if (!el.content) {
            // Check for server-resolved text first (from issued certificates). An empty value prints nothing,
            // such as the expiry date of a certificate that does not expire, rather than the editor placeholder.
            if (data.resolvedtext !== undefined && (data.resolvedtext !== '' || el.type !== 'code')) {
                el.content = data.resolvedtext;
            } else if (el.type === 'text' && data.text) {
                el.content = data.text;
            } else if (el.type === 'code') {
                el.content = data.code || '{XXXX-XXXX}';
            } else if (el.type === 'certdate') {
                el.content = data.city ? data.city + ', ...' : 'Αθήνα, ...';
            } else if (el.type === 'certstatement') {
                el.content = data.text || 'Certificate Statement';
            } else if (Elements.isTextType(el.type)) {
                // Fallback to placeholder text for editor preview.
                var placeholders = {
                    studentname: '{Student Name}', coursename: '{Course Name}',
                    categoryname: '{Category Name}', date: '{Date}',
                    grade: '{Grade}', gradeitemname: '{Grade Item}',
                    teachername: '{Teacher Name}', userfield: '{User Field}',
                    coursefield: '{Course Field}', daterange: '{Start - End}',
                    expiry: '{Expiry Date}'
                };
                el.content = placeholders[el.type] || '{' + el.type + '}';
            }
        }
        // Extract image src.
        if (!el.src && data.src) { el.src = data.src; }
        // Prefix relative plugin paths with wwwroot for subfolder installs.
        if (el.src && el.src.charAt(0) === '/' && el.src.indexOf('/mod/certstudio/') === 0 &&
                typeof M !== 'undefined' && M.cfg && M.cfg.wwwroot) {
            el.src = M.cfg.wwwroot + el.src;
        }
        // Extract border data.
        if (el.type === 'border') {
            el.bordercolor = data.bordercolor || el.bordercolor || '#1a237e';
            el.borderwidth = data.borderwidth || el.borderwidth || 2;
            el.borderstyle = data.borderstyle || el.borderstyle || 'solid';
        }
        return el;
    }

    /** @type {string|null} Name of the Unicode fallback font loaded into jsPDF. */
    var unicodeFallbackFont = null;

    /**
     * Set a font on the PDF, using a Unicode-capable fallback chain.
     * Tries: requested font+style → same font normal → fallback Unicode font → Helvetica.
     *
     * @param {Object} pdf jsPDF instance.
     * @param {string} family Font family name.
     * @param {string} style jsPDF style string.
     */
    function setFontSafe(pdf, family, style) {
        // 1. Try exact match.
        try { pdf.setFont(family, style); return; } catch (e) { /* continue */ }
        // 2. Try same family, normal style.
        if (style !== 'normal') {
            try { pdf.setFont(family, 'normal'); return; } catch (e2) { /* continue */ }
        }
        // 3. Try Unicode fallback font (Noto Sans or first successfully loaded custom font).
        if (unicodeFallbackFont) {
            try { pdf.setFont(unicodeFallbackFont, 'normal'); return; } catch (e3) { /* continue */ }
        }
        // 4. Last resort: Helvetica (no Greek/Cyrillic support).
        try { pdf.setFont('Helvetica', style); } catch (e4) { pdf.setFont('Helvetica', 'normal'); }
    }

    /**
     * Render a single element to the PDF.
     *
     * @param {Object} pdf jsPDF instance.
     * @param {Object} rawEl Element data.
     * @return {Promise} Resolves when rendering is complete.
     */
    function renderElement(pdf, rawEl) {
        var el = normaliseElement(rawEl);
        var type = el.type;
        var x = parseFloat(el.x) || 0;
        var y = parseFloat(el.y) || 0;
        var w = parseFloat(el.width) || 0;
        var h = parseFloat(el.height) || 0;
        var rotation = parseFloat(el.rotation) || 0;
        var cx = x + w / 2;
        var cy = y + h / 2;

        // Apply opacity if set.
        var elOpacity = parseFloat(el.opacity);
        var hasOpacity = !isNaN(elOpacity) && elOpacity < 1;

        /** Restore opacity graphics state if needed. */
        function restoreOpacity() {
            if (hasOpacity) {
                pdf.restoreGraphicsState();
            }
        }

        if (hasOpacity) {
            pdf.saveGraphicsState();
            // GState is exported on jspdf namespace or on the jsPDF constructor.
            var GStateCls = (window.jspdf && window.jspdf.GState) || (getJsPDF().GState);
            if (GStateCls) {
                pdf.setGState(new GStateCls({opacity: elOpacity, 'stroke-opacity': elOpacity}));
            }
        }

        // Text-based elements.
        if (Elements.isTextType(type)) {
            var color = hexToRgb(el.color || '#000000');
            var fontSize = parseFloat(el.fontsize) || 12;
            var fontFamily = el.fontfamily || 'Helvetica';
            var jsPdfStyle = Fonts.getFontStyle(el.fontweight, el.fontstyle);
            var alignment = el.alignment || 'left';

            var textX = x;
            if (alignment === 'center') {
                textX = x + w / 2;
            } else if (alignment === 'right') {
                textX = x + w;
            }
            var textY = y + fontSize * 0.3528; // Approximate pt to mm baseline offset.

            withRotation(pdf, cx, cy, rotation, function() {
                setFontSafe(pdf, fontFamily, jsPdfStyle);
                pdf.setFontSize(fontSize);
                pdf.setTextColor(color.r, color.g, color.b);
                var text = el.content || '';
                try {
                    // Handle multiline text.
                    if (text.indexOf('\n') !== -1) {
                        var lines = text.split('\n');
                        var lineH = fontSize * 0.3528 * 1.3;
                        for (var li = 0; li < lines.length; li++) {
                            pdf.text(lines[li], textX, textY + (li * lineH), {
                                align: alignment,
                                maxWidth: w > 0 ? w : undefined
                            });
                        }
                    } else {
                        pdf.text(text, textX, textY, {
                            align: alignment,
                            maxWidth: w > 0 ? w : undefined
                        });
                    }
                } catch (textErr) {
                    // Font metrics unavailable - retry with fallback font without maxWidth.
                    try {
                        setFontSafe(pdf, unicodeFallbackFont || 'Helvetica', 'normal');
                        pdf.text(text, textX, textY, {align: alignment});
                    } catch (fallbackErr) {
                        window.console.warn('Text render failed for:', text, fallbackErr);
                    }
                }
            });

            restoreOpacity();
            return Promise.resolve();
        }

        // Image-based elements.
        if (type === 'image' || type === 'bgimage' || type === 'digitalsignature' || type === 'userpicture') {
            if (!el.src) {
                restoreOpacity();
                return Promise.resolve();
            }

            return new Promise(function(resolve) {
                var img = new Image();
                img.crossOrigin = 'anonymous';
                img.onload = function() {
                    // Calculate draw dimensions based on sizemode for bgimage.
                    var dx = x, dy = y, dw = w, dh = h;
                    var sizemode = (el.data && el.data.sizemode) || (type === 'bgimage' ? 'cover' : 'contain');
                    if (sizemode !== 'stretch' && img.naturalWidth && img.naturalHeight) {
                        var imgRatio = img.naturalWidth / img.naturalHeight;
                        var boxRatio = w / h;
                        if (sizemode === 'cover') {
                            if (imgRatio > boxRatio) {
                                dh = h; dw = h * imgRatio;
                            } else {
                                dw = w; dh = w / imgRatio;
                            }
                            dx = x + (w - dw) / 2;
                            dy = y + (h - dh) / 2;
                        } else if (sizemode === 'contain') {
                            if (imgRatio > boxRatio) {
                                dw = w; dh = w / imgRatio;
                            } else {
                                dh = h; dw = h * imgRatio;
                            }
                            dx = x + (w - dw) / 2;
                            dy = y + (h - dh) / 2;
                        } else if (sizemode === 'actual') {
                            // 1px ≈ 0.2646mm at 96dpi.
                            dw = img.naturalWidth * 0.2646;
                            dh = img.naturalHeight * 0.2646;
                            dx = x + (w - dw) / 2;
                            dy = y + (h - dh) / 2;
                        }
                    }
                    // Rasterize SVGs to canvas first — jsPDF cannot add SVG
                    // images directly via addImage(), so we draw to a temporary
                    // canvas and pass the rasterized result instead.
                    var isSvg = el.src && (el.src.indexOf('.svg') !== -1 || el.src.indexOf('image/svg') !== -1);
                    var imgSource = img;
                    if (isSvg) {
                        try {
                            var canvas = document.createElement('canvas');
                            // Use high resolution for quality (approx 150 DPI for A4).
                            var natW = img.naturalWidth || 800;
                            var natH = img.naturalHeight || 566;
                            var scale = Math.max(1, Math.ceil(2000 / Math.max(natW, natH)));
                            canvas.width = natW * scale;
                            canvas.height = natH * scale;
                            var ctx = canvas.getContext('2d');
                            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                            imgSource = canvas;
                        } catch (rasterErr) {
                            window.console.warn('SVG rasterization failed:', rasterErr);
                        }
                    }

                    withRotation(pdf, cx, cy, rotation, function() {
                        try {
                            pdf.addImage(imgSource, 'PNG', dx, dy, dw, dh);
                        } catch (e) {
                            window.console.warn('Could not add image to PDF:', e);
                        }
                    });
                    restoreOpacity();
                    resolve();
                };
                img.onerror = function() {
                    window.console.warn('Failed to load image: ' + el.src);
                    restoreOpacity();
                    resolve();
                };
                img.src = el.src;
            });
        }

        // Border.
        if (type === 'border') {
            var bc = hexToRgb(el.bordercolor || '#000000');
            var bw = parseFloat(el.borderwidth) || 1;

            withRotation(pdf, cx, cy, rotation, function() {
                pdf.setDrawColor(bc.r, bc.g, bc.b);
                pdf.setLineWidth(bw * 0.3528);
                if (el.borderstyle === 'dashed') {
                    pdf.setLineDashPattern([3, 2], 0);
                } else if (el.borderstyle === 'dotted') {
                    pdf.setLineDashPattern([1, 1], 0);
                } else {
                    pdf.setLineDashPattern([], 0);
                }
                pdf.rect(x, y, w, h, 'S');
                pdf.setLineDashPattern([], 0);
            });

            restoreOpacity();
            return Promise.resolve();
        }

        // QR Code.
        if (type === 'qrcode') {
            var qrSize = Math.max(w, h) * 4;
            var qrData = el.data || {};
            if (typeof qrData === 'string') {
                try {
                    qrData = JSON.parse(qrData);
                } catch (parseErr) {
                    qrData = {};
                }
            }
            var resolvedCode = qrData.resolvedtext ||
                el.content || '';
            var verifyBase = typeof M !== 'undefined'
                ? M.cfg.wwwroot + '/mod/certstudio/verify.php'
                : '';
            var qrContent;
            if (resolvedCode) {
                qrContent = verifyBase
                    ? verifyBase + '?code=' +
                        encodeURIComponent(resolvedCode)
                    : resolvedCode;
            } else {
                qrContent = verifyBase ||
                    'https://example.com';
            }
            return generateQrDataUrl(qrContent, qrSize).then(function(dataUrl) {
                withRotation(pdf, cx, cy, rotation, function() {
                    try {
                        pdf.addImage(dataUrl, 'PNG', x, y, w, h);
                    } catch (e) {
                        window.console.warn('Could not add QR code to PDF:', e);
                    }
                });
                restoreOpacity();
            }).catch(function(err) {
                window.console.warn('QR code generation failed:', err);
                restoreOpacity();
            });
        }

        restoreOpacity();
        return Promise.resolve();
    }

    return {

        /**
         * Generate a PDF document from the given elements and page configuration.
         *
         * @param {Array}  elements   Array of element data objects.
         * @param {Object} pageConfig Page configuration: {width, height, orientation, unit}.
         * @param {Array}  fonts      Array of font descriptor objects for Fonts.loadFonts().
         * @param {string} code       Optional verification code for the certificate.
         * @param {Object} protection Optional PDF protection settings.
         * @return {Promise<Blob>}    Resolves with the PDF Blob.
         */
        generatePdf: function(elements, pageConfig, fonts, code, protection) {
            var JsPDF = getJsPDF();

            var pageWidth = parseFloat(pageConfig.width) || 210;
            var pageHeight = parseFloat(pageConfig.height) || 297;
            // Auto-detect orientation from dimensions.
            var orientation = pageWidth > pageHeight ? 'landscape' : 'portrait';

            var pdfOptions = {
                orientation: orientation,
                unit: 'mm',
                format: [Math.min(pageWidth, pageHeight), Math.max(pageWidth, pageHeight)]
            };

            // Apply PDF protection/encryption if configured.
            if (protection && (protection.print || protection.modify || protection.copy)) {
                var userPerms = [];
                if (!protection.print) { userPerms.push('print'); }
                if (!protection.modify) { userPerms.push('modify'); }
                if (!protection.copy) { userPerms.push('copy'); }
                pdfOptions.encryption = {
                    userPassword: '',
                    ownerPassword: 'certstudio_' + (code || 'owner'),
                    userPermissions: userPerms
                };
            }

            var pdf = new JsPDF(pdfOptions);

            // Load custom fonts first.
            return Fonts.loadFonts(pdf, fonts || []).then(function(loadedFontNames) {
                // Set the Unicode fallback font from the first successfully loaded font.
                // Prefer Noto Sans/Serif or Roboto as they have wide Unicode coverage.
                if (loadedFontNames && loadedFontNames.length) {
                    var preferred = ['Noto Sans', 'Noto Serif', 'Roboto', 'Open Sans', 'Lato'];
                    unicodeFallbackFont = null;
                    for (var pi = 0; pi < preferred.length; pi++) {
                        if (loadedFontNames.indexOf(preferred[pi]) !== -1) {
                            unicodeFallbackFont = preferred[pi];
                            break;
                        }
                    }
                    if (!unicodeFallbackFont) {
                        unicodeFallbackFont = loadedFontNames[0];
                    }
                }
                // Render page background color if not white.
                var bgColor = pageConfig.bgcolor || '#ffffff';
                if (bgColor && bgColor !== '#ffffff' && bgColor !== '#FFFFFF') {
                    var bg = hexToRgb(bgColor);
                    pdf.setFillColor(bg.r, bg.g, bg.b);
                    pdf.rect(0, 0, pageWidth, pageHeight, 'F');
                }

                // Sort elements by sequence (lower = drawn first = behind).
                var sorted = elements.slice().sort(function(a, b) {
                    return (a.sequence || 0) - (b.sequence || 0);
                });

                // Replace placeholder tokens if a code is provided.
                if (code) {
                    sorted = sorted.map(function(el) {
                        var clone = JSON.parse(JSON.stringify(el));
                        if (clone.content && typeof clone.content === 'string') {
                            clone.content = clone.content.replace(/\{verifyurl\}/g,
                                M.cfg.wwwroot + '/mod/certstudio/verify.php?code=' + encodeURIComponent(code));
                            clone.content = clone.content.replace(/\{code\}/g, code);
                        }
                        return clone;
                    });
                }

                // Render elements sequentially to handle async image loading.
                var chain = Promise.resolve();
                sorted.forEach(function(el) {
                    // Skip invisible elements.
                    if (el.visible === false) {
                        return;
                    }
                    chain = chain.then(function() {
                        return renderElement(pdf, el);
                    });
                });

                return chain.then(function() {
                    return pdf.output('blob');
                });
            });
        },

        /**
         * Normalise server-side template data to renderer format.
         * Server returns {pages: [{width, height, elements: [...]}]}.
         * Renderer expects {elements, page, fonts}.
         *
         * @param {Object} templatedata Raw template data.
         * @return {Object} Normalised {elements, page, fonts}.
         */
        normaliseTemplateData: function(templatedata) {
            // If already in flat format (from editor), return as-is.
            if (templatedata.elements && !templatedata.pages) {
                return templatedata;
            }
            // Server-side format: extract first page.
            var firstPage = (templatedata.pages && templatedata.pages[0]) || {};
            return {
                elements: firstPage.elements || [],
                page: {
                    width: firstPage.width || 297,
                    height: firstPage.height || 210,
                    leftmargin: firstPage.leftmargin || 0,
                    rightmargin: firstPage.rightmargin || 0,
                    bgcolor: firstPage.bgcolor || '#ffffff'
                },
                fonts: templatedata.fonts || [],
                protection: templatedata.protection || null
            };
        },

        /**
         * Generate a PDF blob without triggering a download.
         *
         * @param {Object} templatedata Template data object.
         * @param {string} code Optional verification code.
         * @return {Promise<Blob>}
         */
        getPdfBlob: function(templatedata, code) {
            var data = this.normaliseTemplateData(templatedata);
            return this.generatePdf(
                data.elements || [],
                data.page || {},
                data.fonts || [],
                code || '',
                data.protection || null
            );
        },

        /**
         * Generate and trigger a download of the PDF.
         *
         * @param {Object} templatedata Template data with elements and page config.
         * @param {string} code Optional verification code.
         * @param {string} filename Filename without extension.
         * @return {Promise} Resolves when download is triggered.
         */
        downloadPdf: function(templatedata, code, filename) {
            var pdfFilename = (filename || 'certificate') + '.pdf';
            return this.getPdfBlob(templatedata, code).then(function(blob) {
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = pdfFilename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                setTimeout(function() {
                    URL.revokeObjectURL(url);
                }, 1000);
            });
        },

        /**
         * Attach a click handler to a download button element.
         *
         * @param {string} selector CSS selector for the download button.
         */
        initDownloadButton: function(selector) {
            var self = this;
            var btn = document.querySelector(selector);
            if (!btn) {
                return;
            }
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                btn.disabled = true;
                btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Generating...';
                var dataAttr = btn.getAttribute('data-templatedata');
                var codeAttr = btn.getAttribute('data-code') || '';
                var filenameAttr = btn.getAttribute('data-filename') || 'certificate';
                if (dataAttr) {
                    try {
                        var templatedata = JSON.parse(dataAttr);
                        self.downloadPdf(templatedata, codeAttr, filenameAttr).then(function() {
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fa fa-download"></i> Download Certificate';
                        }).catch(function(err) {
                            window.console.error('PDF generation error:', err);
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fa fa-download"></i> Download Certificate';
                        });
                    } catch (err) {
                        window.console.error('Invalid template data:', err);
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fa fa-download"></i> Download Certificate';
                    }
                }
            });
        }
    };
});
