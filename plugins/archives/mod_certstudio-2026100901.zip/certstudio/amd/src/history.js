// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Undo/Redo history manager for mod_certstudio.
 *
 * @module     mod_certstudio/history
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    /** @type {Array} Stack of state snapshots. */
    var states = [];

    /** @type {number} Current position in the stack (-1 means empty). */
    var pointer = -1;

    /** @type {number} Maximum number of history entries to keep. */
    var maxEntries = 50;

    /**
     * Deep clone a value (elements array).
     *
     * @param {*} value
     * @return {*}
     */
    function deepClone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    return {

        /**
         * Push a new state onto the history stack.
         * Any redo states beyond the current pointer are discarded.
         *
         * @param {Array} state The elements array to snapshot.
         */
        push: function(state) {
            // Discard any future states beyond the current pointer.
            states = states.slice(0, pointer + 1);

            states.push(deepClone(state));
            pointer = states.length - 1;

            // Enforce max entries.
            if (states.length > maxEntries) {
                states.shift();
                pointer--;
            }
        },

        /**
         * Undo: move the pointer back and return the previous state.
         *
         * @return {Array|null} The restored state or null if nothing to undo.
         */
        undo: function() {
            if (!this.canUndo()) {
                return null;
            }
            pointer--;
            return deepClone(states[pointer]);
        },

        /**
         * Redo: move the pointer forward and return the next state.
         *
         * @return {Array|null} The restored state or null if nothing to redo.
         */
        redo: function() {
            if (!this.canRedo()) {
                return null;
            }
            pointer++;
            return deepClone(states[pointer]);
        },

        /**
         * Whether undo is available.
         *
         * @return {boolean}
         */
        canUndo: function() {
            return pointer > 0;
        },

        /**
         * Whether redo is available.
         *
         * @return {boolean}
         */
        canRedo: function() {
            return pointer < states.length - 1;
        },

        /**
         * Get the current state without modifying the pointer.
         *
         * @return {Array|null}
         */
        current: function() {
            if (pointer >= 0 && pointer < states.length) {
                return deepClone(states[pointer]);
            }
            return null;
        },

        /**
         * Reset all history.
         */
        reset: function() {
            states = [];
            pointer = -1;
        },

        /**
         * Get the current stack size.
         *
         * @return {number}
         */
        size: function() {
            return states.length;
        }
    };
});
