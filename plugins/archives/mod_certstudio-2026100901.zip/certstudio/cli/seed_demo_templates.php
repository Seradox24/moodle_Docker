<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * CLI script to seed 6 demo certificate templates.
 *
 * posx/posy = TOP-LEFT corner of the element bounding box.
 * The renderer calculates textX = posx + width/2 for center-aligned text.
 *
 * Usage: php mod/certstudio/cli/seed_demo_templates.php
 *
 * @package    mod_certstudio
 * @copyright  2026 Letstudy Group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('CLI_SCRIPT', true);
require_once(__DIR__ . '/../../../config.php');

global $DB;

$now = time();
$systemctx = \context_system::instance();

// A4 Landscape: 297 x 210 mm.
$lw = 297;
$lh = 210;

/**
 * Returns left-edge X for a centered element of given width.
 */
function cx(float $elw, float $pw = 297): float {
    return ($pw - $elw) / 2;
}

/**
 * Returns top-edge Y for a vertically centered element of given height.
 */
function cy(float $elh, float $ph = 210): float {
    return ($ph - $elh) / 2;
}

/**
 * Create a template and its first page, returning both IDs.
 *
 * @param string $name Template name.
 * @param int $ctxid Context ID.
 * @param int $now Current timestamp.
 * @param int $w Page width in mm.
 * @param int $h Page height in mm.
 * @return array Array of [template ID, page ID].
 */
function create_template_page(string $name, int $ctxid, int $now, int $w = 297, int $h = 210): array {
    global $DB;
    $t = new \stdClass();
    $t->name = $name;
    $t->contextid = $ctxid;
    $t->timecreated = $now;
    $t->timemodified = $now;
    $t->id = $DB->insert_record('certstudio_templates', $t);

    $p = new \stdClass();
    $p->templateid = $t->id;
    $p->width = $w;
    $p->height = $h;
    $p->leftmargin = 0;
    $p->rightmargin = 0;
    $p->sequence = 1;
    $p->timecreated = $now;
    $p->timemodified = $now;
    $p->id = $DB->insert_record('certstudio_pages', $p);

    return [$t->id, $p->id];
}

/**
 * Add an element to a certificate page.
 *
 * @param int $pageid Page ID.
 * @param int $seq Sequence order.
 * @param string $name Element name.
 * @param string $type Element type.
 * @param float $x X position.
 * @param float $y Y position.
 * @param float $w Width.
 * @param float $h Height.
 * @param string $font Font family.
 * @param int $size Font size.
 * @param string $weight Font weight.
 * @param string $style Font style.
 * @param string $color Color hex code.
 * @param string $align Alignment.
 * @param array $data Additional element data.
 * @param int $now Timestamp.
 * @return void
 */
function add_el(
    int $pageid,
    int $seq,
    string $name,
    string $type,
    float $x,
    float $y,
    float $w,
    float $h,
    string $font,
    int $size,
    string $weight,
    string $style,
    string $color,
    string $align,
    array $data = [],
    int $now = 0
): void {
    global $DB;
    if (!$now) {
        $now = time();
    }
    $el = new \stdClass();
    $el->pageid = $pageid;
    $el->name = $name;
    $el->type = $type;
    $el->data = json_encode($data);
    $el->posx = $x;
    $el->posy = $y;
    $el->width = $w;
    $el->height = $h;
    $el->fontfamily = $font;
    $el->fontsize = $size;
    $el->fontweight = $weight;
    $el->fontstyle = $style;
    $el->color = $color;
    $el->alignment = $align;
    $el->opacity = 1;
    $el->rotation = 0;
    $el->locked = 0;
    $el->sequence = $seq;
    $el->timecreated = $now;
    $el->timemodified = $now;
    $DB->insert_record('certstudio_elements', $el);
}

echo "Creating 6 demo templates...\n";

// 1. Professional Navy - Inspired by the Letstudy demo design.
// Navy borders, structured layout, clean hierarchy.
[$tid, $pid] = create_template_page('Professional Navy', $systemctx->id, $now);
$s = 1;
// Outer border: 289x202, 4px navy.
add_el(
    $pid,
    $s++,
    'Outer Border',
    'border',
    cx(289),
    cy(202),
    289,
    202,
    'Roboto',
    12,
    'normal',
    'normal',
    '#2c3e6b',
    'C',
    ['borderwidth' => 4, 'bordercolor' => '#2c3e6b', 'borderstyle' => 'solid'],
    $now
);
// Inner border: 281x194, 1px navy.
add_el(
    $pid,
    $s++,
    'Inner Border',
    'border',
    cx(281),
    cy(194),
    281,
    194,
    'Roboto',
    12,
    'normal',
    'normal',
    '#2c3e6b',
    'C',
    ['borderwidth' => 1, 'bordercolor' => '#2c3e6b', 'borderstyle' => 'solid'],
    $now
);
// Title: CERTIFICATE OF COMPLETION - large, bold, navy.
add_el(
    $pid,
    $s++,
    'Title',
    'text',
    cx(260),
    18,
    260,
    16,
    'Montserrat',
    22,
    'bold',
    'normal',
    '#2c3e6b',
    'C',
    ['text' => 'CERTIFICATE OF COMPLETION'],
    $now
);
// This certifies that.
add_el(
    $pid,
    $s++,
    'Certifies',
    'text',
    cx(200),
    42,
    200,
    8,
    'Lato',
    11,
    'normal',
    'italic',
    '#555555',
    'C',
    ['text' => 'This certifies that'],
    $now
);
// Student name - large, bold, uppercase.
add_el(
    $pid, $s++, 'Student Name', 'studentname', cx(260), 56, 260, 18,
    'Montserrat', 28, 'bold', 'normal', '#1a1a1a', 'C', [], $now
);
// Has successfully completed the course.
add_el(
    $pid,
    $s++,
    'Completed',
    'text',
    cx(240),
    82,
    240,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#555555',
    'C',
    ['text' => 'has successfully completed the course'],
    $now
);
// Course name - bold, navy, in quotes style.
add_el($pid, $s++, 'Course Name', 'coursename', cx(250), 96, 250, 14, 'Montserrat', 18, 'bold', 'normal', '#2c3e6b', 'C', [], $now);
// Description text.
add_el(
    $pid,
    $s++,
    'Description',
    'text',
    cx(250),
    118,
    250,
    10,
    'Lato',
    10,
    'normal',
    'normal',
    '#666666',
    'C',
    ['text' => 'This course was delivered through our online learning platform and completed on the date shown below.'],
    $now
);
// Date on left.
add_el(
    $pid,
    $s++,
    'Date Label',
    'text',
    30,
    148,
    50,
    6,
    'Montserrat',
    8,
    'bold',
    'normal',
    '#888888',
    'L',
    ['text' => 'DATE'],
    $now
);
add_el(
    $pid,
    $s++,
    'Date',
    'date',
    30,
    156,
    80,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#333333',
    'L',
    ['dateformat' => 'F j, Y'],
    $now
);
// Teacher on right.
add_el(
    $pid,
    $s++,
    'Instructor Label',
    'text',
    210,
    148,
    60,
    6,
    'Montserrat',
    8,
    'bold',
    'normal',
    '#888888',
    'L',
    ['text' => 'INSTRUCTOR'],
    $now
);
add_el($pid, $s++, 'Teacher', 'teachername', 210, 156, 70, 8, 'Lato', 11, 'normal', 'normal', '#333333', 'L', [], $now);
// QR code center-bottom.
add_el($pid, $s++, 'QR', 'qrcode', cx(18), 170, 18, 18, 'Roboto', 12, 'normal', 'normal', '#2c3e6b', 'C', [], $now);
// Verification code.
add_el($pid, $s++, 'Code', 'code', cx(80), 192, 80, 5, 'Lato', 7, 'normal', 'normal', '#aaaaaa', 'C', [], $now);
echo "  1. Professional Navy\n";

// 2. Elegant Serif - Classic warm tones, serif typography.
// Gold/brown color scheme, Playfair Display headings.
[$tid, $pid] = create_template_page('Elegant Serif', $systemctx->id, $now);
$s = 1;
add_el(
    $pid,
    $s++,
    'Outer Border',
    'border',
    cx(289),
    cy(202),
    289,
    202,
    'Roboto',
    12,
    'normal',
    'normal',
    '#8b6914',
    'C',
    ['borderwidth' => 3, 'bordercolor' => '#8b6914', 'borderstyle' => 'solid'],
    $now
);
add_el(
    $pid,
    $s++,
    'Inner Border',
    'border',
    cx(283),
    cy(196),
    283,
    196,
    'Roboto',
    12,
    'normal',
    'normal',
    '#c9a84c',
    'C',
    ['borderwidth' => 1, 'bordercolor' => '#c9a84c', 'borderstyle' => 'solid'],
    $now
);
// Title.
add_el(
    $pid,
    $s++,
    'Title',
    'text',
    cx(240),
    20,
    240,
    16,
    'Playfair Display',
    28,
    'bold',
    'normal',
    '#8b6914',
    'C',
    ['text' => 'Certificate of Achievement'],
    $now
);
// Subtitle.
add_el(
    $pid,
    $s++,
    'Subtitle',
    'text',
    cx(180),
    42,
    180,
    8,
    'Merriweather',
    10,
    'normal',
    'italic',
    '#a08040',
    'C',
    ['text' => 'This certificate is proudly presented to'],
    $now
);
// Student.
add_el(
    $pid, $s++, 'Student Name', 'studentname', cx(250), 58, 250, 20,
    'Playfair Display', 30, 'bold', 'normal', '#2a1f0e', 'C', [], $now
);
// For completing.
add_el(
    $pid,
    $s++,
    'For',
    'text',
    cx(200),
    86,
    200,
    8,
    'Merriweather',
    10,
    'normal',
    'normal',
    '#777777',
    'C',
    ['text' => 'for the successful completion of'],
    $now
);
// Course.
add_el(
    $pid, $s++, 'Course Name', 'coursename', cx(240), 100, 240, 14,
    'Playfair Display', 18, 'bold', 'normal', '#8b6914', 'C', [], $now
);
// Category.
add_el(
    $pid, $s++, 'Category', 'categoryname', cx(180), 120, 180, 8,
    'Merriweather', 10, 'normal', 'italic', '#999999', 'C', [], $now
);
// Date left.
add_el(
    $pid,
    $s++,
    'Date',
    'date',
    30,
    158,
    80,
    8,
    'Merriweather',
    11,
    'normal',
    'normal',
    '#555555',
    'C',
    ['dateformat' => 'F j, Y'],
    $now
);
// Teacher right.
add_el($pid, $s++, 'Teacher', 'teachername', 190, 158, 80, 8, 'Merriweather', 11, 'normal', 'normal', '#555555', 'C', [], $now);
// Code.
add_el($pid, $s++, 'Code', 'code', cx(70), 192, 70, 5, 'Lato', 7, 'normal', 'normal', '#bbbbbb', 'C', [], $now);
echo "  2. Elegant Serif\n";

// 3. Modern Minimal - Ultra-clean, sans-serif, lots of space.
// Dark text on white, minimal decoration.
[$tid, $pid] = create_template_page('Modern Minimal', $systemctx->id, $now);
$s = 1;
// Single thin border.
add_el(
    $pid,
    $s++,
    'Border',
    'border',
    cx(287),
    cy(200),
    287,
    200,
    'Roboto',
    12,
    'normal',
    'normal',
    '#222222',
    'C',
    ['borderwidth' => 1, 'bordercolor' => '#222222', 'borderstyle' => 'solid'],
    $now
);
// Title - uppercase, spaced.
add_el(
    $pid,
    $s++,
    'Title',
    'text',
    cx(240),
    28,
    240,
    12,
    'Poppins',
    18,
    'bold',
    'normal',
    '#111111',
    'C',
    ['text' => 'CERTIFICATE OF COMPLETION'],
    $now
);
// Thin line.
add_el(
    $pid,
    $s++,
    'Line',
    'text',
    cx(60),
    45,
    60,
    4,
    'Roboto',
    6,
    'normal',
    'normal',
    '#cccccc',
    'C',
    ['text' => '____________________________'],
    $now
);
// Certifies.
add_el(
    $pid,
    $s++,
    'Certifies',
    'text',
    cx(180),
    58,
    180,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#888888',
    'C',
    ['text' => 'This is to certify that'],
    $now
);
// Student - very large, bold.
add_el($pid, $s++, 'Student Name', 'studentname', cx(260), 72, 260, 22, 'Poppins', 32, 'bold', 'normal', '#111111', 'C', [], $now);
// Completed.
add_el(
    $pid,
    $s++,
    'Completed',
    'text',
    cx(200),
    100,
    200,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#888888',
    'C',
    ['text' => 'has completed the course'],
    $now
);
// Course.
add_el($pid, $s++, 'Course Name', 'coursename', cx(240), 114, 240, 14, 'Poppins', 16, 'bold', 'normal', '#333333', 'C', [], $now);
// Date center.
add_el(
    $pid,
    $s++,
    'Date',
    'date',
    cx(100),
    150,
    100,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#999999',
    'C',
    ['dateformat' => 'F j, Y'],
    $now
);
// Teacher center below.
add_el($pid, $s++, 'Teacher', 'teachername', cx(100), 164, 100, 8, 'Lato', 11, 'normal', 'normal', '#999999', 'C', [], $now);
// Code.
add_el($pid, $s++, 'Code', 'code', cx(70), 192, 70, 5, 'Lato', 7, 'normal', 'normal', '#cccccc', 'C', [], $now);
echo "  3. Modern Minimal\n";

// 4. Corporate Blue - Left-aligned modern corporate style.
// Blue accent, structured sections, professional feel.
[$tid, $pid] = create_template_page('Corporate Blue', $systemctx->id, $now);
$s = 1;
// Border.
add_el(
    $pid,
    $s++,
    'Border',
    'border',
    cx(287),
    cy(200),
    287,
    200,
    'Roboto',
    12,
    'normal',
    'normal',
    '#1a5276',
    'C',
    ['borderwidth' => 2, 'bordercolor' => '#1a5276', 'borderstyle' => 'solid'],
    $now
);
// Small label top-left.
add_el(
    $pid,
    $s++,
    'Label',
    'text',
    22,
    14,
    100,
    6,
    'Montserrat',
    8,
    'bold',
    'normal',
    '#1a5276',
    'L',
    ['text' => 'CERTIFICATE'],
    $now
);
// Big title left-aligned.
add_el(
    $pid,
    $s++,
    'Title',
    'text',
    22,
    26,
    200,
    18,
    'Poppins',
    28,
    'bold',
    'normal',
    '#1a5276',
    'L',
    ['text' => 'Course Completion'],
    $now
);
// Course label.
add_el(
    $pid,
    $s++,
    'Course Label',
    'text',
    22,
    52,
    50,
    6,
    'Montserrat',
    7,
    'bold',
    'normal',
    '#999999',
    'L',
    ['text' => 'PROGRAM'],
    $now
);
// Course name.
add_el($pid, $s++, 'Course Name', 'coursename', 22, 60, 250, 12, 'Poppins', 16, 'normal', 'normal', '#333333', 'L', [], $now);
// Recipient label.
add_el(
    $pid,
    $s++,
    'Recipient Label',
    'text',
    22,
    86,
    60,
    6,
    'Montserrat',
    7,
    'bold',
    'normal',
    '#999999',
    'L',
    ['text' => 'AWARDED TO'],
    $now
);
// Student name.
add_el($pid, $s++, 'Student Name', 'studentname', 22, 95, 250, 18, 'Poppins', 26, 'bold', 'normal', '#111111', 'L', [], $now);
// Description.
add_el(
    $pid,
    $s++,
    'Description',
    'text',
    22,
    120,
    250,
    10,
    'Lato',
    10,
    'normal',
    'normal',
    '#666666',
    'L',
    ['text' => 'Has demonstrated competence and completed all requirements '
        . 'of this program delivered through our learning platform.'],
    $now
);
// Date.
add_el(
    $pid,
    $s++,
    'Date Label',
    'text',
    22,
    150,
    30,
    6,
    'Montserrat',
    7,
    'bold',
    'normal',
    '#999999',
    'L',
    ['text' => 'DATE'],
    $now
);
add_el(
    $pid,
    $s++,
    'Date',
    'date',
    22,
    158,
    80,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#333333',
    'L',
    ['dateformat' => 'F j, Y'],
    $now
);
// Instructor.
add_el(
    $pid,
    $s++,
    'Instructor Label',
    'text',
    140,
    150,
    50,
    6,
    'Montserrat',
    7,
    'bold',
    'normal',
    '#999999',
    'L',
    ['text' => 'INSTRUCTOR'],
    $now
);
add_el($pid, $s++, 'Teacher', 'teachername', 140, 158, 80, 8, 'Lato', 11, 'normal', 'normal', '#333333', 'L', [], $now);
// QR bottom-right.
add_el($pid, $s++, 'QR', 'qrcode', 256, 164, 22, 22, 'Roboto', 12, 'normal', 'normal', '#1a5276', 'C', [], $now);
// Code.
add_el($pid, $s++, 'Code', 'code', cx(80), 194, 80, 5, 'Lato', 7, 'normal', 'normal', '#bbbbbb', 'C', [], $now);
echo "  4. Corporate Blue\n";

// 5. Classic Diploma - Traditional double-border diploma.
// Deep red/burgundy, serif fonts, formal language.
[$tid, $pid] = create_template_page('Classic Diploma', $systemctx->id, $now);
$s = 1;
// Double border.
add_el(
    $pid,
    $s++,
    'Outer Border',
    'border',
    cx(291),
    cy(204),
    291,
    204,
    'Roboto',
    12,
    'normal',
    'normal',
    '#6b1520',
    'C',
    ['borderwidth' => 5, 'bordercolor' => '#6b1520', 'borderstyle' => 'solid'],
    $now
);
add_el(
    $pid,
    $s++,
    'Inner Border',
    'border',
    cx(283),
    cy(196),
    283,
    196,
    'Roboto',
    12,
    'normal',
    'normal',
    '#6b1520',
    'C',
    ['borderwidth' => 1, 'bordercolor' => '#6b1520', 'borderstyle' => 'solid'],
    $now
);
// Title.
add_el(
    $pid,
    $s++,
    'Title',
    'text',
    cx(200),
    18,
    200,
    22,
    'Playfair Display',
    36,
    'bold',
    'normal',
    '#6b1520',
    'C',
    ['text' => 'DIPLOMA'],
    $now
);
// Subtitle.
add_el(
    $pid,
    $s++,
    'Subtitle',
    'text',
    cx(200),
    44,
    200,
    10,
    'Merriweather',
    12,
    'normal',
    'italic',
    '#8b4050',
    'C',
    ['text' => 'of Successful Completion'],
    $now
);
// Awarded to.
add_el(
    $pid,
    $s++,
    'Awarded',
    'text',
    cx(200),
    66,
    200,
    8,
    'Merriweather',
    11,
    'normal',
    'normal',
    '#777777',
    'C',
    ['text' => 'This diploma is awarded to'],
    $now
);
// Student.
add_el(
    $pid, $s++, 'Student Name', 'studentname', cx(260), 80, 260, 20,
    'Playfair Display', 30, 'bold', 'normal', '#1a1a1a', 'C', [], $now
);
// For completing.
add_el(
    $pid,
    $s++,
    'For',
    'text',
    cx(200),
    106,
    200,
    8,
    'Merriweather',
    11,
    'normal',
    'normal',
    '#777777',
    'C',
    ['text' => 'for completing all requirements of'],
    $now
);
// Course.
add_el(
    $pid, $s++, 'Course Name', 'coursename', cx(240), 120, 240, 14,
    'Playfair Display', 18, 'bold', 'normal', '#6b1520', 'C', [], $now
);
// Grade.
add_el(
    $pid,
    $s++,
    'Grade Label',
    'text',
    cx(80),
    142,
    80,
    7,
    'Merriweather',
    10,
    'normal',
    'normal',
    '#888888',
    'C',
    ['text' => 'with a grade of'],
    $now
);
add_el($pid, $s++, 'Grade', 'grade', cx(50), 152, 50, 10, 'Playfair Display', 16, 'bold', 'normal', '#2d6a4f', 'C', [], $now);
// Date left.
add_el(
    $pid,
    $s++,
    'Date',
    'date',
    25,
    178,
    80,
    8,
    'Merriweather',
    11,
    'normal',
    'normal',
    '#555555',
    'C',
    ['dateformat' => 'F j, Y'],
    $now
);
// Teacher right.
add_el($pid, $s++, 'Teacher', 'teachername', 195, 178, 80, 8, 'Merriweather', 11, 'normal', 'normal', '#555555', 'C', [], $now);
// Code.
add_el($pid, $s++, 'Code', 'code', cx(70), 194, 70, 5, 'Merriweather', 7, 'normal', 'normal', '#bbbbbb', 'C', [], $now);
echo "  5. Classic Diploma\n";

// 6. Fresh Green - Modern, vibrant, with verification focus.
// Green accents, QR code prominent, digital-native feel.
[$tid, $pid] = create_template_page('Fresh Green', $systemctx->id, $now);
$s = 1;
// Border.
add_el(
    $pid,
    $s++,
    'Border',
    'border',
    cx(287),
    cy(200),
    287,
    200,
    'Roboto',
    12,
    'normal',
    'normal',
    '#047857',
    'C',
    ['borderwidth' => 2, 'bordercolor' => '#047857', 'borderstyle' => 'solid'],
    $now
);
// Tag.
add_el(
    $pid,
    $s++,
    'Tag',
    'text',
    18,
    12,
    120,
    6,
    'Montserrat',
    7,
    'bold',
    'normal',
    '#047857',
    'L',
    ['text' => 'VERIFIED CERTIFICATE'],
    $now
);
// Title.
add_el(
    $pid,
    $s++,
    'Title',
    'text',
    cx(260),
    26,
    260,
    18,
    'Poppins',
    26,
    'bold',
    'normal',
    '#111827',
    'C',
    ['text' => 'Certificate of Participation'],
    $now
);
// Certifies.
add_el(
    $pid,
    $s++,
    'Certifies',
    'text',
    cx(200),
    52,
    200,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#6b7280',
    'C',
    ['text' => 'This certifies that'],
    $now
);
// Student.
add_el($pid, $s++, 'Student Name', 'studentname', cx(250), 66, 250, 18, 'Poppins', 28, 'bold', 'normal', '#111827', 'C', [], $now);
// Participated.
add_el(
    $pid,
    $s++,
    'Participated',
    'text',
    cx(200),
    92,
    200,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#6b7280',
    'C',
    ['text' => 'has actively participated in'],
    $now
);
// Course.
add_el($pid, $s++, 'Course Name', 'coursename', cx(240), 106, 240, 14, 'Poppins', 18, 'bold', 'normal', '#047857', 'C', [], $now);
// Category.
add_el($pid, $s++, 'Category', 'categoryname', cx(180), 126, 180, 8, 'Lato', 10, 'normal', 'italic', '#9ca3af', 'C', [], $now);
// Date left.
add_el(
    $pid,
    $s++,
    'Date Label',
    'text',
    25,
    152,
    50,
    6,
    'Montserrat',
    7,
    'bold',
    'normal',
    '#9ca3af',
    'L',
    ['text' => 'DATE'],
    $now
);
add_el(
    $pid,
    $s++,
    'Date',
    'date',
    25,
    160,
    80,
    8,
    'Lato',
    11,
    'normal',
    'normal',
    '#374151',
    'L',
    ['dateformat' => 'F j, Y'],
    $now
);
// Teacher right.
add_el(
    $pid,
    $s++,
    'Instructor Label',
    'text',
    180,
    152,
    50,
    6,
    'Montserrat',
    7,
    'bold',
    'normal',
    '#9ca3af',
    'L',
    ['text' => 'INSTRUCTOR'],
    $now
);
add_el($pid, $s++, 'Teacher', 'teachername', 180, 160, 80, 8, 'Lato', 11, 'normal', 'normal', '#374151', 'L', [], $now);
// QR - prominent bottom-right.
add_el($pid, $s++, 'QR', 'qrcode', 254, 152, 26, 26, 'Roboto', 12, 'normal', 'normal', '#047857', 'C', [], $now);
// Code.
add_el($pid, $s++, 'Code', 'code', cx(80), 192, 80, 5, 'Montserrat', 7, 'normal', 'normal', '#d1d5db', 'C', [], $now);
echo "  6. Fresh Green\n";

echo "\nDone! 6 demo templates created.\n";
