<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Transformer utility for agents without OIDC identity.
 *
 * @package   logstore_xapi
 * @copyright 2026 SOM
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace src\transformer\utils;

use logstore_xapi\local\oidc_actor_resolver;

/**
 * Remove agents without OIDC identity from statements.
 *
 * context.instructor is optional, so a teacher without OIDC identity (such as
 * a local admin grading a student) is omitted and the student's statement is
 * kept. A statement with such an agent anywhere else (actor, object, group
 * member) cannot be sent without making up an identifier, so it is dropped.
 *
 * @param array $statements Generated statements.
 * @return array Statements that can be sent.
 */
function drop_nonoidc_agents(array $statements) {
    $hasmarker = function ($value) use (&$hasmarker) {
        if (!is_array($value)) {
            return false;
        }
        if (!empty($value[oidc_actor_resolver::NONOIDC_MARKER])) {
            return true;
        }
        foreach ($value as $item) {
            if ($hasmarker($item)) {
                return true;
            }
        }
        return false;
    };

    $kept = [];
    foreach ($statements as $statement) {
        if (isset($statement['context']['instructor']) && $hasmarker($statement['context']['instructor'])) {
            unset($statement['context']['instructor']);
        }
        if (!$hasmarker($statement)) {
            $kept[] = $statement;
        }
    }
    return $kept;
}
