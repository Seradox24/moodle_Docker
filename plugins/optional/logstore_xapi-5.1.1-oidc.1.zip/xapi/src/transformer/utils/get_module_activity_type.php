<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Transformer utility for retrieving course module activity types.
 *
 * @package   logstore_xapi
 * @copyright Milt Reder <milt@yetanalytics.com>
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace src\transformer\utils;

/**
 * Return the mapping of modules to activity types.
 *
 * @return array
 */
function get_module_activity_type_mapping() {
    return [
        'assign'          => 'https://xapi.edlm/profiles/edlm-lms/concepts/activity-types/assignment',
        'bigbluebuttonbn' => 'http://adlnet.gov/expapi/activities/meeting',
        'book'            => 'http://id.tincanapi.com/activitytype/book',
        'chat'            => 'http://id.tincanapi.com/activitytype/chat-channel',
        'choice'          => 'http://adlnet.gov/expapi/activities/cmi.interaction',
        'data'            => 'http://xapi.org.au/contentprofile/activitytype/database',
        'facetoface'      => 'https://w3id.org/xapi/acrossx/activities/face-to-face-discussion',
        'feedback'        => 'https://xapi.edlm/profiles/edlm-lms/concepts/activity-types/feedback',
        'folder'          => 'http://activitystrea.ms/collection',
        'forum'           => 'https://xapi.edlm/profiles/edlm-lms/concepts/activity-types/forum',
        'glossary'        => 'https://xapi.edlm/profiles/edlm-lms/concepts/activity-types/glossary',
        'h5pactivity'     => 'http://adlnet.gov/expapi/activities/media',
        'imscp'           => 'https://w3id.org/xapi/cmi5/activitytype/course',
        'label'           => 'https://w3id.org/xapi/acrossx/activities/webpage',
        'lesson'          => 'http://adlnet.gov/expapi/activities/lesson',
        'lti'             => 'http://adlnet.gov/expapi/activities/media',
        'page'            => 'https://w3id.org/xapi/acrossx/activities/page',
        'quiz'            => 'http://adlnet.gov/expapi/activities/assessment',
        'resource'        => 'http://id.tincanapi.com/activitytype/resource',
        'scorm'           => 'http://adlnet.gov/expapi/activities/module',
        'url'             => 'http://adlnet.gov/expapi/activities/link',
        'wiki'            => 'https://xapi.edlm/profiles/edlm-lms/concepts/activity-types/wiki',
        'workshop'        => 'https://xapi.edlm/profiles/edlm-lms/concepts/activity-types/workshop',
        'questionnaire'   => 'http://id.tincanapi.com/activitytype/survey',
        'survey'          => 'http://id.tincanapi.com/activitytype/survey',
    ];
}

/**
 * Return an activity type or default for a given module name.
 *
 * @param string $modulename The name of a moodle course module.
 * @return string
 */
function get_module_activity_type(string $modulename) {
    $moduleuris = get_module_activity_type_mapping();

    if (array_key_exists($modulename, $moduleuris)) {
        return $moduleuris[$modulename];
    } else {
        return 'http://id.tincanapi.com/activitytype/lms/module';
    }
}
