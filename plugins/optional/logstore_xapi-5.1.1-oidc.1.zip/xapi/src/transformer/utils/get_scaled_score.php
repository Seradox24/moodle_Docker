<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Transformer utility for determining the scaled score.
 *
 * @package   logstore_xapi
 * @copyright Jerret Fowler <jerrett.fowler@gmail.com>
 *            Ryan Smith <https://www.linkedin.com/in/ryan-smith-uk/>
 *            David Pesce <david.pesce@exputo.com>
 *            Milt Reder <milt@yetanalytics.com>
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace src\transformer\utils;

/**
 * Transformer utility for determining the scaled score.
 *
 * With a non-negative minimum the scaled score is the proportion of the range
 * achieved (7.5 of 10 is 0.75), as consumers of xAPI expect. A negative
 * minimum keeps zero at zero: positive scores are relative to the maximum and
 * negative ones to the minimum, so the result stays within -1..1.
 *
 * @param float $rawscore The rawscore of the event.
 * @param float $minscore The minimum score of the event.
 * @param float $maxscore The maximum score fo the event.
 * @return float
 */
function get_scaled_score($rawscore, $minscore, $maxscore) {
    if ($maxscore == $minscore) {
        return 0;
    }
    if ($minscore >= 0) {
        $scaled = ($rawscore - $minscore) / ($maxscore - $minscore);
    } else if ($rawscore >= 0) {
        $scaled = $maxscore > 0 ? $rawscore / $maxscore : 0;
    } else {
        $scaled = -$rawscore / $minscore;
    }
    return round(max(-1, min(1, $scaled)), 6);
}
