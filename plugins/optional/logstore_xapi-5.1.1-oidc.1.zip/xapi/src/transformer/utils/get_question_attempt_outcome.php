<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Transformer utility for the outcome of a question attempt.
 *
 * @package   logstore_xapi
 * @copyright 2026 SOM
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace src\transformer\utils;

/**
 * Outcome of a question attempt as graded by Moodle.
 *
 * Reads the attempt steps instead of the response summaries, which are
 * translated into the language of the user ("Verdadero", "Falso") and do not
 * reflect how Moodle matched the answer (case, wildcards, several answers).
 *
 * @param array $config The transformer config settings.
 * @param \stdClass $questionattempt The question attempt.
 * @return array ['success' => bool|null, 'answer' => string|null] where success
 *               is null while the attempt is not graded, and answer is the last
 *               submitted value of the "answer" field.
 */
function get_question_attempt_outcome(array $config, \stdClass $questionattempt) {
    $repo = $config['repo'];
    $steps = $repo->read_records(
        'question_attempt_steps',
        ['questionattemptid' => $questionattempt->id],
        'sequencenumber DESC'
    );

    $state = null;
    $answer = null;
    foreach ($steps as $step) {
        if ($state === null) {
            $state = $step->state;
        }
        if ($answer === null) {
            $data = $repo->read_records('question_attempt_step_data', ['attemptstepid' => $step->id, 'name' => 'answer']);
            if ($data) {
                $answer = (string) reset($data)->value;
            }
        }
    }

    $graded = [
        'gradedright' => true,
        'gradedwrong' => false,
        'gradedpartial' => false,
        'mangrright' => true,
        'mangrwrong' => false,
        'mangrpartial' => false,
    ];
    return [
        'success' => $graded[$state] ?? null,
        'answer' => $answer,
    ];
}
