<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Apply default values to statements.
 *
 * @package   logstore_xapi
 * @copyright Milt Reder <milt@yetanalytics.com>
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace src\transformer\utils;

/**
 * Given the config, source event and statements, apply default values.
 *
 * With OIDC actor identity no registration is made up from the cron session,
 * and statement ids are derived from a seed kept with the queued event, so a
 * resend after an uncertain delivery reuses them and the LRS does not store a
 * duplicate. Historical imports use the standard log id, which is exact there.
 *
 * @param array $config configuration array.
 * @param \stdClass $event original event
 * @param array $statements generated xAPI statements.
 * @return array
 */
function apply_statement_defaults(array $config, \stdClass $event, array $statements) {
    $oidc = !empty($config['actor_resolver']);
    $seed = null;
    if (!empty($event->statementseed)) {
        $seed = 'seed|' . $event->statementseed;
    } else if (defined('XAPI_IMPORT_TYPE_HISTORIC') && ($event->type ?? null) == XAPI_IMPORT_TYPE_HISTORIC
            && !empty($event->logstorestandardlogid)) {
        $seed = 'log|' . $config['app_url'] . '|' . $event->logstorestandardlogid;
    }

    return array_map(function ($statement, $index) use ($config, $event, $oidc, $seed) {
        $defaultstatement = [
            'context' => [
                'platform' => $config['context_platform'] ?? 'Moodle',
            ],
            'timestamp' => get_event_timestamp($event),
        ];
        // Application of origin, shared with the other apps of the ecosystem.
        // It is metadata declared by the sender, not a verified identity.
        if (!empty($config['context_client_id']) && !empty($config['context_client_id_extension'])) {
            $defaultstatement['context']['extensions'][$config['context_client_id_extension']] =
                $config['context_client_id'];
        }
        if (!$oidc && ($statement['actor']['account']['name'] ?? null) !== 'anonymous') {
            $defaultstatement['context']['registration'] = stringToUuidV5($config['session_id']);
        } else if ($seed !== null) {
            $defaultstatement['id'] = stringToUuidV5('logstore_xapi|' . $seed . '|' . $index);
        }
        // Merge event output into defaults.
        return deep_merge_arrays($defaultstatement, $statement);
    }, $statements, array_keys($statements));
}
