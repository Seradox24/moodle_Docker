<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Transformer handler.
 *
 * @package   logstore_xapi
 * @copyright Jerret Fowler <jerrett.fowler@gmail.com>
 *            Ryan Smith <https://www.linkedin.com/in/ryan-smith-uk/>
 *            David Pesce <david.pesce@exputo.com>
 *            Milt Reder <milt@yetanalytics.com>
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace src\transformer;

use src\transformer\utils;

/**
 * Generic handler for the transformer.
 *
 * @param array $config The transformer config settings.
 * @param array $events The event to be transformed.
 * @return array
 */
function handler(array $config, array $events) {

    $eventfunctionmap = get_event_function_map();
    $transformedevents = array_map(function ($event) use ($config, $eventfunctionmap) {
        $eventobj = (object) $event;
        try {
            if (!empty($config['actor_resolver'])) {
                $config['actor_resolver']->begin_event($eventobj);
            }
            $eventname = $eventobj->eventname;
            // Feedback already substitutes an anonymous actor. Other flagged events may disclose a protected user.
            $safeanonymous = $eventname === '\\mod_feedback\\event\\response_submitted';
            if (isset($eventfunctionmap[$eventname]) && (empty($eventobj->anonymous) || $safeanonymous)) {
                $eventfunctionname = $eventfunctionmap[$eventname];
                $eventfunction = '\src\transformer\events\\' . $eventfunctionname;
                $eventconfig = array_merge([
                    'event_function' => $eventfunction,
                ], $config);
                $eventstatements = utils\apply_statement_defaults(
                    $eventconfig,
                    $eventobj,
                    $eventfunction($eventconfig, $eventobj)
                );
                if (!empty($config['actor_resolver'])) {
                    $eventstatements = utils\drop_nonoidc_agents($eventstatements);
                }
            } else {
                $eventstatements = [];
            }

            // Returns successfully transformed event with its statements.
            $transformedevent = [
                'event' => $eventobj,
                'statements' => $eventstatements,
                'transformed' => true,
            ];
            return $transformedevent;
        } catch (\Throwable $e) {
            if ($e instanceof \logstore_xapi\local\actor_identity_exception && $e->skip) {
                // Agent without OIDC identity under the skip policy: nothing is sent.
                return [
                    'event' => $eventobj,
                    'statements' => [],
                    'transformed' => true,
                ];
            }
            $logerror = $config['log_error'];
            $id = property_exists($eventobj, 'id') ? $eventobj->id : ' (id not present on event object) ';
            $errormessage = "Failed transform for event id #" . $id . ": " . $e->getMessage();
            $logerror($errormessage);
            $logerror($e->getTraceAsString());
            $eventobj->response = json_encode(['transfromerror' => $errormessage]);

            // Returns unsuccessfully transformed event without statements.
            $transformedevent = [
                'event' => $eventobj,
                'statements' => [],
                'transformed' => false,
            ];
            return $transformedevent;
        }
    }, $events);
    return $transformedevents;
}
