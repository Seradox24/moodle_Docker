<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace logstore_xapi\admin;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/adminlib.php');

/**
 * Admin setting: expected OIDC issuer.
 *
 * The value is compared byte for byte with the iss claim, so it is stored as
 * typed and only rejected when it cannot be an issuer: OpenID Connect issuers
 * are http(s) URLs without query, fragment, credentials or whitespace.
 *
 * @package   logstore_xapi
 * @copyright 2026 SOM
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class setting_oidc_issuer extends \admin_setting_configtext {
    /**
     * Constructor.
     *
     * @param string $name Setting name.
     * @param string $visiblename Label.
     * @param string $description Description.
     */
    public function __construct($name, $visiblename, $description) {
        parent::__construct($name, $visiblename, $description, '', PARAM_RAW_TRIMMED, 80);
    }

    /**
     * Validate the issuer.
     *
     * @param string $data Submitted value.
     * @return true|string True when valid, otherwise the error message.
     */
    public function validate($data) {
        if ($data === '') {
            return true;
        }
        return self::is_valid_issuer($data) ? true : get_string('oidcissuer_invalid', 'logstore_xapi');
    }

    /**
     * Whether a value can be an OpenID Connect issuer.
     *
     * @param string $issuer Candidate issuer.
     * @return bool
     */
    public static function is_valid_issuer(string $issuer): bool {
        if (strlen($issuer) > 255 || preg_match('/\s/', $issuer)) {
            return false;
        }
        $parts = parse_url($issuer);
        return is_array($parts)
            && in_array($parts['scheme'] ?? '', ['https', 'http'], true)
            && !empty($parts['host'])
            && !isset($parts['user']) && !isset($parts['pass'])
            && strpos($issuer, '?') === false && strpos($issuer, '#') === false;
    }
}
