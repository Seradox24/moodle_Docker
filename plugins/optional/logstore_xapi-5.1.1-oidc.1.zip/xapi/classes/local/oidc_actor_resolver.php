<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace logstore_xapi\local;

/**
 * Builds xAPI accounts from the OIDC identity (iss + sub) linked by auth_oidc.
 *
 * The account is always homePage = iss and name = sub, copied byte for byte.
 * Email, username, idnumber and Moodle ids are never used as a fallback: an
 * agent that cannot be identified raises {@see actor_identity_exception}.
 *
 * The identity comes from the rows auth_oidc keeps in auth_oidc_token. The ID
 * token there was received by auth_oidc directly from the token endpoint, so
 * its claims are read without a network call. They are trusted only when iss
 * equals the configured issuer and sub equals the oidcuniqid auth_oidc bound
 * the user to. Tokens are never copied anywhere.
 *
 * @package   logstore_xapi
 * @copyright 2026 SOM
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class oidc_actor_resolver {
    /** @var string Users without an OIDC identity are not sent. */
    const NONOIDC_SKIP = 'skip';

    /** @var string Users without an OIDC identity go to the failed log. */
    const NONOIDC_FAIL = 'fail';

    /** @var string Historical imports without captured identity use the current association. */
    const HISTORICAL_CURRENT = 'current';

    /** @var string Historical imports without captured identity go to the failed log. */
    const HISTORICAL_FAIL = 'fail';

    /** @var string Key marking an agent without OIDC identity under the skip policy. */
    const NONOIDC_MARKER = '__logstore_xapi_nonoidc';

    /** @var int Size of the char columns holding the snapshot. */
    const MAX_LENGTH = 255;

    /** @var \moodle_database */
    protected $db;

    /** @var string Exact issuer expected in the ID token. */
    protected $issuer;

    /** @var string One of the NONOIDC_* constants. */
    protected $nonoidcpolicy;

    /** @var string Client id that must be in the aud claim; empty to skip the check. */
    protected $audience;

    /** @var string One of the HISTORICAL_* constants. */
    protected $historicalpolicy;

    /** @var bool Whether the current event is a historical import that must not use current associations. */
    protected $strict = false;

    /** @var array userid => [issuer, subject] or actor_identity_exception. */
    protected $cache = [];

    /** @var bool|null Whether auth_oidc is installed. */
    protected $hastokentable = null;

    /** @var array Identities captured with the current event: userid => [issuer, subject]. */
    protected $snapshot = [];

    /** @var string[][] Event columns holding captured identities: user column => [issuer, subject]. */
    const SNAPSHOT_COLUMNS = [
        'userid' => ['actorissuer', 'actorsubject'],
        'relateduserid' => ['relatedissuer', 'relatedsubject'],
    ];

    /**
     * Constructor.
     *
     * @param \moodle_database $db Database.
     * @param string $issuer Exact expected issuer, e.g. https://sso.example/realms/educacion.
     * @param string $nonoidcpolicy What to do with agents that have no OIDC identity.
     * @param string $audience Client id of Moodle in the OpenID provider (auth_oidc clientid).
     * @param string $historicalpolicy What to do with historical imports, which have no captured identity.
     */
    public function __construct(\moodle_database $db, string $issuer, string $nonoidcpolicy = self::NONOIDC_SKIP,
            string $audience = '', string $historicalpolicy = self::HISTORICAL_CURRENT) {
        $this->db = $db;
        $this->issuer = $issuer;
        $this->nonoidcpolicy = $nonoidcpolicy === self::NONOIDC_FAIL ? self::NONOIDC_FAIL : self::NONOIDC_SKIP;
        $this->audience = $audience;
        $this->historicalpolicy = $historicalpolicy === self::HISTORICAL_FAIL ? self::HISTORICAL_FAIL : self::HISTORICAL_CURRENT;
    }

    /**
     * Resolve the identity of a user while the event is being recorded.
     *
     * Used in background mode so the queued event keeps the identity the user
     * had when it happened, even if the account is unlinked or deleted before
     * cron sends it. Never throws: without an identity the event is resolved
     * again (and fails closed) when it is transformed.
     *
     * @param int $userid Moodle user id.
     * @return array|null ['issuer' => string, 'subject' => string]
     */
    public function capture(int $userid): ?array {
        if ($userid <= 0) {
            return null;
        }
        try {
            [$issuer, $subject] = $this->lookup($userid);
            return ['issuer' => $issuer, 'subject' => $subject];
        } catch (actor_identity_exception $e) {
            return null;
        }
    }

    /**
     * Capture the identities of the users of an event and its statement id seed.
     *
     * Covers the user who triggered the event and the related user, who is
     * the actor of events such as a grade given by a teacher.
     *
     * @param \stdClass $event Event about to be queued.
     * @return void
     */
    public function capture_event(\stdClass $event): void {
        // Seed of the statement ids, kept through retries to avoid duplicates in the LRS.
        if (empty($event->statementseed)) {
            $event->statementseed = \core\uuid::generate();
        }
        foreach (self::SNAPSHOT_COLUMNS as $usercolumn => [$issuercolumn, $subjectcolumn]) {
            $identity = $this->capture((int) ($event->$usercolumn ?? 0));
            $event->$issuercolumn = $identity['issuer'] ?? null;
            $event->$subjectcolumn = $identity['subject'] ?? null;
        }
    }

    /**
     * Use the identities captured with an event for that event's users.
     *
     * Must be called before transforming each event, so a snapshot never leaks
     * into another event.
     *
     * @param \stdClass $event Event row, possibly with captured identities.
     * @return void
     */
    public function begin_event(\stdClass $event): void {
        $this->snapshot = [];
        $this->strict = $this->historicalpolicy === self::HISTORICAL_FAIL
            && defined('XAPI_IMPORT_TYPE_HISTORIC') && ($event->type ?? null) == XAPI_IMPORT_TYPE_HISTORIC;
        foreach (self::SNAPSHOT_COLUMNS as $usercolumn => [$issuercolumn, $subjectcolumn]) {
            if (!empty($event->$usercolumn) && !empty($event->$issuercolumn) && !empty($event->$subjectcolumn)) {
                $this->snapshot[(int) $event->$usercolumn] = [(string) $event->$issuercolumn, (string) $event->$subjectcolumn];
            }
        }
    }

    /**
     * The xAPI account of a user.
     *
     * @param \stdClass $user Moodle user record (needs id and auth).
     * @return array ['homePage' => iss, 'name' => sub]
     * @throws actor_identity_exception
     */
    public function get_account(\stdClass $user): array {
        $userid = (int) ($user->id ?? 0);
        if (isset($this->snapshot[$userid])) {
            return ['homePage' => $this->snapshot[$userid][0], 'name' => $this->snapshot[$userid][1]];
        }
        [$issuer, $subject] = $this->lookup($userid, $user->auth ?? null);
        if ($this->strict) {
            throw new actor_identity_exception(
                "OIDC actor identity: historical event of user {$userid} has no identity captured when it happened.");
        }
        return ['homePage' => $issuer, 'name' => $subject];
    }

    /**
     * Resolve and cache the identity of a user.
     *
     * @param int $userid Moodle user id.
     * @param string|null $auth Auth plugin of the user, when already known.
     * @return array [issuer, subject]
     * @throws actor_identity_exception
     */
    protected function lookup(int $userid, ?string $auth = null): array {
        if (!array_key_exists($userid, $this->cache)) {
            try {
                $this->cache[$userid] = $this->resolve($userid, $auth);
            } catch (actor_identity_exception $e) {
                $this->cache[$userid] = $e;
            }
        }
        if ($this->cache[$userid] instanceof actor_identity_exception) {
            throw $this->cache[$userid];
        }
        return $this->cache[$userid];
    }

    /**
     * Resolve the identity of a user from auth_oidc.
     *
     * @param int $userid Moodle user id.
     * @param string|null $auth Auth plugin of the user, when already known.
     * @return array [issuer, subject]
     * @throws actor_identity_exception
     */
    protected function resolve(int $userid, ?string $auth): array {
        if ($userid <= 0) {
            throw $this->no_identity();
        }
        if ($this->issuer === '') {
            throw new actor_identity_exception('OIDC actor identity: the expected issuer is not configured.');
        }

        $identities = [];
        $rows = $this->get_token_rows($userid);
        foreach ($rows as $row) {
            if ((string) $row->idtoken === '') {
                // Rows for other resources may carry no ID token: they prove nothing.
                continue;
            }
            $claims = self::decode_claims((string) $row->idtoken);
            $issuer = $claims['iss'] ?? null;
            $subject = $claims['sub'] ?? null;
            if (!$this->audience_matches($claims)) {
                throw new actor_identity_exception("OIDC actor identity: user {$userid} has an ID token for another client.");
            }
            if (!is_string($issuer) || $issuer !== $this->issuer) {
                throw new actor_identity_exception("OIDC actor identity: user {$userid} has an ID token from another issuer.");
            }
            if (!is_string($subject) || $subject === '' || $subject !== (string) $row->oidcuniqid
                    || strlen($subject) > self::MAX_LENGTH || strlen($issuer) > self::MAX_LENGTH) {
                throw new actor_identity_exception("OIDC actor identity: user {$userid} has no valid subject.");
            }
            $identities[$issuer . "\n" . $subject] = [$issuer, $subject];
        }

        if (count($identities) > 1) {
            throw new actor_identity_exception("OIDC actor identity: user {$userid} is linked to more than one subject.");
        }
        if ($identities) {
            return reset($identities);
        }

        if ($auth === null) {
            $auth = $this->db->get_field('user', 'auth', ['id' => $userid]);
        }
        if ($auth === 'oidc' || $rows) {
            throw new actor_identity_exception("OIDC actor identity: user {$userid} has no auth_oidc association.");
        }
        throw $this->no_identity();
    }

    /**
     * Whether the ID token was issued to Moodle's client.
     *
     * @param array $claims ID token claims.
     * @return bool
     */
    protected function audience_matches(array $claims): bool {
        if ($this->audience === '') {
            return true;
        }
        $aud = $claims['aud'] ?? null;
        $audiences = is_string($aud) ? [$aud] : (is_array($aud) ? $aud : []);
        if (!in_array($this->audience, $audiences, true)) {
            return false;
        }
        // With several audiences the token must have been requested by Moodle.
        $azp = $claims['azp'] ?? null;
        return count($audiences) === 1 && ($azp === null || $azp === $this->audience)
            || $azp === $this->audience;
    }

    /**
     * The exception for users that do not sign in through OIDC.
     *
     * @return actor_identity_exception
     */
    protected function no_identity(): actor_identity_exception {
        return new actor_identity_exception(
            'OIDC actor identity: the event involves a user without an OIDC identity.',
            $this->nonoidcpolicy === self::NONOIDC_SKIP
        );
    }

    /**
     * The auth_oidc rows of a user.
     *
     * @param int $userid Moodle user id.
     * @return array Records with oidcuniqid and idtoken.
     */
    protected function get_token_rows(int $userid): array {
        if ($this->hastokentable === null) {
            $this->hastokentable = $this->db->get_manager()->table_exists('auth_oidc_token');
        }
        if (!$this->hastokentable) {
            return [];
        }
        return $this->db->get_records('auth_oidc_token', ['userid' => $userid], 'id', 'id, oidcuniqid, idtoken');
    }

    /**
     * Read the claims of a JWT without keeping the token.
     *
     * @param string $jwt Compact serialised JWT.
     * @return array Claims, or an empty array when malformed.
     */
    public static function decode_claims(string $jwt): array {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3 || !preg_match('/^[A-Za-z0-9_-]+$/D', $parts[1])) {
            return [];
        }
        $json = base64_decode(strtr($parts[1], '-_', '+/'), true);
        $claims = $json === false ? null : json_decode($json, true);
        return is_array($claims) ? $claims : [];
    }
}
