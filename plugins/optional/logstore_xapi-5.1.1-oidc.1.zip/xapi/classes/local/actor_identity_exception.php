<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace logstore_xapi\local;

/**
 * Raised when an agent cannot be identified by its OIDC issuer and subject.
 *
 * When {@see self::$skip} is true the event is intentionally not sent (a user
 * without an OIDC identity under the "skip" policy). Otherwise the event fails
 * closed and is kept in the failed log so it can be resent once fixed.
 *
 * @package   logstore_xapi
 * @copyright 2026 SOM
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class actor_identity_exception extends \Exception {
    /** @var bool True when the event must be dropped instead of failed. */
    public bool $skip;

    /**
     * Constructor.
     *
     * @param string $message Diagnostic without personal data.
     * @param bool $skip Whether the event should be skipped silently.
     */
    public function __construct(string $message, bool $skip = false) {
        parent::__construct($message);
        $this->skip = $skip;
    }
}
